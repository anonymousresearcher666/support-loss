# Command-line reference

Argument declarations extracted from the released source. Defaults are source
expressions; function-level validation and input schemas remain in each script.

## scripts/aggregate_paper_campaigns.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; default=Path('results_cluster') |
| `--output` | type=Path; default=Path('paper_aggregates/main') |

## scripts/experiments/aggregate_published_method_placement_probe.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--expected-cells` | type=int; default=6 |
| `--n-boot` | type=int; default=10000 |
| `--seed` | type=int; default=19092026 |

## scripts/experiments/aggregate_published_method_placement_probe_v2.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--expected-cells` | type=int; default=6 |
| `--n-boot` | type=int; default=10000 |
| `--seed` | type=int; default=19092026 |

## scripts/experiments/aggregate_published_method_rank_audit.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |

## scripts/experiments/aggregate_supportloss_negative_exposure.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |

## scripts/experiments/aggregate_supportloss_specificity.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |

## scripts/experiments/aggregate_unrelated_placement_probe.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--n-boot` | type=int; default=10000 |
| `--seed` | type=int; default=21092026 |

## scripts/experiments/aggregate_w5_mean_tie.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--bootstrap-reps` | type=int; default=10000 |

## scripts/experiments/aggregate_w5_three_reference_null.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--expected-cells` | type=int; default=12 |
| `--n-boot` | type=int; default=10000 |
| `--seed` | type=int; default=19092026 |

## scripts/experiments/aggregate_w7_stronger_training_grid.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--expected-cells` | type=int; default=6 |
| `--n-boot` | type=int; default=10000 |
| `--seed` | type=int; default=22092026 |

## scripts/experiments/analyze_b3_rfpc_per_setting.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |

## scripts/experiments/analyze_directional_followup.py

| Argument | Declaration |
| --- | --- |
| `--cohort` | type=Path; required=True |
| `--controls` | type=Path; required=True |
| `--out` | type=Path; required=True |

## scripts/experiments/analyze_remaining_review_controls.py

| Argument | Declaration |
| --- | --- |
| `--cohort` | type=Path; required=True |
| `--controls` | type=Path; required=True |
| `--out` | type=Path; required=True |

## scripts/experiments/analyze_supportloss_request_auc.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |

## scripts/experiments/analyze_tracka_operational_curve.py

| Argument | Declaration |
| --- | --- |
| `--input` | required=True |
| `--out` | required=True |
| `--taus` | type=float; default=[0.0005, 0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1, 1.0] |

## scripts/experiments/analyze_transe_threshold_dump.py

| Argument | Declaration |
| --- | --- |
| `dump` | — |
| `--out` | default='transe_threshold_metrics_20cells.csv' |

## scripts/experiments/audit_norm_match_oracle_v2.py

| Argument | Declaration |
| --- | --- |
| `--data-root` | type=Path; required=True |
| `--cohort` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--dataset` | choices=['FB15K-237', 'CoDEx-M']; required=True |
| `--seed` | type=int; choices=[17, 29, 43]; required=True |

## scripts/experiments/audit_w7_negative_sampling.py

| Argument | Declaration |
| --- | --- |
| `--data-root` | type=Path; default=Path('data') |
| `--out` | type=Path; default=Path('results_cluster/review/w7_negative_sampling_audit') |

## scripts/experiments/bootstrap_rank_audit_ci.py

| Argument | Declaration |
| --- | --- |
| `--root` | action='append'; default=[] |
| `--file` | action='append'; default=[] |
| `--candidate` | action='append'; default=[] |
| `--n-boot` | type=int; default=10000 |
| `--alpha` | type=float; default=0.05 |
| `--seed` | type=int; default=19092026 |
| `--discover-only` | action='store_true' |
| `--out` | type=Path; required=True |

## scripts/experiments/bootstrap_w5_mean_tie_query_ci.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; action='append'; required=True |
| `--out` | type=Path; required=True |
| `--n-boot` | type=int; default=10000 |
| `--alpha` | type=float; default=0.05 |
| `--seed` | type=int; default=19092026 |
| `--expected-cells` | type=int; default=12 |

## scripts/experiments/bootstrap_w5_primary_rank_ci.py

| Argument | Declaration |
| --- | --- |
| `--null-root` | type=Path; required=True |
| `--rank-root` | action='append'; required=True |
| `--out` | type=Path; required=True |
| `--n-boot` | type=int; default=10000 |
| `--alpha` | type=float; default=0.05 |
| `--seed` | type=int; default=19092026 |
| `--summary-tol` | type=float; default=0.0001 |

## scripts/experiments/check_family_competitor_smoke.py

| Argument | Declaration |
| --- | --- |
| `--input` | required=True |

## scripts/experiments/collect_common_reset_full.py

| Argument | Declaration |
| --- | --- |
| `--root` | required=True |
| `--out` | required=True |

## scripts/experiments/collect_entity_request_robustness.py

| Argument | Declaration |
| --- | --- |
| `--root` | required=True |
| `--out` | required=True |

## scripts/experiments/collect_expansion_ablation.py

| Argument | Declaration |
| --- | --- |
| `--root` | default='results_cluster/mechanism/expansion' |
| `--out` | default='results_cluster/mechanism/expansion_analysis' |

## scripts/experiments/collect_family_restart_competitors.py

| Argument | Declaration |
| --- | --- |
| `--input` | required=True |
| `--out` | required=True |

## scripts/experiments/collect_family_restart_extended.py

| Argument | Declaration |
| --- | --- |
| `--input` | required=True |
| `--out` | required=True |

## scripts/experiments/collect_graphdpo_matched_common.py

| Argument | Declaration |
| --- | --- |
| `--root` | required=True |
| `--out` | required=True |
| `--expected` | type=int; default=18 |

## scripts/experiments/collect_graphdpo_official_suite.py

| Argument | Declaration |
| --- | --- |
| `--new-root` | required=True |
| `--fb10-root` | required=True |
| `--fb-old-root` | required=True |
| `--out` | required=True |

## scripts/experiments/collect_graphdpo_shared_common.py

| Argument | Declaration |
| --- | --- |
| `--root` | required=True |
| `--out` | required=True |
| `--expected` | type=int; default=24 |

## scripts/experiments/collect_norm_match_oracle_v2.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |

## scripts/experiments/collect_random_fact_competitors.py

| Argument | Declaration |
| --- | --- |
| `--root` | required=True |
| `--out` | required=True |
| `--strict` | action='store_true' |

## scripts/experiments/collect_random_fact_reconstruction_mini.py

| Argument | Declaration |
| --- | --- |
| `--baseline-root` | required=True |
| `--reconstruction-root` | required=True |
| `--out` | required=True |
| `--fraction` | type=float; default=DEFAULT_FRACTION |
| `--datasets` | default=list(DATASETS) |

## scripts/experiments/collect_real_coupling.py

| Argument | Declaration |
| --- | --- |
| `--root` | default='results_cluster/mechanism/coupling_real' |
| `--out` | default='results_cluster/mechanism/coupling_analysis' |
| `--damping` | type=float; default=0.01 |

## scripts/experiments/collect_reference_budget_pilot.py

| Argument | Declaration |
| --- | --- |
| `--results` | type=Path; required=True |

## scripts/experiments/collect_reference_sensitivity.py

| Argument | Declaration |
| --- | --- |
| `--eval-root` | required=True |
| `--train-root` | required=True |
| `--out` | required=True |

## scripts/experiments/collect_review_statistics.py

| Argument | Declaration |
| --- | --- |
| `--matched-root` | required=True |
| `--ablation-root` | required=True |
| `--out` | required=True |

## scripts/experiments/collect_schema_ablation.py

| Argument | Declaration |
| --- | --- |
| `--root` | required=True |
| `--out` | required=True |
| `--expected-files` | type=int; default=36 |

## scripts/experiments/collect_sequential_deletion_stress.py

| Argument | Declaration |
| --- | --- |
| `--root` | required=True |
| `--out` | required=True |

## scripts/experiments/collect_shared_competitors.py

| Argument | Declaration |
| --- | --- |
| `--root` | required=True |
| `--out` | required=True |
| `--require-datasets` | default=['FB15K-237', 'WN18RR', 'CoDEx-L', 'YAGO3-10'] |

## scripts/experiments/collect_supportloss_cross_family.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--expected` | type=int; default=72 |

## scripts/experiments/collect_supportloss_request_validation.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |

## scripts/experiments/collect_supportloss_unified.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |

## scripts/experiments/diagnose_output_distinguishability.py

| Argument | Declaration |
| --- | --- |
| `--results` | type=Path; required=True |

## scripts/experiments/discover_rfpc_artifacts.py

| Argument | Declaration |
| --- | --- |
| `--root` | action='append'; type=Path; required=True |
| `--out` | type=Path |

## scripts/experiments/discover_w5_primary_artifacts.py

| Argument | Declaration |
| --- | --- |
| `--root` | action='append'; default=[] |
| `--max-bytes` | type=int; default=5000000 |
| `--out` | type=Path; required=True |

## scripts/experiments/evaluate_family_missing_full.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True; choices=['WN18RR', 'CoDEx-L', 'YAGO3-10'] |
| `--model` | required=True; choices=['distmult', 'complex'] |
| `--seed` | required=True; type=int |
| `--fractions` | type=float; default=[0.1, 0.2] |
| `--data-root` | default='data' |
| `--out` | required=True |
| `--device` | default='cuda:0' |
| `--threads` | type=int; default=1 |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--ref-epochs` | type=int; default=20 |
| `--local-epochs` | type=int; default=5 |
| `--batch-size` | type=int; default=4096 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--hops` | type=int; default=1 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |

## scripts/experiments/evaluate_family_restart.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--model` | required=True; choices=['distmult', 'complex'] |
| `--seed` | required=True; type=int |
| `--fractions` | type=float; default=[0.1, 0.2] |
| `--data-root` | default='data' |
| `--canonical-root` | default='results_cluster/policy128_entitylocal_v2' |
| `--out` | required=True |
| `--device` | default='cuda:0' |
| `--threads` | type=int; default=1 |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--local-epochs` | type=int; default=5 |
| `--batch-size` | type=int; default=4096 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--hops` | type=int; default=1 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |
| `--base-mrr-tol` | type=float; default=0.0005 |

## scripts/experiments/evaluate_family_restart_competitors.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--model` | required=True; choices=sorted(SUPPORTED) |
| `--seed` | required=True; type=int |
| `--fractions` | type=float; default=[0.1, 0.2] |
| `--data-root` | default='data' |
| `--canonical-root` | default='results_cluster/policy128_entitylocal_v2' |
| `--out` | required=True |
| `--device` | default='cuda:0' |
| `--threads` | type=int; default=1 |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--local-epochs` | type=int; default=5 |
| `--batch-size` | type=int; default=4096 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--hops` | type=int; default=1 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |
| `--base-mrr-tol` | type=float; default=0.0005 |
| `--sgu-clusters` | type=int; default=3 |
| `--sgu-lr` | type=float; default=1e-05 |
| `--graphdpo-epochs` | type=int; default=20 |
| `--graphdpo-batch-size` | type=int; default=1024 |
| `--graphdpo-lr` | type=float; default=0.001 |
| `--graphdpo-neg-ratio` | type=int; default=10 |
| `--graphdpo-margin` | type=float; default=8.0 |

## scripts/experiments/evaluate_family_restart_extended.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--model` | required=True; choices=sorted(SUPPORTED) |
| `--seed` | required=True; type=int |
| `--fractions` | type=float; default=[0.1, 0.2] |
| `--data-root` | default='data' |
| `--canonical-root` | default='results_cluster/policy128_entitylocal_v2' |
| `--out` | required=True |
| `--device` | default='cuda:0' |
| `--threads` | type=int; default=1 |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--local-epochs` | type=int; default=5 |
| `--batch-size` | type=int; default=4096 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--hops` | type=int; default=1 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |
| `--base-mrr-tol` | type=float; default=0.0005 |

## scripts/experiments/evaluate_graphdpo_common.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--policy` | default='entity'; choices=['entity', 'relation', 'random'] |
| `--fraction` | required=True; type=float |
| `--seed` | required=True; type=int |
| `--model` | default='transe' |
| `--data-root` | default='data' |
| `--request-dir` | required=True |
| `--schema` | action='append'; default=[] |
| `--external` | action='append'; default=[] |
| `--external-log` | action='append'; default=[] |
| `--device` | default='cuda:0' |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |
| `--out` | required=True |

## scripts/experiments/evaluate_graphdpo_common_support.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--policy` | default='entity'; choices=['entity', 'relation', 'random'] |
| `--fraction` | required=True; type=float |
| `--seed` | required=True; type=int |
| `--model` | default='transe' |
| `--data-root` | default='data' |
| `--request-dir` | required=True |
| `--schema` | action='append'; default=[] |
| `--schema-local-epochs` | action='append'; default=[] |
| `--external` | action='append'; default=[] |
| `--external-log` | action='append'; default=[] |
| `--device` | default='cuda:0' |
| `--threads` | type=int; default=1 |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--ref-epochs` | type=int; default=20 |
| `--batch-size` | type=int; default=4096 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--hops` | type=int; default=1 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |
| `--out` | required=True |

## scripts/experiments/evaluate_graphdpo_common_support_reset.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--policy` | default='entity'; choices=['entity'] |
| `--fraction` | required=True; type=float |
| `--seed` | required=True; type=int |
| `--model` | default='transe' |
| `--data-root` | default='data' |
| `--request-dir` | required=True |
| `--schema-csv` | required=True |
| `--schema-local-epochs` | type=int; default=5 |
| `--external` | action='append'; default=[] |
| `--external-log` | action='append'; default=[] |
| `--device` | default='cuda:0' |
| `--threads` | type=int; default=1 |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--ref-epochs` | type=int; default=20 |
| `--batch-size` | type=int; default=4096 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--hops` | type=int; default=1 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |
| `--out` | required=True |

## scripts/experiments/evaluate_graphdpo_shared_base.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--policy` | default='entity'; choices=['entity'] |
| `--fraction` | required=True; type=float |
| `--seed` | required=True; type=int |
| `--data-root` | default='data' |
| `--request-dir` | required=True |
| `--base-checkpoint` | required=True |
| `--exact-checkpoint` | required=True |
| `--exact-log` | — |
| `--external` | action='append'; default=[] |
| `--external-log` | action='append'; default=[] |
| `--device` | default='cuda:0' |
| `--threads` | type=int; default=1 |
| `--schema-local-epochs` | type=int; default=5 |
| `--schema-local-lr` | type=float; default=0.0001 |
| `--batch-size` | type=int; default=1024 |
| `--hops` | type=int; default=1 |
| `--margin` | type=float; default=8.0 |
| `--neg-ratio` | type=int; default=10 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |
| `--out` | required=True |

## scripts/experiments/evaluate_random_fact_reconstruction.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--fraction` | type=float; default=0.1 |
| `--seed` | type=int; required=True |
| `--data-root` | required=True |
| `--request-dir` | required=True |
| `--base-checkpoint` | required=True |
| `--exact-checkpoint` | required=True |
| `--device` | default='cuda:0' |
| `--threads` | type=int; default=1 |
| `--epochs` | type=int; default=3 |
| `--lr` | type=float; default=0.0001 |
| `--batch-size` | type=int; default=1024 |
| `--neg-ratio` | type=int; default=10 |
| `--margin` | type=float; default=8.0 |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--out` | required=True |

## scripts/experiments/evaluate_reference_sensitivity.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--fraction` | required=True; type=float |
| `--request-seed` | required=True; type=int |
| `--data-root` | default='data' |
| `--request-dir` | required=True |
| `--base-checkpoint` | required=True |
| `--reference` | action='append'; default=[] |
| `--external` | action='append'; default=[] |
| `--device` | default='cuda:0' |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |
| `--entity-chunk` | type=int; default=4096 |
| `--eval-batch` | type=int; default=16 |
| `--out` | required=True |

## scripts/experiments/export_graphdpo_request.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--policy` | choices=['entity', 'relation']; required=True |
| `--fraction` | type=float; required=True |
| `--seed` | type=int; required=True |
| `--data-root` | default='data' |
| `--out` | required=True |

## scripts/experiments/export_w5_request_memberships.py

| Argument | Declaration |
| --- | --- |
| `--data-root` | default='data' |
| `--null-root` | type=Path; default=Path('results_cluster/review/multi_delete_independent_null_v1') |
| `--out` | type=Path; default=Path('results_cluster/review/w5_request_memberships_v1') |

## scripts/experiments/inspect_w8_artifact_schema.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path |

## scripts/experiments/patch_graphdpo_eval_cap.py

| Argument | Declaration |
| --- | --- |
| `--graphdpo-root` | required=True |
| `--max-rankings` | type=int; default=2000 |

## scripts/experiments/render_reference_budget_tables.py

| Argument | Declaration |
| --- | --- |
| `--results` | type=Path; required=True |
| `--repo` | type=Path; default=Path('.') |

## scripts/experiments/render_remaining_review_results.py

| Argument | Declaration |
| --- | --- |
| `--results` | type=Path; required=True |
| `--paper` | type=Path; default=Path('paper') |

## scripts/experiments/rerun_w5_lowmid_null.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True; choices=['FB15K-237', 'CoDEx-M', 'NELL-995'] |
| `--seed` | required=True; type=int; choices=[17, 29, 43] |
| `--data-root` | required=True |
| `--historical-results-root` | required=True |
| `--out` | required=True |
| `--device` | default='cuda:0' |
| `--fraction` | type=float; default=0.1 |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--local-epochs` | type=int; default=5 |
| `--batch-size` | type=int; default=4096 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--max-queries` | type=int; default=1000 |

## scripts/experiments/rerun_w5_mean_tie.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True; choices=['FB15K-237', 'CoDEx-M', 'NELL-995'] |
| `--seed` | required=True; type=int; choices=[17, 29, 43] |
| `--data-root` | required=True |
| `--old-results-root` | required=True |
| `--out` | required=True |
| `--device` | default='cuda:0' |
| `--fraction` | type=float; default=0.1 |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--local-epochs` | type=int; default=5 |
| `--batch-size` | type=int; default=4096 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |

## scripts/experiments/run_entity_request_robustness.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--seed` | type=int; required=True |
| `--data-root` | default='data' |
| `--out` | required=True |
| `--device` | default='cuda:0' |
| `--fraction` | type=float; default=0.1 |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--local-epochs` | type=int; default=5 |
| `--batch-size` | type=int; default=4096 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |

## scripts/experiments/run_entity_reset_diagnostic.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | default='FB15K-237' |
| `--model` | default='transe' |
| `--policy` | default='entity'; choices=['entity'] |
| `--fraction` | type=float; default=0.05 |
| `--seed` | type=int; default=17 |
| `--alt-reset-seed` | type=int; default=100017 |
| `--data-root` | default='data' |
| `--device` | default='cuda:0' |
| `--threads` | type=int; default=1 |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--ref-epochs` | type=int; default=20 |
| `--local-epochs` | type=int; default=5 |
| `--batch-size` | type=int; default=4096 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--hops` | type=int; default=1 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |
| `--out` | required=True |

## scripts/experiments/run_expansion_ablation.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--model` | choices=['transe', 'complex', 'distmult']; required=True |
| `--policy` | choices=['entity', 'relation']; required=True |
| `--seed` | type=int; required=True |
| `--fraction` | type=float; required=True |
| `--data-root` | default='data' |
| `--out` | required=True |
| `--device` | default='cuda' |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--ref-epochs` | type=int; default=20 |
| `--local-epochs` | type=int; default=5 |
| `--batch-size` | type=int; default=32768 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--eval-queries` | type=int; default=500 |
| `--forget-eval-queries` | type=int; default=500 |
| `--entity-chunk` | type=int; default=8192 |
| `--curvature-sample` | type=int; default=1024 |
| `--damping` | type=float; default=0.01 |
| `--power-iters` | type=int; default=4 |
| `--cg-iters` | type=int; default=32 |

## scripts/experiments/run_nell_request_aware_reconstruction.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | default='NELL-995' |
| `--seed` | type=int; required=True |
| `--fraction` | type=float; default=0.1 |
| `--data-root` | default='data' |
| `--out` | required=True |
| `--device` | default='cuda:0' |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--local-epochs` | type=int; default=5 |
| `--repair-epochs` | type=int; default=3 |
| `--batch-size` | type=int; default=4096 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--repair-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |

## scripts/experiments/run_published_method_placement_probe.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | choices=['FB15K-237', 'CoDEx-M']; required=True |
| `--fraction` | type=float; default=0.1 |
| `--request-seed` | type=int; choices=[17, 29, 43]; required=True |
| `--data-root` | type=Path; required=True |
| `--request-dir` | type=Path; required=True |
| `--ref-a` | type=Path; required=True |
| `--ref-b` | type=Path; required=True |
| `--method` | action='append'; default=[] |
| `--device` | default='cuda:0' |
| `--max-pairs` | type=int; default=256 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--out` | type=Path; required=True |

## scripts/experiments/run_published_method_placement_probe_v2.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | choices=['FB15K-237', 'CoDEx-M']; required=True |
| `--fraction` | type=float; default=0.1 |
| `--request-seed` | type=int; choices=[17, 29, 43]; required=True |
| `--data-root` | type=Path; required=True |
| `--request-dir` | type=Path; required=True |
| `--ref-a` | type=Path; required=True |
| `--ref-b` | type=Path; required=True |
| `--method` | action='append'; default=[] |
| `--device` | default='cuda:0' |
| `--max-pairs` | type=int; default=256 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--out` | type=Path; required=True |

## scripts/experiments/run_published_method_rank_audit.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | choices=['FB15K-237', 'CoDEx-M']; required=True |
| `--fraction` | type=float; default=0.1 |
| `--request-seed` | type=int; choices=[17, 29, 43]; required=True |
| `--data-root` | type=Path; required=True |
| `--request-dir` | type=Path; required=True |
| `--ref-a` | type=Path; required=True |
| `--ref-b` | type=Path; required=True |
| `--method` | action='append'; default=[] |
| `--device` | default='cuda:0' |
| `--max-queries` | type=int; default=1000 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--out` | type=Path; required=True |

## scripts/experiments/run_real_coupling.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--model` | choices=['transe', 'distmult', 'complex']; required=True |
| `--policy` | choices=['entity', 'relation']; required=True |
| `--seed` | type=int; required=True |
| `--fraction` | type=float; required=True |
| `--data-root` | default='data' |
| `--out` | required=True |
| `--device` | default='cuda' |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--ref-epochs` | type=int; default=20 |
| `--local-epochs` | type=int; default=5 |
| `--batch-size` | type=int; default=32768 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |
| `--entity-chunk` | type=int; default=8192 |
| `--curvature-sample` | type=int; default=1024 |
| `--damping-grid` | type=float; default=[0.0001, 0.001, 0.01, 0.1, 1.0] |
| `--power-iters` | type=int; default=4 |
| `--cg-iters` | type=int; default=32 |

## scripts/experiments/run_reference_budget_pilot.py

| Argument | Declaration |
| --- | --- |
| `--data-root` | type=Path; required=True |
| `--dataset` | choices=['FB15K-237', 'CoDEx-M']; required=True |
| `--seed` | type=int; choices=[17, 29, 43]; required=True |
| `--out` | type=Path; required=True |

## scripts/experiments/run_remaining_review_controls.py

| Argument | Declaration |
| --- | --- |
| `--data-root` | type=Path; required=True |
| `--cohort` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--dataset` | choices=CONTROL_PROTOCOL['datasets']; required=True |
| `--seed` | type=int; choices=CONTROL_PROTOCOL['seeds']; required=True |

## scripts/experiments/run_samebase_depth_sweep.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | default='FB15K-237' |
| `--model` | default='transe' |
| `--policy` | default='entity'; choices=['entity', 'relation', 'random'] |
| `--fraction` | type=float; default=0.05 |
| `--seed` | type=int; default=17 |
| `--depths` | type=int; default=[5, 10, 20, 50] |
| `--data-root` | default='data' |
| `--device` | default='cuda:0' |
| `--threads` | type=int; default=1 |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--ref-epochs` | type=int; default=20 |
| `--batch-size` | type=int; default=4096 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--hops` | type=int; default=1 |
| `--ng-lr` | type=float; default=0.001 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |
| `--out` | required=True |

## scripts/experiments/run_samebase_ng_pilot.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | default='FB15K-237' |
| `--model` | default='transe' |
| `--policy` | default='entity'; choices=['entity', 'relation', 'random'] |
| `--fraction` | type=float; default=0.05 |
| `--seed` | type=int; default=17 |
| `--data-root` | default='data' |
| `--device` | default='cuda:0' |
| `--threads` | type=int; default=1 |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--ref-epochs` | type=int; default=20 |
| `--local-epochs` | type=int; default=5 |
| `--batch-size` | type=int; default=4096 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--hops` | type=int; default=1 |
| `--ng-epochs` | type=int; default=5 |
| `--ng-lr` | type=float; default=0.001 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |
| `--out` | required=True |

## scripts/experiments/run_schema_ablation.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--model` | required=True; choices=['distmult', 'complex'] |
| `--seed` | required=True; type=int |
| `--fractions` | type=float; default=[0.1, 0.2] |
| `--data-root` | default='data' |
| `--canonical-root` | default='results_cluster/policy128_entitylocal_v2' |
| `--out` | required=True |
| `--device` | default='cuda:0' |
| `--threads` | type=int; default=1 |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--local-epochs` | type=int; default=5 |
| `--batch-size` | type=int; default=4096 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |
| `--base-mrr-tol` | type=float; default=0.0005 |

## scripts/experiments/run_sequential_deletion_stress.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--seed` | type=int; required=True |
| `--data-root` | default='data' |
| `--out` | required=True |
| `--device` | default='cuda:0' |
| `--step-fraction` | type=float; default=0.02 |
| `--steps` | type=int; default=5 |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--local-epochs` | type=int; default=5 |
| `--batch-size` | type=int; default=4096 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |

## scripts/experiments/run_shared_competitor_ports.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--fraction` | type=float; required=True |
| `--policy` | choices=['entity', 'random']; default='entity' |
| `--seed` | type=int; required=True |
| `--data-root` | default='data' |
| `--request-dir` | required=True |
| `--base-checkpoint` | required=True |
| `--methods` | default=['SGU', 'ZeroFisher']; choices=['SGU', 'ZeroFisher'] |
| `--device` | default='cuda:0' |
| `--out` | required=True |
| `--sgu-clusters` | type=int; default=3 |
| `--sgu-lr` | type=float; default=1e-05 |
| `--zf-epsilon` | type=float; default=1e-05 |
| `--zf-gamma` | type=float; default=1.0 |
| `--zf-iterations` | type=int; default=100 |
| `--zf-damp` | type=float; default=0.0 |
| `--zf-scale` | type=float; default=10.0 |
| `--zf-batch-size` | type=int; default=1024 |
| `--neg-ratio` | type=int; default=10 |
| `--margin` | type=float; default=8.0 |

## scripts/experiments/run_supportloss_cross_family.py

| Argument | Declaration |
| --- | --- |
| `--data-root` | type=Path; required=True |
| `--dataset` | choices=['FB15K-237', 'CoDEx-M']; required=True |
| `--seed` | type=int; choices=[17, 29, 43]; required=True |
| `--out` | type=Path; required=True |
| `--model` | choices=MODEL_NAMES; required=True |
| `--negative` | choices=['tail', 'balanced']; default='tail' |
| `--device` | default='cuda' |
| `--smoke` | action='store_true' |

## scripts/experiments/run_supportloss_negative_exposure_control.py

| Argument | Declaration |
| --- | --- |
| `--data-root` | type=Path; required=True |
| `--cohort` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--dataset` | choices=['FB15K-237', 'CoDEx-M']; required=True |
| `--seed` | type=int; choices=[17, 29, 43]; required=True |

## scripts/experiments/run_supportloss_request_validation.py

| Argument | Declaration |
| --- | --- |
| `--data-root` | type=Path; required=True |
| `--dataset` | choices=['FB15K-237', 'CoDEx-M']; required=True |
| `--seed` | type=int; choices=[17, 29, 43]; required=True |
| `--out` | type=Path; required=True |
| `--model` | choices=['distmult', 'complex']; required=True |
| `--negative` | choices=['balanced']; default='balanced' |
| `--device` | default='cuda' |
| `--selection` | type=Path; required=True |
| `--request-stratum` | choices=['low', 'middle', 'high']; required=True |
| `--request-index` | type=int; choices=[0, 1, 2]; required=True |
| `--smoke` | action='store_true' |

## scripts/experiments/run_supportloss_specificity_diagnostic.py

| Argument | Declaration |
| --- | --- |
| `--data-root` | type=Path; required=True |
| `--cohort` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--dataset` | choices=['FB15K-237', 'CoDEx-M']; required=True |
| `--seed` | type=int; choices=[17, 29, 43]; required=True |

## scripts/experiments/run_supportloss_unified.py

| Argument | Declaration |
| --- | --- |
| `--task` | type=int; required=True; choices=range(36) |
| `--out` | type=Path; required=True |
| `--data-root` | type=Path; required=True |
| `--device` | default='cuda:0' |
| `--smoke` | action='store_true' |

## scripts/experiments/run_unrelated_placement_probe.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True; choices=['FB15K-237', 'CoDEx-M', 'NELL-995'] |
| `--seed` | required=True; type=int; choices=[17, 29, 43] |
| `--root` | action='append'; type=Path; required=True |
| `--data-root` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--device` | default='cuda:0' |
| `--n-probes` | type=int; default=256 |
| `--batch` | type=int; default=32 |
| `--entity-chunk` | type=int; default=4096 |

## scripts/experiments/run_w5_third_reference.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True; choices=DATASETS |
| `--seed` | required=True; type=int; choices=SEEDS |
| `--mode` | required=True; choices=MODES |
| `--source-root` | type=Path; required=True |
| `--data-root` | type=Path; required=True |
| `--out-root` | type=Path; required=True |
| `--device` | default='cuda:0' |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--batch-size` | type=int; default=4096 |
| `--lr` | type=float; default=0.002 |
| `--l2` | type=float; default=1e-06 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |

## scripts/experiments/run_w6_well_trained_distmult.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | default='FB15K-237' |
| `--data-root` | default='data' |
| `--device` | default='cuda:0' |
| `--dim` | type=int; default=256 |
| `--fraction` | type=float; default=0.1 |
| `--request-seed` | type=int; default=17 |
| `--base-seed` | type=int; default=17 |
| `--ref-a-seed` | type=int; default=101 |
| `--ref-b-seed` | type=int; default=202 |
| `--max-epochs` | type=int; default=300 |
| `--eval-every` | type=int; default=10 |
| `--patience` | type=int; default=6 |
| `--batch-size` | type=int; default=256 |
| `--lr` | type=float; default=0.1 |
| `--weight-decay` | type=float; default=1e-06 |
| `--label-smoothing` | type=float; default=0.1 |
| `--repair-epochs` | type=int; default=30 |
| `--min-test-mrr` | type=float; default=0.2 |
| `--out` | type=Path; required=True |

## scripts/experiments/run_w7_refc_probe.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | default='NELL-995'; choices=['FB15K-237', 'CoDEx-M', 'NELL-995'] |
| `--data-root` | required=True |
| `--device` | default='cuda:0' |
| `--threads` | type=int; default=1 |
| `--dim` | type=int; default=256 |
| `--fraction` | type=float; default=0.1 |
| `--request-seed` | type=int; required=True |
| `--expected-request-hash` | required=True |
| `--ref-c-seed` | type=int; required=True |
| `--existing-cell` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--max-epochs` | type=int; default=300 |
| `--eval-every` | type=int; default=10 |
| `--patience` | type=int; default=6 |
| `--batch-size` | type=int; default=256 |
| `--lr` | type=float; default=0.1 |
| `--weight-decay` | type=float; default=1e-06 |
| `--val-queries` | type=int; default=1500 |
| `--test-queries` | type=int; default=2000 |
| `--forget-queries` | type=int; default=1000 |

## scripts/experiments/run_w7_stronger_training_grid.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True; choices=['FB15K-237', 'CoDEx-M', 'NELL-995'] |
| `--data-root` | default='data' |
| `--device` | default='cuda:0' |
| `--threads` | type=int; default=1 |
| `--dim` | type=int; default=256 |
| `--fraction` | type=float; default=0.1 |
| `--request-mode` | choices=['entity-deterministic', 'fullstar-low', 'fullstar-mid']; default='entity-deterministic' |
| `--expected-request-hash` | default=None |
| `--request-seed` | type=int; required=True |
| `--base-seed` | type=int; required=True |
| `--ref-a-seed` | type=int; required=True |
| `--ref-b-seed` | type=int; required=True |
| `--max-epochs` | type=int; default=300 |
| `--eval-every` | type=int; default=10 |
| `--patience` | type=int; default=6 |
| `--batch-size` | type=int; default=256 |
| `--lr` | type=float; default=0.1 |
| `--weight-decay` | type=float; default=1e-06 |
| `--repair-epochs` | type=int; default=30 |
| `--val-queries` | type=int; default=1500 |
| `--test-queries` | type=int; default=2000 |
| `--forget-queries` | type=int; default=1000 |
| `--min-test-mrr` | type=float; default=-1.0 |
| `--out-root` | type=Path; required=True |
| `--base-stage-from` | type=Path; default=None |

## scripts/experiments/select_supportloss_learning_rate.py

| Argument | Declaration |
| --- | --- |
| `--data-root` | type=Path; required=True |
| `--dataset` | choices=['FB15K-237', 'CoDEx-M']; required=True |
| `--model` | choices=['distmult', 'complex']; required=True |
| `--out` | type=Path; required=True |
| `--device` | default='cuda:0' |

## scripts/experiments/w7_closeout/collect_w7_low_mid.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |

## scripts/experiments/w7_closeout/extract_nell29_three_reference_metrics.py

| Argument | Declaration |
| --- | --- |
| `--existing-cell` | type=Path; required=True |
| `--refc-dir` | type=Path; required=True |
| `--out-dir` | type=Path; required=True |

## scripts/experiments/w8_reference_free_correction/aggregate_normoracle_placement.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--n-boot` | type=int; default=10000 |
| `--seed` | type=int; default=25092026 |

## scripts/experiments/w8_reference_free_correction/aggregate_w12_scale_rfpc.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |

## scripts/experiments/w8_reference_free_correction/aggregate_w13_placement.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--n-boot` | type=int; default=10000 |
| `--seed` | type=int; default=25092026 |

## scripts/experiments/w8_reference_free_correction/aggregate_w13_reference_free_norm.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |

## scripts/experiments/w8_reference_free_correction/aggregate_w14_rf_norm_matched_controls.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--n-boot` | type=int; default=10000 |
| `--seed` | type=int; default=25092026 |

## scripts/experiments/w8_reference_free_correction/aggregate_w8_reference_free_placement.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--n-boot` | type=int; default=10000 |
| `--seed` | type=int; default=19092026 |

## scripts/experiments/w8_reference_free_correction/analyze_b3_official_w8.py

| Argument | Declaration |
| --- | --- |
| `--aggregate-dir` | type=Path; required=True |
| `--out` | type=Path; required=True |

## scripts/experiments/w8_reference_free_correction/analyze_normoracle_placement.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True; choices=['FB15K-237', 'CoDEx-M', 'NELL-995'] |
| `--seed` | required=True; type=int; choices=[17, 29, 43] |
| `--w8-root` | type=Path; required=True |
| `--placement-root` | type=Path; required=True |
| `--data-root` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--device` | default='cuda:0' |
| `--batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |

## scripts/experiments/w8_reference_free_correction/analyze_section7_norm_mechanism.py

| Argument | Declaration |
| --- | --- |
| `--w8-root` | type=Path; required=True |
| `--w13-root` | type=Path; required=True |
| `--data-root` | type=Path; required=True |
| `--out` | type=Path; required=True |

## scripts/experiments/w8_reference_free_correction/analyze_w13_placement.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True; choices=['FB15K-237', 'CoDEx-M', 'NELL-995'] |
| `--seed` | required=True; type=int; choices=[17, 29, 43] |
| `--w8-root` | type=Path; required=True |
| `--placement-root` | type=Path; required=True |
| `--data-root` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--device` | default='cuda:0' |
| `--batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |

## scripts/experiments/w8_reference_free_correction/preflight_w8.py

| Argument | Declaration |
| --- | --- |
| `--results-root` | type=Path; required=True |
| `--placement-root` | type=Path; required=True |

## scripts/experiments/w8_reference_free_correction/run_w12_scale_rfpc_decomposition.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True; choices=['FB15K-237', 'CoDEx-M', 'NELL-995'] |
| `--seed` | required=True; type=int; choices=[17, 29, 43] |
| `--w8-root` | type=Path; required=True |
| `--data-root` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--device` | default='cuda:0' |
| `--batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |

## scripts/experiments/w8_reference_free_correction/run_w13_reference_free_norm.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True; choices=['FB15K-237', 'CoDEx-M', 'NELL-995'] |
| `--seed` | required=True; type=int; choices=[17, 29, 43] |
| `--w8-root` | type=Path; required=True |
| `--data-root` | type=Path; required=True |
| `--w12-root` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--device` | default='cuda:0' |
| `--batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |

## scripts/experiments/w8_reference_free_correction/run_w14_rf_norm_matched_controls.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True; choices=['FB15K-237', 'CoDEx-M', 'NELL-995'] |
| `--seed` | required=True; type=int; choices=[17, 29, 43] |
| `--w8-root` | type=Path; required=True |
| `--w12-root` | type=Path; required=True |
| `--data-root` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--device` | default='cuda:0' |
| `--batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |

## scripts/experiments/w8_reference_free_correction/run_w8_reference_free_placement.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True; choices=['FB15K-237', 'CoDEx-M', 'NELL-995'] |
| `--seed` | required=True; type=int; choices=[17, 29, 43] |
| `--results-root` | type=Path; required=True |
| `--placement-root` | type=Path; required=True |
| `--data-root` | type=Path; required=True |
| `--out-root` | type=Path; required=True |
| `--device` | default='cuda:0' |
| `--background-contexts` | type=int; default=200 |
| `--controls` | type=int; default=20 |
| `--test-queries` | type=int; default=1000 |
| `--eval-seed` | type=int; default=19092026 |
| `--batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |

## scripts/experiments/w8_stronger_transfer/aggregate_w8_stronger_transfer.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--n-boot` | type=int; default=10000 |
| `--seed` | type=int; default=19092026 |

## scripts/experiments/w8_stronger_transfer/run_w8_stronger_transfer.py

| Argument | Declaration |
| --- | --- |
| `--cell` | type=Path; required=True |
| `--data-root` | type=Path; required=True |
| `--device` | default='cuda:0' |
| `--out` | type=Path; required=True |

## scripts/experiments/w9_method_transfer/aggregate_w9_method_transfer.py

| Argument | Declaration |
| --- | --- |
| `--root` | type=Path; required=True |
| `--out` | type=Path; required=True |
| `--n-boot` | type=int; default=10000 |
| `--seed` | type=int; default=19092026 |

## scripts/experiments/w9_method_transfer/run_w9_method_transfer.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True; choices=['FB15K-237', 'CoDEx-M'] |
| `--fraction` | type=float; default=0.1 |
| `--request-seed` | required=True; type=int; choices=[17, 29, 43] |
| `--data-root` | type=Path; required=True |
| `--request-dir` | type=Path; required=True |
| `--ref-a` | type=Path; required=True |
| `--ref-b` | type=Path; required=True |
| `--method` | action='append'; default=[] |
| `--baseline-dir` | type=Path; required=True |
| `--device` | default='cuda:0' |
| `--max-queries` | type=int; default=1000 |
| `--test-queries` | type=int; default=1000 |
| `--background-contexts` | type=int; default=B_FROZEN |
| `--controls` | type=int; default=K_FROZEN |
| `--placement-targets` | type=int; default=P_FROZEN |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--out` | type=Path; required=True |

## scripts/run_publication_cpu.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--model` | choices=['transe', 'complex']; required=True |
| `--policy` | choices=['relation', 'random', 'entity']; default='relation' |
| `--seed` | type=int; default=17 |
| `--data-root` | default='data' |
| `--out` | default='results_publication' |
| `--device` | default='cpu' |
| `--threads` | type=int; default=4 |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--ref-epochs` | type=int; default=20 |
| `--local-epochs` | type=int; default=5 |
| `--batch-size` | type=int; default=4096 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--hops` | type=int; default=1 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--eval-queries` | type=int; default=1000 |
| `--score-queries` | type=int; default=10000 |
| `--fractions` | type=float; default=[0.01, 0.05, 0.1, 0.2] |

## scripts/run_publication_families.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--model` | choices=MODEL_NAMES; required=True |
| `--policy` | choices=['relation', 'random', 'entity']; default='relation' |
| `--seed` | type=int; default=17 |
| `--data-root` | default='data' |
| `--out` | default='results_families' |
| `--device` | default='cpu' |
| `--threads` | type=int; default=4 |
| `--dim` | type=int; default=128 |
| `--epochs` | type=int; default=20 |
| `--ref-epochs` | type=int; default=20 |
| `--local-epochs` | type=int; default=5 |
| `--batch-size` | type=int; default=4096 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--hops` | type=int; default=1 |
| `--eval-batch` | type=int; default=16 |
| `--entity-chunk` | type=int; default=4096 |
| `--eval-queries` | type=int; default=1000 |
| `--forget-eval-queries` | type=int; default=1000 |
| `--score-queries` | type=int; default=10000 |
| `--extended-diagnostics` | action='store_true' |
| `--fractions` | type=float; default=[0.01, 0.05, 0.1, 0.2] |

## scripts/run_real_kge.py

| Argument | Declaration |
| --- | --- |
| `--dataset` | required=True |
| `--model` | choices=['transe', 'complex']; default='transe' |
| `--data-root` | default='data' |
| `--out` | default='results' |
| `--dim` | type=int; default=64 |
| `--epochs` | type=int; default=4 |
| `--local-epochs` | type=int; default=3 |
| `--retrain-epochs` | type=int; default=3 |
| `--batch-size` | type=int; default=2048 |
| `--lr` | type=float; default=0.002 |
| `--local-lr` | type=float; default=0.001 |
| `--l2` | type=float; default=1e-06 |
| `--damping` | type=float; default=0.1 |
| `--hops` | type=int; default=1 |
| `--eval-neg` | type=int; default=256 |
| `--eval-queries` | type=int; default=1000 |
| `--threads` | type=int; default=4 |
| `--seed` | type=int; default=17 |
| `--device` | default='cpu' |
| `--fractions` | type=float; default=[0.01, 0.05, 0.1, 0.2] |

