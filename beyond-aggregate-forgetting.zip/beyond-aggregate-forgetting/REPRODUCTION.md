# Command examples

Run from the archive root with `PYTHONPATH` set as in the README. The following
commands use relative paths and assume the required artifacts described in the
README are present. Commands train models and write new output; they are not
part of the packaging verification.

## Primary 36-setting grid and correction

```bash
for dataset in FB15K-237 CoDEx-M NELL-995; do
  for seed in 17 29 43; do
    python scripts/experiments/run_entity_request_robustness.py \
      --dataset "$dataset" --seed "$seed" --data-root data \
      --out artifacts/robustness --device cuda:0
    python scripts/experiments/rerun_w5_mean_tie.py \
      --dataset "$dataset" --seed "$seed" --data-root data \
      --old-results-root artifacts/historical \
      --out artifacts/w5/high --device cuda:0
    python scripts/experiments/rerun_w5_lowmid_null.py \
      --dataset "$dataset" --seed "$seed" --data-root data \
      --historical-results-root artifacts/robustness \
      --out artifacts/w5/lowmid --device cuda:0
    python scripts/experiments/run_unrelated_placement_probe.py \
      --dataset "$dataset" --seed "$seed" --data-root data \
      --root artifacts/w5/high --root artifacts/w5/lowmid \
      --out artifacts/placement --device cuda:0
    python scripts/experiments/w8_reference_free_correction/run_w8_reference_free_placement.py \
      --dataset "$dataset" --seed "$seed" --data-root data \
      --results-root artifacts/w5 --placement-root artifacts/placement \
      --out-root artifacts/w8 --device cuda:0 \
      --background-contexts 200 --controls 20 --test-queries 1000 \
      --eval-seed 19092026 --batch 16 --entity-chunk 4096
  done
done
python scripts/experiments/bootstrap_w5_mean_tie_query_ci.py \
  --root artifacts/w5/high --root artifacts/w5/lowmid \
  --out artifacts/w5_ci --expected-cells 36 --n-boot 10000 --seed 19092026
python scripts/experiments/w8_reference_free_correction/aggregate_w8_reference_free_placement.py \
  --root artifacts/w8 --out artifacts/w8_aggregate --n-boot 10000 --seed 19092026
```

Do not place duplicate copies of a cell below the discovery roots. Discovery
and request-hash gates intentionally reject ambiguous or mismatched inputs.

## Norm mechanism analysis

After generating W13 outputs with the included W13 runner:

```bash
python scripts/experiments/w8_reference_free_correction/analyze_section7_norm_mechanism.py \
  --w8-root artifacts/w8 --w13-root artifacts/w13 \
  --data-root data --out artifacts/norm_mechanism
```

For W7, W9, W12, W13 and W14, consult the exact required artifact arguments in
`CLI_REFERENCE.md` and the corresponding protocol documents. Checkpoint paths
must refer to models trained on the matching retained graph; an unrelated model
cannot be used as a replacement reference.
