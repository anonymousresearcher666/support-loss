from __future__ import annotations
from dataclasses import dataclass
import math
import numpy as np

@dataclass
class StructuralCertificate:
    eta_proxy: float
    boundary_ratio: float
    degree_mass_ratio: float
    radius_proxy: float
    note: str

def structural_certificate(train,forget_idx,affected_entities,affected_relations,grad_norm_proxy,damping=0.1):
    retain=np.delete(train,forget_idx,axis=0);ae=np.asarray(affected_entities);ar=np.asarray(affected_relations);cross=((np.isin(retain[:,0],ae)^np.isin(retain[:,2],ae)) | (np.isin(retain[:,1],ar) & ~(np.isin(retain[:,0],ae)&np.isin(retain[:,2],ae))));inc=(np.isin(retain[:,0],ae)|np.isin(retain[:,2],ae)|np.isin(retain[:,1],ar));br=float(cross.sum()/max(inc.sum(),1));eta=min(0.999,math.sqrt(br));radius=eta/(1-eta)*float(grad_norm_proxy)/max(damping,1e-12);return StructuralCertificate(eta,br,float(inc.mean()),radius,'diagnostic only for the non-convex KGE; formal certificate is the strongly-convex surrogate path')
