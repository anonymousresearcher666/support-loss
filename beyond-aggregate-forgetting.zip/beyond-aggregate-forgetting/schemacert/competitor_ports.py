from __future__ import annotations

from dataclasses import dataclass
import copy
import random
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from .graphdpo_shared import (
    GraphDPOSharedTransE,
    _graphdpo_facts,
    _margin_batch,
    clone_shared,
)


@dataclass
class CompetitorResult:
    model: GraphDPOSharedTransE
    seconds: float
    metadata: dict


def save_graphdpo_shared_checkpoint(model: GraphDPOSharedTransE, path: str | Path) -> None:
    """Save a shared TransE model in the checkpoint layout used by GraphDPO."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    state = {
        'ent_embeddings.weight': model.entity.weight.detach().cpu().float(),
        'rel_embeddings.weight': model.relation.weight.detach().cpu().float(),
    }
    torch.save({'state_dict': state}, p)


def _build_adjacency(train_forward: np.ndarray) -> dict[int, list[tuple[int, int]]]:
    adj: dict[int, list[tuple[int, int]]] = {}
    for h, r, t in train_forward:
        h, r, t = int(h), int(r), int(t)
        adj.setdefault(h, []).append((t, r))
        adj.setdefault(t, []).append((h, r))
    return adj


def _build_relation_index(train_forward: np.ndarray) -> dict[int, list[tuple[int, int]]]:
    out: dict[int, list[tuple[int, int]]] = {}
    for h, r, t in train_forward:
        out.setdefault(int(r), []).append((int(h), int(t)))
    return out


def _query_match_entity(
    query: np.ndarray,
    relation_index: dict[int, list[tuple[int, int]]],
    adjacency: dict[int, list[tuple[int, int]]],
    labels: np.ndarray,
    rng: random.Random,
) -> tuple[int | None, int | None, int | None, int | None]:
    """Port of KGUnlearningBySchema CosineSchemaDataLoader.query_match_entity.

    The public implementation scans for a different triple with the same relation,
    samples a non-query neighbor at each endpoint, and then finds neighbors of the
    matched triple whose KMeans labels agree with those query-neighbor labels.
    We keep the same semantics but pre-index relations to avoid an O(|T|) scan for
    every forgotten triple.
    """
    qh, qr, qt = map(int, query)
    mh = mt = None
    for h, t in relation_index.get(qr, []):
        if h != qh and t != qt:
            mh, mt = h, t
            break

    qhn = list(adjacency.get(qh, ()))
    qtn = list(adjacency.get(qt, ()))
    rng.shuffle(qhn)
    rng.shuffle(qtn)

    mhn = list(adjacency.get(mh, ())) if mh is not None else []
    mtn = list(adjacency.get(mt, ())) if mt is not None else []
    rng.shuffle(mhn)
    rng.shuffle(mtn)

    e1 = next((n for n, _ in qhn if n != qt), None)
    e2 = next((n for n, _ in qtn if n != qh), None)
    e3 = None
    e4 = None
    if mh is not None and mt is not None and e1 is not None:
        e3 = next((n for n, _ in mhn if n != mt and labels[n] == labels[e1]), None)
    if mh is not None and mt is not None and e2 is not None:
        e4 = next((n for n, _ in mtn if n != mh and labels[n] == labels[e2]), None)
    return e1, e2, e3, e4


def sgu_schema_entity_shared(
    base: GraphDPOSharedTransE,
    train_forward: np.ndarray,
    forget_forward: np.ndarray,
    *,
    seed: int,
    device: str = 'cuda:0',
    n_clusters: int = 3,
    lr: float = 1e-5,
    max_attempts: int = 20,
) -> CompetitorResult:
    """Matched port of the public COLING'25 schema/entity unlearning update.

    Source semantics: NKUShaw/KGUnlearningBySchema,
    ``Exp_FB15K237/Entity_TransE_FB15K237.py`` and
    ``openke/data/EmbeddingDataLoader.py``.  The public code uses KMeans over
    pretrained entity embeddings (3 clusters), finds same-relation matched
    neighborhoods, and performs one Adam step per forgotten triple minimizing
    ``1 - cosine(e1-e2, e3-e4)``.  This port applies that update to the exact
    shared GraphDPO TransE checkpoint/request, so theta_0 and the downstream
    evaluator remain matched across methods.
    """
    try:
        from sklearn.cluster import KMeans
    except Exception as exc:  # pragma: no cover - cluster setup catches this
        raise RuntimeError('SGU port requires scikit-learn') from exc

    model = clone_shared(base).to(device)
    st = time.time()

    weights = model.entity.weight.detach().cpu().numpy()
    labels = KMeans(n_clusters=int(n_clusters), random_state=0, n_init=10).fit(weights).labels_
    adjacency = _build_adjacency(train_forward)
    relation_index = _build_relation_index(train_forward)
    rng = random.Random(int(seed))
    opt = torch.optim.Adam(model.parameters(), lr=float(lr))

    used = 0
    skipped = 0
    total_loss = 0.0
    for query in forget_forward:
        e1 = e2 = e3 = e4 = None
        attempts = 0
        while (e1 is None or e2 is None or e3 is None or e4 is None) and attempts < int(max_attempts):
            e1, e2, e3, e4 = _query_match_entity(
                query, relation_index, adjacency, labels, rng
            )
            attempts += 1
        if e1 is None or e2 is None or e3 is None or e4 is None:
            skipped += 1
            continue

        idx = torch.as_tensor([e1, e2, e3, e4], dtype=torch.long, device=device)
        emb = model.entity(idx)
        query_vec = emb[0] - emb[1]
        match_vec = emb[2] - emb[3]
        loss = 1.0 - F.cosine_similarity(query_vec, match_vec, dim=0)
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()
        total_loss += float(loss.detach().cpu())
        used += 1

    if model.entity.weight.is_cuda:
        torch.cuda.synchronize()
    sec = time.time() - st
    return CompetitorResult(
        model=model,
        seconds=sec,
        metadata={
            'implementation': 'matched port of public KGUnlearningBySchema entity/TransE update',
            'n_clusters': int(n_clusters),
            'lr': float(lr),
            'max_attempts': int(max_attempts),
            'forgotten_triples': int(len(forget_forward)),
            'used_triples': int(used),
            'skipped_triples': int(skipped),
            'mean_update_loss': float(total_loss / max(used, 1)),
        },
    )


def _zo_loss(
    model: GraphDPOSharedTransE,
    positives: np.ndarray,
    n_entities: int,
    *,
    neg_ratio: int,
    margin: float,
    seed: int,
    device: str,
) -> torch.Tensor:
    # Recreate the same negative sample for +epsilon and -epsilon evaluations.
    return _margin_batch(
        model,
        positives,
        n_entities,
        int(neg_ratio),
        float(margin),
        np.random.default_rng(int(seed)),
        device,
    )


def _zero_order_vectors(
    model: GraphDPOSharedTransE,
    positives: np.ndarray,
    n_entities: int,
    *,
    epsilon: float,
    neg_ratio: int,
    margin: float,
    seed: int,
    device: str,
) -> list[torch.Tensor]:
    """Port the public ZOWFKGIF two-sided zeroth-order parameter estimator.

    The source perturbs each embedding table by one random vector broadcast over
    rows and returns the row-mean gradient, i.e. one update vector per table.
    """
    params = [model.entity.weight, model.relation.weight]
    out: list[torch.Tensor] = []
    gen = torch.Generator(device=device)
    gen.manual_seed(int(seed))
    for pidx, param in enumerate(params):
        vec = torch.randn(
            param.shape[1], generator=gen, dtype=param.dtype, device=param.device
        ) * float(epsilon)
        original = param.data.clone()
        try:
            param.data.add_(vec.unsqueeze(0))
            with torch.no_grad():
                lp = _zo_loss(
                    model, positives, n_entities,
                    neg_ratio=neg_ratio, margin=margin,
                    seed=seed + 1009 * pidx, device=device,
                )
            param.data.copy_(original)
            param.data.sub_(vec.unsqueeze(0))
            with torch.no_grad():
                lm = _zo_loss(
                    model, positives, n_entities,
                    neg_ratio=neg_ratio, margin=margin,
                    seed=seed + 1009 * pidx, device=device,
                )
        finally:
            param.data.copy_(original)
        grad_vec = ((lp - lm) / (2.0 * float(epsilon))) * vec
        out.append(grad_vec.detach())
    return out


def _woodfisher_vectors(grad_all: list[torch.Tensor], gamma: float) -> list[torch.Tensor]:
    vtv = sum(torch.sum(g * g) for g in grad_all)
    out = []
    for g in grad_all:
        term1 = (1.0 / float(gamma)) * g
        term2 = ((float(gamma) ** -2) * g * vtv) / (1.0 + (float(gamma) ** -1) * vtv)
        out.append(term1 + term2)
    return out


def zero_fisher_shared(
    base: GraphDPOSharedTransE,
    train_forward: np.ndarray,
    forget_idx: np.ndarray,
    n_entities: int,
    *,
    seed: int,
    device: str = 'cuda:0',
    epsilon: float = 1e-5,
    gamma: float = 1.0,
    iterations: int = 100,
    damp: float = 0.0,
    scale: float = 10.0,
    batch_size: int = 1024,
    neg_ratio: int = 10,
    margin: float = 8.0,
) -> CompetitorResult:
    """Matched TransE port of the public CIKM'25 ZOWFKGIF/ZeroFisher update.

    The algebra follows ``NKUShaw/ZOWFKGIF:ZO.py``: one zeroth-order vector per
    embedding table, the WoodFisher approximation, and the published iterative
    update.  We deliberately apply it to the same GraphDPO checkpoint/objective
    used by the matched benchmark instead of mixing an unrelated OpenKE base.
    This should be described in the paper as a *matched port*, not an official
    author-produced checkpoint.
    """
    model = clone_shared(base).to(device)
    st = time.time()

    keep = np.ones(len(train_forward), dtype=bool)
    keep[np.asarray(forget_idx, dtype=np.int64)] = False
    retain_forward = train_forward[keep]
    full_facts = _graphdpo_facts(train_forward)
    retain_facts = _graphdpo_facts(retain_forward)

    rng = np.random.default_rng(int(seed))
    full_n = min(int(batch_size), len(full_facts))
    retain_n = min(int(batch_size), len(retain_facts))
    full_batch = full_facts[rng.choice(len(full_facts), full_n, replace=False)]
    retain_batch = retain_facts[rng.choice(len(retain_facts), retain_n, replace=False)]

    grad_full = _zero_order_vectors(
        model, full_batch, n_entities,
        epsilon=epsilon, neg_ratio=neg_ratio, margin=margin,
        seed=seed + 10001, device=device,
    )
    grad_removed_name_in_source = _zero_order_vectors(
        model, retain_batch, n_entities,
        epsilon=epsilon, neg_ratio=neg_ratio, margin=margin,
        seed=seed + 20003, device=device,
    )

    # Preserve the public ZO.py algebra exactly.  Note that the public variable
    # named ``grad_removed`` is computed from the remaining-data loader.
    grad1 = [a - b for a, b in zip(grad_full, grad_removed_name_in_source)]
    grad2 = grad_removed_name_in_source
    v = [a - b for a, b in zip(grad1, grad2)]
    h_estimate = [x.clone() for x in v]
    for _ in range(int(iterations)):
        hv = _woodfisher_vectors(grad_full, float(gamma))
        h_estimate = [
            vv + (1.0 - float(damp)) * hh - hvv / float(scale)
            for vv, hh, hvv in zip(v, h_estimate, hv)
        ]

    params = [model.entity.weight, model.relation.weight]
    with torch.no_grad():
        for p, h in zip(params, h_estimate):
            p.add_((h / float(scale)).unsqueeze(0))

    if model.entity.weight.is_cuda:
        torch.cuda.synchronize()
    sec = time.time() - st
    return CompetitorResult(
        model=model,
        seconds=sec,
        metadata={
            'implementation': 'matched TransE port of public ZOWFKGIF/ZO.py',
            'epsilon': float(epsilon),
            'gamma': float(gamma),
            'iterations': int(iterations),
            'damp': float(damp),
            'scale': float(scale),
            'batch_size': int(batch_size),
            'neg_ratio': int(neg_ratio),
            'margin': float(margin),
            'source_semantics_note': (
                'public ZO.py computes its variable grad_removed from the remaining-data loader; '
                'this port preserves that algebra'
            ),
        },
    )
