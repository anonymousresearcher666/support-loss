from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import numpy as np

@dataclass
class KGData:
    train: np.ndarray
    valid: np.ndarray
    test: np.ndarray
    entities: list[str]
    relations: list[str]
    e2i: dict[str,int]
    r2i: dict[str,int]

def _read(path):
    out=[]
    with open(path,encoding='utf8',errors='ignore') as f:
        for line in f:
            p=line.strip().split()
            if len(p)>=3: out.append((p[0],p[1],p[2]))
    return out

def load_dataset(train_path, valid_path=None, test_path=None):
    tr=_read(train_path);va=_read(valid_path) if valid_path and Path(valid_path).exists() else [];te=_read(test_path) if test_path and Path(test_path).exists() else []
    allx=tr+va+te;ents=sorted({x for h,r,t in allx for x in (h,t)});rels=sorted({r for h,r,t in allx});e2i={x:i for i,x in enumerate(ents)};r2i={x:i for i,x in enumerate(rels)}
    def enc(rows): return np.asarray([(e2i[h],r2i[r],e2i[t]) for h,r,t in rows],dtype=np.int64).reshape(-1,3)
    return KGData(enc(tr),enc(va),enc(te),ents,rels,e2i,r2i)

def infer_paths(dataset,root='data'):
    root=Path(root);d=dataset.lower()
    if d=='codex-s': base=root/'codex'/'data'/'triples'/'codex-s';return base/'train.txt',base/'valid.txt',base/'test.txt'
    if d=='codex-m': base=root/'codex'/'data'/'triples'/'codex-m';return base/'train.txt',base/'valid.txt',base/'test.txt'
    if d=='codex-l': base=root/'codex'/'data'/'triples'/'codex-l';return base/'train.txt',base/'valid.txt',base/'test.txt'
    if d=='fb15k-237': base=root/'FB15k-237';return base/'train.txt',base/'valid.txt',base/'test.txt'
    if d=='wn18rr': base=root/'WN18RR';return base/'train.txt',base/'valid.txt',base/'test.txt'
    if d in {'yago3-10','yago310'}: base=root/'YAGO3-10';return base/'train.txt',base/'valid.txt',base/'test.txt'
    if d=='nell-995': base=root/'kb_reasoning'/'NELL-995';return base/'raw.kb',None,None
    raise KeyError(dataset)

def deterministic_holdout(data,n_valid=1000,n_test=2000,seed=17):
    if len(data.valid) or len(data.test): return data
    rng=np.random.default_rng(seed);n=len(data.train);idx=rng.permutation(n);nv=min(n_valid,max(0,n//20));nt=min(n_test,max(0,n//10));vi=idx[:nv];ti=idx[nv:nv+nt];keep=np.ones(n,bool);keep[vi]=False;keep[ti]=False
    return KGData(data.train[keep],data.train[vi],data.train[ti],data.entities,data.relations,data.e2i,data.r2i)
