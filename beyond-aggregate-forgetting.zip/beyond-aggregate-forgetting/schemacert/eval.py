from __future__ import annotations
import numpy as np
import torch

@torch.no_grad()
def sampled_mrr(model,triples,n_entities,n_neg=512,max_queries=2000,seed=17,device='cpu'):
    if not len(triples): return float('nan')
    rng=np.random.default_rng(seed);q=triples if len(triples)<=max_queries else triples[rng.choice(len(triples),max_queries,replace=False)];rr=[]
    for i in range(0,len(q),128):
        b=q[i:i+128];B=len(b);neg=rng.integers(0,n_entities,size=(B,n_neg),dtype=np.int64);true=np.repeat(b[:,None,:],n_neg,axis=1);true[:,:,2]=neg;bt=torch.as_tensor(b,dtype=torch.long,device=device);cand=torch.as_tensor(true.reshape(-1,3),dtype=torch.long,device=device);s0=model.score(bt).cpu().numpy();sn=model.score(cand).view(B,n_neg).cpu().numpy();rank=1+(sn>=s0[:,None]).sum(1);rr.extend(1/rank)
    return float(np.mean(rr))

@torch.no_grad()
def mean_score(model,triples,max_queries=10000,seed=17,device='cpu'):
    if not len(triples):return float('nan')
    rng=np.random.default_rng(seed);q=triples if len(triples)<=max_queries else triples[rng.choice(len(triples),max_queries,replace=False)];out=[]
    for i in range(0,len(q),4096):out.append(model.score(torch.as_tensor(q[i:i+4096],dtype=torch.long,device=device)).cpu().numpy())
    return float(np.concatenate(out).mean())
