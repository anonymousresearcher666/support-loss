from __future__ import annotations

import math
import torch
from torch import nn
import torch.nn.functional as F


class FamilyKGE(nn.Module):
    def score(self, triples: torch.Tensor) -> torch.Tensor:
        raise NotImplementedError

    def forward(self, triples: torch.Tensor) -> torch.Tensor:
        return self.score(triples)

    def normalize_(self) -> None:
        pass

    def score_candidates(self, kind: str, a: torch.Tensor, b: torch.Tensor, cand: torch.Tensor) -> torch.Tensor:
        raise NotImplementedError


class TransE(FamilyKGE):
    def __init__(self, n_entities: int, n_relations: int, dim: int = 128, p: int = 1):
        super().__init__()
        self.dim = dim
        self.p = p
        self.entity = nn.Embedding(n_entities, dim)
        self.relation = nn.Embedding(n_relations, dim)
        nn.init.uniform_(self.entity.weight, -6 / math.sqrt(dim), 6 / math.sqrt(dim))
        nn.init.uniform_(self.relation.weight, -6 / math.sqrt(dim), 6 / math.sqrt(dim))
        self.normalize_()

    def score(self, x):
        h = self.entity(x[:, 0])
        r = self.relation(x[:, 1])
        t = self.entity(x[:, 2])
        return -torch.linalg.vector_norm(h + r - t, ord=self.p, dim=-1)

    def normalize_(self):
        with torch.no_grad():
            self.entity.weight[:] = F.normalize(self.entity.weight, p=2, dim=-1)

    def score_candidates(self, kind, a, b, cand):
        e = self.entity(cand)
        if kind == 'tail':
            q = self.entity(a) + self.relation(b)
            return -torch.linalg.vector_norm(q[:, None, :] - e[None, :, :], ord=self.p, dim=-1)
        r = self.relation(a)
        t = self.entity(b)
        return -torch.linalg.vector_norm(e[None, :, :] + r[:, None, :] - t[:, None, :], ord=self.p, dim=-1)


class DistMult(FamilyKGE):
    def __init__(self, n_entities: int, n_relations: int, dim: int = 128):
        super().__init__()
        self.dim = dim
        self.entity = nn.Embedding(n_entities, dim)
        self.relation = nn.Embedding(n_relations, dim)
        nn.init.xavier_uniform_(self.entity.weight)
        nn.init.xavier_uniform_(self.relation.weight)

    def score(self, x):
        h = self.entity(x[:, 0])
        r = self.relation(x[:, 1])
        t = self.entity(x[:, 2])
        return (h * r * t).sum(-1)

    def score_candidates(self, kind, a, b, cand):
        e = self.entity(cand)
        if kind == 'tail':
            return (self.entity(a) * self.relation(b)) @ e.T
        return (self.relation(a) * self.entity(b)) @ e.T


class ComplEx(FamilyKGE):
    def __init__(self, n_entities: int, n_relations: int, dim: int = 128):
        super().__init__()
        self.dim = dim
        self.entity = nn.Embedding(n_entities, 2 * dim)
        self.relation = nn.Embedding(n_relations, 2 * dim)
        nn.init.xavier_uniform_(self.entity.weight)
        nn.init.xavier_uniform_(self.relation.weight)

    def score(self, x):
        h = self.entity(x[:, 0])
        r = self.relation(x[:, 1])
        t = self.entity(x[:, 2])
        hr, hi = h.chunk(2, -1)
        rr, ri = r.chunk(2, -1)
        tr, ti = t.chunk(2, -1)
        return (hr * rr * tr + hi * rr * ti + hr * ri * ti - hi * ri * tr).sum(-1)

    def score_candidates(self, kind, a, b, cand):
        e = self.entity(cand)
        er, ei = e.chunk(2, -1)
        if kind == 'tail':
            h = self.entity(a)
            r = self.relation(b)
            hr, hi = h.chunk(2, -1)
            rr, ri = r.chunk(2, -1)
            ar = hr * rr - hi * ri
            ai = hi * rr + hr * ri
            return ar @ er.T + ai @ ei.T
        r = self.relation(a)
        t = self.entity(b)
        rr, ri = r.chunk(2, -1)
        tr, ti = t.chunk(2, -1)
        ar = rr * tr + ri * ti
        ai = rr * ti - ri * tr
        return ar @ er.T + ai @ ei.T


class RotatE(FamilyKGE):
    def __init__(self, n_entities: int, n_relations: int, dim: int = 128):
        super().__init__()
        self.dim = dim
        self.entity = nn.Embedding(n_entities, 2 * dim)
        self.relation = nn.Embedding(n_relations, dim)
        nn.init.xavier_uniform_(self.entity.weight)
        nn.init.uniform_(self.relation.weight, -math.pi, math.pi)

    def _parts(self, ids):
        e = self.entity(ids)
        return e.chunk(2, -1)

    def score(self, x):
        hr, hi = self._parts(x[:, 0])
        phase = self.relation(x[:, 1])
        rr, ri = torch.cos(phase), torch.sin(phase)
        tr, ti = self._parts(x[:, 2])
        dr = hr * rr - hi * ri - tr
        di = hr * ri + hi * rr - ti
        return -torch.sqrt(dr * dr + di * di + 1e-12).sum(-1)

    def score_candidates(self, kind, a, b, cand):
        e = self.entity(cand)
        er, ei = e.chunk(2, -1)
        if kind == 'tail':
            hr, hi = self._parts(a)
            phase = self.relation(b)
            rr, ri = torch.cos(phase), torch.sin(phase)
            qr = hr * rr - hi * ri
            qi = hr * ri + hi * rr
            dr = qr[:, None, :] - er[None, :, :]
            di = qi[:, None, :] - ei[None, :, :]
        else:
            phase = self.relation(a)
            rr, ri = torch.cos(phase), torch.sin(phase)
            tr, ti = self._parts(b)
            cr = er[None, :, :] * rr[:, None, :] - ei[None, :, :] * ri[:, None, :]
            ci = er[None, :, :] * ri[:, None, :] + ei[None, :, :] * rr[:, None, :]
            dr = cr - tr[:, None, :]
            di = ci - ti[:, None, :]
        return -torch.sqrt(dr * dr + di * di + 1e-12).sum(-1)


class PairRE(FamilyKGE):
    def __init__(self, n_entities: int, n_relations: int, dim: int = 128):
        super().__init__()
        self.dim = dim
        self.entity = nn.Embedding(n_entities, dim)
        self.relation = nn.Embedding(n_relations, 2 * dim)
        nn.init.xavier_uniform_(self.entity.weight)
        nn.init.xavier_uniform_(self.relation.weight)

    def score(self, x):
        h = F.normalize(self.entity(x[:, 0]), p=2, dim=-1)
        rh, rt = self.relation(x[:, 1]).chunk(2, -1)
        t = F.normalize(self.entity(x[:, 2]), p=2, dim=-1)
        return -torch.linalg.vector_norm(h * rh - t * rt, ord=1, dim=-1)

    def score_candidates(self, kind, a, b, cand):
        e = F.normalize(self.entity(cand), p=2, dim=-1)
        if kind == 'tail':
            h = F.normalize(self.entity(a), p=2, dim=-1)
            rh, rt = self.relation(b).chunk(2, -1)
            d = h[:, None, :] * rh[:, None, :] - e[None, :, :] * rt[:, None, :]
        else:
            rh, rt = self.relation(a).chunk(2, -1)
            t = F.normalize(self.entity(b), p=2, dim=-1)
            d = e[None, :, :] * rh[:, None, :] - t[:, None, :] * rt[:, None, :]
        return -torch.linalg.vector_norm(d, ord=1, dim=-1)


class CompoundE(FamilyKGE):
    """CompoundE-tail: relation-dependent rotation, translation and scaling of the tail."""

    def __init__(self, n_entities: int, n_relations: int, dim: int = 128):
        super().__init__()
        if dim % 2:
            raise ValueError('CompoundE requires an even embedding dimension')
        self.dim = dim
        self.entity = nn.Embedding(n_entities, dim)
        self.relation = nn.Embedding(n_relations, 3 * dim)
        nn.init.xavier_uniform_(self.entity.weight)
        with torch.no_grad():
            scale, translate, theta_full = self.relation.weight.chunk(3, -1)
            scale.uniform_(0.8, 1.2)
            translate.uniform_(-1.0 / math.sqrt(dim), 1.0 / math.sqrt(dim))
            theta_full.uniform_(-math.pi, math.pi)

    def _transform_tail(self, tail, relation):
        scale, translate, theta_full = relation.chunk(3, -1)
        theta = theta_full[..., : self.dim // 2]
        c, s = torch.cos(theta), torch.sin(theta)
        tp = tail.view(*tail.shape[:-1], self.dim // 2, 2)
        x, y = tp[..., 0], tp[..., 1]
        rot = torch.stack((c * x - s * y, s * x + c * y), dim=-1).reshape(*tail.shape[:-1], self.dim)
        return (rot + translate) * scale

    def score(self, x):
        h = F.normalize(self.entity(x[:, 0]), p=2, dim=-1)
        r = self.relation(x[:, 1])
        t = F.normalize(self.entity(x[:, 2]), p=2, dim=-1)
        tt = self._transform_tail(t, r)
        return -torch.linalg.vector_norm(h - tt, ord=1, dim=-1)

    def score_candidates(self, kind, a, b, cand):
        e = F.normalize(self.entity(cand), p=2, dim=-1)
        if kind == 'tail':
            h = F.normalize(self.entity(a), p=2, dim=-1)
            r = self.relation(b)
            scale, translate, theta_full = r.chunk(3, -1)
            theta = theta_full[:, : self.dim // 2]
            c, s = torch.cos(theta), torch.sin(theta)
            ep = e.view(e.shape[0], self.dim // 2, 2)
            x, y = ep[..., 0], ep[..., 1]
            rx = c[:, None, :] * x[None, :, :] - s[:, None, :] * y[None, :, :]
            ry = s[:, None, :] * x[None, :, :] + c[:, None, :] * y[None, :, :]
            rot = torch.stack((rx, ry), dim=-1).reshape(len(a), len(cand), self.dim)
            tt = (rot + translate[:, None, :]) * scale[:, None, :]
            return -torch.linalg.vector_norm(h[:, None, :] - tt, ord=1, dim=-1)
        r = self.relation(a)
        t = F.normalize(self.entity(b), p=2, dim=-1)
        tt = self._transform_tail(t, r)
        return -torch.linalg.vector_norm(e[None, :, :] - tt[:, None, :], ord=1, dim=-1)


def make_model(name: str, n_entities: int, n_relations: int, dim: int):
    n = name.lower()
    if n == 'transe':
        return TransE(n_entities, n_relations, dim)
    if n == 'distmult':
        return DistMult(n_entities, n_relations, dim)
    if n == 'complex':
        return ComplEx(n_entities, n_relations, dim)
    if n == 'rotate':
        return RotatE(n_entities, n_relations, dim)
    if n == 'pairre':
        return PairRE(n_entities, n_relations, dim)
    if n == 'compounde':
        return CompoundE(n_entities, n_relations, dim)
    raise KeyError(name)


MODEL_NAMES = ('transe', 'distmult', 'complex', 'rotate', 'pairre', 'compounde')
