from __future__ import annotations

from dataclasses import dataclass
import copy
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn

from .unlearn import affected_region


@dataclass
class SharedLocalResult:
    model: nn.Module
    seconds: float
    affected_entities: np.ndarray
    affected_relations: np.ndarray
    boundary_entities: np.ndarray
    parameter_fraction: float
    local_triples: int
    work_triples: int
    work_unique_triples: int


class GraphDPOSharedTransE(nn.Module):
    """Trainable SchemaCert view of an official GraphDPO TransE checkpoint.

    The parameter tensors are copied exactly from GraphDPO. GraphDPO stores
    forward and inverse relations as adjacent rows. Scores use the same
    normalized L1 TransE geometry. The class exposes ``entity`` and ``relation``
    embeddings so SchemaCert can mask local updates without converting the
    checkpoint to another model family.
    """

    def __init__(self, entity_weight: torch.Tensor, relation_weight: torch.Tensor):
        super().__init__()
        if entity_weight.ndim != 2 or relation_weight.ndim != 2:
            raise ValueError('GraphDPO embedding tensors must be matrices')
        if entity_weight.shape[1] != relation_weight.shape[1]:
            raise ValueError('Entity/relation embedding dimensions differ')
        if relation_weight.shape[0] % 2:
            raise ValueError('GraphDPO relation table must contain forward/inverse pairs')
        self.entity = nn.Embedding(entity_weight.shape[0], entity_weight.shape[1]).double()
        self.relation = nn.Embedding(relation_weight.shape[0], relation_weight.shape[1]).double()
        with torch.no_grad():
            self.entity.weight.copy_(entity_weight.detach().to(dtype=torch.float64, device='cpu'))
            self.relation.weight.copy_(relation_weight.detach().to(dtype=torch.float64, device='cpu'))

    @staticmethod
    def _norm(x: torch.Tensor) -> torch.Tensor:
        return F.normalize(x, p=2, dim=-1)

    def normalize_(self) -> None:
        # Official GraphDPO normalizes inside score_fun/predict rather than
        # projecting the stored parameters after each optimizer step.
        return None

    def distance(self, x: torch.Tensor) -> torch.Tensor:
        h = self._norm(self.entity(x[:, 0]))
        r = self._norm(self.relation(x[:, 1]))
        t = self._norm(self.entity(x[:, 2]))
        return torch.linalg.vector_norm(h + r - t, ord=1, dim=-1)

    def score(self, x: torch.Tensor) -> torch.Tensor:
        return -self.distance(x)

    def score_candidates(
        self, kind: str, a: torch.Tensor, b: torch.Tensor, cand: torch.Tensor
    ) -> torch.Tensor:
        e = self._norm(self.entity(cand))
        if kind == 'tail':
            h = self._norm(self.entity(a))
            r = self._norm(self.relation(b))
            return -torch.linalg.vector_norm(
                (h + r)[:, None, :] - e[None, :, :], ord=1, dim=-1
            )
        if kind == 'head':
            # The common evaluator ranks the same forward triple score s(h,r,t)
            # for both head and tail prediction, so the true-score threshold and
            # candidate scores are exactly comparable for every method.
            r = self._norm(self.relation(a))
            t = self._norm(self.entity(b))
            return -torch.linalg.vector_norm(
                e[None, :, :] + r[:, None, :] - t[:, None, :], ord=1, dim=-1
            )
        raise KeyError(kind)


def load_graphdpo_shared_checkpoint(path: str | Path) -> GraphDPOSharedTransE:
    checkpoint = torch.load(str(path), map_location='cpu')
    state = checkpoint.get('state_dict', checkpoint)
    try:
        ent = state['ent_embeddings.weight']
        rel = state['rel_embeddings.weight']
    except KeyError as exc:
        raise RuntimeError(f'{path} is not an official GraphDPO TransE checkpoint') from exc
    return GraphDPOSharedTransE(ent, rel)


def clone_shared(model: GraphDPOSharedTransE) -> GraphDPOSharedTransE:
    return copy.deepcopy(model)


def retained_positive_degrees(retain: np.ndarray, entity_ids: np.ndarray) -> dict[int, int]:
    out: dict[int, int] = {}
    for e in entity_ids:
        e = int(e)
        out[e] = int(((retain[:, 0] == e) | (retain[:, 2] == e)).sum())
    return out


def deterministic_xavier_restart(
    model: GraphDPOSharedTransE,
    retain: np.ndarray,
    selected_entities: np.ndarray,
    seed: int,
) -> tuple[GraphDPOSharedTransE, float, np.ndarray, dict[int, int]]:
    """Restart zero-positive-support selected rows before the local update.

    The restart is deterministic and request/seed controlled. It is deliberately
    a pre-update warm start, matching the theory ordering; it does not use the
    deleted triples or the retrain reference.
    """
    deg = retained_positive_degrees(retain, selected_entities)
    unsupported = np.asarray(
        [int(e) for e in selected_entities if deg[int(e)] == 0], dtype=np.int64
    )
    out = clone_shared(model)
    st = time.time()
    if len(unsupported):
        g = torch.Generator(device='cpu')
        g.manual_seed(int(seed))
        fresh = torch.empty(
            out.entity.weight.shape,
            dtype=out.entity.weight.dtype,
            device='cpu',
        )
        nn.init.xavier_normal_(fresh, generator=g)
        idx_cpu = torch.as_tensor(unsupported, dtype=torch.long)
        idx_dev = idx_cpu.to(out.entity.weight.device)
        with torch.no_grad():
            out.entity.weight[idx_dev] = fresh[idx_cpu].to(out.entity.weight.device)
        if out.entity.weight.is_cuda:
            torch.cuda.synchronize()
    return out, time.time() - st, unsupported, deg


def _graphdpo_facts(forward: np.ndarray) -> np.ndarray:
    if len(forward) == 0:
        return np.empty((0, 3), dtype=np.int64)
    if np.any(forward[:, 1] % 2 != 0):
        raise ValueError('Expected forward GraphDPO relation IDs (even rows)')
    inv = forward.copy()
    inv[:, 0] = forward[:, 2]
    inv[:, 1] = forward[:, 1] + 1
    inv[:, 2] = forward[:, 0]
    return np.concatenate([forward, inv], axis=0)


def _margin_batch(
    model: GraphDPOSharedTransE,
    positives: np.ndarray,
    n_entities: int,
    neg_ratio: int,
    margin: float,
    rng: np.random.Generator,
    device: str,
) -> torch.Tensor:
    b = len(positives)
    if b == 0:
        raise ValueError('Empty positive batch')
    # Match the public GraphDPO corruption rule, including its high bound
    # ``ent_num - 1`` (the final entity id is therefore not sampled as noise).
    high = max(1, n_entities - 1)
    neg_h = rng.integers(0, high, size=(b, neg_ratio), dtype=np.int64)
    neg_t = rng.integers(0, high, size=(b, neg_ratio), dtype=np.int64)
    choose_tail = rng.random((b, neg_ratio)) > 0.5

    h = np.where(choose_tail, positives[:, 0, None], neg_h)
    t = np.where(choose_tail, neg_t, positives[:, 2, None])
    r = np.broadcast_to(positives[:, 1, None], (b, neg_ratio))
    negatives = np.stack([h, r, t], axis=-1).reshape(-1, 3)

    p = torch.as_tensor(positives, dtype=torch.long, device=device)
    n = torch.as_tensor(negatives, dtype=torch.long, device=device)
    p_dist = model.distance(p)
    n_dist = model.distance(n).reshape(b, neg_ratio).mean(dim=1)

    # Official TransE uses MarginRankingLoss(pos_dist, mean_neg_dist, y=-1,
    # reduction='sum') and then divides by the concatenated sample count.
    loss = torch.relu(p_dist - n_dist + float(margin)).sum()
    return loss / float(b * (1 + neg_ratio))


def local_retrain_graphdpo_shared(
    model: GraphDPOSharedTransE,
    train_forward: np.ndarray,
    forget_idx: np.ndarray,
    n_entities: int,
    hops: int = 1,
    epochs: int = 5,
    batch_size: int = 1024,
    lr: float = 1e-4,
    seed: int = 17,
    device: str = 'cpu',
    neg_ratio: int = 10,
    margin: float = 8.0,
) -> tuple[SharedLocalResult, np.ndarray]:
    """SchemaCert local update on the exact GraphDPO TransE parameterization.

    Locality/work-set selection is SchemaCert's. The optimization objective is
    GraphDPO-compatible TransE: forward+inverse facts, 10-way head/tail negative
    corruption, normalized L1 distance, margin loss, and Adam. Thus the base
    checkpoint and scoring family are shared; only the unlearning update rule
    differs across methods.
    """
    ae, ar_forward, boundary, retain = affected_region(train_forward, forget_idx, hops)
    m = clone_shared(model).to(device)
    st = time.time()

    inc = np.isin(retain[:, 0], ae) | np.isin(retain[:, 2], ae)
    local_idx = np.flatnonzero(inc)
    rng_work = np.random.default_rng(seed)
    extra_n = min(len(retain), max(len(local_idx) // 2, 4096))
    if len(retain) > extra_n:
        extra_idx = rng_work.choice(len(retain), extra_n, replace=False)
    else:
        extra_idx = np.arange(len(retain), dtype=np.int64)
    work_idx = np.concatenate([local_idx, extra_idx])
    work_forward = retain[work_idx]
    facts = _graphdpo_facts(work_forward)

    em = np.zeros(tuple(m.entity.weight.shape), dtype=np.float64)
    rm = np.zeros(tuple(m.relation.weight.shape), dtype=np.float64)
    em[ae] = 1.0
    ar_all = np.unique(np.concatenate([ar_forward, ar_forward + 1])).astype(np.int64)
    rm[ar_all] = 1.0

    hooks = [
        m.entity.weight.register_hook(
            lambda g, mask=torch.as_tensor(em, dtype=m.entity.weight.dtype, device=device): g * mask
        ),
        m.relation.weight.register_hook(
            lambda g, mask=torch.as_tensor(rm, dtype=m.relation.weight.dtype, device=device): g * mask
        ),
    ]
    opt = torch.optim.Adam(m.parameters(), lr=float(lr))
    rng = np.random.default_rng(seed)
    try:
        for _ in range(int(epochs)):
            order = rng.permutation(len(facts))
            for start in range(0, len(order), int(batch_size)):
                pos = facts[order[start:start + int(batch_size)]]
                opt.zero_grad(set_to_none=True)
                loss = _margin_batch(
                    m, pos, n_entities, int(neg_ratio), float(margin), rng, device
                )
                loss.backward()
                opt.step()
    finally:
        for hook in hooks:
            hook.remove()

    if m.entity.weight.is_cuda:
        torch.cuda.synchronize()
    total = m.entity.weight.numel() + m.relation.weight.numel()
    affected = float(em.sum() + rm.sum())
    result = SharedLocalResult(
        model=m,
        seconds=time.time() - st,
        affected_entities=ae,
        affected_relations=ar_all,
        boundary_entities=boundary,
        parameter_fraction=affected / float(total),
        local_triples=int(len(local_idx)),
        work_triples=int(len(work_idx)),
        work_unique_triples=int(len(np.union1d(local_idx, extra_idx))),
    )
    return result, retain
