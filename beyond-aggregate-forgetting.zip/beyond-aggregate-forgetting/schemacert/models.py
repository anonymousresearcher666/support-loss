from __future__ import annotations
import torch
from torch import nn
import torch.nn.functional as F

class KGEModel(nn.Module):
    def score(self, triples): raise NotImplementedError
    def forward(self, triples): return self.score(triples)
    def normalize_(self): pass

class TransE(KGEModel):
    def __init__(self,n_entities,n_relations,dim=64,p=1):
        super().__init__(); self.dim=dim;self.p=p
        self.entity=nn.Embedding(n_entities,dim);self.relation=nn.Embedding(n_relations,dim)
        nn.init.uniform_(self.entity.weight,-6/(dim**0.5),6/(dim**0.5));nn.init.uniform_(self.relation.weight,-6/(dim**0.5),6/(dim**0.5));self.normalize_()
    def score(self,x):
        h=self.entity(x[:,0]);r=self.relation(x[:,1]);t=self.entity(x[:,2]);return -torch.linalg.vector_norm(h+r-t,ord=self.p,dim=-1)
    def normalize_(self):
        with torch.no_grad(): self.entity.weight[:] = F.normalize(self.entity.weight,p=2,dim=-1)

class ComplEx(KGEModel):
    def __init__(self,n_entities,n_relations,dim=64):
        super().__init__();self.dim=dim
        self.entity=nn.Embedding(n_entities,2*dim);self.relation=nn.Embedding(n_relations,2*dim)
        nn.init.xavier_uniform_(self.entity.weight);nn.init.xavier_uniform_(self.relation.weight)
    def score(self,x):
        h=self.entity(x[:,0]);r=self.relation(x[:,1]);t=self.entity(x[:,2]);hr,hi=h.chunk(2,-1);rr,ri=r.chunk(2,-1);tr,ti=t.chunk(2,-1)
        return (hr*rr*tr + hi*rr*ti + hr*ri*ti - hi*ri*tr).sum(-1)

def make_model(name,n_entities,n_relations,dim):
    n=name.lower()
    if n=='transe': return TransE(n_entities,n_relations,dim)
    if n=='complex': return ComplEx(n_entities,n_relations,dim)
    raise KeyError(name)
