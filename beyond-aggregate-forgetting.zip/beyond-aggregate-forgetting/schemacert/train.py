from __future__ import annotations
from dataclasses import dataclass
import copy,time
import numpy as np
import torch
import torch.nn.functional as F

@dataclass
class TrainStats:
    seconds: float
    losses: list[float]

def batch_iter(n,batch_size,rng):
    idx=rng.permutation(n)
    for i in range(0,n,batch_size): yield idx[i:i+batch_size]

def corrupt_tail(pos,n_entities,rng):
    neg=pos.copy();z=rng.integers(0,n_entities,size=len(pos),dtype=np.int64);z+=(z>=pos[:,2]);z%=n_entities;neg[:,2]=z;return neg

def loss_batch(model,pos,neg,l2=0.0):
    sp=model.score(pos);sn=model.score(neg);loss=F.softplus(-sp).mean()+F.softplus(sn).mean()
    if l2: loss=loss+l2*sum((p*p).mean() for p in model.parameters())
    return loss

def train_model(model,train,n_entities,epochs=5,batch_size=2048,lr=2e-3,l2=1e-6,seed=17,device='cpu',trainable_masks=None):
    model.to(device);opt=torch.optim.Adam(model.parameters(),lr=lr);rng=np.random.default_rng(seed);losses=[];st=time.time();hooks=[]
    if trainable_masks:
        for param,mask in trainable_masks:
            m=torch.as_tensor(mask,dtype=param.dtype,device=param.device);hooks.append(param.register_hook(lambda g,m=m:g*m))
    for _ in range(epochs):
        tot=0.;cnt=0
        for ids in batch_iter(len(train),batch_size,rng):
            p=train[ids];n=corrupt_tail(p,n_entities,rng);pt=torch.as_tensor(p,dtype=torch.long,device=device);nt=torch.as_tensor(n,dtype=torch.long,device=device)
            opt.zero_grad(set_to_none=True);loss=loss_batch(model,pt,nt,l2);loss.backward();opt.step();model.normalize_();tot+=float(loss.detach())*len(ids);cnt+=len(ids)
        losses.append(tot/max(cnt,1))
    for h in hooks:h.remove()
    return TrainStats(time.time()-st,losses)

def clone_model(model): return copy.deepcopy(model)
