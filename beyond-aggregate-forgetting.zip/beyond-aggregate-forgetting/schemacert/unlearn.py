from __future__ import annotations
from dataclasses import dataclass
import time
import numpy as np
import torch
from .train import clone_model, train_model


@dataclass
class UnlearnResult:
    model: torch.nn.Module
    seconds: float
    affected_entities: np.ndarray
    affected_relations: np.ndarray
    boundary_entities: np.ndarray
    parameter_fraction: float
    local_triples: int
    work_triples: int
    work_unique_triples: int


def select_forget(train, fraction, seed=17, relation_id=None):
    rng = np.random.default_rng(seed)
    if relation_id is None:
        u, c = np.unique(train[:, 1], return_counts=True)
        relation_id = int(u[np.argmax(c)])
    cand = np.flatnonzero(train[:, 1] == relation_id)
    k = max(1, int(round(fraction * len(cand))))
    tails, counts = np.unique(train[cand, 2], return_counts=True)
    order = tails[np.argsort(-counts)]
    picked = []
    for t in order:
        x = cand[train[cand, 2] == t]
        if len(x) > 1:
            picked.extend(x.tolist())
        if len(picked) >= max(2, k // 3):
            break
    picked = list(dict.fromkeys(picked))[:min(k, max(2, k // 3))]
    rem = np.array([i for i in cand if int(i) not in set(picked)])
    if len(picked) < k:
        picked += rng.choice(rem, k - len(picked), replace=False).tolist()
    return np.asarray(picked[:k], dtype=np.int64), relation_id, len(cand)


def affected_region(train, forget_idx, hops=1):
    f = train[forget_idx]
    ae = set(f[:, 0]) | set(f[:, 2])
    ar = set(f[:, 1])
    for _ in range(max(0, hops - 1)):
        # Topological expansion is entity-adjacency only.  A retained triple
        # enters the next hop when it shares a head/tail entity with the
        # current affected entity set; sharing only a relation is not enough.
        mask = np.isin(train[:, 0], list(ae)) | np.isin(train[:, 2], list(ae))
        x = train[mask]
        ae |= set(x[:, 0]) | set(x[:, 2])
        ar |= set(x[:, 1])
    retain = np.delete(train, forget_idx, axis=0)
    bm = np.isin(retain[:, 0], list(ae)) | np.isin(retain[:, 2], list(ae))
    b = retain[bm]
    boundary = np.unique(np.r_[b[:, 0], b[:, 2]]) if len(b) else np.array([], dtype=np.int64)
    return (
        np.array(sorted(ae), dtype=np.int64),
        np.array(sorted(ar), dtype=np.int64),
        boundary,
        retain,
    )


def local_retrain(
    model,
    train,
    forget_idx,
    n_entities,
    hops=1,
    epochs=3,
    batch_size=2048,
    lr=1e-3,
    l2=1e-6,
    seed=17,
    device='cpu',
):
    ae, ar, boundary, retain = affected_region(train, forget_idx, hops)
    m = clone_model(model)
    st = time.time()

    # IMPORTANT: locality is defined through shared ENTITIES only.
    # A triple elsewhere in the KG that merely uses the same relation is not
    # part of the affected local context. This prevents relation-wide blow-up
    # for frequent relations and matches the standard topological notion of a
    # local KG neighbourhood.
    inc = np.isin(retain[:, 0], ae) | np.isin(retain[:, 2], ae)
    local_idx = np.flatnonzero(inc)

    rng = np.random.default_rng(seed)
    extra_n = min(len(retain), max(len(local_idx) // 2, 4096))
    if len(retain) > extra_n:
        extra_idx = rng.choice(len(retain), extra_n, replace=False)
    else:
        extra_idx = np.arange(len(retain), dtype=np.int64)

    work_idx = np.concatenate([local_idx, extra_idx])
    work = retain[work_idx]

    em = np.zeros_like(m.entity.weight.detach().cpu().numpy())
    rm = np.zeros_like(m.relation.weight.detach().cpu().numpy())
    em[ae] = 1
    rm[ar] = 1

    stats = train_model(
        m,
        work,
        n_entities,
        epochs,
        batch_size,
        lr,
        l2,
        seed,
        device,
        [(m.entity.weight, em), (m.relation.weight, rm)],
    )

    total = m.entity.weight.numel() + m.relation.weight.numel()
    affected = em.sum() + rm.sum()

    result = UnlearnResult(
        model=m,
        seconds=time.time() - st,
        affected_entities=ae,
        affected_relations=ar,
        boundary_entities=boundary,
        parameter_fraction=float(affected / total),
        local_triples=int(len(local_idx)),
        work_triples=int(len(work_idx)),
        work_unique_triples=int(len(np.union1d(local_idx, extra_idx))),
    )
    return result, retain, stats
