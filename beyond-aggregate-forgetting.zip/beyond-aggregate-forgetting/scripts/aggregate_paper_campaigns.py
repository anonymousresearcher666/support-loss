#!/usr/bin/env python3
"""Build paper-ready aggregates without copying raw experiment CSV files."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd


CAMPAIGNS = {
    "local5_original": {
        "directories": ["relation128", "policy128"],
        "local_epochs": 5,
        "expected_rows": 864,
    },
    "local5_entitylocal_v2": {
        "directories": ["relation128_entitylocal_v2", "policy128_entitylocal_v2"],
        "local_epochs": 5,
        "expected_rows": 864,
    },
    "local10_targeted": {
        "directories": ["targeted_local10_entitylocal_v2"],
        "local_epochs": 10,
        "expected_rows": 180,
    },
}

BASE_REQUIRED = {
    "dataset",
    "model",
    "policy",
    "seed",
    "fraction",
    "forget_n",
    "train_triples",
    "mrr_gap_to_reference",
    "forget_score_gap_to_reference",
    "parameter_fraction",
    "speedup_vs_reference",
}

KEY = ["dataset", "model", "policy", "seed", "target_fraction"]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_campaign(root: Path, name: str, spec: dict) -> tuple[pd.DataFrame, pd.DataFrame]:
    frames: list[pd.DataFrame] = []
    manifest: list[dict] = []

    for directory in spec["directories"]:
        source = root / directory
        if not source.is_dir():
            raise SystemExit(f"Missing result directory: {source}")

        for path in sorted(source.rglob("*.csv")):
            record = {
                "campaign": name,
                "source_directory": directory,
                "source_file": str(path.relative_to(source)),
                "sha256": sha256(path),
            }
            try:
                frame = pd.read_csv(path)
            except Exception as exc:  # preserve the failure in the manifest
                record.update(status="unreadable", rows=None, detail=str(exc))
                manifest.append(record)
                continue

            missing = sorted(BASE_REQUIRED.difference(frame.columns))
            if len(frame) != 4 or missing:
                record.update(
                    status="excluded_non_run_csv",
                    rows=len(frame),
                    detail=(f"missing={missing}" if missing else "expected four rows"),
                )
                manifest.append(record)
                continue

            schema = "entitylocal_v2" if "result_schema_version" in frame.columns else "legacy"
            record.update(status="included", rows=len(frame), detail="", schema=schema)
            manifest.append(record)
            if "target_fraction" not in frame.columns:
                frame["target_fraction"] = frame["fraction"]
            if "actual_fraction" not in frame.columns:
                frame["actual_fraction"] = frame["forget_n"] / frame["train_triples"]
            if "forget_mrr_gap_to_reference" not in frame.columns:
                frame["forget_mrr_gap_to_reference"] = float("nan")
            if "work_unique_fraction" not in frame.columns:
                frame["work_unique_fraction"] = float("nan")
            frame["source_directory"] = directory
            frame["source_file"] = str(path.relative_to(source))
            frames.append(frame)

    if not frames:
        raise SystemExit(f"No valid run CSVs found for {name}")

    data = pd.concat(frames, ignore_index=True)
    duplicate_mask = data.duplicated(KEY, keep=False)
    if duplicate_mask.any():
        duplicate_report = data.loc[
            duplicate_mask, KEY + ["source_directory", "source_file"]
        ].sort_values(KEY)
        print(f"\nDuplicate configurations in {name}:\n{duplicate_report.to_string(index=False)}")
        raise SystemExit(
            f"Refusing to aggregate {name}: duplicated configuration keys detected"
        )

    expected = int(spec["expected_rows"])
    if len(data) != expected:
        raise SystemExit(
            f"{name}: expected {expected} configurations, found {len(data)}. "
            "Inspect source_manifest.csv after resolving the input set."
        )

    data["local_epochs"] = int(spec["local_epochs"])
    data = data.rename(
        columns={
            "mrr_gap_to_reference": "global_gap",
            "forget_mrr_gap_to_reference": "forgotten_mrr_gap",
            "forget_score_gap_to_reference": "forgotten_score_gap",
            "work_unique_fraction": "unique_work",
            "speedup_vs_reference": "speedup",
        }
    )
    return data, pd.DataFrame(manifest)


def aggregates(data: pd.DataFrame) -> dict[str, pd.DataFrame]:
    by_fraction = (
        data.groupby(["dataset", "model", "policy", "target_fraction"], as_index=False)
        .agg(
            n=("global_gap", "size"),
            actual_fraction=("actual_fraction", "mean"),
            global_gap_mean=("global_gap", "mean"),
            global_gap_std=("global_gap", "std"),
            forgotten_mrr_gap_mean=("forgotten_mrr_gap", "mean"),
            forgotten_mrr_gap_std=("forgotten_mrr_gap", "std"),
            forgotten_score_gap_mean=("forgotten_score_gap", "mean"),
            forgotten_score_gap_std=("forgotten_score_gap", "std"),
            parameter_fraction=("parameter_fraction", "mean"),
            unique_work=("unique_work", "mean"),
            speedup=("speedup", "mean"),
        )
        .sort_values(["dataset", "model", "policy", "target_fraction"])
    )

    def headline(group: list[str]) -> pd.DataFrame:
        return (
            data.groupby(group, as_index=False)
            .agg(
                n=("global_gap", "size"),
                global_gap_mean=("global_gap", "mean"),
                global_gap_std=("global_gap", "std"),
                global_gap_median=("global_gap", "median"),
                forgotten_mrr_gap_mean=("forgotten_mrr_gap", "mean"),
                forgotten_mrr_gap_std=("forgotten_mrr_gap", "std"),
                forgotten_mrr_gap_median=("forgotten_mrr_gap", "median"),
                forgotten_score_gap_mean=("forgotten_score_gap", "mean"),
                forgotten_score_gap_std=("forgotten_score_gap", "std"),
                forgotten_score_gap_median=("forgotten_score_gap", "median"),
                parameter_fraction_mean=("parameter_fraction", "mean"),
                unique_work_mean=("unique_work", "mean"),
                speedup_mean=("speedup", "mean"),
            )
            .sort_values(group)
        )

    return {
        "aggregate_by_dataset_model_policy_fraction.csv": by_fraction,
        "headline_by_dataset_model_policy.csv": headline(["dataset", "model", "policy"]),
        "headline_by_model_policy.csv": headline(["model", "policy"]),
        "headline_by_policy.csv": headline(["policy"]),
    }


def summarize(data: pd.DataFrame, manifest: pd.DataFrame, name: str, spec: dict) -> dict:
    summary = {
        "campaign": name,
        "protocol": {
            "local_epochs": int(spec["local_epochs"]),
            "source_directories": spec["directories"],
        },
        "raw_files_examined": int(len(manifest)),
        "raw_files_included": int((manifest["status"] == "included").sum()),
        "raw_files_excluded": int((manifest["status"] != "included").sum()),
        "configurations": int(len(data)),
        "datasets": sorted(data["dataset"].astype(str).unique().tolist()),
        "models": sorted(data["model"].astype(str).unique().tolist()),
        "policies": sorted(data["policy"].astype(str).unique().tolist()),
        "seeds": sorted(int(x) for x in data["seed"].unique()),
        "target_fractions": sorted(float(x) for x in data["target_fraction"].unique()),
        "policy_counts": {
            str(k): int(v) for k, v in data["policy"].value_counts().sort_index().items()
        },
        "metric_availability": {
            "global_mrr_gap": bool(data["global_gap"].notna().any()),
            "forgotten_set_mrr_gap": bool(data["forgotten_mrr_gap"].notna().any()),
            "forgotten_score_gap": bool(data["forgotten_score_gap"].notna().any()),
            "unique_work_fraction": bool(data["unique_work"].notna().any()),
        },
    }
    for column in ["dim", "epochs", "extended_diagnostics"]:
        if column in data.columns:
            values = data[column].dropna().unique().tolist()
            summary["protocol"][column] = [
                value.item() if hasattr(value, "item") else value for value in values
            ]

    if {
        "full_finetune_mrr_gap_to_reference",
        "forget_full_finetune_mrr_gap_to_reference",
    }.issubset(data.columns):
        global_valid = data["full_finetune_mrr_gap_to_reference"].notna()
        forget_valid = data["forget_full_finetune_mrr_gap_to_reference"].notna()
        if global_valid.any():
            summary["local_at_least_as_close_as_full_finetune_global_rate"] = float(
                (
                    data.loc[global_valid, "global_gap"]
                    <= data.loc[global_valid, "full_finetune_mrr_gap_to_reference"]
                ).mean()
            )
        if forget_valid.any():
            summary["local_at_least_as_close_as_full_finetune_forgotten_rate"] = float(
                (
                    data.loc[forget_valid, "forgotten_mrr_gap"]
                    <= data.loc[forget_valid, "forget_full_finetune_mrr_gap_to_reference"]
                ).mean()
            )
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path("results_cluster"))
    parser.add_argument(
        "--output", type=Path, default=Path("paper_aggregates/main")
    )
    args = parser.parse_args()

    args.output.mkdir(parents=True, exist_ok=True)
    for name, spec in CAMPAIGNS.items():
        data, manifest = load_campaign(args.root, name, spec)
        destination = args.output / name
        destination.mkdir(parents=True, exist_ok=True)

        manifest.to_csv(destination / "source_manifest.csv", index=False)
        tables = aggregates(data)
        for filename, table in tables.items():
            table.to_csv(destination / filename, index=False, float_format="%.9g")

        summary = summarize(data, manifest, name, spec)
        (destination / "aggregation_summary.json").write_text(
            json.dumps(summary, indent=2) + "\n", encoding="utf-8"
        )
        print(
            f"{name}: {summary['raw_files_included']} run files, "
            f"{summary['configurations']} configurations -> {destination}"
        )


if __name__ == "__main__":
    main()
