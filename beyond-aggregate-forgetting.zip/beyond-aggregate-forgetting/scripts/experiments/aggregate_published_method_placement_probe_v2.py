
#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np


METHODS = ("Finetune", "GraphDPO", "SGU")


def load_cell_rows(path: Path):
    with path.open(newline="", encoding="utf8") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        raise RuntimeError(f"Empty CSV: {path}")
    return rows


def paired_vectors(rows, method: str):
    rr = [r for r in rows if r["method"] == method]
    if not rr:
        raise RuntimeError(f"No rows for method={method}")
    by_probe = {}
    for r in rr:
        pid = int(r["probe_id"])
        by_probe.setdefault(pid, {})[r["side"]] = r
    did = []
    target = []
    control = []
    for pid in sorted(by_probe):
        sides = by_probe[pid]
        if set(sides) != {"head", "tail"}:
            raise RuntimeError(f"probe_id={pid}: expected head+tail, got {sorted(sides)}")
        did.append(np.mean([float(sides[s]["did"]) for s in ("head", "tail")]))
        target.append(np.mean([float(sides[s]["target_promotion"]) for s in ("head", "tail")]))
        control.append(np.mean([float(sides[s]["control_promotion"]) for s in ("head", "tail")]))
    return np.asarray(did), np.asarray(target), np.asarray(control)


def ci(x):
    return [float(np.quantile(x, .025)), float(np.quantile(x, .975))]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--expected-cells", type=int, default=6)
    p.add_argument("--n-boot", type=int, default=10000)
    p.add_argument("--seed", type=int, default=19092026)
    args = p.parse_args()

    jsons = sorted(args.root.rglob("*_published_placement_v2.json"))
    print(f"W9_V2_DISCOVERY root={args.root} found={len(jsons)}", flush=True)
    for jp in jsons:
        print(f"W9_V2_DISCOVERED {jp}", flush=True)
    if len(jsons) != args.expected_cells:
        raise RuntimeError(
            f"Expected {args.expected_cells} W9 JSONs, found {len(jsons)} under {args.root}"
        )

    cells = []
    seen = set()
    for jp in jsons:
        meta = json.loads(jp.read_text())
        matching = meta.get("matching", {})
        if matching.get("matching_version") != "exact-retained-degree-v2":
            raise RuntimeError(f"{jp}: not an exact-retained-degree-v2 cell")
        if float(matching.get("mean_abs_retained_degree_mismatch", -1)) != 0.0:
            raise RuntimeError(f"{jp}: retained-degree balance gate failed")
        if int(matching.get("probed_pairs", 0)) < 128:
            raise RuntimeError(f"{jp}: fewer than 128 exact matched pairs")
        key = (meta["dataset"], int(meta["request_seed"]))
        if key in seen:
            raise RuntimeError(f"Duplicate cell {key}")
        seen.add(key)
        cp = Path(meta["rows_csv"])
        if not cp.is_file():
            cp = jp.with_name(jp.stem + "_rows.csv")
        rows = load_cell_rows(cp)
        methods = {r["method"] for r in rows}
        if methods != set(METHODS):
            raise RuntimeError(f"{cp}: methods={sorted(methods)}")
        cells.append({"meta": meta, "rows": rows, "csv": cp})

    if len(seen) != args.expected_cells:
        raise RuntimeError(f"Unique cell count mismatch: {len(seen)}")

    cell_rows = []
    vectors = {}
    for method in METHODS:
        vectors[method] = []
        for c in cells:
            did, target, control = paired_vectors(c["rows"], method)
            vectors[method].append((did, target, control))
            head = [float(r["did"]) for r in c["rows"] if r["method"] == method and r["side"] == "head"]
            tail = [float(r["did"]) for r in c["rows"] if r["method"] == method and r["side"] == "tail"]
            cell_rows.append({
                "dataset": c["meta"]["dataset"],
                "request_seed": int(c["meta"]["request_seed"]),
                "request_hash": c["meta"]["request_hash"],
                "method": method,
                "pairs": int(len(did)),
                "zero_retained_support_touched": int(c["meta"]["zero_retained_support_touched"]),
                "positive_retained_support_touched": int(c["meta"]["positive_retained_support_touched"]),
                "target_promotion": float(np.mean(target)),
                "control_promotion": float(np.mean(control)),
                "did": float(np.mean(did)),
                "head_did": float(np.mean(head)),
                "tail_did": float(np.mean(tail)),
            })

    rng = np.random.default_rng(args.seed)
    summary = {}
    for method in METHODS:
        vv = vectors[method]
        point_did = float(np.mean([np.mean(x[0]) for x in vv]))
        point_target = float(np.mean([np.mean(x[1]) for x in vv]))
        point_control = float(np.mean([np.mean(x[2]) for x in vv]))

        boot_did = np.empty(args.n_boot, dtype=float)
        boot_target = np.empty(args.n_boot, dtype=float)
        boot_control = np.empty(args.n_boot, dtype=float)

        for b in range(args.n_boot):
            d_acc = []
            t_acc = []
            c_acc = []
            for did, target, control in vv:
                ids = rng.integers(0, len(did), size=len(did))
                d_acc.append(float(np.mean(did[ids])))
                t_acc.append(float(np.mean(target[ids])))
                c_acc.append(float(np.mean(control[ids])))
            boot_did[b] = np.mean(d_acc)
            boot_target[b] = np.mean(t_acc)
            boot_control[b] = np.mean(c_acc)

        cr = [r for r in cell_rows if r["method"] == method]
        summary[method] = {
            "cells": len(cr),
            "point": {
                "target_promotion": point_target,
                "control_promotion": point_control,
                "did": point_did,
            },
            "ci95": {
                "target_promotion": ci(boot_target),
                "control_promotion": ci(boot_control),
                "did": ci(boot_did),
            },
            "positive_did_cells": int(sum(r["did"] > 0 for r in cr)),
            "negative_did_cells": int(sum(r["did"] < 0 for r in cr)),
            "zero_did_cells": int(sum(r["did"] == 0 for r in cr)),
        }

    args.out.mkdir(parents=True, exist_ok=True)

    cell_csv = args.out / "W9_V2_PUBLISHED_METHOD_PLACEMENT_CELLS.csv"
    with cell_csv.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(cell_rows[0]))
        w.writeheader()
        w.writerows(cell_rows)

    summary_rows = []
    for method in METHODS:
        s = summary[method]
        summary_rows.append({
            "method": method,
            "cells": s["cells"],
            "target_promotion": s["point"]["target_promotion"],
            "target_ci95_low": s["ci95"]["target_promotion"][0],
            "target_ci95_high": s["ci95"]["target_promotion"][1],
            "control_promotion": s["point"]["control_promotion"],
            "control_ci95_low": s["ci95"]["control_promotion"][0],
            "control_ci95_high": s["ci95"]["control_promotion"][1],
            "did": s["point"]["did"],
            "did_ci95_low": s["ci95"]["did"][0],
            "did_ci95_high": s["ci95"]["did"][1],
            "positive_did_cells": s["positive_did_cells"],
            "negative_did_cells": s["negative_did_cells"],
        })

    summary_csv = args.out / "W9_V2_PUBLISHED_METHOD_PLACEMENT_SUMMARY.csv"
    with summary_csv.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(summary_rows[0]))
        w.writeheader()
        w.writerows(summary_rows)

    payload = {
        "protocol": "published-method-placement-v2",
        "design": {
            "cells": len(cells),
            "datasets": sorted({c["meta"]["dataset"] for c in cells}),
            "request_seeds": sorted({int(c["meta"]["request_seed"]) for c in cells}),
            "methods": list(METHODS),
            "bootstrap": (
                "paired target-control probe resampling within cell; "
                "head/tail averaged within probe; equal cell weights"
            ),
            "n_boot": args.n_boot,
            "bootstrap_seed": args.seed,
        },
        "summary": summary,
        "cells_csv": str(cell_csv),
        "summary_csv": str(summary_csv),
    }
    out_json = args.out / "W9_V2_PUBLISHED_METHOD_PLACEMENT_SUMMARY.json"
    out_json.write_text(json.dumps(payload, indent=2) + "\n")

    print("=== W9-V2 PUBLISHED-METHOD PLACEMENT ===")
    for method in METHODS:
        s = summary[method]
        lo, hi = s["ci95"]["did"]
        print(
            method,
            f"target_promotion={s['point']['target_promotion']:.10f}",
            f"control_promotion={s['point']['control_promotion']:.10f}",
            f"DID={s['point']['did']:.10f}",
            f"CI95=[{lo:.10f},{hi:.10f}]",
            f"positive={s['positive_did_cells']}/{s['cells']}",
            f"negative={s['negative_did_cells']}/{s['cells']}",
        )
    print(f"json={out_json}")
    print(f"cells_csv={cell_csv}")
    print(f"summary_csv={summary_csv}")
    print("W9_V2_PUBLISHED_METHOD_PLACEMENT_AGGREGATE_OK")


if __name__ == "__main__":
    main()
