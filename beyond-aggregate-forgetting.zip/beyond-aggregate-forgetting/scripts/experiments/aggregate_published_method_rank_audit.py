#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

METHODS = ('Finetune','GraphDPO','SGU')


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    args = p.parse_args()

    files = sorted(args.root.glob('*_published_rank.json'))
    if len(files) != 6:
        raise RuntimeError(f'Expected 6 published-rank JSON files, found {len(files)}')

    cells = []
    for path in files:
        d = json.loads(path.read_text())
        for method in METHODS:
            c = d['comparisons'][method]
            cells.append({
                'dataset': d['dataset'],
                'seed': d['request_seed'],
                'method': method,
                'request_hash': d['request_hash'],
                'sampled_query_triples': d['sampled_query_triples'],
                'candidate_logrank_gap': c['mean_abs_log10_rank_gap'],
                'null_logrank_gap': c['null_mean_abs_log10_rank_gap'],
                'logrank_excess': c['logrank_excess_over_null'],
                'candidate_mrr_gap': c['mrr_gap'],
                'null_mrr_gap': c['null_mrr_gap'],
                'mrr_gap_excess': c['mrr_gap_excess_over_null'],
                'candidate_top10_disagreement': c['top10_membership_disagreement'],
                'null_top10_disagreement': c['null_top10_membership_disagreement'],
                'top10_excess': c['top10_excess_over_null'],
                'candidate_top100_disagreement': c['top100_membership_disagreement'],
                'null_top100_disagreement': c['null_top100_membership_disagreement'],
                'top100_excess': c['top100_excess_over_null'],
            })

    summary = []
    for dataset in sorted({r['dataset'] for r in cells}):
        for method in METHODS:
            rr = [r for r in cells if r['dataset'] == dataset and r['method'] == method]
            summary.append({
                'dataset': dataset,
                'method': method,
                'n_cells': len(rr),
                'candidate_logrank_gap_mean': float(np.mean([r['candidate_logrank_gap'] for r in rr])),
                'null_logrank_gap_mean': float(np.mean([r['null_logrank_gap'] for r in rr])),
                'logrank_excess_mean': float(np.mean([r['logrank_excess'] for r in rr])),
                'logrank_positive_excess_cells': int(sum(r['logrank_excess'] > 0 for r in rr)),
                'candidate_mrr_gap_mean': float(np.mean([r['candidate_mrr_gap'] for r in rr])),
                'null_mrr_gap_mean': float(np.mean([r['null_mrr_gap'] for r in rr])),
                'top10_excess_mean': float(np.mean([r['top10_excess'] for r in rr])),
                'top100_excess_mean': float(np.mean([r['top100_excess'] for r in rr])),
            })

    overall = []
    for method in METHODS:
        rr = [r for r in cells if r['method'] == method]
        overall.append({
            'method': method,
            'n_cells': len(rr),
            'candidate_logrank_gap_mean': float(np.mean([r['candidate_logrank_gap'] for r in rr])),
            'null_logrank_gap_mean': float(np.mean([r['null_logrank_gap'] for r in rr])),
            'logrank_excess_mean': float(np.mean([r['logrank_excess'] for r in rr])),
            'logrank_positive_excess_cells': int(sum(r['logrank_excess'] > 0 for r in rr)),
            'candidate_mrr_gap_mean': float(np.mean([r['candidate_mrr_gap'] for r in rr])),
            'null_mrr_gap_mean': float(np.mean([r['null_mrr_gap'] for r in rr])),
            'top10_excess_mean': float(np.mean([r['top10_excess'] for r in rr])),
            'top100_excess_mean': float(np.mean([r['top100_excess'] for r in rr])),
        })

    args.out.mkdir(parents=True, exist_ok=True)
    for name, rows in (
        ('published_method_rank_cells.csv', cells),
        ('published_method_rank_summary.csv', summary),
        ('published_method_rank_overall.csv', overall),
    ):
        with (args.out / name).open('w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)

    payload = {'files': len(files), 'cells': cells, 'summary': summary, 'overall': overall}
    (args.out / 'SUMMARY.json').write_text(json.dumps(payload, indent=2) + '\n')

    print('=== W2 PUBLISHED-METHOD CALIBRATED RANK AUDIT ===')
    for row in overall:
        print(json.dumps(row, sort_keys=True))
    print('PUBLISHED_METHOD_RANK_AGGREGATE_OK')


if __name__ == '__main__':
    main()
