#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,json
from pathlib import Path
import numpy as np

METHODS=("ResetLocal","NegExposure20eq","NormMatchRefOracle")

def mean(xs): return float(np.mean(list(xs)))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",type=Path,required=True)
    ap.add_argument("--out",type=Path,required=True)
    args=ap.parse_args()
    files=sorted(args.root.glob("*_seed*_negative_exposure.json"))
    if len(files)!=6: raise RuntimeError(f"Expected 6 JSON files, found {len(files)}")
    rows=[]
    for p in files:
        d=json.loads(p.read_text())
        for m in METHODS:
            rows.append({
              "dataset":d["dataset"],"seed":d["seed"],"method":m,
              "selected_norm_median":d["selected_norms"][m]["median"],
              "forgotten_mrr_gap":d["forgotten"][m]["mrr_gap"],
              "forgotten_logrank_gap":d["forgotten"][m]["mean_abs_log10_rank_gap"],
              "forgotten_top10_disagreement":d["forgotten"][m]["top10_membership_disagreement"],
              "forgotten_top100_disagreement":d["forgotten"][m]["top100_membership_disagreement"],
              "test_mrr_gap":d["test"][m]["mrr_gap"],
              "test_logrank_gap":d["test"][m]["mean_abs_log10_rank_gap"],
              "expected_negative_presentations_per_entity":d["expected_negative_presentations_per_selected_entity"],
            })
    summary=[]
    for ds in sorted({r["dataset"] for r in rows}):
        for m in METHODS:
            rr=[r for r in rows if r["dataset"]==ds and r["method"]==m]
            summary.append({
              "dataset":ds,"method":m,"n_seeds":len(rr),
              "selected_norm_median":mean(r["selected_norm_median"] for r in rr),
              "forgotten_mrr_gap":mean(r["forgotten_mrr_gap"] for r in rr),
              "forgotten_logrank_gap":mean(r["forgotten_logrank_gap"] for r in rr),
              "forgotten_top10_disagreement":mean(r["forgotten_top10_disagreement"] for r in rr),
              "forgotten_top100_disagreement":mean(r["forgotten_top100_disagreement"] for r in rr),
              "test_mrr_gap":mean(r["test_mrr_gap"] for r in rr),
              "test_logrank_gap":mean(r["test_logrank_gap"] for r in rr),
            })
    contrasts=[]
    for ds in sorted({r["dataset"] for r in summary}):
        x={r["method"]:r for r in summary if r["dataset"]==ds}
        base=x["ResetLocal"]
        for m in ("NegExposure20eq","NormMatchRefOracle"):
            cur=x[m]
            contrasts.append({
              "dataset":ds,"method":m,
              "logrank_gap_before":base["forgotten_logrank_gap"],
              "logrank_gap_after":cur["forgotten_logrank_gap"],
              "logrank_reduction_fraction":1-cur["forgotten_logrank_gap"]/base["forgotten_logrank_gap"],
              "mrr_gap_before":base["forgotten_mrr_gap"],
              "mrr_gap_after":cur["forgotten_mrr_gap"],
              "test_mrr_gap_after":cur["test_mrr_gap"],
              "selected_norm_median_after":cur["selected_norm_median"],
            })
    args.out.mkdir(parents=True,exist_ok=True)
    for name,data in (("negative_exposure_cells.csv",rows),("negative_exposure_summary.csv",summary),("negative_exposure_contrasts.csv",contrasts)):
        with (args.out/name).open("w",newline="") as f:
            w=csv.DictWriter(f,fieldnames=list(data[0].keys()));w.writeheader();w.writerows(data)
    result={"files":len(files),"summary":summary,"contrasts":contrasts}
    (args.out/"SUMMARY.json").write_text(json.dumps(result,indent=2)+"\n")
    print("=== W3C NEGATIVE-EXPOSURE CONTRASTS ===")
    for r in contrasts: print(json.dumps(r,sort_keys=True))
    print("SUPPORTLOSS_NEGATIVE_EXPOSURE_AGGREGATE_OK")

if __name__=="__main__": main()
