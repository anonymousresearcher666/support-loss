#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np


def mean(xs):
    xs = list(xs)
    return float(np.mean(xs)) if xs else float("nan")


def write_csv(path: Path, rows):
    if not rows:
        return
    fields = list(rows[0].keys())
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()

    files = sorted(args.root.glob("*_seed*_specificity.json"))
    if len(files) != 6:
        raise RuntimeError(f"Expected 6 specificity JSON files, found {len(files)}")

    cells = []
    for p in files:
        d = json.loads(p.read_text())
        for model, md in d["models"].items():
            row = {
                "dataset": d["dataset"],
                "seed": d["seed"],
                "model": model,
                "selected_norm_median": md["selected_norm"]["median"],
                "selected_norm_mean": md["selected_norm"]["mean"],
                "other_norm_median": md["other_entity_norm"]["median"],
            }
            for side in ("head", "tail"):
                row[f"{side}_true_rank_median"] = md[side]["true_rank"]["median"]
                row[f"{side}_false_rank_median"] = md[side]["false_rank"]["median"]
                row[f"{side}_true_score_median"] = md[side]["true_score"]["median"]
                row[f"{side}_false_score_median"] = md[side]["false_score"]["median"]
                row[f"{side}_specificity_auc_rank"] = md[side]["specificity_auc_rank"]
                row[f"{side}_specificity_auc_score"] = md[side]["specificity_auc_score"]
                row[f"{side}_logrank_advantage"] = md[side]["median_log10_rank_advantage_true_over_false"]
            cells.append(row)

    groups = defaultdict(list)
    for r in cells:
        groups[(r["dataset"], r["model"])].append(r)

    summary = []
    for (ds, model), rs in sorted(groups.items()):
        o = {"dataset": ds, "model": model, "n_seeds": len(rs)}
        for k in cells[0]:
            if k in ("dataset", "seed", "model"):
                continue
            o[k] = mean(r[k] for r in rs)
        summary.append(o)

    contrasts = []
    for ds in sorted({r["dataset"] for r in cells}):
        rr = {r["model"]: r for r in summary if r["dataset"] == ds}
        rl = rr["ResetLocal"]
        ref = rr["Reference20"]
        contrasts.append({
            "dataset": ds,
            "selected_norm_ratio_RL_over_ref": rl["selected_norm_median"] / ref["selected_norm_median"],
            "tail_true_rank_ratio_RL_over_ref": rl["tail_true_rank_median"] / ref["tail_true_rank_median"],
            "tail_false_rank_ratio_RL_over_ref": rl["tail_false_rank_median"] / ref["tail_false_rank_median"],
            "tail_specificity_auc_rank_RL": rl["tail_specificity_auc_rank"],
            "tail_specificity_auc_rank_ref": ref["tail_specificity_auc_rank"],
            "tail_logrank_advantage_RL": rl["tail_logrank_advantage"],
            "tail_logrank_advantage_ref": ref["tail_logrank_advantage"],
            "head_true_rank_ratio_RL_over_ref": rl["head_true_rank_median"] / ref["head_true_rank_median"],
            "head_false_rank_ratio_RL_over_ref": rl["head_false_rank_median"] / ref["head_false_rank_median"],
            "head_specificity_auc_rank_RL": rl["head_specificity_auc_rank"],
            "head_specificity_auc_rank_ref": ref["head_specificity_auc_rank"],
        })

    args.out.mkdir(parents=True, exist_ok=True)
    write_csv(args.out / "specificity_cells.csv", cells)
    write_csv(args.out / "specificity_summary.csv", summary)
    write_csv(args.out / "specificity_contrasts.csv", contrasts)

    result = {
        "files": len(files),
        "cells": len(cells),
        "datasets": sorted({r["dataset"] for r in cells}),
        "models": sorted({r["model"] for r in cells}),
        "contrasts": contrasts,
        "interpretation_guide": {
            "calibration_artifact_signature": "R+L ranks deleted entities unusually high on true and matched false queries, with weak true-vs-false specificity.",
            "fact_specific_signature": "R+L ranks deleted entities substantially higher on their true deleted contexts than on matched false contexts, beyond the same contrast for Ref20.",
        },
    }
    (args.out / "SUMMARY.json").write_text(json.dumps(result, indent=2) + "\n")

    print("=== W3 SPECIFICITY CONTRASTS ===")
    for x in contrasts:
        print(json.dumps(x, sort_keys=True))
    print("SUPPORTLOSS_SPECIFICITY_AGGREGATE_OK")


if __name__ == "__main__":
    main()
