#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np


def load_rows(path: Path):
    with path.open(newline="", encoding="utf8") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        raise RuntimeError(f"Empty placement CSV: {path}")
    return rows


def arrays(rows):
    def f(k):
        return np.asarray([float(r[k]) for r in rows], dtype=float)

    lc_s = np.log10(f("candidate_selected_rank"))
    la_s = np.log10(f("refA_selected_rank"))
    lb_s = np.log10(f("refB_selected_rank"))
    lc_c = np.log10(f("candidate_control_rank"))
    la_c = np.log10(f("refA_control_rank"))
    lb_c = np.log10(f("refB_control_rank"))

    zc_s = f("candidate_selected_z")
    za_s = f("refA_selected_z")
    zb_s = f("refB_selected_z")
    zc_c = f("candidate_control_z")
    za_c = f("refA_control_z")
    zb_c = f("refB_control_z")

    sel = .5 * (la_s + lb_s) - lc_s
    ctl = .5 * (la_c + lb_c) - lc_c
    selz = zc_s - .5 * (za_s + zb_s)
    ctlz = zc_c - .5 * (za_c + zb_c)

    rc_s = f("candidate_selected_rank")
    ra_s = f("refA_selected_rank")
    rb_s = f("refB_selected_rank")
    rc_c = f("candidate_control_rank")
    ra_c = f("refA_control_rank")
    rb_c = f("refB_control_rank")

    return {
        "selected_logrank_promotion": sel,
        "control_logrank_promotion": ctl,
        "did_logrank_promotion": sel - ctl,
        "selected_z_promotion": selz,
        "control_z_promotion": ctlz,
        "did_z_promotion": selz - ctlz,
        "selected_beats_both_refs": (
            rc_s < np.minimum(ra_s, rb_s)
        ).astype(float),
        "control_beats_both_refs": (
            rc_c < np.minimum(ra_c, rb_c)
        ).astype(float),
        "selected_top100_excess": (
            (rc_s <= 100).astype(float)
            - .5 * ((ra_s <= 100).astype(float) + (rb_s <= 100).astype(float))
        ),
        "control_top100_excess": (
            (rc_c <= 100).astype(float)
            - .5 * ((ra_c <= 100).astype(float) + (rb_c <= 100).astype(float))
        ),
    }


def ci(x):
    return [float(np.quantile(x, .025)), float(np.quantile(x, .975))]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--n-boot", type=int, default=10000)
    ap.add_argument("--seed", type=int, default=21092026)
    args = ap.parse_args()

    files = sorted(args.root.glob("*_placement.csv"))
    if len(files) != 36:
        raise RuntimeError(f"Expected 36 placement CSVs, found {len(files)}")

    cells = []
    for p in files:
        rows = load_rows(p)
        key = (
            rows[0]["dataset"], int(rows[0]["seed"]),
            rows[0]["mode"], rows[0]["request_hash"]
        )
        a = arrays(rows)
        cells.append({"key": key, "path": p, "rows": rows, "arrays": a})

    metrics = list(cells[0]["arrays"])
    point = {
        k: float(np.mean([np.mean(c["arrays"][k]) for c in cells]))
        for k in metrics
    }
    positive_cells = {
        k: int(sum(np.mean(c["arrays"][k]) > 0 for c in cells))
        for k in metrics
    }

    rng = np.random.default_rng(args.seed)
    dist = {k: np.empty(args.n_boot, dtype=float) for k in metrics}
    chunk = 250
    for st in range(0, args.n_boot, chunk):
        en = min(args.n_boot, st + chunk)
        size = en - st
        acc = {k: np.zeros(size, dtype=float) for k in metrics}
        for c in cells:
            n = len(c["rows"])
            ids = rng.integers(0, n, size=(size, n))
            for k in metrics:
                acc[k] += c["arrays"][k][ids].mean(axis=1)
        for k in metrics:
            dist[k][st:en] = acc[k] / len(cells)

    # Side-specific point estimates, useful to check whether promotion depends on
    # predicting head versus tail.
    side_point = {}
    for side in ("head", "tail"):
        vals = {}
        for k in metrics:
            cell_means = []
            for c in cells:
                mask = np.asarray([r["side"] == side for r in c["rows"]], dtype=bool)
                cell_means.append(float(np.mean(c["arrays"][k][mask])))
            vals[k] = float(np.mean(cell_means))
        side_point[side] = vals

    # Construction-wise mechanism strength.
    construction = {}
    for mode in sorted({c["key"][2] for c in cells}):
        cc = [c for c in cells if c["key"][2] == mode]
        construction[mode] = {
            k: {
                "mean": float(np.mean([np.mean(c["arrays"][k]) for c in cc])),
                "positive_cells": int(sum(np.mean(c["arrays"][k]) > 0 for c in cc)),
                "cells": len(cc),
            }
            for k in ("selected_logrank_promotion", "did_logrank_promotion")
        }

    result = {
        "design": {
            "cells": 36,
            "probe_unit": "paired restarted entity and degree-matched unaffected control in a deletion-disjoint context",
            "context_scope": "original context head/tail outside the deletion-selected entity set; inserted selected/control triples absent from train/valid/test",
            "rank": "unfiltered mean-tie full-vocabulary rank",
            "bootstrap": "within-cell probe resampling, equal-weight mean over 36 fixed cells",
            "n_boot": args.n_boot,
            "seed": args.seed,
        },
        "point": point,
        "ci95": {k: ci(dist[k]) for k in metrics},
        "positive_cells": positive_cells,
        "side_point": side_point,
        "construction": construction,
    }

    args.out.mkdir(parents=True, exist_ok=True)
    out_json = args.out / "PLACEMENT_PROBE_36_SUMMARY.json"
    out_json.write_text(json.dumps(result, indent=2) + "\n", encoding="utf8")

    cell_csv = args.out / "PLACEMENT_PROBE_36_CELLS.csv"
    with cell_csv.open("w", newline="", encoding="utf8") as f:
        fields = ["dataset", "seed", "mode", "request_hash"] + metrics
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for c in cells:
            ds, seed, mode, rh = c["key"]
            row = {"dataset": ds, "seed": seed, "mode": mode, "request_hash": rh}
            row.update({k: float(np.mean(c["arrays"][k])) for k in metrics})
            w.writerow(row)

    print("=== 36-CELL BACKGROUND-CONTEXT PLACEMENT PROBE ===")
    print(f"cells=36 n_boot={args.n_boot} seed={args.seed}")
    for k in metrics:
        lo, hi = result["ci95"][k]
        print(
            f"{k}={point[k]:.10f} CI95=[{lo:.10f},{hi:.10f}] "
            f"positive_cells={positive_cells[k]}/36"
        )
    print("\n[SIDES]")
    for side in ("head", "tail"):
        print(
            side,
            "selected_logrank_promotion=",
            f"{side_point[side]['selected_logrank_promotion']:.10f}",
            "DID=",
            f"{side_point[side]['did_logrank_promotion']:.10f}",
        )
    print("\n[CONSTRUCTIONS]")
    for mode, rec in construction.items():
        x = rec["did_logrank_promotion"]
        print(
            mode,
            f"DID={x['mean']:.10f}",
            f"positive={x['positive_cells']}/{x['cells']}",
        )
    print(f"json={out_json}")
    print(f"cells_csv={cell_csv}")
    print("PLACEMENT_PROBE_36_OK")


if __name__ == "__main__":
    main()
