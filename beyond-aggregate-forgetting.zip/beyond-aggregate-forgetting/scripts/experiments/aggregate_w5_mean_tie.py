#!/usr/bin/env python3
from __future__ import annotations

import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd

def metrics(a_h,a_t,b_h,b_t):
    a=np.concatenate([np.asarray(a_h,float),np.asarray(a_t,float)])
    b=np.concatenate([np.asarray(b_h,float),np.asarray(b_t,float)])
    if len(a)!=len(b): raise ValueError("rank length mismatch")
    return {
      "n_rankings": int(len(a)),
      "mrr_gap": float(abs((1.0/a).mean()-(1.0/b).mean())),
      "rank_different_fraction": float((a!=b).mean()),
      "mean_abs_rank_gap": float(np.abs(a-b).mean()),
      "median_abs_rank_gap": float(np.median(np.abs(a-b))),
      "mean_abs_log10_rank_gap": float(np.abs(np.log10(a)-np.log10(b)).mean()),
      "median_abs_log10_rank_gap": float(np.median(np.abs(np.log10(a)-np.log10(b)))),
      "top10_membership_disagreement": float(((a<=10)!=(b<=10)).mean()),
      "top100_membership_disagreement": float(((a<=100)!=(b<=100)).mean()),
    }

def get(z,label,rule):
    return z[f"{label}_head_{rule}_rank"], z[f"{label}_tail_{rule}_rank"]

def bootstrap(df, cols, reps=10000, seed=20260921):
    rng=np.random.default_rng(seed)
    n=len(df)
    out={}
    for col in cols:
        x=df[col].to_numpy(float)
        vals=np.empty(reps,float)
        for i in range(reps):
            vals[i]=x[rng.integers(0,n,size=n)].mean()
        out[col]={
          "mean":float(x.mean()),
          "ci95_low":float(np.quantile(vals,.025)),
          "ci95_high":float(np.quantile(vals,.975)),
          "positive_cells":int((x>0).sum()),
          "nonnegative_cells":int((x>=0).sum()),
          "cells":int(n),
        }
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",type=Path,required=True)
    ap.add_argument("--out",type=Path,required=True)
    ap.add_argument("--bootstrap-reps",type=int,default=10000)
    args=ap.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)

    rows=[]
    for summary_path in sorted(args.root.glob("*/*/*/summary.json")):
        s=json.loads(summary_path.read_text())
        npz=summary_path.with_name("mean_tie_rank_audit.npz")
        if not npz.is_file(): raise FileNotFoundError(npz)
        z=np.load(npz,allow_pickle=False)

        base={
          "dataset":s["dataset"],"seed":int(s["seed"]),"mode":s["mode"],
          "request_hash":s["request_hash"],"forget_n":int(s["forget_n"]),
          "selected_n":int(s["selected_n"]),
        }
        bylabel={x["label"]:x for x in s["model_summaries"]}
        for rule in ("optimistic","mean_tie"):
            ch,ct=get(z,"candidate",rule)
            ah,at=get(z,"refA",rule)
            bh,bt=get(z,"refB",rule)
            cand=metrics(ch,ct,ah,at)
            null=metrics(bh,bt,ah,at)
            r={**base,"rule":rule}
            for k,v in cand.items(): r[f"candidate_{k}"]=v
            for k,v in null.items(): r[f"null_{k}"]=v
            for k in ("mrr_gap","rank_different_fraction","mean_abs_rank_gap",
                      "median_abs_rank_gap","mean_abs_log10_rank_gap",
                      "median_abs_log10_rank_gap","top10_membership_disagreement",
                      "top100_membership_disagreement"):
                r[f"excess_{k}"]=cand[k]-null[k]
            # tie diagnostics are model/rerun-specific, independent of rank rule
            for lab in ("candidate","refA","refB"):
                allrec=bylabel[lab]["all"]
                r[f"{lab}_tie_fraction"]=float(allrec["tie_fraction"])
                r[f"{lab}_mean_tie_changed_fraction"]=float(allrec["mean_tie_changed_fraction"])
                if "old_optimistic_exact_match_fraction" in allrec:
                    r[f"{lab}_old_optimistic_exact_match_fraction"]=float(allrec["old_optimistic_exact_match_fraction"])
                    r[f"{lab}_old_optimistic_max_abs_delta"]=int(allrec["old_optimistic_max_abs_delta"])
            rows.append(r)

    df=pd.DataFrame(rows)
    if len(df)!=24:
        raise RuntimeError(f"expected 24 rows (12 cells x 2 rules), got {len(df)}")
    df.to_csv(args.out/"W5_MEAN_TIE_PER_CELL.csv",index=False)

    summary={}
    for rule,g in df.groupby("rule",sort=False):
        rec={
          "cells":int(len(g)),
          "candidate_mean_abs_log10_rank_gap":float(g["candidate_mean_abs_log10_rank_gap"].mean()),
          "null_mean_abs_log10_rank_gap":float(g["null_mean_abs_log10_rank_gap"].mean()),
          "excess_mean_abs_log10_rank_gap":float(g["excess_mean_abs_log10_rank_gap"].mean()),
          "positive_excess_logrank_cells":int((g["excess_mean_abs_log10_rank_gap"]>0).sum()),
          "candidate_top10_disagreement":float(g["candidate_top10_membership_disagreement"].mean()),
          "null_top10_disagreement":float(g["null_top10_membership_disagreement"].mean()),
          "excess_top10_disagreement":float(g["excess_top10_membership_disagreement"].mean()),
          "positive_excess_top10_cells":int((g["excess_top10_membership_disagreement"]>0).sum()),
          "candidate_top100_disagreement":float(g["candidate_top100_membership_disagreement"].mean()),
          "null_top100_disagreement":float(g["null_top100_membership_disagreement"].mean()),
          "excess_top100_disagreement":float(g["excess_top100_membership_disagreement"].mean()),
          "positive_excess_top100_cells":int((g["excess_top100_membership_disagreement"]>0).sum()),
          "candidate_mrr_gap":float(g["candidate_mrr_gap"].mean()),
          "null_mrr_gap":float(g["null_mrr_gap"].mean()),
          "excess_mrr_gap":float(g["excess_mrr_gap"].mean()),
          "positive_excess_mrr_cells":int((g["excess_mrr_gap"]>0).sum()),
        }
        summary[rule]=rec

    opt=df[df.rule=="optimistic"].sort_values(["dataset","seed","mode"]).reset_index(drop=True)
    mean=df[df.rule=="mean_tie"].sort_values(["dataset","seed","mode"]).reset_index(drop=True)
    if not (opt[["dataset","seed","mode","request_hash"]].values==mean[["dataset","seed","mode","request_hash"]].values).all():
        raise RuntimeError("optimistic/mean cell mismatch")

    delta={}
    for col in (
      "candidate_mean_abs_log10_rank_gap","null_mean_abs_log10_rank_gap","excess_mean_abs_log10_rank_gap",
      "candidate_top10_membership_disagreement","null_top10_membership_disagreement","excess_top10_membership_disagreement",
      "candidate_top100_membership_disagreement","null_top100_membership_disagreement","excess_top100_membership_disagreement",
      "candidate_mrr_gap","null_mrr_gap","excess_mrr_gap",
    ):
        d=mean[col].to_numpy()-opt[col].to_numpy()
        delta[col]={
          "mean_delta":float(d.mean()),
          "max_abs_cell_delta":float(np.abs(d).max()),
          "changed_cells":int((d!=0).sum()),
        }

    tie_summary={}
    for lab in ("candidate","refA","refB"):
        x=mean[f"{lab}_tie_fraction"].to_numpy(float)
        tie_summary[lab]={
          "mean_tie_fraction":float(x.mean()),
          "max_cell_tie_fraction":float(x.max()),
          "cells_with_any_ties":int((x>0).sum()),
        }

    boot_cols=[
      "excess_mean_abs_log10_rank_gap",
      "excess_top10_membership_disagreement",
      "excess_top100_membership_disagreement",
      "excess_mrr_gap",
    ]
    bootstrap_results={}
    for rule,g in df.groupby("rule",sort=False):
        bootstrap_results[rule]=bootstrap(g,boot_cols,args.bootstrap_reps)

    result={
      "summary":summary,
      "mean_minus_optimistic":delta,
      "tie_diagnostics":tie_summary,
      "cell_bootstrap_10k":bootstrap_results,
      "note":"Bootstrap resamples the 12 fixed cells; it is conditional on these rerun models and cells."
    }
    (args.out/"W5_MEAN_TIE_SUMMARY.json").write_text(json.dumps(result,indent=2)+"\n")

    print("=== W5 MEAN-TIE AUDIT ===")
    for rule in ("optimistic","mean_tie"):
        r=summary[rule]
        print(f"\n[{rule}]")
        print(f"logrank candidate={r['candidate_mean_abs_log10_rank_gap']:.10f} null={r['null_mean_abs_log10_rank_gap']:.10f} excess={r['excess_mean_abs_log10_rank_gap']:.10f} positive={r['positive_excess_logrank_cells']}/12")
        print(f"top10   candidate={r['candidate_top10_disagreement']:.10f} null={r['null_top10_disagreement']:.10f} excess={r['excess_top10_disagreement']:.10f} positive={r['positive_excess_top10_cells']}/12")
        print(f"top100  candidate={r['candidate_top100_disagreement']:.10f} null={r['null_top100_disagreement']:.10f} excess={r['excess_top100_disagreement']:.10f} positive={r['positive_excess_top100_cells']}/12")
        print(f"MRR gap candidate={r['candidate_mrr_gap']:.10f} null={r['null_mrr_gap']:.10f} excess={r['excess_mrr_gap']:.10f} positive={r['positive_excess_mrr_cells']}/12")

    print("\n[TIES]")
    for lab,r in tie_summary.items():
        print(f"{lab}: mean={r['mean_tie_fraction']:.8f} max_cell={r['max_cell_tie_fraction']:.8f} cells_any={r['cells_with_any_ties']}/12")

    print("\n[MEAN - OPTIMISTIC]")
    for k,r in delta.items():
        print(f"{k}: mean_delta={r['mean_delta']:.12g} max_abs_cell_delta={r['max_abs_cell_delta']:.12g} changed_cells={r['changed_cells']}/12")

    print("\n[BOOTSTRAP]")
    for rule in ("optimistic","mean_tie"):
        print(rule)
        for k,r in bootstrap_results[rule].items():
            print(f" {k}: mean={r['mean']:.10f} CI=[{r['ci95_low']:.10f},{r['ci95_high']:.10f}] positive={r['positive_cells']}/12")

if __name__=="__main__":
    main()
