
#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np


def load_npz(path: Path):
    z = np.load(path, allow_pickle=False)
    out = {}
    for label in ("candidate", "refA", "refB", "refC"):
        h = np.asarray(z[f"{label}_head"], dtype=float)
        t = np.asarray(z[f"{label}_tail"], dtype=float)
        if h.shape != t.shape:
            raise RuntimeError(f"{path}: head/tail mismatch for {label}")
        out[label] = np.stack([h, t], axis=1)
    return out


def cell_contributions(arrays):
    c = arrays["candidate"]
    a = arrays["refA"]
    b = arrays["refB"]
    d = arrays["refC"]

    def qgap(x, y):
        return np.mean(np.abs(np.log10(x) - np.log10(y)), axis=1)

    cand = np.mean(
        np.stack([qgap(c, a), qgap(c, b), qgap(c, d)], axis=1),
        axis=1,
    )
    null = np.mean(
        np.stack([qgap(a, b), qgap(a, d), qgap(b, d)], axis=1),
        axis=1,
    )
    return cand, null, cand - null


def ci(x):
    return [float(np.quantile(x, .025)), float(np.quantile(x, .975))]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--expected-cells", type=int, default=12)
    p.add_argument("--n-boot", type=int, default=10000)
    p.add_argument("--seed", type=int, default=19092026)
    args = p.parse_args()

    jsons = sorted(args.root.glob("*/*/*/W10_THREE_REFERENCE_SUMMARY.json"))
    if len(jsons) != args.expected_cells:
        raise RuntimeError(
            f"Expected {args.expected_cells} W10 cells, found {len(jsons)}"
        )

    rows = []
    cells = []
    seen = set()

    for jp in jsons:
        d = json.loads(jp.read_text())
        key = (d["dataset"], int(d["seed"]), d["mode"])
        if key in seen:
            raise RuntimeError(f"Duplicate W10 cell {key}")
        seen.add(key)

        npz = jp.with_name("W10_THREE_REFERENCE_RANKS.npz")
        if not npz.is_file():
            raise FileNotFoundError(npz)
        arrays = load_npz(npz)
        cand_q, null_q, excess_q = cell_contributions(arrays)

        p0 = d["primary"]
        row = {
            "dataset": d["dataset"],
            "seed": int(d["seed"]),
            "mode": d["mode"],
            "request_hash": d["request_hash"],
            "refA_seed": int(d["reference_seeds"]["RefA"]),
            "refB_seed": int(d["reference_seeds"]["RefB"]),
            "refC_seed": int(d["reference_seeds"]["RefC"]),
            "reference_pair_mean_logrank": float(p0["reference_pair_mean_logrank"]),
            "reference_pair_sd_logrank": float(p0["reference_pair_sd_logrank"]),
            "reference_pair_min_logrank": float(p0["reference_pair_min_logrank"]),
            "reference_pair_max_logrank": float(p0["reference_pair_max_logrank"]),
            "candidate_mean_logrank_to_references": float(
                p0["candidate_mean_logrank_to_references"]
            ),
            "symmetrized_excess_mean": float(p0["symmetrized_excess_mean"]),
            "original_excess_RefA_RefB": float(p0["original_excess_RefA_RefB"]),
        }
        rows.append(row)
        cells.append(
            {
                "row": row,
                "cand_q": cand_q,
                "null_q": null_q,
                "excess_q": excess_q,
            }
        )

    if len(seen) != args.expected_cells:
        raise RuntimeError(f"Unique W10 cell count mismatch: {len(seen)}")

    point = {
        "candidate_mean_logrank_to_references": float(
            np.mean([r["candidate_mean_logrank_to_references"] for r in rows])
        ),
        "reference_pair_mean_logrank": float(
            np.mean([r["reference_pair_mean_logrank"] for r in rows])
        ),
        "symmetrized_excess_mean": float(
            np.mean([r["symmetrized_excess_mean"] for r in rows])
        ),
        "mean_within_setting_reference_pair_sd": float(
            np.mean([r["reference_pair_sd_logrank"] for r in rows])
        ),
        "median_within_setting_reference_pair_sd": float(
            np.median([r["reference_pair_sd_logrank"] for r in rows])
        ),
        "positive_symmetrized_excess_cells": int(
            sum(r["symmetrized_excess_mean"] > 0 for r in rows)
        ),
    }

    # Query-conditional bootstrap: this does not create additional training-run
    # draws. It conditions on the three trained references in each setting.
    rng = np.random.default_rng(args.seed)
    boot_c = np.empty(args.n_boot, dtype=float)
    boot_n = np.empty(args.n_boot, dtype=float)
    boot_e = np.empty(args.n_boot, dtype=float)
    for b in range(args.n_boot):
        cv = []
        nv = []
        ev = []
        for cell in cells:
            n = len(cell["cand_q"])
            ids = rng.integers(0, n, size=n)
            cv.append(float(np.mean(cell["cand_q"][ids])))
            nv.append(float(np.mean(cell["null_q"][ids])))
            ev.append(float(np.mean(cell["excess_q"][ids])))
        boot_c[b] = np.mean(cv)
        boot_n[b] = np.mean(nv)
        boot_e[b] = np.mean(ev)

    by_dataset = {}
    for ds in sorted({r["dataset"] for r in rows}):
        rr = [r for r in rows if r["dataset"] == ds]
        by_dataset[ds] = {
            "cells": len(rr),
            "candidate_mean_logrank_to_references": float(
                np.mean([x["candidate_mean_logrank_to_references"] for x in rr])
            ),
            "reference_pair_mean_logrank": float(
                np.mean([x["reference_pair_mean_logrank"] for x in rr])
            ),
            "mean_within_setting_reference_pair_sd": float(
                np.mean([x["reference_pair_sd_logrank"] for x in rr])
            ),
            "symmetrized_excess_mean": float(
                np.mean([x["symmetrized_excess_mean"] for x in rr])
            ),
            "positive_symmetrized_excess_cells": int(
                sum(x["symmetrized_excess_mean"] > 0 for x in rr)
            ),
        }

    args.out.mkdir(parents=True, exist_ok=True)

    cell_csv = args.out / "W10_THREE_REFERENCE_CELLS.csv"
    with cell_csv.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

    result = {
        "protocol": "w5-three-reference-null-v1",
        "design": {
            "cells": len(rows),
            "datasets": sorted({r["dataset"] for r in rows}),
            "seeds": sorted({int(r["seed"]) for r in rows}),
            "modes": sorted({r["mode"] for r in rows}),
            "references_per_setting": 3,
            "reference_pairs_per_setting": 3,
            "bootstrap": (
                "query-conditional paired bootstrap with head/tail kept together; "
                "equal cell weights; does not estimate additional training-run variability"
            ),
            "n_boot": args.n_boot,
            "bootstrap_seed": args.seed,
        },
        "point": point,
        "query_conditional_ci95": {
            "candidate_mean_logrank_to_references": ci(boot_c),
            "reference_pair_mean_logrank": ci(boot_n),
            "symmetrized_excess_mean": ci(boot_e),
        },
        "by_dataset": by_dataset,
        "cells_csv": str(cell_csv),
    }

    out_json = args.out / "W10_THREE_REFERENCE_SUMMARY.json"
    out_json.write_text(json.dumps(result, indent=2) + "\n")

    print("=== W10 THREE-REFERENCE NULL ===")
    print(
        f"cells={len(rows)} "
        f"candidate_mean={point['candidate_mean_logrank_to_references']:.10f} "
        f"null_mean={point['reference_pair_mean_logrank']:.10f} "
        f"sym_excess={point['symmetrized_excess_mean']:.10f} "
        f"positive={point['positive_symmetrized_excess_cells']}/{len(rows)}"
    )
    print(
        "within_setting_null_sd_mean="
        f"{point['mean_within_setting_reference_pair_sd']:.10f} "
        "median="
        f"{point['median_within_setting_reference_pair_sd']:.10f}"
    )
    lo, hi = result["query_conditional_ci95"]["symmetrized_excess_mean"]
    print(f"sym_excess_query_conditional_CI95=[{lo:.10f},{hi:.10f}]")
    for ds, rec in by_dataset.items():
        print(
            ds,
            f"candidate={rec['candidate_mean_logrank_to_references']:.10f}",
            f"null={rec['reference_pair_mean_logrank']:.10f}",
            f"null_sd={rec['mean_within_setting_reference_pair_sd']:.10f}",
            f"excess={rec['symmetrized_excess_mean']:.10f}",
            f"positive={rec['positive_symmetrized_excess_cells']}/{rec['cells']}",
        )
    print(f"json={out_json}")
    print(f"cells_csv={cell_csv}")
    print("W10_THREE_REFERENCE_AGGREGATE_OK")


if __name__ == "__main__":
    main()
