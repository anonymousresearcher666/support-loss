#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np


def per_query(npz_path: Path):
    z = np.load(npz_path)
    rc = np.asarray(z["rl_forget"], dtype=float)
    ra = np.asarray(z["refA_forget"], dtype=float)
    rb = np.asarray(z["refB_forget"], dtype=float)
    if not (len(rc) == len(ra) == len(rb)) or len(rc) % 2:
        raise RuntimeError(f"Rank-array mismatch: {npz_path}")
    n = len(rc) // 2
    # filtered_ranks returns tails first, then heads for the identical sampled queries.
    rc = np.stack([rc[:n], rc[n:]], axis=1)
    ra = np.stack([ra[:n], ra[n:]], axis=1)
    rb = np.stack([rb[:n], rb[n:]], axis=1)
    return rc, ra, rb


def cell_metrics(rc, ra, rb, ids=None):
    if ids is not None:
        rc, ra, rb = rc[ids], ra[ids], rb[ids]
    log_c = np.mean(np.abs(np.log10(rc) - np.log10(ra)))
    log_n = np.mean(np.abs(np.log10(rb) - np.log10(ra)))
    t10_c = np.mean((rc <= 10) != (ra <= 10))
    t10_n = np.mean((rb <= 10) != (ra <= 10))
    t100_c = np.mean((rc <= 100) != (ra <= 100))
    t100_n = np.mean((rb <= 100) != (ra <= 100))
    mrr_c = abs(np.mean(1.0 / rc) - np.mean(1.0 / ra))
    mrr_n = abs(np.mean(1.0 / rb) - np.mean(1.0 / ra))
    return {
        "candidate_logrank_gap": float(log_c),
        "null_logrank_gap": float(log_n),
        "logrank_excess": float(log_c - log_n),
        "candidate_top10_disagreement": float(t10_c),
        "null_top10_disagreement": float(t10_n),
        "top10_excess": float(t10_c - t10_n),
        "candidate_top100_disagreement": float(t100_c),
        "null_top100_disagreement": float(t100_n),
        "top100_excess": float(t100_c - t100_n),
        "candidate_mrr_gap": float(mrr_c),
        "null_mrr_gap": float(mrr_n),
        "mrr_excess": float(mrr_c - mrr_n),
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--expected-cells", type=int, default=6)
    p.add_argument("--n-boot", type=int, default=10000)
    p.add_argument("--seed", type=int, default=22092026)
    args = p.parse_args()

    jsons = sorted(args.root.glob("*/*/*/W7_STRONGER_TRAINING_*.json"))
    if len(jsons) != args.expected_cells:
        raise RuntimeError(
            f"Expected {args.expected_cells} stronger-training JSONs, found {len(jsons)}"
        )

    cells = []
    for jp in jsons:
        d = json.loads(jp.read_text())
        npz = jp.with_name(jp.stem + "_ranks.npz")
        if not npz.is_file():
            raise FileNotFoundError(npz)
        rc, ra, rb = per_query(npz)
        met = cell_metrics(rc, ra, rb)
        cells.append({"json": jp, "payload": d, "rc": rc, "ra": ra, "rb": rb, "metrics": met})

    metric_names = list(cells[0]["metrics"])
    point = {
        k: float(np.mean([c["metrics"][k] for c in cells]))
        for k in metric_names
    }
    positive = {
        k: int(sum(c["metrics"][k] > 0 for c in cells))
        for k in ("logrank_excess", "top10_excess", "top100_excess", "mrr_excess")
    }

    rng = np.random.default_rng(args.seed)
    dist = {k: np.empty(args.n_boot, dtype=float) for k in metric_names}
    chunk = 200
    for st in range(0, args.n_boot, chunk):
        en = min(args.n_boot, st + chunk)
        b = en - st
        acc = {k: np.zeros(b, dtype=float) for k in metric_names}
        for c in cells:
            n = len(c["rc"])
            ids = rng.integers(0, n, size=(b, n))
            # Chunk replicate loop keeps memory bounded and makes the statistic
            # identical to per-cell paired-query resampling with head/tail together.
            for j in range(b):
                m = cell_metrics(c["rc"], c["ra"], c["rb"], ids[j])
                for k in metric_names:
                    acc[k][j] += m[k]
        for k in metric_names:
            dist[k][st:en] = acc[k] / len(cells)

    ci = {
        k: [float(np.quantile(v, .025)), float(np.quantile(v, .975))]
        for k, v in dist.items()
    }

    by_dataset = {}
    for ds in sorted({c["payload"]["dataset"] for c in cells}):
        cc = [c for c in cells if c["payload"]["dataset"] == ds]
        by_dataset[ds] = {
            "cells": len(cc),
            **{
                k: float(np.mean([c["metrics"][k] for c in cc]))
                for k in ("candidate_logrank_gap", "null_logrank_gap", "logrank_excess",
                          "top10_excess", "top100_excess", "mrr_excess")
            },
            "mean_ref_epoch_abs_diff": float(np.mean([
                abs(
                    int(c["payload"]["fit"]["refA"]["best_epoch"])
                    - int(c["payload"]["fit"]["refB"]["best_epoch"])
                )
                for c in cc
            ])),
            "mean_RL_test_mrr": float(np.mean([
                float(c["payload"]["fit"]["RL"]["test_mrr"]) for c in cc
            ])),
            "mean_refA_test_mrr": float(np.mean([
                float(c["payload"]["fit"]["refA"]["test_mrr"]) for c in cc
            ])),
            "mean_refB_test_mrr": float(np.mean([
                float(c["payload"]["fit"]["refB"]["test_mrr"]) for c in cc
            ])),
            "positive_logrank_cells": int(sum(c["metrics"]["logrank_excess"] > 0 for c in cc)),
        }

    result = {
        "design": {
            "cells": len(cells),
            "datasets": sorted({c["payload"]["dataset"] for c in cells}),
            "seeds": sorted({int(c["payload"]["base_seed"]) for c in cells}),
            "training": "reciprocal DistMult 1-N softmax, d=256, Adagrad, validation early stopping",
            "bootstrap": "within-cell forgotten-query resampling; head/tail kept together; equal cell weights",
            "n_boot": args.n_boot,
            "bootstrap_seed": args.seed,
        },
        "point": point,
        "ci95": ci,
        "positive_cells": positive,
        "by_dataset": by_dataset,
    }

    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "W7_STRONGER_TRAINING_GRID_SUMMARY.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )

    with (args.out / "W7_STRONGER_TRAINING_GRID_CELLS.csv").open("w", newline="") as f:
        fields = [
            "dataset", "base_seed", "request_seed", "request_hash",
            "base_test_mrr", "RL_test_mrr", "refA_test_mrr", "refB_test_mrr",
            "base_best_epoch", "refA_best_epoch", "refB_best_epoch",
            "ref_epoch_abs_diff",
        ] + metric_names
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for c in cells:
            d = c["payload"]
            row = {
                "dataset": d["dataset"],
                "base_seed": d["base_seed"],
                "request_seed": d["request_seed"],
                "request_hash": d["request_hash"],
                "base_test_mrr": d["fit"]["base"]["test_mrr"],
                "RL_test_mrr": d["fit"]["RL"]["test_mrr"],
                "refA_test_mrr": d["fit"]["refA"]["test_mrr"],
                "refB_test_mrr": d["fit"]["refB"]["test_mrr"],
                "base_best_epoch": d["fit"]["base"]["best_epoch"],
                "refA_best_epoch": d["fit"]["refA"]["best_epoch"],
                "refB_best_epoch": d["fit"]["refB"]["best_epoch"],
                "ref_epoch_abs_diff": abs(
                    int(d["fit"]["refA"]["best_epoch"])
                    - int(d["fit"]["refB"]["best_epoch"])
                ),
                **c["metrics"],
            }
            w.writerow(row)

    print("=== W7 STRONGER-TRAINING GRID ===")
    print(
        f"cells={len(cells)} datasets={','.join(result['design']['datasets'])} "
        f"n_boot={args.n_boot} seed={args.seed}"
    )
    for k in metric_names:
        lo, hi = ci[k]
        suffix = ""
        if k in positive:
            suffix = f" positive_cells={positive[k]}/{len(cells)}"
        print(f"{k}={point[k]:.10f} CI95=[{lo:.10f},{hi:.10f}]{suffix}")
    print("[BY_DATASET]")
    for ds, rec in by_dataset.items():
        print(
            ds,
            f"candidate_logrank={rec['candidate_logrank_gap']:.10f}",
            f"null_logrank={rec['null_logrank_gap']:.10f}",
            f"logrank_excess={rec['logrank_excess']:.10f}",
            f"positive={rec['positive_logrank_cells']}/{rec['cells']}",
            f"mean_ref_epoch_abs_diff={rec['mean_ref_epoch_abs_diff']:.3f}",
            f"RL_test_mrr={rec['mean_RL_test_mrr']:.6f}",
            f"RefA_test_mrr={rec['mean_refA_test_mrr']:.6f}",
            f"RefB_test_mrr={rec['mean_refB_test_mrr']:.6f}",
        )
    print(f"json={args.out/'W7_STRONGER_TRAINING_GRID_SUMMARY.json'}")
    print(f"cells_csv={args.out/'W7_STRONGER_TRAINING_GRID_CELLS.csv'}")
    print("W7_STRONGER_TRAINING_GRID_OK")


if __name__ == "__main__":
    main()
