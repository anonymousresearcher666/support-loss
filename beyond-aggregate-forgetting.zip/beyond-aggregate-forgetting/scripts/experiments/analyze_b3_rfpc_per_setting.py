#!/usr/bin/env python3
"""B3 reanalysis for historical RFPC results.

Read-only scanner over the W8 artifact tree. It attempts to identify one
median and one mean RFPC result per primary 36-setting cell and computes
per-setting reductions under the paper's equal-setting convention.

The script fails closed if it cannot uniquely recover all 36 cells/rule.
"""
from __future__ import annotations
import argparse, csv, json, math, re
from pathlib import Path
import numpy as np

DATASETS=("FB15K-237","CoDEx-M","NELL-995")
SEEDS=(17,29,43)
MODES=("fullstar-low","fullstar-mid","fullstar-high","exact-card-high")
RULES=("median","mean")

ALIASES={
 "FB15K-237":["fb15k-237","fb15k237","fb15k"],
 "CoDEx-M":["codex-m","codex_m","codexm"],
 "NELL-995":["nell-995","nell_995","nell995","nell"],
}
MODE_ALIASES={
 "fullstar-low":["fullstar-low","low-degree","low_degree","low"],
 "fullstar-mid":["fullstar-mid","mid-degree","mid_degree","mid"],
 "fullstar-high":["fullstar-high","high-degree","high_degree","high"],
 "exact-card-high":["exact-card-high","exact_card_high","exact-cardinality","exact"],
}

def normkey(s): return re.sub(r"[^a-z0-9]+","",str(s).lower())

def first(d, names):
    if not isinstance(d,dict): return None
    nk={normkey(k):k for k in d}
    for name in names:
        k=nk.get(normkey(name))
        if k is not None:
            return d[k]
    return None

def infer_dataset(path, rec):
    vals=[str(path), *(str(v) for k,v in rec.items() if normkey(k) in {"dataset","graph"})]
    low=" ".join(vals).lower()
    for ds,aa in ALIASES.items():
        if any(a in low for a in aa): return ds
    return None

def infer_seed(path, rec):
    v=first(rec,["seed","base_seed","training_seed"])
    if v is not None:
        try:
            z=int(float(v))
            if z in SEEDS:return z
        except: pass
    m=re.search(r"(?:seed|s)[_\-]?(17|29|43)(?:\D|$)",str(path).lower())
    return int(m.group(1)) if m else None

def infer_mode(path, rec):
    v=first(rec,["mode","construction","request_mode","request_type"])
    low=(" ".join([str(path),str(v or "")])).lower()
    # exact before generic high
    for mode in ("exact-card-high","fullstar-low","fullstar-mid","fullstar-high"):
        if any(a in low for a in MODE_ALIASES[mode]): return mode
    return None

def infer_rule(path, rec):
    v=first(rec,["delta_rule","rule","rfpc_rule"])
    low=(" ".join([str(path),str(v or "")])).lower()
    if "median" in low:return "median"
    if re.search(r"(^|[^a-z])mean([^a-z]|$)",low):return "mean"
    return None

def walk_json(obj, prefix=()):
    if isinstance(obj,dict):
        yield prefix,obj
        for k,v in obj.items():
            yield from walk_json(v,prefix+(str(k),))
    elif isinstance(obj,list):
        for i,v in enumerate(obj):
            yield from walk_json(v,prefix+(str(i),))

def candidate_records_json(p):
    try: obj=json.loads(p.read_text(errors="ignore"))
    except: return []
    out=[]
    for pref,d in walk_json(obj):
        if not isinstance(d,dict):continue
        keys={normkey(k) for k in d}
        if keys & {
            "logrankexcess","candidatelogrank","nulllogrank",
            "beforelogrankexcess","afterlogrankexcess","rfpclogrankexcess"
        }:
            rec=dict(d); rec["_json_path"]=".".join(pref); out.append(rec)
    return out

def candidate_records_csv(p):
    try:
        with p.open(newline="",encoding="utf8",errors="ignore") as f:
            return list(csv.DictReader(f))
    except:return []

def fnum(x):
    try:
        z=float(x)
        return z if math.isfinite(z) else None
    except:return None

def extract_metrics(rec):
    # after-RFPC values
    excess=fnum(first(rec,[
        "logrank_excess","log_rank_excess","rfpc_logrank_excess",
        "after_logrank_excess","residual_logrank_excess"
    ]))
    cand=fnum(first(rec,[
        "candidate_logrank","candidate_log_rank","rfpc_candidate_logrank",
        "after_candidate_logrank"
    ]))
    null=fnum(first(rec,["null_logrank","null_log_rank","refb_refa_logrank"]))
    if excess is None and cand is not None and null is not None:
        excess=cand-null

    before=fnum(first(rec,[
        "baseline_logrank_excess","before_logrank_excess","pre_logrank_excess",
        "uncorrected_logrank_excess","rl_logrank_excess"
    ]))
    # sometimes before candidate/null are stored
    bc=fnum(first(rec,["baseline_candidate_logrank","before_candidate_logrank","rl_candidate_logrank"]))
    bn=fnum(first(rec,["baseline_null_logrank","before_null_logrank"]))
    if before is None and bc is not None:
        before=bc-(bn if bn is not None else (null if null is not None else 0.0))
    return before,excess,cand,null

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",type=Path,required=True)
    ap.add_argument("--out",type=Path,required=True)
    args=ap.parse_args()
    root=args.root.resolve()
    rows=[]
    for p in root.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in {".json",".csv"}:continue
        low=str(p).lower()
        if "aggregate_bootstrap" in low: continue
        recs=candidate_records_json(p) if p.suffix.lower()==".json" else candidate_records_csv(p)
        for rec in recs:
            ds=infer_dataset(p,rec); seed=infer_seed(p,rec); mode=infer_mode(p,rec); rule=infer_rule(p,rec)
            if None in (ds,seed,mode,rule):continue
            before,after,cand,null=extract_metrics(rec)
            if after is None:continue
            rows.append({
                "dataset":ds,"seed":seed,"mode":mode,"rule":rule,
                "before_excess":before,"after_excess":after,
                "candidate_logrank":cand,"null_logrank":null,
                "source":str(p),"record_path":str(rec.get("_json_path","")),
            })

    # Deduplicate exact cell/rule. Prefer rows that include before and null.
    chosen={}
    conflicts=[]
    for r in rows:
        key=(r["dataset"],r["seed"],r["mode"],r["rule"])
        score=sum(r[k] is not None for k in ("before_excess","candidate_logrank","null_logrank"))
        if key not in chosen or score>chosen[key][0]:
            chosen[key]=(score,r)
        elif score==chosen[key][0]:
            old=chosen[key][1]
            if abs(old["after_excess"]-r["after_excess"])>1e-10:
                conflicts.append({"key":key,"a":old,"b":r})

    expected={(d,s,m,r) for d in DATASETS for s in SEEDS for m in MODES for r in RULES}
    missing=sorted(expected-set(chosen))
    if conflicts:
        raise RuntimeError("Conflicting per-cell W8 rows; inspect output manually: "+json.dumps(conflicts[:3]))
    if missing:
        diagnostic={
            "found_unique":len(chosen),"expected":72,"missing":[list(x) for x in missing],
            "sample_candidates":rows[:40],
        }
        args.out.mkdir(parents=True,exist_ok=True)
        (args.out/"B3_RFPC_EXTRACTION_DIAGNOSTIC.json").write_text(json.dumps(diagnostic,indent=2)+"\n")
        raise RuntimeError(f"Could not recover all 72 cell/rule results; found {len(chosen)}. See diagnostic.")

    cellrows=[chosen[k][1] for k in sorted(chosen)]
    # Baseline can be recovered from historical primary W5 per-cell data only if
    # W8 row stores it. If absent, fail closed rather than fabricate reductions.
    no_before=[r for r in cellrows if r["before_excess"] is None]
    if no_before:
        diagnostic={"missing_before_excess":no_before[:30]}
        args.out.mkdir(parents=True,exist_ok=True)
        (args.out/"B3_RFPC_EXTRACTION_DIAGNOSTIC.json").write_text(json.dumps(diagnostic,indent=2)+"\n")
        raise RuntimeError("Recovered RFPC residuals but not per-cell pre-RFPC excess. Need to join primary W5 cells.")

    for r in cellrows:
        b=r["before_excess"]; a=r["after_excess"]
        r["reduction"]=(b-a)/b if b!=0 else float("nan")

    summary={"cells_per_rule":36,"rules":{}}
    for rule in RULES:
        rr=[r for r in cellrows if r["rule"]==rule]
        red=np.array([r["reduction"] for r in rr],float)
        summary["rules"][rule]={
            "mean_reduction":float(np.mean(red)),
            "median_reduction":float(np.median(red)),
            "min_reduction":float(np.min(red)),
            "max_reduction":float(np.max(red)),
            "gt_50_count":int(np.sum(red>.5)),
            "ge_50_count":int(np.sum(red>=.5)),
            "ratio_of_equal_setting_mean_excesses":float(1-np.mean([r["after_excess"] for r in rr])/np.mean([r["before_excess"] for r in rr])),
            "mean_before_excess":float(np.mean([r["before_excess"] for r in rr])),
            "mean_after_excess":float(np.mean([r["after_excess"] for r in rr])),
            "by_construction":{},
            "by_dataset":{},
        }
        for mode in MODES:
            x=[r for r in rr if r["mode"]==mode]
            z=np.array([r["reduction"] for r in x],float)
            summary["rules"][rule]["by_construction"][mode]={
                "mean_before_excess":float(np.mean([r["before_excess"] for r in x])),
                "mean_after_excess":float(np.mean([r["after_excess"] for r in x])),
                "mean_reduction":float(np.mean(z)),
                "median_reduction":float(np.median(z)),
                "gt_50_count":int(np.sum(z>.5)),
                "cells":len(x),
                "mean_null_logrank":(
                    float(np.mean([r["null_logrank"] for r in x]))
                    if all(r["null_logrank"] is not None for r in x) else None
                ),
                "mean_candidate_logrank":(
                    float(np.mean([r["candidate_logrank"] for r in x]))
                    if all(r["candidate_logrank"] is not None for r in x) else None
                ),
            }
        for ds in DATASETS:
            x=[r for r in rr if r["dataset"]==ds]
            z=np.array([r["reduction"] for r in x],float)
            summary["rules"][rule]["by_dataset"][ds]={
                "mean_reduction":float(np.mean(z)),
                "mean_before_excess":float(np.mean([r["before_excess"] for r in x])),
                "mean_after_excess":float(np.mean([r["after_excess"] for r in x])),
            }

    args.out.mkdir(parents=True,exist_ok=True)
    (args.out/"B3_RFPC_36SETTING_SUMMARY.json").write_text(json.dumps(summary,indent=2)+"\n")
    fields=list(cellrows[0].keys())
    with (args.out/"B3_RFPC_36SETTING_CELLS.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(cellrows)

    print("=== B3 RFPC 36-SETTING REANALYSIS ===")
    for rule in RULES:
        x=summary["rules"][rule]
        print(rule,
              f"mean={100*x['mean_reduction']:.2f}%",
              f"median={100*x['median_reduction']:.2f}%",
              f"min={100*x['min_reduction']:.2f}%",
              f"max={100*x['max_reduction']:.2f}%",
              f">50={x['gt_50_count']}/36",
              f"ratio-of-means={100*x['ratio_of_equal_setting_mean_excesses']:.2f}%")
    print(args.out/"B3_RFPC_36SETTING_SUMMARY.json")
    print("B3_RFPC_REANALYSIS_OK")

if __name__=="__main__":
    main()
