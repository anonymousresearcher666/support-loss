"""Exploratory follow-up after the score/rank ablations, not preregistered.

Separates head-only and tail-only rank signals using the same held-out splits.
No model, training parameter, or result is selected with these outcomes.
"""
from pathlib import Path
import argparse,json
import numpy as np
from scripts.experiments.analyze_remaining_review_controls import attack_folds,write_csv
from scripts.experiments.diagnose_output_distinguishability import features
from scripts.experiments.collect_reference_budget_pilot import aggregate


def main():
    p=argparse.ArgumentParser();p.add_argument('--cohort',type=Path,required=True)
    p.add_argument('--controls',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();rows=[];medians=[];seeds=[17,29,43]
    for ds in ['FB15K-237','CoDEx-M']:
        P={}
        for s in seeds:
            for label in ['ResetLocal','Reference20','IndependentRef20']:
                root=a.controls if label=='IndependentRef20' else a.cohort
                z=dict(np.load(root/ds/f'seed{s}'/f'{label}_predictions.npz'));P[s,label]=features(z)
                medians.append({'dataset':ds,'seed':s,'candidate':label,
                    'head_median_rank':float(np.median(z['forgotten_ranks'][0])),
                    'tail_median_rank':float(np.median(z['forgotten_ranks'][1]))})
        for ca,cb,name in [('ResetLocal','Reference20','update'),('Reference20','IndependentRef20','null')]:
            for side,col in [('head',[1]),('tail',[2])]:
                for f in attack_folds([P[s,ca] for s in seeds],[P[s,cb] for s in seeds],
                    [f'{ca}:{s}' for s in seeds],[f'{cb}:{s}' for s in seeds],col):
                    rows.append({'dataset':ds,'comparison':name,'rank_side':side,**f})
    out=a.out;out.mkdir(parents=True,exist_ok=True)
    summary=aggregate(rows,['dataset','comparison','rank_side'],['roc_auc'])
    med=aggregate(medians,['dataset','candidate'],['head_median_rank','tail_median_rank'])
    write_csv(out/'directional_folds.csv',rows);write_csv(out/'directional_summary.csv',summary)
    write_csv(out/'directional_medians.csv',med)
    (out/'directional_scope.json').write_text(json.dumps({'exploratory_followup':True,
      'reason':'Rank signal remained strong in the completed primary feature ablation',
      'no_model_selection':True,'folds':len(rows),'reference_budget':20,'scope':'same tail-corruption DistMult cohort only'},indent=2)+'\n')
    print(json.dumps({'summary':summary,'median_ranks':med},indent=2))
if __name__=='__main__':main()
