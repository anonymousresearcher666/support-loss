#!/usr/bin/env python3
"""All prespecified feature ablations and same-budget controls, no test tuning.

AUC is reported in the fitted direction (not max(AUC,1-AUC)). Model and query
splits are both disjoint. The null consists of separately trained Ref20 models
from two seed groups, not identical outputs relabeled twice. Budget frontiers
are descriptive comparisons of a fixed grid, not a selected deployment policy.
"""
from __future__ import annotations
import argparse,csv,json,hashlib,itertools
from pathlib import Path
import numpy as np
from scripts.experiments.collect_reference_budget_pilot import prediction_metrics, aggregate, METHODS, DATASETS, SEEDS
from scripts.experiments.diagnose_output_distinguishability import fit_attack, roc_auc, features
from scripts.experiments.run_remaining_review_controls import CONTROL_PROTOCOL

FEATURE_SETS={'score':[0],'ranks':[1,2],'joint':[0,1,2]}


def write_csv(path,rows):
    fields=sorted(set().union(*(r.keys() for r in rows)))
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)


def attack_folds(group_a,group_b,ids_a,ids_b,feature_columns):
    """Three model-pair holdouts; a distinct query half is reserved for testing."""
    if len(group_a)!=3 or len(group_b)!=3:raise ValueError('Three paired replicates required')
    if len(set(ids_a+ids_b))!=6:raise ValueError('Distinct models required in the two groups')
    n=len(group_a[0]);order=np.random.default_rng(271828).permutation(n)
    iq,jq=order[:n//2],order[n//2:]
    if set(iq)&set(jq):raise AssertionError('Query split overlap')
    for held in range(3):
        train=[j for j in range(3) if j!=held]
        train_ids=[ids for j in train for ids in (ids_a[j],ids_b[j])]
        test_ids=[ids_a[held],ids_b[held]]
        if set(train_ids)&set(test_ids):raise AssertionError('Model split overlap')
        x=np.concatenate([g[j][iq][:,feature_columns] for j in train for g in (group_a,group_b)])
        y=np.tile(np.r_[np.ones(len(iq)),np.zeros(len(iq))],2)
        f=fit_attack(x,y)
        xt=np.concatenate([g[held][jq][:,feature_columns] for g in (group_a,group_b)])
        yt=np.r_[np.ones(len(jq)),np.zeros(len(jq))];z=f(xt)
        yield {'fold':held,'roc_auc':roc_auc(yt,z),
               'balanced_accuracy_at_zero':float(((z>=0)==yt).mean()),
               'train_models':';'.join(train_ids),'test_models':';'.join(test_ids),
               'train_queries':len(iq),'test_queries':len(jq),
               'query_split_disjoint':True,'model_split_disjoint':True,
               'solver_gradient_inf':f.gradient_inf}


def main():
    p=argparse.ArgumentParser();p.add_argument('--cohort',type=Path,required=True)
    p.add_argument('--controls',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    args=p.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    P={};Q={};manifests=[]
    for ds in DATASETS:
        for s in SEEDS:
            cp=args.cohort/ds/f'seed{s}';xp=args.controls/ds/f'seed{s}'
            cm=json.loads((cp/'COMPLETE.json').read_text());xm=json.loads((xp/'COMPLETE.json').read_text())
            if xm['protocol']!=CONTROL_PROTOCOL:raise ValueError('Unrecognized control protocol')
            if cm['forget_hash']!=xm['forget_hash'] or cm['test_query_hash']!=xm['test_query_hash']:
                raise ValueError('Different request/query input')
            for folder in (cp,xp):
                for f in sorted(folder.glob('*_predictions.npz')):
                    key=(ds,s,f.stem.removesuffix('_predictions'))
                    if key in P:raise ValueError('Duplicate model label')
                    P[key]=dict(np.load(f))
            for name in ('test','forgotten','retained'):
                arrays=[v[name+'_ranks'] for (d,se,label),v in P.items() if (d,se)==(ds,s)]
                if not all(a.shape==(2,256) and (a>=1).all() for a in arrays):raise ValueError('Bad rankings')
            raw={r['label']:r for r in json.loads((xp/'raw.json').read_text())}
            for b in (1,3,10):
                rr=[raw[f'{m}_B{b}'] for m in CONTROL_PROTOCOL['methods']]
                if {r['presentations'] for r in rr}!={b*cm['retained_triples']} or len({r['steps'] for r in rr})!=1:
                    raise ValueError('Budget mismatch')
            manifests.append({'dataset':ds,'seed':s,'cohort':cm,'controls':xm})
    folds=[]
    for ds in DATASETS:
        for b in (20,50,100):
            ref=f'Reference{b}'
            for method in METHODS+('AllFresh','AllZero'):
                ga=[features(P[ds,s,method]) for s in SEEDS]
                gb=[features(P[ds,s,ref]) for s in SEEDS]
                for feat,cols in FEATURE_SETS.items():
                    for f in attack_folds(ga,gb,[f'{method}:{s}' for s in SEEDS],[f'{ref}:{s}' for s in SEEDS],cols):
                        folds.append({'dataset':ds,'candidate':method,'reference_budget':b,'features':feat,'comparison':'intervention',**f})
        ga=[features(P[ds,s,'Reference20']) for s in SEEDS]
        gb=[features(P[ds,s,'IndependentRef20']) for s in SEEDS]
        for feat,cols in FEATURE_SETS.items():
            for f in attack_folds(ga,gb,[f'Ref20:{s}' for s in SEEDS],[f'Ref20:{s+1000}' for s in SEEDS],cols):
                folds.append({'dataset':ds,'candidate':'IndependentRef20Null','reference_budget':20,'features':feat,'comparison':'same_budget_null',**f})
    feature_stats=[]
    for ds in DATASETS:
        for seed in SEEDS:
            for label in ['ResetLocal','ResetOnly','AllFresh','AllZero','Reference20','Reference100','IndependentRef20']:
                arr=features(P[ds,seed,label])
                for name,col in [('true_score',0),('log_head_rank',1),('log_tail_rank',2)]:
                    vals=arr[:,col]
                    feature_stats.append({'dataset':ds,'seed':seed,'candidate':label,'feature':name,
                         'mean':float(vals.mean()),'median':float(np.median(vals)),
                         'q05':float(np.quantile(vals,.05)),'q95':float(np.quantile(vals,.95))})
    budget_rows=[]
    for ds in DATASETS:
        for s in SEEDS:
            for b in (0,1,3,5,10):
                for m in CONTROL_PROTOCOL['methods']:
                    label='ResetOnly' if b==0 else (m if b==5 else f'{m}_B{b}')
                    for refbudget in (20,50,100):
                        budget_rows.append({'dataset':ds,'seed':s,'method':m,'budget':b,'reference_budget':refbudget,
                           **prediction_metrics(P[ds,s,label],P[ds,s,f'Reference{refbudget}'])})
    auc_summary=aggregate(folds,['dataset','reference_budget','candidate','features'],['roc_auc','balanced_accuracy_at_zero'])
    budget_summary=aggregate(budget_rows,['dataset','reference_budget','method','budget'],
          ['test_gap','forgotten_gap','test_rr_mae','forgotten_rr_mae','test_mrr','forgotten_mrr'])
    damaged=[]
    for ds in DATASETS:
        for s in SEEDS:
            for m in ['AllFresh','AllZero','ResetLocal','Reference20']:
                damaged.append({'dataset':ds,'seed':s,'candidate':m,**prediction_metrics(P[ds,s,m],P[ds,s,'Reference20'])})
    damage_summary=aggregate(damaged,['dataset','candidate'],['test_mrr','retained_mrr','forgotten_mrr','test_gap','forgotten_gap'])
    wins=[]
    for ds in DATASETS:
        for b in (1,3,5,10):
            for ref in (20,100):
                rr=[r for r in budget_rows if r['dataset']==ds and r['budget']==b and r['reference_budget']==ref]
                win={'dataset':ds,'budget':b,'reference_budget':ref,'n':3}
                for metric in ['test_gap','forgotten_gap']:
                    win['local_better_'+metric]=sum(next(r for r in rr if r['seed']==s and r['method']=='ResetLocal')[metric] < next(r for r in rr if r['seed']==s and r['method']=='ResetFullRetain')[metric] for s in SEEDS)
                wins.append(win)
    for name,rows in [('feature_attack_folds.csv',folds),('feature_attack_summary.csv',auc_summary),
                      ('budget_pairs.csv',budget_rows),('budget_summary.csv',budget_summary),
                      ('feature_distributions.csv',feature_stats),
                      ('damage_pairs.csv',damaged),('damage_summary.csv',damage_summary),('budget_win_counts.csv',wins)]:
        write_csv(args.out/name,rows)
    result={'scope':'New post-review controls; full-split noiseless DistMult, not certified release',
      'protocol':CONTROL_PROTOCOL,'feature_sets':FEATURE_SETS,'attack_folds':len(folds),'same_budget_null_folds':18,
      'same_budget_null_reference_epochs':20,'auc_uses_test_orientation_flipping':False,
      'null_models_are_independently_trained':True,'holdout_query_ids_and_model_seeds_disjoint':True,
      'budget_pairs':len(budget_rows),'uncertainty':'three seed-pair descriptive ranges; no population inference',
      'feature_summary':auc_summary,'budget_summary':budget_summary,'damage_summary':damage_summary,'wins':wins,
      'source_hashes':{str(f.relative_to(args.cohort)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(args.cohort.rglob('*_predictions.npz'))},
      'control_hashes':{str(f.relative_to(args.controls)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(args.controls.rglob('*_predictions.npz'))}}
    (args.out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'attack_folds':len(folds),'budget_pairs':len(budget_rows),'all_checks':'PASS'}))
if __name__=='__main__':main()
