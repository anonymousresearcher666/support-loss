#!/usr/bin/env python3
"""Fixed rank-only output-source probe; disjoint query IDs and model seeds.
No orientation selection, hyperparameter search, or claim of privacy certification.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
from scipy.special import expit
from scipy.stats import rankdata

SEEDS = (17, 29, 43)
METHODS = ('Unchanged', 'ResetOnly', 'Local', 'ResetLocal', 'FullRetain',
           'ResetFullRetain', 'ResetDenseSameWork', 'IndependentReference')
BUDGETS = (20, 100)


def auc(y, scores):
    y = np.asarray(y, dtype=bool)
    if not y.any() or y.all() or not np.isfinite(scores).all():
        raise ValueError('AUC requires finite scores and both classes')
    n = y.sum()
    return float((rankdata(scores)[y].sum() - n * (n + 1) / 2) / (n * (~y).sum()))


def fit(X, y):
    mu, sd = X.mean(0), X.std(0)
    sd[sd < 1e-12] = 1
    Z = np.c_[(X - mu) / sd, np.ones(len(X))]
    def objective(w):
        z = Z @ w
        loss = np.logaddexp(0, -(2 * y - 1) * z).mean() + .5 * (w[:-1] @ w[:-1]) / len(y)
        grad = Z.T @ (expit(z) - y) / len(y)
        grad[:-1] += w[:-1] / len(y)
        return loss, grad
    result = minimize(objective, np.zeros(Z.shape[1]), jac=True, method='L-BFGS-B',
                      options={'maxiter': 1000, 'gtol': 1e-8, 'ftol': 1e-12, 'maxls': 50})
    residual = float(abs(objective(result.x)[1]).max())
    if not result.success and residual > 1e-6:
        raise RuntimeError('Probe optimizer did not converge')
    return lambda x: np.c_[(x - mu) / sd, np.ones(len(x))] @ result.x, residual


def query_halves(q):
    # Equal triple IDs always remain in the same half, including duplicate rows.
    unique, inverse = np.unique(q, axis=0, return_inverse=True)
    if len(unique) < 8:
        raise ValueError('At least eight distinct forgotten queries required')
    order = np.random.default_rng(271828).permutation(len(unique))
    is_train = np.isin(inverse, order[:len(unique) // 2])
    return np.flatnonzero(is_train), np.flatnonzero(~is_train)


def probe_fold(features, method, reference, heldout, train_q, test_q):
    train_seeds = [s for s in SEEDS if s != heldout]
    X = np.concatenate([features[s, m][train_q] for s in train_seeds for m in (method, reference)])
    y = np.tile(np.r_[np.ones(len(train_q)), np.zeros(len(train_q))], len(train_seeds))
    model, residual = fit(X, y)
    Xt = np.r_[features[heldout, method][test_q], features[heldout, reference][test_q]]
    yt = np.r_[np.ones(len(test_q)), np.zeros(len(test_q))]
    return auc(yt, model(Xt)), residual


def analyze(root, out):
    audit = json.loads((root / 'REQUEST_AUDIT.json').read_text())
    if audit['completed_runs'] != 108 or audit['requests_per_graph'] != 9:
        raise ValueError('Run the complete request collector before this analysis')
    rows, hashes = [], {}
    for dataset in ('FB15K-237', 'CoDEx-M'):
        for family in ('distmult', 'complex'):
            for stratum in ('low', 'middle', 'high'):
                for request in range(3):
                    features, query, identity = {}, None, None
                    for seed in SEEDS:
                        folder = root / stratum / f'request{request}' / 'full' / 'balanced' / dataset / family / f'seed{seed}'
                        manifest = json.loads((folder / 'COMPLETE.json').read_text())
                        current_id = (manifest['protocol']['selected_entity'], manifest['forget_hash'])
                        if identity is not None and current_id != identity:
                            raise ValueError('Different requests across training seeds')
                        identity = current_id
                        with np.load(folder / 'queries.npz', allow_pickle=False) as source:
                            q = source['forgotten']
                        if query is not None and not np.array_equal(q, query):
                            raise ValueError('Query ordering differs across seeds')
                        query = q
                        labels = [m for m in METHODS if m != 'IndependentReference']
                        labels += [prefix + str(b) for prefix in ('Reference', 'IndependentReference') for b in BUDGETS]
                        for label in labels:
                            path = folder / f'{label}_predictions.npz'
                            hashes[str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
                            with np.load(path, allow_pickle=False) as pred:
                                ranks = pred['forgotten_ranks']
                            if ranks.shape != (2, len(q)) or not np.isfinite(ranks).all() or (ranks < 1).any():
                                raise ValueError('Invalid prediction ranks')
                            features[seed, label] = np.log(ranks).T
                    train_q, test_q = query_halves(query)
                    for budget in BUDGETS:
                        ref, null = f'Reference{budget}', f'IndependentReference{budget}'
                        for seed in SEEDS:
                            null_auc, _ = probe_fold(features, null, ref, seed, train_q, test_q)
                            for label in METHODS:
                                method = null if label == 'IndependentReference' else label
                                value, residual = probe_fold(features, method, ref, seed, train_q, test_q)
                                rows.append(dict(dataset=dataset, model=family, stratum=stratum, request=request,
                                    entity=identity[0], method=label, reference_budget=budget, heldout_seed=seed,
                                    train_queries=len(train_q), test_queries=len(test_q), auc=value,
                                    null_auc=null_auc, excess_auc=value-null_auc, optimizer_gradient_inf=residual))
    out.mkdir(parents=True, exist_ok=True)
    with (out / 'request_auc_folds.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    keys = ('dataset', 'model', 'stratum', 'request', 'entity', 'method', 'reference_budget')
    groups = {}
    for row in rows:
        groups.setdefault(tuple(row[k] for k in keys), []).append(row)
    summary = []
    for key, group in groups.items():
        result = dict(zip(keys, key)); result['folds'] = len(group)
        for metric in ('auc', 'null_auc', 'excess_auc'):
            values = [r[metric] for r in group]
            result.update({metric+'_mean': float(np.mean(values)), metric+'_min': min(values), metric+'_max': max(values)})
        summary.append(result)
    with (out / 'request_auc_summary.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(summary[0])); writer.writeheader(); writer.writerows(summary)
    (out / 'AUC_PROTOCOL.json').write_text(json.dumps(dict(
        features=['log head rank', 'log tail rank'], regularization='L2 logistic; lambda=1/n_train',
        query_seed=271828, reference_budgets=BUDGETS, folds=len(rows), request_model_groups=36,
        split='disjoint triple IDs and leave-one-model-seed-out; two directions are features, not independent samples',
        interpretation='Post-hoc output-source diagnostic; AUC orientation fixed by training labels. Fold ranges are descriptive, not confidence intervals. Nine requests per graph stratified by degree. No privacy or population-equivalence guarantee.',
        prediction_sha256=hashes), indent=2)+'\n')
    print(json.dumps({'folds': len(rows), 'request_summaries': len(summary), 'out': str(out)}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    analyze(args.root, args.out)
