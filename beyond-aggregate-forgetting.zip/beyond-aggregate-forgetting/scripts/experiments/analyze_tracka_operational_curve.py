#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json
from pathlib import Path


def f(x): return float(x)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input',required=True)
    ap.add_argument('--out',required=True)
    ap.add_argument('--taus',nargs='+',type=float,default=[5e-4,1e-3,2e-3,5e-3,1e-2,2e-2,5e-2,1e-1,1.0])
    a=ap.parse_args()
    rows=list(csv.DictReader(open(a.input,newline='')))
    if len(rows)!=24: raise RuntimeError(f'Expected 24 Track-A rows, got {len(rows)}')
    required={'dataset','frac','A_frac','expansion_steps','validation_radius','candidate_actual','local_sec','retrain_sec'}
    miss=required-set(rows[0]);
    if miss: raise RuntimeError(f'Missing columns: {sorted(miss)}')
    out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
    detail=[]; summary=[]
    for tau in a.taus:
        acc=0; viol=0; cost=0.0; af=[]; ex=[]; accepted_actual=[]
        for r in rows:
            vr=f(r['validation_radius']); actual=f(r['candidate_actual']); local=f(r['local_sec']); retr=f(r['retrain_sec'])
            accept=vr<=tau
            if accept:
                acc+=1; cost+=local; af.append(f(r['A_frac'])); ex.append(f(r['expansion_steps'])); accepted_actual.append(actual)
                violation=actual>tau
                viol+=int(violation)
            else:
                cost+=local+retr
                violation=False
            detail.append({**r,'tau':tau,'accept_local':int(accept),'fallback':int(not accept),'policy_output_distance':actual if accept else 0.0,'violation':int(violation),'policy_sec':local if accept else local+retr})
        n=len(rows)
        baseline=sum(f(r['retrain_sec']) for r in rows)
        summary.append({'tau':tau,'n':n,'local_accept':acc,'fallback':n-acc,'accept_rate':acc/n,'fallback_rate':1-acc/n,'violations':viol,'mean_A_frac_accepted':sum(af)/len(af) if af else None,'mean_expansion_steps_accepted':sum(ex)/len(ex) if ex else None,'max_actual_accepted':max(accepted_actual) if accepted_actual else None,'mean_policy_sec':cost/n,'mean_retrain_sec':baseline/n,'speedup_vs_retrain':baseline/cost if cost else None})
    with open(out/'tracka_operational_curve.csv','w',newline='') as h:
        w=csv.DictWriter(h,fieldnames=list(summary[0].keys())); w.writeheader(); w.writerows(summary)
    with open(out/'tracka_operational_detail.csv','w',newline='') as h:
        w=csv.DictWriter(h,fieldnames=list(detail[0].keys())); w.writeheader(); w.writerows(detail)
    md=['# Track-A operational acceptance/fallback curve','',f'- Source rows: {len(rows)}','- Policy: accept local iff certified validation radius <= tau; otherwise execute retraining fallback.','- End-to-end fallback cost counts the attempted local step plus retraining.','', '| tau | local | fallback | accept rate | violations | mean policy s | speedup vs retrain |','|---:|---:|---:|---:|---:|---:|---:|']
    for x in summary:
        md.append(f"| {x['tau']:.6g} | {x['local_accept']} | {x['fallback']} | {x['accept_rate']:.3f} | {x['violations']} | {x['mean_policy_sec']:.6f} | {x['speedup_vs_retrain']:.3f} |")
    (out/'TRACKA_OPERATIONAL_CURVE.md').write_text('\n'.join(md)+'\n')
    (out/'tracka_operational_curve.json').write_text(json.dumps({'summary':summary},indent=2)+'\n')
    print('TRACKA_OPERATIONAL_CURVE_OK',len(summary),'taus')

if __name__=='__main__': main()
