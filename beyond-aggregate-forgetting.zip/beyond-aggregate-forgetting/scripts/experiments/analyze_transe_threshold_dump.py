#!/usr/bin/env python3
"""Parse the archived concatenated common-evaluator dump.

The historical dump contains 20/24 TransE cells. Missing YAGO seed-29/43
cells are intentionally not imputed. This script computes aggregate threshold
metrics only; it cannot reconstruct per-query ranks from aggregate rows.
"""
from pathlib import Path
import argparse,csv,re
import pandas as pd

METHODS=('ExactRetrain','SchemaCert+Restart-L5','GraphDPO')
METRICS=('forget_mrr','forget_h1','forget_h3','forget_h10')
PAT=re.compile(r'/([^/]+)_transe_entity_f([0-9.]+)_s(\d+)_common_shared_base\.csv$')

def parse(path):
    text=Path(path).read_text();parts=re.split(r'^=+\s+(.*?)\s+=+\s*$',text,flags=re.M);rows=[]
    for i in range(1,len(parts),2):
        name,body=parts[i].strip(),parts[i+1].strip();m=PAT.search(name)
        if not m:continue
        lines=[x for x in body.splitlines() if x.strip()]
        if not lines or not lines[0].startswith('method,'):continue
        for r in csv.DictReader(lines):
            if r['method'] in METHODS:
                r.update(dataset=m.group(1),fraction=m.group(2),seed=m.group(3));rows.append(r)
    return pd.DataFrame(rows)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('dump');ap.add_argument('--out',default='transe_threshold_metrics_20cells.csv');args=ap.parse_args()
    d=parse(args.dump);idx=['dataset','fraction','seed']
    ex=d[d.method=='ExactRetrain'].set_index(idx);sc=d[d.method=='SchemaCert+Restart-L5'].set_index(idx);gd=d[d.method=='GraphDPO'].set_index(idx)
    common=ex.index.intersection(sc.index).intersection(gd.index)
    if len(common)!=20:raise RuntimeError(f'Expected historical 20-cell dump, found {len(common)}')
    out=[]
    for m in METRICS:
        for x in (ex,sc,gd):x[m]=pd.to_numeric(x[m])
        ga=(sc.loc[common,m]-ex.loc[common,m]).abs();gb=(gd.loc[common,m]-ex.loc[common,m]).abs()
        out.append({'metric':m,'schemacert_restart_gap':ga.mean(),'graphdpo_gap':gb.mean(),'schemacert_smaller':int((ga<gb).sum()),'n':len(ga)})
    pd.DataFrame(out).to_csv(args.out,index=False);print(pd.DataFrame(out).to_string(index=False))
if __name__=='__main__':main()
