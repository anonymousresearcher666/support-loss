#!/usr/bin/env python3
"""B2 audit: verify and correct the NormMatchRefOracle mechanism control.

This is evaluation-only. It loads the exact frozen cohort used by the original
support-loss negative-exposure control, rescales ONLY the selected zero-support
entity rows with an explicit index_copy_, then recomputes forgotten-query ranks.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
import torch

from schemacert.data import load_dataset
from schemacert.family_models import DistMult
from scripts.experiments.run_reference_budget_pilot import filters, rank_queries


def load_model(path: Path, ne: int, nr: int) -> DistMult:
    obj = torch.load(path, map_location="cpu", weights_only=False)
    state = obj["state_dict"] if isinstance(obj, dict) and "state_dict" in obj else obj
    dim = int(state["entity.weight"].shape[1])
    m = DistMult(ne, nr, dim)
    m.load_state_dict(state)
    m.eval()
    return m


def med(x):
    return float(np.median(np.asarray(x, dtype=float)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-root", type=Path, required=True)
    ap.add_argument("--cohort", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--dataset", choices=["FB15K-237", "CoDEx-M"], required=True)
    ap.add_argument("--seed", type=int, choices=[17, 29, 43], required=True)
    args = ap.parse_args()

    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)

    folder = "FB15k-237" if args.dataset == "FB15K-237" else "codex-m"
    path = args.data_root / folder
    if args.dataset == "CoDEx-M" and not (path / "train.txt").is_file():
        alt = args.data_root / "codex" / "data" / "triples" / "codex-m"
        if (alt / "train.txt").is_file():
            path = alt
    data = load_dataset(path/"train.txt", path/"valid.txt", path/"test.txt")
    ne, nr = len(data.entities), len(data.relations)

    direct = args.cohort/args.dataset/f"seed{args.seed}"
    nested = args.cohort/args.dataset/"distmult"/f"seed{args.seed}"
    run = direct if direct.is_dir() else nested
    if not run.is_dir():
        raise FileNotFoundError(f"Missing cohort cell: {direct} or {nested}")

    q = dict(np.load(run/"queries.npz"))
    fi = q["forget_indices"]
    selected = q["selected_entities"].astype(np.int64)
    if len(selected) == 0:
        raise RuntimeError("No selected zero-support entities")
    U = data.train[fi]
    R = np.delete(data.train, fi, axis=0)
    if np.isin(R[:, [0, 2]], selected).any():
        raise RuntimeError("Selected entities are not zero-support in retained graph")
    truth = filters(R, data.valid, data.test, U)

    rl = load_model(run/"ResetLocal.pt", ne, nr)
    ref = load_model(run/"Reference20.pt", ne, nr)
    oracle = load_model(run/"ResetLocal.pt", ne, nr)

    idx = torch.as_tensor(selected, dtype=torch.long)
    with torch.no_grad():
        before_all = oracle.entity.weight.detach().clone()
        before_rows = oracle.entity.weight.index_select(0, idx).clone()
        ref_rows = ref.entity.weight.index_select(0, idx)
        rn = before_rows.norm(dim=1, keepdim=True).clamp_min(1e-12)
        tn = ref_rows.norm(dim=1, keepdim=True)
        scale = tn / rn

        # IMPORTANT: explicit write-back.  The v1 code used
        #   oracle.entity.weight[selected].mul_(scale)
        # which mutates an advanced-indexing temporary rather than entity.weight.
        after_rows = before_rows * scale
        oracle.entity.weight.index_copy_(0, idx, after_rows)

        after_all = oracle.entity.weight.detach()
        selected_mask = torch.zeros(ne, dtype=torch.bool)
        selected_mask[idx] = True
        unchanged_exact = bool(torch.equal(
            after_all[~selected_mask], before_all[~selected_mask]
        ))
        selected_changed_rows = int(
            (after_all[selected_mask] != before_all[selected_mask]).any(dim=1).sum().item()
        )
        norm_target_error = float(
            (after_all.index_select(0, idx).norm(dim=1) - tn[:, 0]).abs().max().item()
        )

    if not unchanged_exact:
        raise RuntimeError("Non-selected embedding rows changed")
    if selected_changed_rows != len(selected):
        raise RuntimeError(
            f"Expected all {len(selected)} selected rows to change; got {selected_changed_rows}"
        )
    if norm_target_error > 2e-5:
        raise RuntimeError(f"Norm target mismatch after rescaling: {norm_target_error}")

    rl_eval = rank_queries(rl, q["forgotten"], truth)
    oracle_eval = rank_queries(oracle, q["forgotten"], truth)
    ref_eval = rank_queries(ref, q["forgotten"], truth)

    rr = rl_eval["ranks"].astype(float)
    ro = oracle_eval["ranks"].astype(float)
    rf = ref_eval["ranks"].astype(float)
    sr = rl_eval["scores"].astype(float)
    so = oracle_eval["scores"].astype(float)

    rl_gap = float(np.abs(np.log10(rr) - np.log10(rf)).mean())
    oracle_gap = float(np.abs(np.log10(ro) - np.log10(rf)).mean())
    reduction = float((rl_gap - oracle_gap) / rl_gap) if rl_gap else float("nan")

    # side 0=head prediction, side 1=tail prediction.
    forgotten = q["forgotten"]
    head_target_selected = np.isin(forgotten[:, 0], selected)
    tail_target_selected = np.isin(forgotten[:, 2], selected)
    target_selected = np.stack([head_target_selected, tail_target_selected])

    changed = ro != rr
    promoted = ro < rr
    demoted = ro > rr
    positive_score = sr > 0
    negative_score = sr < 0

    def count(mask):
        return int(np.asarray(mask, dtype=bool).sum())

    before_norm = before_rows.norm(dim=1).cpu().numpy()
    after_norm = oracle.entity.weight.index_select(0, idx).detach().norm(dim=1).cpu().numpy()
    ref_norm = ref_rows.detach().norm(dim=1).cpu().numpy()
    scales = scale[:, 0].cpu().numpy()

    payload = {
        "protocol": "B2-norm-match-oracle-audit-v2",
        "dataset": args.dataset,
        "seed": args.seed,
        "cohort_cell": str(run),
        "query_directions": int(rr.size),
        "forgotten_queries": int(len(q["forgotten"])),
        "selected_zero_support_entities": int(len(selected)),
        "rescaling": {
            "rows": "selected_entities only",
            "write_method": "entity.weight.index_copy_",
            "nonselected_rows_bit_identical": unchanged_exact,
            "selected_rows_changed": selected_changed_rows,
            "max_abs_postnorm_minus_refnorm": norm_target_error,
            "median_norm_before": med(before_norm),
            "median_norm_after": med(after_norm),
            "median_norm_ref20": med(ref_norm),
            "median_scale_factor": med(scales),
            "min_scale_factor": float(scales.min()),
            "max_scale_factor": float(scales.max()),
        },
        "forgotten_rank_gap": {
            "ResetLocal": rl_gap,
            "NormMatchRefOracle_fixed": oracle_gap,
            "relative_reduction": reduction,
        },
        "rank_changes": {
            "changed": count(changed),
            "unchanged": count(~changed),
            "promoted": count(promoted),
            "demoted": count(demoted),
            "target_selected_directions": count(target_selected),
            "target_selected_changed": count(changed & target_selected),
            "context_only_changed": count(changed & ~target_selected),
            "positive_score_target_selected": count(positive_score & target_selected),
            "positive_score_target_selected_promoted": count(positive_score & target_selected & promoted),
            "positive_score_target_selected_demoted": count(positive_score & target_selected & demoted),
            "negative_score_target_selected": count(negative_score & target_selected),
            "negative_score_target_selected_promoted": count(negative_score & target_selected & promoted),
            "negative_score_target_selected_demoted": count(negative_score & target_selected & demoted),
        },
        "mean_rank_change_oracle_minus_rl": float((ro - rr).mean()),
        "mean_score_change_oracle_minus_rl": float((so - sr).mean()),
    }

    args.out.mkdir(parents=True, exist_ok=True)
    stem = f"{args.dataset}_seed{args.seed}_norm_oracle_audit_v2"
    (args.out/f"{stem}.json").write_text(json.dumps(payload, indent=2)+"\n")
    np.savez_compressed(
        args.out/f"{stem}_arrays.npz",
        rl_ranks=rr, oracle_ranks=ro, ref_ranks=rf,
        rl_scores=sr, oracle_scores=so,
        target_selected=target_selected,
        before_norm=before_norm, after_norm=after_norm, ref_norm=ref_norm,
        scales=scales, selected=selected,
    )

    print(json.dumps(payload, indent=2))
    print("B2_NORM_ORACLE_AUDIT_CELL_OK", flush=True)


if __name__ == "__main__":
    main()
