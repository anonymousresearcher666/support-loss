#!/usr/bin/env python3
"""W7 audit for the GraphDPO-compatible negative-sampling upper bound.

This is a zero-training provenance check. It reproduces the 36 deletion requests
from run_supportloss_unified.py and asks whether the one entity never sampled as
negative by the public GraphDPO corruption rule (entity id N-1) is involved in
the deleted request. It does not alter any checkpoint or result.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from schemacert.data import infer_paths, load_dataset

def select_forget(train, fraction, seed, policy="relation"):
    rng = np.random.default_rng(seed)
    if policy == "relation":
        u, counts = np.unique(train[:, 1], return_counts=True)
        rid = int(u[np.argmax(counts)])
        cand = np.flatnonzero(train[:, 1] == rid)
        k = max(1, int(round(fraction * len(cand))))
        tails, tail_counts = np.unique(train[cand, 2], return_counts=True)
        order = tails[np.argsort(-tail_counts)]
        picked = []
        for t in order:
            x = cand[train[cand, 2] == t]
            if len(x) > 1:
                picked.extend(x.tolist())
            if len(picked) >= max(2, k // 3):
                break
        picked = list(dict.fromkeys(picked))[:min(k, max(2, k // 3))]
        chosen = set(picked)
        rem = np.asarray([int(i) for i in cand if int(i) not in chosen], dtype=np.int64)
        if len(picked) < k:
            picked += rng.choice(rem, k - len(picked), replace=False).tolist()
        return np.asarray(picked[:k], dtype=np.int64), {
            "policy": "relation",
            "relation_id": rid,
            "candidates": len(cand),
        }
    if policy == "random":
        k = max(1, int(round(fraction * len(train))))
        return np.sort(rng.choice(len(train), k, replace=False)), {
            "policy": "random",
            "candidates": len(train),
        }
    if policy == "entity":
        target = max(1, int(round(fraction * len(train))))
        ents = np.r_[train[:, 0], train[:, 2]]
        u, counts = np.unique(ents, return_counts=True)
        order = u[np.argsort(-counts)]
        chosen = []
        mask = np.zeros(len(train), dtype=bool)
        for e in order:
            chosen.append(int(e))
            mask |= (train[:, 0] == e) | (train[:, 2] == e)
            if int(mask.sum()) >= target:
                break
        return np.flatnonzero(mask), {
            "policy": "entity",
            "entities": chosen,
            "candidates": len(train),
        }
    raise KeyError(policy)

SEEDS = (17, 29, 43)
TASKS = [
    (d, "entity", f, s)
    for d in ("FB15K-237", "WN18RR", "CoDEx-L", "YAGO3-10")
    for f in (.1, .2)
    for s in SEEDS
]
TASKS += [
    (d, "random", f, s)
    for d in ("FB15K-237", "CoDEx-M")
    for f in (.1, .2)
    for s in SEEDS
]


def load_split(dataset: str, data_root: Path):
    paths = infer_paths(dataset, data_root)
    if not Path(paths[0]).exists() and dataset.startswith("CoDEx"):
        paths = tuple(data_root / dataset.lower() / (s + ".txt")
                      for s in ("train", "valid", "test"))
    return load_dataset(*paths)


def count_incident(triples: np.ndarray, entity_id: int) -> int:
    return int(((triples[:, 0] == entity_id) | (triples[:, 2] == entity_id)).sum())

def retained_degrees(retain: np.ndarray, n_entities: int) -> np.ndarray:
    deg = np.zeros(int(n_entities), dtype=np.int64)
    if len(retain):
        np.add.at(deg, retain[:, 0], 1)
        np.add.at(deg, retain[:, 2], 1)
    return deg


def cost_aware_star_cover(forget: np.ndarray, retain: np.ndarray, n_entities: int) -> np.ndarray:
    if len(forget) == 0:
        return np.empty(0, dtype=np.int64)
    deg = retained_degrees(retain, n_entities)
    selected = set()
    incident = {}
    edges = []
    for i, (h, _, t) in enumerate(forget):
        h, t = int(h), int(t)
        edges.append((h, t))
        incident.setdefault(h, []).append(i)
        if t != h:
            incident.setdefault(t, []).append(i)
        if h == t:
            selected.add(h)
        elif deg[h] < deg[t]:
            selected.add(h)
        elif deg[t] < deg[h]:
            selected.add(t)
        else:
            selected.add(min(h, t))
    cover_count = np.zeros(len(edges), dtype=np.int16)
    for i, (h, t) in enumerate(edges):
        cover_count[i] = int(h in selected) + (int(t in selected) if t != h else 0)
    for v in sorted(selected, key=lambda x: (int(deg[x]), x), reverse=True):
        inc = incident.get(v, [])
        if inc and all(int(cover_count[i]) >= 2 for i in inc):
            selected.remove(v)
            for i in inc:
                cover_count[i] -= 1
    if np.any(cover_count <= 0):
        raise RuntimeError("Pruned star cover does not cover all forgotten facts")
    return np.asarray(sorted(selected), dtype=np.int64)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-root", type=Path, default=Path("data"))
    ap.add_argument("--out", type=Path,
                    default=Path("results_cluster/review/w7_negative_sampling_audit"))
    args = ap.parse_args()

    cache = {}
    rows = []
    for task_id, (dataset, policy, fraction, seed) in enumerate(TASKS):
        if dataset not in cache:
            cache[dataset] = load_split(dataset, args.data_root)
        data = cache[dataset]
        train = data.train.copy()
        ne = len(data.entities)
        last_id = ne - 1

        # Relation ids are doubled in the unified TransE runner before request
        # construction. This is immaterial to entity/random request membership
        # but is reproduced here for exact provenance.
        train[:, 1] *= 2
        fi, meta = select_forget(
            train, fraction, seed + int(fraction * 10000), policy
        )
        forget = train[fi]
        keep = np.ones(len(train), dtype=bool)
        keep[fi] = False
        retain = train[keep]

        selected = set(map(int, meta.get("entities", [])))
        endpoint_selected = bool(policy == "random" and count_incident(forget, last_id) > 0)
        starcover_selected = False
        if policy == "random":
            cover = cost_aware_star_cover(forget, retain, ne)
            starcover_selected = bool(last_id in set(map(int, cover)))
        row = {
            "task": task_id,
            "dataset": dataset,
            "policy": policy,
            "fraction": fraction,
            "seed": seed,
            "n_entities": ne,
            "excluded_negative_entity_id": last_id,
            "last_id_train_incident": count_incident(train, last_id),
            "last_id_forget_incident": count_incident(forget, last_id),
            "last_id_retain_incident": count_incident(retain, last_id),
            "last_id_in_forget": bool(count_incident(forget, last_id) > 0),
            "last_id_selected_entity_request": bool(last_id in selected),
            "last_id_zero_support_after_delete": bool(
                count_incident(retain, last_id) == 0
            ),
            "last_id_endpoint_selected": endpoint_selected,
            "last_id_starcover_selected": starcover_selected,
            "forget_n": int(len(fi)),
        }
        rows.append(row)

    summary = {
        "n_tasks": len(rows),
        "tasks_last_id_in_forget": int(sum(r["last_id_in_forget"] for r in rows)),
        "tasks_last_id_selected_entity_request": int(
            sum(r["last_id_selected_entity_request"] for r in rows)
        ),
        "tasks_last_id_zero_support_after_delete": int(
            sum(r["last_id_zero_support_after_delete"] for r in rows)
        ),
        "random_tasks_last_id_endpoint_selected": int(
            sum(r["last_id_endpoint_selected"] for r in rows)
        ),
        "random_tasks_last_id_starcover_selected": int(
            sum(r["last_id_starcover_selected"] for r in rows)
        ),
        "random_tasks_last_id_zero_support_and_endpoint": int(
            sum(r["policy"] == "random" and r["last_id_zero_support_after_delete"]
                and r["last_id_endpoint_selected"] for r in rows)
        ),
        "random_tasks_last_id_zero_support_and_starcover": int(
            sum(r["policy"] == "random" and r["last_id_zero_support_after_delete"]
                and r["last_id_starcover_selected"] for r in rows)
        ),
        "interpretation": (
            "The public GraphDPO-compatible sampler omits entity id N-1 as a "
            "negative candidate. The main unified TransE campaign applies the "
            "same rule to base training, Local/R+L repair, and retained-data "
            "references. This audit only checks whether the omitted entity is "
            "also part of each deletion request."
        ),
    }

    payload = {"summary": summary, "rows": rows}
    args.out.mkdir(parents=True, exist_ok=True)
    out = args.out / "W7_NEGATIVE_SAMPLING_AUDIT.json"
    out.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf8")

    print("=== W7 NEGATIVE SAMPLING AUDIT ===")
    print(json.dumps(summary, indent=2))
    for r in rows:
        if r["last_id_in_forget"] or r["last_id_selected_entity_request"]:
            print("AFFECTED", json.dumps(r, sort_keys=True))
    print(f"json={out}")
    print("W7_NEGATIVE_SAMPLING_AUDIT_OK")


if __name__ == "__main__":
    main()
