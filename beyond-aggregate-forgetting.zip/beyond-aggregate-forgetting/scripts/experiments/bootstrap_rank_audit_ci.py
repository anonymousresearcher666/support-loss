#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path

import numpy as np

REF_A_NAMES = ("rank_RefA", "rank_refA", "rank_ref_a", "refA_rank", "ref_a_rank")
REF_B_NAMES = ("rank_RefB", "rank_refB", "rank_ref_b", "refB_rank", "ref_b_rank")
GROUP_NAMES = ("query_index", "query_idx", "query_id", "source_query_index", "qid")
META_NAMES = {
    "dataset", "request_seed", "seed", "request_hash", "side", "query_index",
    "query_idx", "query_id", "source_query_index", "qid",
}


def first_present(fieldnames, names):
    for n in names:
        if n in fieldnames:
            return n
    return None


def rank_candidates(fieldnames, refa, refb):
    out = []
    for f in fieldnames:
        if not f.startswith("rank_"):
            continue
        if f in {refa, refb}:
            continue
        out.append(f)
    return out


def read_csv(path: Path):
    with path.open(newline="", encoding="utf8") as f:
        r = csv.DictReader(f)
        rows = list(r)
        fields = list(r.fieldnames or [])
    return fields, rows


def infer_cell(path: Path, rows):
    first = rows[0] if rows else {}
    dataset = first.get("dataset") or path.stem.split("_seed")[0]
    seed = first.get("request_seed") or first.get("seed")
    req = first.get("request_hash")
    return {
        "file": str(path),
        "dataset": dataset,
        "seed": seed,
        "request_hash": req,
    }


def group_arrays(rows, group_col, cand_col, refa_col, refb_col):
    groups = defaultdict(list)
    if group_col is None:
        # Conservative fallback: each row is an independent paired unit.
        for i, row in enumerate(rows):
            groups[str(i)].append(row)
    else:
        for row in rows:
            # If query ids repeat once for head and once for tail, both stay
            # in the same bootstrap unit.
            groups[str(row[group_col])].append(row)

    keys = sorted(groups)
    cand, refa, refb = [], [], []
    for k in keys:
        rr = groups[k]
        c = np.asarray([float(x[cand_col]) for x in rr], dtype=float)
        a = np.asarray([float(x[refa_col]) for x in rr], dtype=float)
        b = np.asarray([float(x[refb_col]) for x in rr], dtype=float)
        if not (np.all(np.isfinite(c)) and np.all(np.isfinite(a)) and np.all(np.isfinite(b))):
            raise ValueError(f"Non-finite rank in group {k}")
        if np.any(c < 1) or np.any(a < 1) or np.any(b < 1):
            raise ValueError(f"Rank < 1 in group {k}")
        cand.append(c)
        refa.append(a)
        refb.append(b)
    return keys, cand, refa, refb


def metrics(c, a, b):
    c = np.asarray(c, dtype=float)
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    cand_log = float(np.mean(np.abs(np.log10(c) - np.log10(a))))
    null_log = float(np.mean(np.abs(np.log10(b) - np.log10(a))))
    return {
        "candidate_logrank_gap": cand_log,
        "null_logrank_gap": null_log,
        "logrank_excess": cand_log - null_log,
        "candidate_mrr_gap": float(abs(np.mean(1.0 / c) - np.mean(1.0 / a))),
        "null_mrr_gap": float(abs(np.mean(1.0 / b) - np.mean(1.0 / a))),
        "candidate_top10_disagreement": float(np.mean((c <= 10) != (a <= 10))),
        "null_top10_disagreement": float(np.mean((b <= 10) != (a <= 10))),
        "candidate_top100_disagreement": float(np.mean((c <= 100) != (a <= 100))),
        "null_top100_disagreement": float(np.mean((b <= 100) != (a <= 100))),
    }


def flatten_selected(arrays, ids):
    if len(ids) == 0:
        return np.asarray([], dtype=float)
    return np.concatenate([arrays[int(i)] for i in ids])


def bootstrap_cell(cg, ag, bg, n_boot, rng):
    n = len(cg)
    if n < 2:
        raise ValueError("Need at least 2 paired query groups")
    point = metrics(np.concatenate(cg), np.concatenate(ag), np.concatenate(bg))

    # The W5 inferential target is the calibrated log-rank statistic.
    # Precompute one contribution per paired query group (normally head+tail)
    # and bootstrap those groups. This is exactly equivalent to rebuilding
    # rank rows for the log-rank means but is much faster and preserves the
    # within-query dependence.
    cand_g = np.asarray([
        np.mean(np.abs(np.log10(c) - np.log10(a)))
        for c, a in zip(cg, ag)
    ], dtype=float)
    null_g = np.asarray([
        np.mean(np.abs(np.log10(b) - np.log10(a)))
        for b, a in zip(bg, ag)
    ], dtype=float)

    dist = {
        "candidate_logrank_gap": np.empty(n_boot, dtype=float),
        "null_logrank_gap": np.empty(n_boot, dtype=float),
        "logrank_excess": np.empty(n_boot, dtype=float),
    }
    chunk = 500
    for st in range(0, n_boot, chunk):
        en = min(n_boot, st + chunk)
        ids = rng.integers(0, n, size=(en - st, n))
        cm = cand_g[ids].mean(axis=1)
        nm = null_g[ids].mean(axis=1)
        dist["candidate_logrank_gap"][st:en] = cm
        dist["null_logrank_gap"][st:en] = nm
        dist["logrank_excess"][st:en] = cm - nm
    return point, dist


def ci(x, alpha):
    lo = float(np.quantile(x, alpha / 2.0))
    hi = float(np.quantile(x, 1.0 - alpha / 2.0))
    return [lo, hi]


def discover(paths):
    hits = []
    for root in paths:
        root = Path(root)
        if not root.exists():
            continue
        files = [root] if root.is_file() else sorted(root.rglob("*.csv"))
        for p in files:
            try:
                fields, rows = read_csv(p)
            except Exception:
                continue
            if not rows:
                continue
            a = first_present(fields, REF_A_NAMES)
            b = first_present(fields, REF_B_NAMES)
            cs = rank_candidates(fields, a, b) if a and b else []
            if a and b and cs:
                hits.append({
                    "file": str(p),
                    "refA": a,
                    "refB": b,
                    "candidates": cs,
                    "group": first_present(fields, GROUP_NAMES),
                    "rows": len(rows),
                })
    return hits


def main():
    p = argparse.ArgumentParser(
        description="Paired query bootstrap CIs for calibrated rank audits."
    )
    p.add_argument("--root", action="append", default=[], help="CSV file or directory; repeatable")
    p.add_argument("--file", action="append", default=[], help="Exact CSV row file; repeatable")
    p.add_argument("--candidate", action="append", default=[],
                   help="Candidate rank column, e.g. rank_GraphDPO; default: all rank_* except refs")
    p.add_argument("--n-boot", type=int, default=10000)
    p.add_argument("--alpha", type=float, default=0.05)
    p.add_argument("--seed", type=int, default=19092026)
    p.add_argument("--discover-only", action="store_true")
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()

    scan = [Path(x) for x in args.root] + [Path(x) for x in args.file]
    hits = discover(scan)
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "discovery.json").write_text(json.dumps(hits, indent=2) + "\n")
    print("=== ELIGIBLE PAIRED-RANK FILES ===")
    for h in hits:
        print(json.dumps(h, sort_keys=True))
    if args.discover_only:
        print("W5_DISCOVERY_OK")
        return
    if not hits:
        raise RuntimeError("No CSV with RefA, RefB, and candidate rank columns found")

    rng_master = np.random.default_rng(args.seed)
    per_cell = []
    # For fixed-cell stratified aggregate bootstrap, keep each cell distribution
    # aligned by bootstrap replicate, but use an independent RNG stream per cell.
    candidate_to_cells = defaultdict(list)

    for h in hits:
        path = Path(h["file"])
        fields, rows = read_csv(path)
        candidates = args.candidate or h["candidates"]
        for cand_col in candidates:
            if cand_col not in fields:
                continue
            cell = infer_cell(path, rows)
            keys, cg, ag, bg = group_arrays(rows, h["group"], cand_col, h["refA"], h["refB"])
            cell_seed = int(rng_master.integers(0, 2**31 - 1))
            point, dist = bootstrap_cell(cg, ag, bg, args.n_boot, np.random.default_rng(cell_seed))
            label = cand_col[len("rank_"):] if cand_col.startswith("rank_") else cand_col
            rec = {
                **cell,
                "candidate": label,
                "candidate_column": cand_col,
                "paired_query_groups": len(keys),
                "rank_rows": int(sum(len(x) for x in cg)),
                "point": point,
                "ci95": {k: ci(v, args.alpha) for k, v in dist.items()},
            }
            per_cell.append(rec)
            candidate_to_cells[label].append((rec, dist))

    if not per_cell:
        raise RuntimeError("Requested candidate columns were not found")

    aggregate = []
    for label, cells in sorted(candidate_to_cells.items()):
        # Equal-weight cells. Each bootstrap replicate independently resamples
        # paired query groups within every fixed experimental cell.
        point_keys = list(cells[0][0]["point"])
        point = {
            k: float(np.mean([rec["point"][k] for rec, _ in cells]))
            for k in point_keys
        }
        inferential_keys = ("candidate_logrank_gap", "null_logrank_gap", "logrank_excess")
        dist = {}
        for k in inferential_keys:
            mat = np.vstack([d[k] for _, d in cells])
            dist[k] = np.mean(mat, axis=0)
        aggregate.append({
            "candidate": label,
            "n_cells": len(cells),
            "point": point,
            "ci95": {k: ci(v, args.alpha) for k, v in dist.items()},
            "positive_excess_cells": int(sum(rec["point"]["logrank_excess"] > 0 for rec, _ in cells)),
            "excess_ci_excludes_zero": bool(ci(dist["logrank_excess"], args.alpha)[0] > 0),
        })

    payload = {
        "bootstrap": {
            "unit": "paired query group (head/tail kept together when query id is available)",
            "aggregation": "stratified within cell, equal-weight fixed-cell mean",
            "n_boot": args.n_boot,
            "alpha": args.alpha,
            "seed": args.seed,
        },
        "cells": per_cell,
        "aggregate": aggregate,
    }
    (args.out / "W5_BOOTSTRAP_CI.json").write_text(json.dumps(payload, indent=2) + "\n")

    with (args.out / "W5_BOOTSTRAP_CI.csv").open("w", newline="") as f:
        fieldnames = [
            "candidate","n_cells",
            "candidate_logrank_gap","candidate_logrank_ci_lo","candidate_logrank_ci_hi",
            "null_logrank_gap","null_logrank_ci_lo","null_logrank_ci_hi",
            "logrank_excess","excess_ci_lo","excess_ci_hi",
            "positive_excess_cells","excess_ci_excludes_zero",
        ]
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for a in aggregate:
            w.writerow({
                "candidate": a["candidate"],
                "n_cells": a["n_cells"],
                "candidate_logrank_gap": a["point"]["candidate_logrank_gap"],
                "candidate_logrank_ci_lo": a["ci95"]["candidate_logrank_gap"][0],
                "candidate_logrank_ci_hi": a["ci95"]["candidate_logrank_gap"][1],
                "null_logrank_gap": a["point"]["null_logrank_gap"],
                "null_logrank_ci_lo": a["ci95"]["null_logrank_gap"][0],
                "null_logrank_ci_hi": a["ci95"]["null_logrank_gap"][1],
                "logrank_excess": a["point"]["logrank_excess"],
                "excess_ci_lo": a["ci95"]["logrank_excess"][0],
                "excess_ci_hi": a["ci95"]["logrank_excess"][1],
                "positive_excess_cells": a["positive_excess_cells"],
                "excess_ci_excludes_zero": a["excess_ci_excludes_zero"],
            })

    print("=== W5 PAIRED BOOTSTRAP ===")
    for a in aggregate:
        print(json.dumps({
            "candidate": a["candidate"],
            "n_cells": a["n_cells"],
            "candidate_logrank": a["point"]["candidate_logrank_gap"],
            "candidate_logrank_ci95": a["ci95"]["candidate_logrank_gap"],
            "null_logrank": a["point"]["null_logrank_gap"],
            "null_logrank_ci95": a["ci95"]["null_logrank_gap"],
            "excess": a["point"]["logrank_excess"],
            "excess_ci95": a["ci95"]["logrank_excess"],
            "positive_excess_cells": a["positive_excess_cells"],
            "excess_ci_excludes_zero": a["excess_ci_excludes_zero"],
        }, sort_keys=True))
    print("W5_BOOTSTRAP_OK")


if __name__ == "__main__":
    main()
