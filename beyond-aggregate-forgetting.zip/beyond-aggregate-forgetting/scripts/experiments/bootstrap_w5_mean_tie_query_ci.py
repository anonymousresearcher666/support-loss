#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np


RULES = ("optimistic", "mean_tie")


def load_cell(summary_path: Path):
    meta = json.loads(summary_path.read_text(encoding="utf8"))
    npz_path = summary_path.with_name("mean_tie_rank_audit.npz")
    if not npz_path.is_file():
        raise FileNotFoundError(npz_path)

    z = np.load(npz_path, allow_pickle=False)
    needed = {"queries"}
    for rule in RULES:
        for label in ("candidate", "refA", "refB"):
            for side in ("head", "tail"):
                needed.add(f"{label}_{side}_{rule}_rank")
    missing = sorted(needed - set(z.files))
    if missing:
        raise ValueError(f"{npz_path}: missing arrays {missing}")

    q = np.asarray(z["queries"], dtype=np.int64)
    if q.ndim != 2 or q.shape[1] != 3:
        raise ValueError(f"{npz_path}: bad queries shape {q.shape}")
    if len(q) != 1000:
        raise ValueError(f"{npz_path}: expected 1000 queries, got {len(q)}")

    arrays = {}
    for rule in RULES:
        arrays[rule] = {}
        for label in ("candidate", "refA", "refB"):
            arrays[rule][label] = {}
            for side in ("head", "tail"):
                k = f"{label}_{side}_{rule}_rank"
                a = np.asarray(z[k], dtype=float)
                if a.shape != (len(q),):
                    raise ValueError(f"{npz_path}: {k} shape {a.shape}")
                if not np.all(np.isfinite(a)):
                    raise ValueError(f"{npz_path}: non-finite values in {k}")
                if np.any(a < 1):
                    raise ValueError(f"{npz_path}: rank < 1 in {k}")
                arrays[rule][label][side] = a

    return meta, q, arrays, npz_path


def query_contributions(a):
    ch, ct = a["candidate"]["head"], a["candidate"]["tail"]
    ah, at = a["refA"]["head"], a["refA"]["tail"]
    bh, bt = a["refB"]["head"], a["refB"]["tail"]

    cand_log = 0.5 * (
        np.abs(np.log10(ch) - np.log10(ah))
        + np.abs(np.log10(ct) - np.log10(at))
    )
    null_log = 0.5 * (
        np.abs(np.log10(bh) - np.log10(ah))
        + np.abs(np.log10(bt) - np.log10(at))
    )

    def topk_pair(xh, xt, yh, yt, k):
        return 0.5 * (
            ((xh <= k) != (yh <= k)).astype(float)
            + ((xt <= k) != (yt <= k)).astype(float)
        )

    cand_t10 = topk_pair(ch, ct, ah, at, 10)
    null_t10 = topk_pair(bh, bt, ah, at, 10)
    cand_t100 = topk_pair(ch, ct, ah, at, 100)
    null_t100 = topk_pair(bh, bt, ah, at, 100)

    # Keep MRR as an extra diagnostic. It does not replace the original
    # W5 primary metrics, but is useful for the same matched rerun.
    cand_mrr_q = 0.5 * (1.0 / ch + 1.0 / ct)
    refa_mrr_q = 0.5 * (1.0 / ah + 1.0 / at)
    refb_mrr_q = 0.5 * (1.0 / bh + 1.0 / bt)

    return {
        "candidate_logrank_gap": cand_log,
        "null_logrank_gap": null_log,
        "logrank_excess": cand_log - null_log,
        "candidate_top10_disagreement": cand_t10,
        "null_top10_disagreement": null_t10,
        "top10_excess": cand_t10 - null_t10,
        "candidate_top100_disagreement": cand_t100,
        "null_top100_disagreement": null_t100,
        "top100_excess": cand_t100 - null_t100,
        # Per-query signed MRR differences are bootstrapped; the reported
        # aggregate gap remains the absolute difference of aggregate MRRs.
        "candidate_mrr_signed": cand_mrr_q - refa_mrr_q,
        "null_mrr_signed": refb_mrr_q - refa_mrr_q,
    }


def ci(x, alpha):
    return [
        float(np.quantile(x, alpha / 2.0)),
        float(np.quantile(x, 1.0 - alpha / 2.0)),
    ]


def bootstrap_contrib(contrib, n_boot, rng):
    n = len(next(iter(contrib.values())))
    if n < 2:
        raise ValueError("Need at least 2 query groups")

    point = {k: float(np.mean(v)) for k, v in contrib.items()}
    dist = {k: np.empty(n_boot, dtype=float) for k in contrib}

    chunk = 500
    for st in range(0, n_boot, chunk):
        en = min(n_boot, st + chunk)
        ids = rng.integers(0, n, size=(en - st, n))
        for k, v in contrib.items():
            dist[k][st:en] = v[ids].mean(axis=1)
    return point, dist


def summarize_rule(cells, dists, alpha):
    keys = [
        "candidate_logrank_gap",
        "null_logrank_gap",
        "logrank_excess",
        "candidate_top10_disagreement",
        "null_top10_disagreement",
        "top10_excess",
        "candidate_top100_disagreement",
        "null_top100_disagreement",
        "top100_excess",
    ]

    point = {
        k: float(np.mean([c["point"][k] for c in cells]))
        for k in keys
    }
    dist = {
        k: np.mean(np.vstack([d[k] for d in dists]), axis=0)
        for k in keys
    }
    ci95 = {k: ci(dist[k], alpha) for k in keys}

    # MRR gaps are absolute differences of aggregate MRRs per cell, matching
    # the earlier W5 reporting. Bootstrap distribution takes abs after the
    # per-cell signed differences are resampled.
    cand_mrr_point_cells = [
        abs(c["point"]["candidate_mrr_signed"]) for c in cells
    ]
    null_mrr_point_cells = [
        abs(c["point"]["null_mrr_signed"]) for c in cells
    ]
    mrr_excess_point_cells = [
        x - y for x, y in zip(cand_mrr_point_cells, null_mrr_point_cells)
    ]

    cand_mrr_dist = np.mean(
        np.vstack([np.abs(d["candidate_mrr_signed"]) for d in dists]), axis=0
    )
    null_mrr_dist = np.mean(
        np.vstack([np.abs(d["null_mrr_signed"]) for d in dists]), axis=0
    )
    mrr_excess_dist = cand_mrr_dist - null_mrr_dist

    point.update({
        "candidate_mrr_gap": float(np.mean(cand_mrr_point_cells)),
        "null_mrr_gap": float(np.mean(null_mrr_point_cells)),
        "mrr_excess": float(np.mean(mrr_excess_point_cells)),
    })
    ci95.update({
        "candidate_mrr_gap": ci(cand_mrr_dist, alpha),
        "null_mrr_gap": ci(null_mrr_dist, alpha),
        "mrr_excess": ci(mrr_excess_dist, alpha),
    })

    positive = {
        "logrank_excess": int(sum(c["point"]["logrank_excess"] > 0 for c in cells)),
        "top10_excess": int(sum(c["point"]["top10_excess"] > 0 for c in cells)),
        "top100_excess": int(sum(c["point"]["top100_excess"] > 0 for c in cells)),
        "mrr_excess": int(sum(x > 0 for x in mrr_excess_point_cells)),
    }

    return {
        "point": point,
        "ci95": ci95,
        "positive_excess_cells": positive,
        "ci_excludes_zero_positive": {
            k: bool(ci95[k][0] > 0)
            for k in ("logrank_excess", "top10_excess", "top100_excess", "mrr_excess")
        },
    }


def main():
    ap = argparse.ArgumentParser(
        description="Query-level bootstrap for the W5 mean-tie sensitivity rerun."
    )
    ap.add_argument("--root", type=Path, action="append", required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--n-boot", type=int, default=10000)
    ap.add_argument("--alpha", type=float, default=0.05)
    ap.add_argument("--seed", type=int, default=19092026)
    ap.add_argument("--expected-cells", type=int, default=12)
    args = ap.parse_args()

    summary_paths = []
    for root in args.root:
        summary_paths.extend(root.glob("*/*/*/summary.json"))
    summary_paths = sorted(set(summary_paths))
    if len(summary_paths) != args.expected_cells:
        raise RuntimeError(
            f"Expected {args.expected_cells} cell summary.json files, found {len(summary_paths)}"
        )

    args.out.mkdir(parents=True, exist_ok=True)
    rng_master = np.random.default_rng(args.seed)

    cells_by_rule = {rule: [] for rule in RULES}
    dists_by_rule = {rule: [] for rule in RULES}

    for summary_path in summary_paths:
        meta, queries, arrays, npz_path = load_cell(summary_path)
        cell_seed = int(rng_master.integers(0, 2**31 - 1))

        base = {
            "dataset": meta["dataset"],
            "seed": int(meta["seed"]),
            "mode": meta["mode"],
            "request_hash": meta["request_hash"],
            "n_queries": int(len(queries)),
            "n_rankings": int(2 * len(queries)),
            "npz": str(npz_path),
        }

        # Crucially, use the same bootstrap resample indices for optimistic
        # and mean-tie within a cell by reinitializing with cell_seed.
        for rule in RULES:
            contrib = query_contributions(arrays[rule])
            point, dist = bootstrap_contrib(
                contrib, args.n_boot, np.random.default_rng(cell_seed)
            )
            cells_by_rule[rule].append({**base, "rule": rule, "point": point})
            dists_by_rule[rule].append(dist)

    aggregate = {
        rule: summarize_rule(cells_by_rule[rule], dists_by_rule[rule], args.alpha)
        for rule in RULES
    }

    # Paired difference mean-tie minus optimistic using the SAME bootstrap
    # replicates, which directly quantifies tie-rule sensitivity.
    paired_delta = {}
    metric_keys = [
        "candidate_logrank_gap",
        "null_logrank_gap",
        "logrank_excess",
        "candidate_top10_disagreement",
        "null_top10_disagreement",
        "top10_excess",
        "candidate_top100_disagreement",
        "null_top100_disagreement",
        "top100_excess",
    ]
    for k in metric_keys:
        opt_point = aggregate["optimistic"]["point"][k]
        mt_point = aggregate["mean_tie"]["point"][k]
        opt_dist = np.mean(
            np.vstack([d[k] for d in dists_by_rule["optimistic"]]), axis=0
        )
        mt_dist = np.mean(
            np.vstack([d[k] for d in dists_by_rule["mean_tie"]]), axis=0
        )
        dd = mt_dist - opt_dist
        paired_delta[k] = {
            "point_delta": float(mt_point - opt_point),
            "ci95_delta": ci(dd, args.alpha),
            "max_abs_bootstrap_delta": float(np.max(np.abs(dd))),
        }

    payload = {
        "bootstrap": {
            "roots": [str(x) for x in args.root],
            "unit": "query triple; head and tail kept together",
            "aggregation": f"stratified within each fixed cell; equal-weight mean across {args.expected_cells} cells",
            "n_boot": args.n_boot,
            "alpha": args.alpha,
            "seed": args.seed,
            "paired_rule_comparison": "same bootstrap indices within each cell for optimistic and mean-tie",
            "evaluation_dtype": "float32",
        },
        "cells": {
            rule: cells_by_rule[rule]
            for rule in RULES
        },
        "aggregate": aggregate,
        "mean_tie_minus_optimistic": paired_delta,
    }

    out_json = args.out / "W5_MEAN_TIE_QUERY_BOOTSTRAP.json"
    out_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf8")

    out_csv = args.out / "W5_MEAN_TIE_QUERY_BOOTSTRAP.csv"
    with out_csv.open("w", newline="", encoding="utf8") as f:
        fields = [
            "rule", "dataset", "seed", "mode", "request_hash", "n_queries",
            "candidate_logrank_gap", "null_logrank_gap", "logrank_excess",
            "candidate_top10_disagreement", "null_top10_disagreement", "top10_excess",
            "candidate_top100_disagreement", "null_top100_disagreement", "top100_excess",
            "candidate_mrr_gap", "null_mrr_gap", "mrr_excess",
        ]
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for rule in RULES:
            for c in cells_by_rule[rule]:
                p = c["point"]
                cand_mrr_gap = abs(p["candidate_mrr_signed"])
                null_mrr_gap = abs(p["null_mrr_signed"])
                w.writerow({
                    "rule": rule,
                    "dataset": c["dataset"],
                    "seed": c["seed"],
                    "mode": c["mode"],
                    "request_hash": c["request_hash"],
                    "n_queries": c["n_queries"],
                    "candidate_logrank_gap": p["candidate_logrank_gap"],
                    "null_logrank_gap": p["null_logrank_gap"],
                    "logrank_excess": p["logrank_excess"],
                    "candidate_top10_disagreement": p["candidate_top10_disagreement"],
                    "null_top10_disagreement": p["null_top10_disagreement"],
                    "top10_excess": p["top10_excess"],
                    "candidate_top100_disagreement": p["candidate_top100_disagreement"],
                    "null_top100_disagreement": p["null_top100_disagreement"],
                    "top100_excess": p["top100_excess"],
                    "candidate_mrr_gap": cand_mrr_gap,
                    "null_mrr_gap": null_mrr_gap,
                    "mrr_excess": cand_mrr_gap - null_mrr_gap,
                })

    print("=== W5 MEAN-TIE QUERY BOOTSTRAP ===")
    print(f"cells={args.expected_cells} n_boot={args.n_boot} seed={args.seed}")
    for rule in RULES:
        a = aggregate[rule]
        print(f"\n[{rule}]")
        for k in (
            "candidate_logrank_gap", "null_logrank_gap", "logrank_excess",
            "candidate_top10_disagreement", "null_top10_disagreement", "top10_excess",
            "candidate_top100_disagreement", "null_top100_disagreement", "top100_excess",
            "candidate_mrr_gap", "null_mrr_gap", "mrr_excess",
        ):
            p = a["point"][k]
            lo, hi = a["ci95"][k]
            print(f"{k}={p:.10f} CI95=[{lo:.10f},{hi:.10f}]")
        for k in ("logrank_excess", "top10_excess", "top100_excess", "mrr_excess"):
            print(
                f"{k}: positive_cells={a['positive_excess_cells'][k]}/{args.expected_cells} "
                f"ci_excludes_zero_positive={a['ci_excludes_zero_positive'][k]}"
            )

    print("\n[MEAN_TIE - OPTIMISTIC, PAIRED BOOTSTRAP]")
    for k, rec in paired_delta.items():
        lo, hi = rec["ci95_delta"]
        print(
            f"{k}: delta={rec['point_delta']:.12g} "
            f"CI95=[{lo:.12g},{hi:.12g}] "
            f"max_abs_bootstrap_delta={rec['max_abs_bootstrap_delta']:.12g}"
        )

    print(f"json={out_json}")
    print(f"csv={out_csv}")
    print("W5_MEAN_TIE_QUERY_BOOTSTRAP_OK")


if __name__ == "__main__":
    main()
