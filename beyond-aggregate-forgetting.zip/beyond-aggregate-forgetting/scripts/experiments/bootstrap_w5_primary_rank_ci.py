#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path

import numpy as np


FILE_RE = re.compile(
    r"(?P<dataset>.+)_s(?P<seed>\d+)_(?P<mode>.+)_(?P<request_hash>[0-9a-f]+)_independent_null\.npz$"
)

RL_HEAD = "SchemaCert_plus_Restart_L5_head_rank"
RL_TAIL = "SchemaCert_plus_Restart_L5_tail_rank"


def qkey(row):
    return (int(row["h"]), int(row["r"]), int(row["t"]))


def load_candidate_csv(path: Path):
    with path.open(newline="", encoding="utf8") as f:
        reader = csv.DictReader(f)
        fields = set(reader.fieldnames or [])
        required = {"h", "r", "t", RL_HEAD, RL_TAIL}
        missing = sorted(required - fields)
        if missing:
            raise ValueError(f"{path}: missing columns {missing}")

        mapping = {}
        duplicate_identical = 0
        for row in reader:
            k = qkey(row)
            v = (int(row[RL_HEAD]), int(row[RL_TAIL]))
            if k in mapping:
                if mapping[k] != v:
                    raise ValueError(
                        f"{path}: ambiguous duplicate triple {k}: {mapping[k]} vs {v}"
                    )
                duplicate_identical += 1
            else:
                mapping[k] = v
    return mapping, duplicate_identical


def find_candidate_csv(roots, dataset, seed, mode, request_hash):
    name = f"{dataset}_s{seed}_{mode}_{request_hash}_forgotten_query_ranks.csv"
    hits = []
    for root in roots:
        root = Path(root)
        if root.exists():
            hits.extend(root.rglob(name))
    hits = sorted(set(hits))
    if len(hits) != 1:
        raise RuntimeError(
            f"Expected exactly one candidate CSV for {name}, found {len(hits)}: "
            + ", ".join(str(x) for x in hits)
        )
    return hits[0]


def paired_arrays(npz_path: Path, csv_path: Path):
    z = np.load(npz_path, allow_pickle=False)
    needed = {
        "queries", "refA_head_rank", "refA_tail_rank",
        "refB_head_rank", "refB_tail_rank",
    }
    missing = sorted(needed - set(z.files))
    if missing:
        raise ValueError(f"{npz_path}: missing arrays {missing}")

    queries = np.asarray(z["queries"], dtype=np.int64)
    if queries.ndim != 2 or queries.shape[1] != 3:
        raise ValueError(f"{npz_path}: queries has unexpected shape {queries.shape}")

    n = len(queries)
    arrays = {
        "refA_head": np.asarray(z["refA_head_rank"], dtype=float),
        "refA_tail": np.asarray(z["refA_tail_rank"], dtype=float),
        "refB_head": np.asarray(z["refB_head_rank"], dtype=float),
        "refB_tail": np.asarray(z["refB_tail_rank"], dtype=float),
    }
    for k, a in arrays.items():
        if a.shape != (n,):
            raise ValueError(f"{npz_path}: {k} shape {a.shape}, expected {(n,)}")

    mapping, duplicate_identical = load_candidate_csv(csv_path)
    cand_head = np.empty(n, dtype=float)
    cand_tail = np.empty(n, dtype=float)
    missing_queries = []
    for i, q in enumerate(queries):
        k = tuple(int(x) for x in q)
        v = mapping.get(k)
        if v is None:
            missing_queries.append(k)
            continue
        cand_head[i], cand_tail[i] = v

    if missing_queries:
        preview = ", ".join(map(str, missing_queries[:10]))
        raise RuntimeError(
            f"{csv_path}: {len(missing_queries)}/{n} null queries not found in candidate CSV; "
            f"first: {preview}"
        )

    out = {
        "candidate_head": cand_head,
        "candidate_tail": cand_tail,
        **arrays,
    }
    for k, a in out.items():
        if not np.all(np.isfinite(a)):
            raise ValueError(f"{npz_path}: non-finite values in {k}")
        if np.any(a < 1):
            raise ValueError(f"{npz_path}: rank < 1 in {k}")

    return queries, out, duplicate_identical


def query_contributions(a):
    ch, ct = a["candidate_head"], a["candidate_tail"]
    ah, at = a["refA_head"], a["refA_tail"]
    bh, bt = a["refB_head"], a["refB_tail"]

    cand_log = 0.5 * (
        np.abs(np.log10(ch) - np.log10(ah))
        + np.abs(np.log10(ct) - np.log10(at))
    )
    null_log = 0.5 * (
        np.abs(np.log10(bh) - np.log10(ah))
        + np.abs(np.log10(bt) - np.log10(at))
    )

    def topk_pair(xh, xt, yh, yt, k):
        return 0.5 * (
            ((xh <= k) != (yh <= k)).astype(float)
            + ((xt <= k) != (yt <= k)).astype(float)
        )

    cand_t10 = topk_pair(ch, ct, ah, at, 10)
    null_t10 = topk_pair(bh, bt, ah, at, 10)
    cand_t100 = topk_pair(ch, ct, ah, at, 100)
    null_t100 = topk_pair(bh, bt, ah, at, 100)

    return {
        "candidate_logrank_gap": cand_log,
        "null_logrank_gap": null_log,
        "logrank_excess": cand_log - null_log,
        "candidate_top10_disagreement": cand_t10,
        "null_top10_disagreement": null_t10,
        "top10_excess": cand_t10 - null_t10,
        "candidate_top100_disagreement": cand_t100,
        "null_top100_disagreement": null_t100,
        "top100_excess": cand_t100 - null_t100,
    }


def ci(x, alpha):
    return [
        float(np.quantile(x, alpha / 2.0)),
        float(np.quantile(x, 1.0 - alpha / 2.0)),
    ]


def bootstrap_contrib(contrib, n_boot, rng):
    n = len(next(iter(contrib.values())))
    if n < 2:
        raise ValueError("Need at least 2 query groups")

    point = {k: float(np.mean(v)) for k, v in contrib.items()}
    dist = {k: np.empty(n_boot, dtype=float) for k in contrib}

    chunk = 500
    for st in range(0, n_boot, chunk):
        en = min(n_boot, st + chunk)
        ids = rng.integers(0, n, size=(en - st, n))
        for k, v in contrib.items():
            dist[k][st:en] = v[ids].mean(axis=1)
    return point, dist


def validate_summary(npz_path: Path, point, tol):
    js = npz_path.with_suffix(".json")
    if not js.exists():
        raise RuntimeError(f"Missing paired JSON summary: {js}")
    meta = json.loads(js.read_text(encoding="utf8"))
    c = meta.get("candidate_vs_refA", {})
    n = meta.get("refA_vs_refB", {})

    expected = {
        "candidate_logrank_gap": c.get("mean_abs_log10_rank_gap"),
        "null_logrank_gap": n.get("mean_abs_log10_rank_gap"),
        "candidate_top10_disagreement": c.get("top10_membership_disagreement"),
        "null_top10_disagreement": n.get("top10_membership_disagreement"),
        "candidate_top100_disagreement": c.get("top100_membership_disagreement"),
        "null_top100_disagreement": n.get("top100_membership_disagreement"),
    }

    diffs = {}
    for k, e in expected.items():
        if e is None:
            raise RuntimeError(f"{js}: missing validation metric for {k}")
        d = abs(point[k] - float(e))
        diffs[k] = d
        if d > tol:
            raise RuntimeError(
                f"{npz_path}: validation failed for {k}: computed={point[k]:.12g}, "
                f"json={float(e):.12g}, abs_diff={d:.3g} > tol={tol}"
            )
    return meta, diffs


def main():
    ap = argparse.ArgumentParser(
        description="W5 primary paired-query bootstrap: R+L vs independent retraining null."
    )
    ap.add_argument("--null-root", type=Path, required=True)
    ap.add_argument("--rank-root", action="append", required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--n-boot", type=int, default=10000)
    ap.add_argument("--alpha", type=float, default=0.05)
    ap.add_argument("--seed", type=int, default=19092026)
    ap.add_argument("--summary-tol", type=float, default=1e-4)
    args = ap.parse_args()

    npzs = sorted(args.null_root.glob("*_independent_null.npz"))
    if len(npzs) != 12:
        raise RuntimeError(f"Expected 12 independent-null cells, found {len(npzs)}")

    args.out.mkdir(parents=True, exist_ok=True)
    rng_master = np.random.default_rng(args.seed)

    cells = []
    dists = []

    for npz_path in npzs:
        m = FILE_RE.match(npz_path.name)
        if not m:
            raise RuntimeError(f"Cannot parse cell name: {npz_path.name}")
        info = m.groupdict()
        csv_path = find_candidate_csv(
            args.rank_root,
            info["dataset"],
            info["seed"],
            info["mode"],
            info["request_hash"],
        )
        queries, arrays, duplicate_identical = paired_arrays(npz_path, csv_path)
        contrib = query_contributions(arrays)

        cell_seed = int(rng_master.integers(0, 2**31 - 1))
        point, dist = bootstrap_contrib(
            contrib, args.n_boot, np.random.default_rng(cell_seed)
        )
        meta, validation_diffs = validate_summary(
            npz_path, point, args.summary_tol
        )

        rec = {
            **info,
            "null_npz": str(npz_path),
            "candidate_csv": str(csv_path),
            "n_queries": int(len(queries)),
            "n_rankings": int(2 * len(queries)),
            "duplicate_identical_candidate_triples": int(duplicate_identical),
            "reference_seed_a": meta.get("reference_seed_a"),
            "reference_seed_b": meta.get("reference_seed_b"),
            "point": point,
            "ci95": {k: ci(v, args.alpha) for k, v in dist.items()},
            "validation_abs_diff": validation_diffs,
        }
        cells.append(rec)
        dists.append(dist)

    keys = list(cells[0]["point"])
    aggregate_point = {
        k: float(np.mean([c["point"][k] for c in cells]))
        for k in keys
    }
    aggregate_dist = {
        k: np.mean(np.vstack([d[k] for d in dists]), axis=0)
        for k in keys
    }
    aggregate_ci = {k: ci(v, args.alpha) for k, v in aggregate_dist.items()}

    excess_keys = ("logrank_excess", "top10_excess", "top100_excess")
    aggregate = {
        "n_cells": len(cells),
        "point": aggregate_point,
        "ci95": aggregate_ci,
        "positive_excess_cells": {
            k: int(sum(c["point"][k] > 0 for c in cells))
            for k in excess_keys
        },
        "ci_excludes_zero_positive": {
            k: bool(aggregate_ci[k][0] > 0)
            for k in excess_keys
        },
    }

    payload = {
        "bootstrap": {
            "candidate": "SchemaCert_plus_Restart_L5 (R+L)",
            "candidate_reference": "RefA independent same-budget retraining",
            "null": "RefA vs RefB independent same-budget retraining",
            "unit": "query triple; head and tail kept together",
            "aggregation": "stratified within each fixed cell; equal-weight mean across 12 cells",
            "n_boot": args.n_boot,
            "alpha": args.alpha,
            "seed": args.seed,
            "summary_validation_tolerance": args.summary_tol,
        },
        "cells": cells,
        "aggregate": aggregate,
    }
    out_json = args.out / "W5_PRIMARY_BOOTSTRAP_CI.json"
    out_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf8")

    out_csv = args.out / "W5_PRIMARY_BOOTSTRAP_CI.csv"
    with out_csv.open("w", newline="", encoding="utf8") as f:
        fields = [
            "dataset", "seed", "mode", "request_hash", "n_queries",
            "candidate_logrank_gap", "candidate_logrank_ci_lo", "candidate_logrank_ci_hi",
            "null_logrank_gap", "null_logrank_ci_lo", "null_logrank_ci_hi",
            "logrank_excess", "logrank_excess_ci_lo", "logrank_excess_ci_hi",
            "candidate_top10_disagreement", "candidate_top10_ci_lo", "candidate_top10_ci_hi",
            "null_top10_disagreement", "null_top10_ci_lo", "null_top10_ci_hi",
            "top10_excess", "top10_excess_ci_lo", "top10_excess_ci_hi",
            "candidate_top100_disagreement", "candidate_top100_ci_lo", "candidate_top100_ci_hi",
            "null_top100_disagreement", "null_top100_ci_lo", "null_top100_ci_hi",
            "top100_excess", "top100_excess_ci_lo", "top100_excess_ci_hi",
        ]
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for c in cells:
            p, ci95 = c["point"], c["ci95"]
            row = {
                "dataset": c["dataset"], "seed": c["seed"], "mode": c["mode"],
                "request_hash": c["request_hash"], "n_queries": c["n_queries"],
            }
            for metric in (
                "candidate_logrank_gap", "null_logrank_gap", "logrank_excess",
                "candidate_top10_disagreement", "null_top10_disagreement", "top10_excess",
                "candidate_top100_disagreement", "null_top100_disagreement", "top100_excess",
            ):
                base = metric
                row[base] = p[metric]
                if metric == "candidate_logrank_gap":
                    pref = "candidate_logrank"
                elif metric == "null_logrank_gap":
                    pref = "null_logrank"
                elif metric == "logrank_excess":
                    pref = "logrank_excess"
                elif metric == "candidate_top10_disagreement":
                    pref = "candidate_top10"
                elif metric == "null_top10_disagreement":
                    pref = "null_top10"
                elif metric == "top10_excess":
                    pref = "top10_excess"
                elif metric == "candidate_top100_disagreement":
                    pref = "candidate_top100"
                elif metric == "null_top100_disagreement":
                    pref = "null_top100"
                else:
                    pref = "top100_excess"
                row[pref + "_ci_lo"] = ci95[metric][0]
                row[pref + "_ci_hi"] = ci95[metric][1]
            w.writerow(row)

    print("=== W5 PRIMARY BOOTSTRAP ===")
    print(f"cells={len(cells)}")
    for k in (
        "candidate_logrank_gap", "null_logrank_gap", "logrank_excess",
        "candidate_top10_disagreement", "null_top10_disagreement", "top10_excess",
        "candidate_top100_disagreement", "null_top100_disagreement", "top100_excess",
    ):
        print(
            f"{k}={aggregate_point[k]:.8f} "
            f"CI95=[{aggregate_ci[k][0]:.8f}, {aggregate_ci[k][1]:.8f}]"
        )
    for k in excess_keys:
        print(
            f"{k}: positive_cells={aggregate['positive_excess_cells'][k]}/12 "
            f"ci_excludes_zero_positive={aggregate['ci_excludes_zero_positive'][k]}"
        )
    print(f"json={out_json}")
    print(f"csv={out_csv}")
    print("W5_PRIMARY_BOOTSTRAP_OK")


if __name__ == "__main__":
    main()
