#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

EXPECTED_MODELS = {'rotate', 'pairre', 'compounde'}
REQUIRED = {
    'ExactRetrain', 'SchemaCert-L5', 'FullFinetune',
    'SchemaCert+Restart-L5', 'SGU-FamilyAdapted', 'GraphDPO-FamilyAdapted',
}


def finite(x):
    return x not in ('', None) and math.isfinite(float(x))


def main():
    p = argparse.ArgumentParser(); p.add_argument('--input', required=True)
    args = p.parse_args(); root = Path(args.input)
    csvs = sorted(root.glob('*_family_competitors.csv'))
    if len(csvs) != 3:
        raise RuntimeError(f'expected 3 smoke CSVs, found {len(csvs)}')
    seen = set()
    for path in csvs:
        with path.open(newline='') as h:
            rows = list(csv.DictReader(h))
        by = {r['method']: r for r in rows}
        if set(by) != REQUIRED:
            raise RuntimeError(f'{path}: methods={sorted(by)} expected={sorted(REQUIRED)}')
        ref = by['ExactRetrain']; model = ref['model'].lower(); seen.add(model)
        if ref['dataset'] != 'FB15K-237' or int(ref['seed']) != 17 or abs(float(ref['fraction']) - 0.10) > 1e-9:
            raise RuntimeError(f'{path}: unexpected smoke cell')
        for method, row in by.items():
            for key in ('global_mrr', 'forget_mrr', 'global_mrr_gap_to_exact', 'forget_mrr_gap_to_exact'):
                if not finite(row.get(key)):
                    raise RuntimeError(f'{path}: non-finite {method}/{key}')
        meta_path = path.with_suffix('.json')
        if not meta_path.is_file():
            raise RuntimeError(f'missing {meta_path}')
        meta = json.loads(meta_path.read_text())
        base = meta['base_rebuild']
        if float(base['absolute_delta']) > float(base['tolerance']):
            raise RuntimeError(f'{path}: base reconstruction outside tolerance')
        if int(meta['sgu']['used_triples']) <= 0:
            raise RuntimeError(f'{path}: SGU used zero triples')
        if int(meta['graphdpo']['preference_pairs']) <= 0:
            raise RuntimeError(f'{path}: GraphDPO generated zero pairs')
        if not finite(meta['graphdpo']['final_preference_accuracy']):
            raise RuntimeError(f'{path}: GraphDPO preference accuracy non-finite')
        print(
            f"SMOKE_OK model={model} "
            f"restart=({float(by['SchemaCert+Restart-L5']['global_mrr_gap_to_exact']):.6f},"
            f"{float(by['SchemaCert+Restart-L5']['forget_mrr_gap_to_exact']):.6f}) "
            f"sgu=({float(by['SGU-FamilyAdapted']['global_mrr_gap_to_exact']):.6f},"
            f"{float(by['SGU-FamilyAdapted']['forget_mrr_gap_to_exact']):.6f}) "
            f"graphdpo=({float(by['GraphDPO-FamilyAdapted']['global_mrr_gap_to_exact']):.6f},"
            f"{float(by['GraphDPO-FamilyAdapted']['forget_mrr_gap_to_exact']):.6f})"
        )
    if seen != EXPECTED_MODELS:
        raise RuntimeError(f'model coverage mismatch: {seen}')
    print('FAMILY_COMPETITOR_SMOKE_GATE_OK 3/3')


if __name__ == '__main__':
    main()
