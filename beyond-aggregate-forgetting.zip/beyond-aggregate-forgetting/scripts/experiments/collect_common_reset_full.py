#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path
from statistics import mean, stdev


def f(x):
    if x is None or x == '':
        return math.nan
    return float(x)


def stats(xs):
    vals = [x for x in xs if math.isfinite(x)]
    if not vals:
        return {'n': 0, 'mean': None, 'sd': None}
    return {
        'n': len(vals),
        'mean': mean(vals),
        'sd': stdev(vals) if len(vals) > 1 else 0.0,
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', required=True)
    p.add_argument('--out', required=True)
    args = p.parse_args()

    root = Path(args.root)
    files = sorted(root.glob('*_common_support_reset.csv'))
    if len(files) != 12:
        raise RuntimeError(f'Expected 12 common-reset CSVs, found {len(files)} in {root}')

    records = []
    required = {'ExactRetrain', 'SchemaCert-L5', 'SchemaCert+Reset-L5', 'Finetune', 'NG', 'GraphDPO'}
    for path in files:
        with open(path, newline='') as fh:
            rows = list(csv.DictReader(fh))
        methods = {r['method'] for r in rows}
        missing = required - methods
        if missing:
            raise RuntimeError(f'{path}: missing methods {sorted(missing)}')
        if len(rows) != len(required):
            raise RuntimeError(f'{path}: expected {len(required)} rows, found {len(rows)}')
        config = path.stem.removesuffix('_common_support_reset')
        for r in rows:
            r = dict(r)
            r['_file'] = str(path)
            r['_config'] = config
            records.append(r)

    by_method = defaultdict(list)
    for r in records:
        by_method[r['method']].append(r)

    order = ['ExactRetrain', 'SchemaCert-L5', 'SchemaCert+Reset-L5', 'Finetune', 'NG', 'GraphDPO']
    summary = []
    for m in order:
        rs = by_method[m]
        gg = [f(r['global_mrr_gap_to_exact']) for r in rs]
        fg = [f(r['forget_mrr_gap_to_exact']) for r in rs]
        gm = [f(r['global_mrr']) for r in rs]
        fm = [f(r['forget_mrr']) for r in rs]
        ts = [f(r['train_sec']) for r in rs]
        summary.append({
            'method': m,
            'n': len(rs),
            'global_gap_mean': stats(gg)['mean'],
            'global_gap_sd': stats(gg)['sd'],
            'forget_gap_mean': stats(fg)['mean'],
            'forget_gap_sd': stats(fg)['sd'],
            'global_mrr_mean': stats(gm)['mean'],
            'forget_mrr_mean': stats(fm)['mean'],
            'train_sec_mean_native_or_local': stats(ts)['mean'],
        })

    # Per-configuration Pareto comparison among approximate methods only.
    approx = ['SchemaCert-L5', 'SchemaCert+Reset-L5', 'Finetune', 'NG', 'GraphDPO']
    grouped = defaultdict(dict)
    for r in records:
        if r['method'] == 'ExactRetrain':
            continue
        grouped[r['_config']][r['method']] = r

    if len(grouped) != 12:
        raise RuntimeError(f'Expected 12 configurations, found {len(grouped)}')

    pareto_counts = {m: 0 for m in approx}
    both_best_counts = {m: 0 for m in approx}
    reset_dominates = {m: 0 for m in ['Finetune', 'NG', 'GraphDPO', 'SchemaCert-L5']}
    per_config = []
    for config, mm in sorted(grouped.items()):
        if set(mm) != set(approx):
            raise RuntimeError(f'{config}: incomplete method set: {sorted(mm)}')
        points = {
            m: (f(mm[m]['global_mrr_gap_to_exact']), f(mm[m]['forget_mrr_gap_to_exact']))
            for m in approx
        }
        min_g = min(v[0] for v in points.values())
        min_f = min(v[1] for v in points.values())
        for m, (g, q) in points.items():
            dominated = any(
                (g2 <= g and q2 <= q and (g2 < g or q2 < q))
                for om, (g2, q2) in points.items() if om != m
            )
            if not dominated:
                pareto_counts[m] += 1
            if math.isclose(g, min_g, rel_tol=0, abs_tol=1e-15) and math.isclose(q, min_f, rel_tol=0, abs_tol=1e-15):
                both_best_counts[m] += 1
        rg, rf = points['SchemaCert+Reset-L5']
        for m in reset_dominates:
            g, q = points[m]
            if rg <= g and rf <= q and (rg < g or rf < q):
                reset_dominates[m] += 1
        per_config.append({
            'config': config,
            'request_hash': mm['SchemaCert+Reset-L5']['request_hash'],
            'points': points,
        })

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    csv_path = out / 'common_reset_full_summary.csv'
    json_path = out / 'common_reset_full_summary.json'
    with open(csv_path, 'w', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=list(summary[0].keys()))
        w.writeheader()
        w.writerows(summary)

    payload = {
        'n_csv': len(files),
        'n_configs': len(grouped),
        'summary': summary,
        'pareto_counts': pareto_counts,
        'both_best_counts': both_best_counts,
        'reset_dominates_counts': reset_dominates,
        'per_config': per_config,
    }
    json_path.write_text(json.dumps(payload, indent=2))

    print('method\tn\tglobal_gap_mean\tforget_gap_mean')
    for r in summary:
        print(f"{r['method']}\t{r['n']}\t{r['global_gap_mean']:.6f}\t{r['forget_gap_mean']:.6f}")
    print('PARETO_COUNTS ' + json.dumps(pareto_counts, sort_keys=True))
    print('BOTH_BEST_COUNTS ' + json.dumps(both_best_counts, sort_keys=True))
    print('RESET_DOMINATES_COUNTS ' + json.dumps(reset_dominates, sort_keys=True))
    print(f'COMMON_RESET_FULL_SUMMARY_CSV={csv_path}')
    print(f'COMMON_RESET_FULL_SUMMARY_JSON={json_path}')
    print('COMMON_RESET_FULL_COLLECT_OK')


if __name__ == '__main__':
    main()
