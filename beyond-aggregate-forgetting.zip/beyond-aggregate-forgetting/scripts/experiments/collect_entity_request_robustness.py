#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,json
from pathlib import Path
import numpy as np

MODES=['fullstar-low','fullstar-mid','fullstar-high','exact-card-high','partial-star-high']
METHODS=['FiniteRetrain-20','SchemaCert-L5','SchemaCert+Restart-L5']

def ci(x,seed,b=10000):
    x=np.asarray(x,float);rng=np.random.default_rng(seed);z=np.array([rng.choice(x,len(x),replace=True).mean() for _ in range(b)])
    return float(x.mean()),float(np.quantile(z,.025)),float(np.quantile(z,.975))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--out',required=True);args=ap.parse_args()
    files=sorted(Path(args.root).glob('*_entity_request_robustness.csv'))
    if len(files)!=6: raise RuntimeError(f'expected6 files found{len(files)}')
    rows=[]
    for p in files: rows+=list(csv.DictReader(p.open()))
    if len(rows)!=90: raise RuntimeError(f'expected90 rows found{len(rows)}')
    summary=[]
    for i,mode in enumerate(MODES):
        mr=[r for r in rows if r['request_mode']==mode]
        if len(mr)!=18: raise RuntimeError(f'{mode}: expected18 rows')
        # request properties duplicated across 3 method rows; take one per dataset/seed.
        req=[r for r in mr if r['method']=='FiniteRetrain-20']
        for method in ['SchemaCert-L5','SchemaCert+Restart-L5']:
            s=[r for r in mr if r['method']==method]
            g=ci([float(r['global_gap_to_ref']) for r in s],100+i*10+(0 if method=='SchemaCert-L5' else 1))
            f=ci([float(r['forget_gap_to_ref']) for r in s],200+i*10+(0 if method=='SchemaCert-L5' else 1))
            summary.append({'request_mode':mode,'method':method,'n':len(s),
                'mean_realized_fraction':float(np.mean([float(r['realized_fraction']) for r in req])),
                'mean_selected_n':float(np.mean([float(r['selected_n']) for r in req])),
                'mean_unsupported_fraction':float(np.mean([float(r['unsupported_fraction']) for r in req])),
                'global_gap_mean':g[0],'global_gap_ci95_lo':g[1],'global_gap_ci95_hi':g[2],
                'forget_gap_mean':f[0],'forget_gap_ci95_lo':f[1],'forget_gap_ci95_hi':f[2]})
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    with (out/'entity_request_robustness_summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(summary[0].keys()));w.writeheader();w.writerows(summary)
    obj={'files':6,'requests':30,'summary':summary}
    (out/'entity_request_robustness_summary.json').write_text(json.dumps(obj,indent=2)+'\n')
    md=['# Entity request robustness','', '| Request | Method | unsupported selected fraction | global gap [95% CI] | forgotten gap [95% CI] |','|---|---|---:|---:|---:|']
    for x in summary:
        md.append(f"| {x['request_mode']} | {x['method']} | {x['mean_unsupported_fraction']:.3f} | {x['global_gap_mean']:.6f} [{x['global_gap_ci95_lo']:.6f},{x['global_gap_ci95_hi']:.6f}] | {x['forget_gap_mean']:.6f} [{x['forget_gap_ci95_lo']:.6f},{x['forget_gap_ci95_hi']:.6f}] |")
    (out/'ENTITY_REQUEST_ROBUSTNESS.md').write_text('\n'.join(md)+'\n')
    print('ENTITY_REQUEST_ROBUSTNESS_COLLECT_OK');print('\n'.join(md))
if __name__=='__main__':main()
