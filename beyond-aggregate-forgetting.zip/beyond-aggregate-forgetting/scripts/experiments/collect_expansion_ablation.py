#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import math
import statistics
from collections import defaultdict
from pathlib import Path

REQ_KEYS = ("dataset", "model", "policy", "fraction", "seed")
LEVEL_ORDER = {"hops1": 1, "hops2": 2, "hops3": 3, "full_finetune": 4}
METRICS = (
    "eta_hvp",
    "boundary_ratio",
    "parameter_fraction",
    "unique_work_fraction",
    "global_mrr_gap",
    "forgotten_mrr_gap",
    "parameter_distance_to_reference",
    "speedup_vs_reference",
    "local_sec",
)
VALID_NONFULL_ETA_STATUS = {"ok", "zero_cross"}


def f(x):
    try:
        return float(x)
    except Exception:
        return float("nan")


def finite(xs):
    return [x for x in xs if math.isfinite(x)]


def mean(xs):
    xs = finite(xs)
    return statistics.fmean(xs) if xs else float("nan")


def sd(xs):
    xs = finite(xs)
    if not xs:
        return float("nan")
    return statistics.stdev(xs) if len(xs) >= 2 else 0.0


def median(xs):
    xs = finite(xs)
    return statistics.median(xs) if xs else float("nan")


def prop(flags):
    vals = [1.0 if x else 0.0 for x in flags]
    return statistics.fmean(vals) if vals else float("nan")


def write_csv(path: Path, rows, fields=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = list(rows[0].keys()) if rows else []
    with path.open("w", newline="") as h:
        w = csv.DictWriter(h, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def load_rows(root: Path):
    rows = []
    files = sorted(root.glob("*.csv"))
    for p in files:
        with p.open(newline="") as h:
            for r in csv.DictReader(h):
                r["_file"] = str(p)
                r["fraction"] = f(r.get("fraction"))
                r["seed"] = int(float(r.get("seed", "nan")))
                r["hops"] = int(float(r.get("hops", "nan")))
                for k in METRICS:
                    r[k] = f(r.get(k))
                rows.append(r)
    return files, rows


def req_key(r):
    return tuple(r[k] for k in REQ_KEYS)


def is_full(r):
    return (
        r.get("eta_status") == "full"
        or (math.isfinite(r["parameter_fraction"]) and r["parameter_fraction"] >= 1.0 - 1e-9)
    )


def delta(a, b, metric):
    x, y = a[metric], b[metric]
    return y - x if math.isfinite(x) and math.isfinite(y) else float("nan")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default="results_cluster/mechanism/expansion")
    ap.add_argument("--out", default="results_cluster/mechanism/expansion_analysis")
    args = ap.parse_args()

    root = Path(args.root)
    out = Path(args.out)
    files, rows = load_rows(root)
    by_req = defaultdict(list)
    for r in rows:
        by_req[req_key(r)].append(r)

    complete, incomplete = [], []
    wanted = set(LEVEL_ORDER)
    for k, rs in sorted(by_req.items(), key=str):
        levels = {r.get("level") for r in rs}
        (complete if levels == wanted and len(rs) == 4 else incomplete).append((k, rs))

    print(f"files={len(files)} rows={len(rows)} requests={len(by_req)} complete={len(complete)} incomplete={len(incomplete)}")
    if incomplete:
        print("INCOMPLETE REQUESTS")
        for k, rs in incomplete:
            print(" ", k, sorted(r.get("level") for r in rs))

    # Validate non-full coupling solves. zero_cross is a valid diagnostic outcome:
    # the sampled cross block vanishes even though a tiny complement may remain.
    nonfull = [r for r in rows if r.get("level") in {"hops1", "hops2", "hops3"} and not is_full(r)]
    bad_eta = [r for r in nonfull if r.get("eta_status") not in VALID_NONFULL_ETA_STATUS or not math.isfinite(r["eta_hvp"])]
    zero_cross = [r for r in nonfull if r.get("eta_status") == "zero_cross"]
    print(f"nonfull coupling rows={len(nonfull)} bad_eta={len(bad_eta)} zero_cross={len(zero_cross)}")
    if bad_eta:
        print("BAD ETA ROWS")
        for r in bad_eta:
            print(" ", r["_file"], r.get("level"), r.get("eta_status"), r.get("eta_hvp"), r.get("parameter_fraction"))
    if zero_cross:
        print("ZERO-CROSS VALID ROWS")
        for r in zero_cross:
            print(" ", r["_file"], r.get("level"), f"param={r['parameter_fraction']:.6f}", f"eta={r['eta_hvp']:.6f}")

    # Level summaries.
    level_rows = []
    for level in sorted(LEVEL_ORDER, key=LEVEL_ORDER.get):
        rs = [r for r in rows if r.get("level") == level]
        row = {"level": level, "n": len(rs), "full_fraction": prop([is_full(r) for r in rs])}
        for m in METRICS:
            vals = [r[m] for r in rs]
            row[m + "_mean"] = mean(vals)
            row[m + "_median"] = median(vals)
            row[m + "_sd"] = sd(vals)
        level_rows.append(row)
    write_csv(out / "expansion_level_summary.csv", level_rows)

    # Fine-grained group summaries for paper tables/plots.
    groups = defaultdict(list)
    for r in rows:
        groups[(r["dataset"], r["model"], r["policy"], r["fraction"], r["level"])].append(r)
    group_rows = []
    for key, rs in sorted(groups.items(), key=str):
        d, m, p, frac, level = key
        row = {"dataset": d, "model": m, "policy": p, "fraction": frac, "level": level, "n": len(rs),
               "full_fraction": prop([is_full(r) for r in rs])}
        for metric in METRICS:
            row[metric + "_mean"] = mean([r[metric] for r in rs])
        group_rows.append(row)
    write_csv(out / "expansion_group_summary.csv", group_rows)

    # Per-request path, useful for plotting trajectories.
    path_rows = []
    for k, rs in complete:
        by_level = {r["level"]: r for r in rs}
        base = dict(zip(REQ_KEYS, k))
        for level in sorted(LEVEL_ORDER, key=LEVEL_ORDER.get):
            r = by_level[level]
            row = dict(base)
            row.update({"level": level, "is_full": int(is_full(r)), "eta_status": r.get("eta_status", "")})
            for metric in METRICS:
                row[metric] = r[metric]
            path_rows.append(row)
    write_csv(out / "expansion_request_paths.csv", path_rows)

    # Saturation at each local expansion level.
    saturation = []
    for level in ("hops1", "hops2", "hops3"):
        rs = [r for r in rows if r.get("level") == level]
        saturation.append({
            "level": level,
            "n": len(rs),
            "full_n": sum(is_full(r) for r in rs),
            "full_fraction": prop([is_full(r) for r in rs]),
            "zero_cross_n": sum(r.get("eta_status") == "zero_cross" for r in rs),
            "zero_cross_fraction": prop([r.get("eta_status") == "zero_cross" for r in rs]),
            "mean_parameter_fraction": mean([r["parameter_fraction"] for r in rs]),
            "mean_work_fraction": mean([r["unique_work_fraction"] for r in rs]),
        })
    write_csv(out / "expansion_saturation.csv", saturation)

    # Matched transitions within exactly the same request.
    transitions = []
    transition_specs = (("hops1", "hops2"), ("hops2", "hops3"), ("hops1", "hops3"))
    for k, rs in complete:
        by_level = {r["level"]: r for r in rs}
        base = dict(zip(REQ_KEYS, k))
        for src, dst in transition_specs:
            a, b = by_level[src], by_level[dst]
            row = dict(base)
            row.update({"src": src, "dst": dst, "src_full": int(is_full(a)), "dst_full": int(is_full(b))})
            for metric in METRICS:
                row["delta_" + metric] = delta(a, b, metric)
            de = row["delta_eta_hvp"]
            dp = row["delta_parameter_fraction"]
            dw = row["delta_unique_work_fraction"]
            dg = row["delta_global_mrr_gap"]
            df = row["delta_forgotten_mrr_gap"]
            row["eta_down"] = int(math.isfinite(de) and de < 0)
            row["param_up"] = int(math.isfinite(dp) and dp > 0)
            row["work_up"] = int(math.isfinite(dw) and dw > 0)
            row["global_better"] = int(math.isfinite(dg) and dg < 0)
            row["forgotten_better"] = int(math.isfinite(df) and df < 0)
            row["cost_up_eta_down"] = int(row["eta_down"] and (row["param_up"] or row["work_up"]))
            row["eta_down_global_better"] = int(row["eta_down"] and row["global_better"])
            row["eta_down_forgotten_better"] = int(row["eta_down"] and row["forgotten_better"])
            row["eta_down_both_fidelity_better"] = int(row["eta_down"] and row["global_better"] and row["forgotten_better"])
            transitions.append(row)
    write_csv(out / "expansion_transitions.csv", transitions)

    transition_summary = []
    for src, dst in transition_specs:
        rs = [r for r in transitions if r["src"] == src and r["dst"] == dst]
        row = {"src": src, "dst": dst, "n": len(rs)}
        for metric in METRICS:
            vals = [r["delta_" + metric] for r in rs]
            row["mean_delta_" + metric] = mean(vals)
            row["median_delta_" + metric] = median(vals)
        for flag in ("eta_down", "param_up", "work_up", "global_better", "forgotten_better",
                     "cost_up_eta_down", "eta_down_global_better", "eta_down_forgotten_better",
                     "eta_down_both_fidelity_better"):
            row[flag + "_fraction"] = mean([float(r[flag]) for r in rs])
        transition_summary.append(row)
    write_csv(out / "expansion_transition_summary.csv", transition_summary)

    print("\nLEVEL SUMMARY")
    for r in level_rows:
        print(
            f"{r['level']:13s} n={r['n']:2d} full={r['full_fraction']:.3f} "
            f"eta={r['eta_hvp_mean']:.4f} param={r['parameter_fraction_mean']:.4f} "
            f"work={r['unique_work_fraction_mean']:.4f} "
            f"gMRR={r['global_mrr_gap_mean']:.5f} fMRR={r['forgotten_mrr_gap_mean']:.5f}"
        )

    print("\nMATCHED TRANSITIONS")
    for r in transition_summary:
        print(
            f"{r['src']}->{r['dst']} n={r['n']} "
            f"dEta={r['mean_delta_eta_hvp']:+.4f} eta_down={r['eta_down_fraction']:.3f} "
            f"dParam={r['mean_delta_parameter_fraction']:+.4f} dWork={r['mean_delta_unique_work_fraction']:+.4f} "
            f"dG={r['mean_delta_global_mrr_gap']:+.5f} Gbetter={r['global_better_fraction']:.3f} "
            f"dF={r['mean_delta_forgotten_mrr_gap']:+.5f} Fbetter={r['forgotten_better_fraction']:.3f} "
            f"costUpEtaDown={r['cost_up_eta_down_fraction']:.3f} "
            f"etaDownBothBetter={r['eta_down_both_fidelity_better_fraction']:.3f}"
        )

    print("\nSATURATION")
    for r in saturation:
        print(
            f"{r['level']:6s} full={r['full_n']}/{r['n']} ({r['full_fraction']:.3f}) "
            f"zero_cross={r['zero_cross_n']}/{r['n']} ({r['zero_cross_fraction']:.3f}) "
            f"param={r['mean_parameter_fraction']:.4f} work={r['mean_work_fraction']:.4f}"
        )

    print("\nwrote:")
    for name in (
        "expansion_level_summary.csv",
        "expansion_group_summary.csv",
        "expansion_request_paths.csv",
        "expansion_saturation.csv",
        "expansion_transitions.csv",
        "expansion_transition_summary.csv",
    ):
        print(" ", out / name)


if __name__ == "__main__":
    main()
