#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from statistics import mean

DATASETS = ('FB15K-237', 'CoDEx-M')
MODELS = ('rotate', 'pairre', 'compounde')
SEEDS = (17, 29, 43)
FRACTIONS = (0.10, 0.20)
METHODS = (
    'ExactRetrain',
    'SchemaCert-L5',
    'FullFinetune',
    'SchemaCert+Restart-L5',
    'SGU-FamilyAdapted',
    'GraphDPO-FamilyAdapted',
)
COMPARE = ('SchemaCert-L5', 'FullFinetune', 'SGU-FamilyAdapted', 'GraphDPO-FamilyAdapted')


def fl(x):
    y = float(x)
    if not math.isfinite(y):
        raise ValueError(f'non-finite value {x}')
    return y


def read_cell(path: Path):
    with path.open(newline='') as h:
        rows = list(csv.DictReader(h))
    by = {r['method']: r for r in rows}
    missing = [m for m in METHODS if m not in by]
    if missing:
        raise RuntimeError(f'{path}: missing methods {missing}')
    ref = by['ExactRetrain']
    base = {
        'dataset': ref['dataset'], 'model': ref['model'].lower(),
        'seed': int(ref['seed']), 'fraction': fl(ref['fraction']),
        'request_hash': ref['request_hash'], 'forget_n': int(float(ref['forget_n'])),
    }
    out = dict(base)
    for method in METHODS:
        r = by[method]
        if (r['dataset'], r['model'].lower(), int(r['seed']), round(fl(r['fraction']), 2), r['request_hash']) != (
            base['dataset'], base['model'], base['seed'], round(base['fraction'], 2), base['request_hash']
        ):
            raise RuntimeError(f'{path}: method metadata mismatch for {method}')
        tag = {
            'ExactRetrain': 'exact',
            'SchemaCert-L5': 'bare',
            'FullFinetune': 'finetune',
            'SchemaCert+Restart-L5': 'restart',
            'SGU-FamilyAdapted': 'sgu',
            'GraphDPO-FamilyAdapted': 'graphdpo',
        }[method]
        out[f'{tag}_global_mrr'] = fl(r['global_mrr'])
        out[f'{tag}_forget_mrr'] = fl(r['forget_mrr'])
        out[f'{tag}_dG'] = fl(r['global_mrr_gap_to_exact'])
        out[f'{tag}_dF'] = fl(r['forget_mrr_gap_to_exact'])
        out[f'{tag}_sec'] = fl(r['train_sec']) if r.get('train_sec') not in ('', None) else None
    return out


def agg(rows):
    result = {'n': len(rows)}
    tags = ('bare', 'finetune', 'restart', 'sgu', 'graphdpo')
    for tag in tags:
        result[f'{tag}_dG_mean'] = mean(r[f'{tag}_dG'] for r in rows)
        result[f'{tag}_dF_mean'] = mean(r[f'{tag}_dF'] for r in rows)
        times = [r[f'{tag}_sec'] for r in rows if r[f'{tag}_sec'] is not None]
        result[f'{tag}_sec_mean'] = mean(times) if times else None
    for method, tag in (
        ('SchemaCert-L5', 'bare'), ('FullFinetune', 'finetune'),
        ('SGU-FamilyAdapted', 'sgu'), ('GraphDPO-FamilyAdapted', 'graphdpo'),
    ):
        result[f'restart_vs_{tag}_winG'] = sum(r['restart_dG'] < r[f'{tag}_dG'] for r in rows)
        result[f'restart_vs_{tag}_winF'] = sum(r['restart_dF'] < r[f'{tag}_dF'] for r in rows)
        result[f'restart_vs_{tag}_winBoth'] = sum(
            r['restart_dG'] < r[f'{tag}_dG'] and r['restart_dF'] < r[f'{tag}_dF'] for r in rows
        )
    return result


def write_csv(path: Path, rows):
    if not rows:
        return
    fields = []
    for row in rows:
        for k in row:
            if k not in fields:
                fields.append(k)
    with path.open('w', newline='') as h:
        w = csv.DictWriter(h, fieldnames=fields)
        w.writeheader(); w.writerows(rows)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--input', required=True)
    p.add_argument('--out', required=True)
    args = p.parse_args()
    root = Path(args.input); out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    expected = {(d, m, s, f) for d in DATASETS for m in MODELS for s in SEEDS for f in FRACTIONS}
    rows = [read_cell(x) for x in sorted(root.glob('*_family_competitors.csv'))]
    keys = [(r['dataset'], r['model'], r['seed'], round(r['fraction'], 2)) for r in rows]
    if len(keys) != len(set(keys)):
        raise RuntimeError('duplicate cells')
    missing = sorted(expected - set(keys))
    if missing or len(rows) != 36:
        raise RuntimeError(f'incomplete campaign: {len(rows)}/36 missing={missing}')
    rows.sort(key=lambda r: (r['model'], r['dataset'], r['fraction'], r['seed']))
    write_csv(out / 'family_restart_competitors_combined.csv', rows)

    by_model = []
    for m in MODELS:
        rr = [r for r in rows if r['model'] == m]
        by_model.append({'model': m, **agg(rr)})
    write_csv(out / 'family_restart_competitors_by_model.csv', by_model)

    by_group = []
    for m in MODELS:
        for d in DATASETS:
            for f in FRACTIONS:
                rr = [r for r in rows if r['model'] == m and r['dataset'] == d and abs(r['fraction'] - f) < 1e-9]
                by_group.append({'model': m, 'dataset': d, 'fraction': f, **agg(rr)})
    write_csv(out / 'family_restart_competitors_by_dataset_model_fraction.csv', by_group)

    overall = agg(rows)
    summary = {
        'status': 'COMPLETE', 'cells': 36,
        'datasets': list(DATASETS), 'models': list(MODELS),
        'seeds': list(SEEDS), 'fractions': list(FRACTIONS),
        'method_labels': {
            'SGU-FamilyAdapted': 'matched family-aware adaptation, not author-produced checkpoint',
            'GraphDPO-FamilyAdapted': 'matched GraphDPO-style family adaptation, not native official run',
        },
        'overall': overall, 'by_model': by_model,
    }
    (out / 'family_restart_competitors_summary.json').write_text(json.dumps(summary, indent=2))
    print('FAMILY_RESTART_COMPETITORS_COMPLETE 36/36')
    print(json.dumps(overall, indent=2))
    for row in by_model:
        print(
            f"MODEL={row['model']} n={row['n']} "
            f"restart=({row['restart_dG_mean']:.6f},{row['restart_dF_mean']:.6f}) "
            f"sgu=({row['sgu_dG_mean']:.6f},{row['sgu_dF_mean']:.6f}) "
            f"graphdpo=({row['graphdpo_dG_mean']:.6f},{row['graphdpo_dF_mean']:.6f})"
        )


if __name__ == '__main__':
    main()
