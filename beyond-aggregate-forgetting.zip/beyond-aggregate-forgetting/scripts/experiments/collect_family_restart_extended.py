#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path
from statistics import mean

DATASETS = ('FB15K-237', 'CoDEx-M')
MODELS = ('rotate', 'pairre', 'compounde')
SEEDS = (17, 29, 43)
FRACTIONS = (0.10, 0.20)
REQUIRED_METHODS = ('ExactRetrain', 'SchemaCert-L5', 'SchemaCert+Restart-L5')


def f(x):
    return float(x)


def read_file(path: Path):
    with path.open(newline='') as h:
        rows = list(csv.DictReader(h))
    methods = {r['method']: r for r in rows}
    missing = [m for m in REQUIRED_METHODS if m not in methods]
    if missing:
        raise RuntimeError(f'{path}: missing methods {missing}')
    b = methods['SchemaCert-L5']
    r = methods['SchemaCert+Restart-L5']
    e = methods['ExactRetrain']
    for row in (b, r, e):
        if row.get('policy') != 'entity':
            raise RuntimeError(f'{path}: non-entity policy')
    return {
        'dataset': r['dataset'],
        'model': r['model'].lower(),
        'seed': int(r['seed']),
        'fraction': f(r['fraction']),
        'request_hash': r['request_hash'],
        'forget_n': int(float(r['forget_n'])),
        'exact_global_mrr': f(e['global_mrr']),
        'exact_forget_mrr': f(e['forget_mrr']),
        'bare_global_mrr': f(b['global_mrr']),
        'bare_forget_mrr': f(b['forget_mrr']),
        'bare_dG': f(b['global_mrr_gap_to_exact']),
        'bare_dF': f(b['forget_mrr_gap_to_exact']),
        'bare_sec': f(b['train_sec']),
        'restart_global_mrr': f(r['global_mrr']),
        'restart_forget_mrr': f(r['forget_mrr']),
        'restart_dG': f(r['global_mrr_gap_to_exact']),
        'restart_dF': f(r['forget_mrr_gap_to_exact']),
        'restart_sec': f(r['train_sec']),
        'selected_count': int(float(r.get('selected_count') or 0)),
        'unsupported_selected_count': int(float(r.get('unsupported_selected_count') or 0)),
        'unsupported_fraction': f(r.get('unsupported_fraction') or 0.0),
        'parameter_fraction': f(r.get('parameter_fraction') or 0.0),
        'work_unique_triples': int(float(r.get('work_unique_triples') or 0)),
        'restart_wins_global': int(f(r['global_mrr_gap_to_exact']) < f(b['global_mrr_gap_to_exact'])),
        'restart_wins_forget': int(f(r['forget_mrr_gap_to_exact']) < f(b['forget_mrr_gap_to_exact'])),
        'restart_wins_both': int(
            f(r['global_mrr_gap_to_exact']) < f(b['global_mrr_gap_to_exact'])
            and f(r['forget_mrr_gap_to_exact']) < f(b['forget_mrr_gap_to_exact'])
        ),
    }


def aggregate(rows):
    return {
        'n': len(rows),
        'bare_dG_mean': mean(x['bare_dG'] for x in rows),
        'restart_dG_mean': mean(x['restart_dG'] for x in rows),
        'bare_dF_mean': mean(x['bare_dF'] for x in rows),
        'restart_dF_mean': mean(x['restart_dF'] for x in rows),
        'restart_wins_global': sum(x['restart_wins_global'] for x in rows),
        'restart_wins_forget': sum(x['restart_wins_forget'] for x in rows),
        'restart_wins_both': sum(x['restart_wins_both'] for x in rows),
        'bare_sec_mean': mean(x['bare_sec'] for x in rows),
        'restart_sec_mean': mean(x['restart_sec'] for x in rows),
        'unsupported_fraction_mean': mean(x['unsupported_fraction'] for x in rows),
        'parameter_fraction_mean': mean(x['parameter_fraction'] for x in rows),
    }


def write_csv(path, rows, fields=None):
    if not rows:
        return
    if fields is None:
        fields = list(rows[0])
    with path.open('w', newline='') as h:
        w = csv.DictWriter(h, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--input', required=True)
    p.add_argument('--out', required=True)
    args = p.parse_args()

    root = Path(args.input)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    expected = {
        (d, m, s, frac)
        for d in DATASETS for m in MODELS for s in SEEDS for frac in FRACTIONS
    }
    rows = []
    for path in sorted(root.glob('*_restart_ext.csv')):
        row = read_file(path)
        key = (row['dataset'], row['model'], row['seed'], round(row['fraction'], 2))
        if key not in expected:
            raise RuntimeError(f'Unexpected configuration {key} from {path}')
        rows.append(row)

    keys = [(r['dataset'], r['model'], r['seed'], round(r['fraction'], 2)) for r in rows]
    if len(keys) != len(set(keys)):
        raise RuntimeError('Duplicate configuration(s) detected')
    missing = sorted(expected - set(keys))
    if missing:
        raise RuntimeError(f'Incomplete campaign: have {len(rows)}/36; missing={missing}')
    if len(rows) != 36:
        raise RuntimeError(f'Expected exactly 36 configurations, found {len(rows)}')

    rows.sort(key=lambda x: (x['model'], x['dataset'], x['fraction'], x['seed']))
    write_csv(out / 'family_restart_extended_combined.csv', rows)

    by_model = []
    for model in MODELS:
        rr = [x for x in rows if x['model'] == model]
        by_model.append({'model': model, **aggregate(rr)})
    write_csv(out / 'family_restart_extended_by_model.csv', by_model)

    by_group = []
    for model in MODELS:
        for dataset in DATASETS:
            for frac in FRACTIONS:
                rr = [
                    x for x in rows
                    if x['model'] == model and x['dataset'] == dataset
                    and abs(x['fraction'] - frac) < 1e-9
                ]
                by_group.append({
                    'model': model,
                    'dataset': dataset,
                    'fraction': frac,
                    **aggregate(rr),
                })
    write_csv(out / 'family_restart_extended_by_dataset_model_fraction.csv', by_group)

    overall = aggregate(rows)
    summary = {
        'status': 'COMPLETE',
        'expected_configurations': 36,
        'observed_configurations': len(rows),
        'datasets': list(DATASETS),
        'models': list(MODELS),
        'fractions': list(FRACTIONS),
        'seeds': list(SEEDS),
        'overall': overall,
        'by_model': by_model,
        'claim_checks': {
            'restart_improves_forget_all_36': overall['restart_wins_forget'] == 36,
            'restart_improves_global_all_36': overall['restart_wins_global'] == 36,
            'restart_improves_both_all_36': overall['restart_wins_both'] == 36,
        },
    }
    (out / 'family_restart_extended_summary.json').write_text(json.dumps(summary, indent=2))

    print('FAMILY_RESTART_EXTENDED_COMPLETE 36/36')
    print(json.dumps(summary['overall'], indent=2))
    for x in by_model:
        print(
            f"MODEL={x['model']} n={x['n']} "
            f"dG {x['bare_dG_mean']:.6f}->{x['restart_dG_mean']:.6f} "
            f"dF {x['bare_dF_mean']:.6f}->{x['restart_dF_mean']:.6f} "
            f"winsG={x['restart_wins_global']}/{x['n']} "
            f"winsF={x['restart_wins_forget']}/{x['n']} "
            f"both={x['restart_wins_both']}/{x['n']}"
        )


if __name__ == '__main__':
    main()
