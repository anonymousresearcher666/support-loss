#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path
from statistics import mean, stdev

ORDER = ['ExactRetrain', 'SchemaCert-L5', 'SchemaCert+Reset-L5', 'Finetune', 'NG', 'GraphDPO']
APPROX = ORDER[1:]
REQUIRED = set(ORDER)


def num(x):
    if x is None or x == '':
        return math.nan
    return float(x)


def stats(xs):
    xs = [float(x) for x in xs if math.isfinite(float(x))]
    if not xs:
        return {'n': 0, 'mean': None, 'sd': None}
    return {'n': len(xs), 'mean': mean(xs), 'sd': stdev(xs) if len(xs) > 1 else 0.0}


def summarize(records):
    by_method = defaultdict(list)
    for r in records:
        by_method[r['method']].append(r)
    out = []
    for m in ORDER:
        rs = by_method[m]
        out.append({
            'method': m,
            'n': len(rs),
            'global_gap_mean': stats([num(r['global_mrr_gap_to_exact']) for r in rs])['mean'],
            'global_gap_sd': stats([num(r['global_mrr_gap_to_exact']) for r in rs])['sd'],
            'forget_gap_mean': stats([num(r['forget_mrr_gap_to_exact']) for r in rs])['mean'],
            'forget_gap_sd': stats([num(r['forget_mrr_gap_to_exact']) for r in rs])['sd'],
            'global_mrr_mean': stats([num(r['global_mrr']) for r in rs])['mean'],
            'forget_mrr_mean': stats([num(r['forget_mrr']) for r in rs])['mean'],
            'train_sec_mean_native_or_local': stats([num(r['train_sec']) for r in rs])['mean'],
        })
    return out


def pareto(records):
    grouped = defaultdict(dict)
    for r in records:
        if r['method'] != 'ExactRetrain':
            grouped[r['_config']][r['method']] = r
    pareto_counts = {m: 0 for m in APPROX}
    both_best_counts = {m: 0 for m in APPROX}
    reset_dominates = {m: 0 for m in ['SchemaCert-L5', 'Finetune', 'NG', 'GraphDPO']}
    details = []
    for config, mm in sorted(grouped.items()):
        if set(mm) != set(APPROX):
            raise RuntimeError(f'{config}: incomplete method set {sorted(mm)}')
        points = {
            m: (num(mm[m]['global_mrr_gap_to_exact']), num(mm[m]['forget_mrr_gap_to_exact']))
            for m in APPROX
        }
        min_g = min(g for g, _ in points.values())
        min_f = min(q for _, q in points.values())
        for m, (g, q) in points.items():
            dominated = any(
                g2 <= g and q2 <= q and (g2 < g or q2 < q)
                for om, (g2, q2) in points.items() if om != m
            )
            if not dominated:
                pareto_counts[m] += 1
            if math.isclose(g, min_g, abs_tol=1e-15) and math.isclose(q, min_f, abs_tol=1e-15):
                both_best_counts[m] += 1
        rg, rf = points['SchemaCert+Reset-L5']
        for m in reset_dominates:
            g, q = points[m]
            if rg <= g and rf <= q and (rg < g or rf < q):
                reset_dominates[m] += 1
        details.append({
            'config': config,
            'dataset': mm['SchemaCert+Reset-L5']['_dataset'],
            'request_hash': mm['SchemaCert+Reset-L5']['request_hash'],
            'points': points,
        })
    return {
        'n_configs': len(grouped),
        'pareto_counts': pareto_counts,
        'both_best_counts': both_best_counts,
        'reset_dominates_counts': reset_dominates,
        'per_config': details,
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--expected', type=int, default=18)
    args = p.parse_args()

    root = Path(args.root)
    files = sorted(root.glob('*_common_support_reset.csv'))
    if len(files) != args.expected:
        raise RuntimeError(f'Expected {args.expected} common-reset CSVs, found {len(files)} in {root}')

    records = []
    for path in files:
        config = path.stem.removesuffix('_common_support_reset')
        if '_transe_entity_' not in config:
            raise RuntimeError(f'Cannot parse dataset from {config}')
        dataset = config.split('_transe_entity_', 1)[0]
        with open(path, newline='') as fh:
            rows = list(csv.DictReader(fh))
        methods = {r['method'] for r in rows}
        if methods != REQUIRED:
            raise RuntimeError(f'{path}: method set {sorted(methods)} != {sorted(REQUIRED)}')
        for r in rows:
            r = dict(r)
            r['_file'] = str(path)
            r['_config'] = config
            r['_dataset'] = dataset
            records.append(r)

    overall = summarize(records)
    overall_pareto = pareto(records)
    datasets = sorted({r['_dataset'] for r in records})
    per_dataset = {}
    for d in datasets:
        rr = [r for r in records if r['_dataset'] == d]
        per_dataset[d] = {
            'summary': summarize(rr),
            'pareto': pareto(rr),
        }

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    csv_path = out / 'graphdpo_matched_common_summary.csv'
    json_path = out / 'graphdpo_matched_common_summary.json'
    with open(csv_path, 'w', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=list(overall[0].keys()))
        w.writeheader()
        w.writerows(overall)
    json_path.write_text(json.dumps({
        'n_csv': len(files),
        'datasets': datasets,
        'overall': overall,
        'overall_pareto': overall_pareto,
        'per_dataset': per_dataset,
        'runtime_warning': 'Competitor train_sec values are native-pipeline times; SchemaCert times are local-pipeline times and must not be compared as a common runtime benchmark.',
    }, indent=2))

    print('=== OVERALL MATCHED COMMON ===')
    print('method\tn\tglobal_gap_mean\tforget_gap_mean')
    for r in overall:
        print(f"{r['method']}\t{r['n']}\t{r['global_gap_mean']:.6f}\t{r['forget_gap_mean']:.6f}")
    print('PARETO_COUNTS ' + json.dumps(overall_pareto['pareto_counts'], sort_keys=True))
    print('BOTH_BEST_COUNTS ' + json.dumps(overall_pareto['both_best_counts'], sort_keys=True))
    print('RESET_DOMINATES_COUNTS ' + json.dumps(overall_pareto['reset_dominates_counts'], sort_keys=True))
    for d in datasets:
        print(f'=== DATASET {d} ===')
        for r in per_dataset[d]['summary']:
            print(f"{r['method']}\t{r['n']}\t{r['global_gap_mean']:.6f}\t{r['forget_gap_mean']:.6f}")
        print('RESET_DOMINATES_COUNTS ' + json.dumps(per_dataset[d]['pareto']['reset_dominates_counts'], sort_keys=True))
    print(f'GRAPHDPO_MATCHED_SUMMARY_CSV={csv_path}')
    print(f'GRAPHDPO_MATCHED_SUMMARY_JSON={json_path}')
    print('GRAPHDPO_MATCHED_COLLECT_OK')


if __name__ == '__main__':
    main()
