#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path
from statistics import mean, stdev

ORDER = ['ExactRetrain', 'SchemaCert-L5', 'SchemaCert+Reset-L5', 'Finetune', 'NG', 'GraphDPO']
APPROX = ORDER[1:]
REQUIRED = set(ORDER)


def val(x):
    if x is None or x == '':
        return math.nan
    return float(x)


def stat(xs):
    xs = [x for x in xs if math.isfinite(x)]
    if not xs:
        return {'n': 0, 'mean': None, 'sd': None}
    return {'n': len(xs), 'mean': mean(xs), 'sd': stdev(xs) if len(xs) > 1 else 0.0}


def parse_dataset(config: str) -> str:
    marker = '_transe_entity_'
    if marker not in config:
        raise RuntimeError(f'Cannot parse dataset from config {config}')
    return config.split(marker, 1)[0]


def load_files(files):
    records = []
    for path in sorted(files):
        config = path.stem.removesuffix('_common_support_reset')
        dataset = parse_dataset(config)
        with open(path, newline='') as fh:
            rows = list(csv.DictReader(fh))
        methods = {r['method'] for r in rows}
        if methods != REQUIRED:
            raise RuntimeError(f'{path}: methods={sorted(methods)} expected={sorted(REQUIRED)}')
        if len(rows) != len(REQUIRED):
            raise RuntimeError(f'{path}: expected {len(REQUIRED)} rows, found {len(rows)}')
        for r in rows:
            r = dict(r)
            r['_config'] = config
            r['_dataset'] = dataset
            r['_file'] = str(path)
            records.append(r)
    return records


def summary(records):
    by = defaultdict(list)
    for r in records:
        by[r['method']].append(r)
    out = []
    for m in ORDER:
        rs = by[m]
        gg = [val(r['global_mrr_gap_to_exact']) for r in rs]
        fg = [val(r['forget_mrr_gap_to_exact']) for r in rs]
        gm = [val(r['global_mrr']) for r in rs]
        fm = [val(r['forget_mrr']) for r in rs]
        out.append({
            'method': m,
            'n': len(rs),
            'global_gap_mean': stat(gg)['mean'],
            'global_gap_sd': stat(gg)['sd'],
            'forget_gap_mean': stat(fg)['mean'],
            'forget_gap_sd': stat(fg)['sd'],
            'global_mrr_mean': stat(gm)['mean'],
            'forget_mrr_mean': stat(fm)['mean'],
        })
    return out


def pareto(records):
    grouped = defaultdict(dict)
    for r in records:
        if r['method'] != 'ExactRetrain':
            grouped[r['_config']][r['method']] = r
    pc = {m: 0 for m in APPROX}
    bb = {m: 0 for m in APPROX}
    rd = {m: 0 for m in ['SchemaCert-L5', 'Finetune', 'NG', 'GraphDPO']}
    details = []
    for config, mm in sorted(grouped.items()):
        if set(mm) != set(APPROX):
            raise RuntimeError(f'{config}: incomplete method set {sorted(mm)}')
        pts = {
            m: (val(mm[m]['global_mrr_gap_to_exact']), val(mm[m]['forget_mrr_gap_to_exact']))
            for m in APPROX
        }
        min_g = min(g for g, _ in pts.values())
        min_f = min(q for _, q in pts.values())
        for m, (g, q) in pts.items():
            dominated = any(
                g2 <= g and q2 <= q and (g2 < g or q2 < q)
                for om, (g2, q2) in pts.items() if om != m
            )
            if not dominated:
                pc[m] += 1
            if math.isclose(g, min_g, rel_tol=0, abs_tol=1e-15) and math.isclose(q, min_f, rel_tol=0, abs_tol=1e-15):
                bb[m] += 1
        rg, rf = pts['SchemaCert+Reset-L5']
        for m in rd:
            g, q = pts[m]
            if rg <= g and rf <= q and (rg < g or rf < q):
                rd[m] += 1
        details.append({
            'config': config,
            'dataset': mm['SchemaCert+Reset-L5']['_dataset'],
            'request_hash': mm['SchemaCert+Reset-L5']['request_hash'],
            'points': pts,
        })
    return {
        'n_configs': len(grouped),
        'pareto_counts': pc,
        'both_best_counts': bb,
        'reset_dominates_counts': rd,
        'per_config': details,
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--new-root', required=True, help='WN18RR/CoDEx-L/YAGO3-10 common results')
    p.add_argument('--fb10-root', required=True, help='FB15K-237 10% common results')
    p.add_argument('--fb-old-root', required=True, help='Existing FB15K-237 common results containing 20%')
    p.add_argument('--out', required=True)
    args = p.parse_args()

    new_files = list(Path(args.new_root).glob('*_common_support_reset.csv'))
    fb10_files = list(Path(args.fb10_root).glob('FB15K-237_transe_entity_f0.1_s*_common_support_reset.csv'))
    fb20_files = list(Path(args.fb_old_root).glob('FB15K-237_transe_entity_f0.2_s*_common_support_reset.csv'))
    if len(new_files) != 18:
        raise RuntimeError(f'Expected 18 WN/CoDEx-L/YAGO files, found {len(new_files)}')
    if len(fb10_files) != 3:
        raise RuntimeError(f'Expected 3 FB15K-237 10% files, found {len(fb10_files)}')
    if len(fb20_files) != 3:
        raise RuntimeError(f'Expected 3 FB15K-237 20% files, found {len(fb20_files)}')
    files = new_files + fb10_files + fb20_files
    if len({str(x) for x in files}) != 24:
        raise RuntimeError('Expected 24 unique official-suite files')

    records = load_files(files)
    configs = {r['_config'] for r in records}
    datasets = sorted({r['_dataset'] for r in records})
    if len(configs) != 24:
        raise RuntimeError(f'Expected 24 configurations, found {len(configs)}')
    expected_datasets = {'FB15K-237', 'WN18RR', 'CoDEx-L', 'YAGO3-10'}
    if set(datasets) != expected_datasets:
        raise RuntimeError(f'Dataset set mismatch: {datasets}')

    overall = summary(records)
    overall_p = pareto(records)
    per_dataset = {}
    for d in datasets:
        rr = [r for r in records if r['_dataset'] == d]
        per_dataset[d] = {'summary': summary(rr), 'pareto': pareto(rr)}

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    csv_path = out / 'graphdpo_official_suite_summary.csv'
    json_path = out / 'graphdpo_official_suite_summary.json'
    with open(csv_path, 'w', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=list(overall[0].keys()))
        w.writeheader()
        w.writerows(overall)
    json_path.write_text(json.dumps({
        'suite': {
            'datasets': datasets,
            'fractions': [0.10, 0.20],
            'training_seeds': [17, 29, 43],
            'n_configs': 24,
            'note': 'Entity-star deletion requests are held fixed across methods. These are the same base datasets and forgetting ratios as GraphDPO, but not GraphDPO\'s original incremental snapshot requests.',
        },
        'overall': overall,
        'overall_pareto': overall_p,
        'per_dataset': per_dataset,
        'runtime_warning': 'Competitor train_sec values are native-pipeline times; SchemaCert times are local-pipeline times and are not a common runtime comparison.',
    }, indent=2))

    print('=== GRAPHDPO OFFICIAL-DATASET SUITE: 4 DATASETS x 2 FRACTIONS x 3 TRAINING SEEDS ===')
    print('method\tn\tglobal_gap_mean\tforget_gap_mean')
    for r in overall:
        print(f"{r['method']}\t{r['n']}\t{r['global_gap_mean']:.6f}\t{r['forget_gap_mean']:.6f}")
    print('PARETO_COUNTS ' + json.dumps(overall_p['pareto_counts'], sort_keys=True))
    print('BOTH_BEST_COUNTS ' + json.dumps(overall_p['both_best_counts'], sort_keys=True))
    print('RESET_DOMINATES_COUNTS ' + json.dumps(overall_p['reset_dominates_counts'], sort_keys=True))
    for d in datasets:
        print(f'=== {d} ===')
        for r in per_dataset[d]['summary']:
            print(f"{r['method']}\t{r['n']}\t{r['global_gap_mean']:.6f}\t{r['forget_gap_mean']:.6f}")
        print('RESET_DOMINATES_COUNTS ' + json.dumps(per_dataset[d]['pareto']['reset_dominates_counts'], sort_keys=True))
    print(f'GRAPHDPO_OFFICIAL_SUITE_CSV={csv_path}')
    print(f'GRAPHDPO_OFFICIAL_SUITE_JSON={json_path}')
    print('GRAPHDPO_OFFICIAL_SUITE_COLLECT_OK')


if __name__ == '__main__':
    main()
