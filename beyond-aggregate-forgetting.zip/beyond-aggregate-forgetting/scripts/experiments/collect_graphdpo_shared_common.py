#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path
from statistics import mean, stdev

ORDER = ['ExactRetrain', 'SchemaCert-L5', 'SchemaCert+Restart-L5', 'Finetune', 'NG', 'GraphDPO']
APPROX = ORDER[1:]
REQUIRED = set(ORDER)


def num(x):
    if x is None or x == '':
        return math.nan
    return float(x)


def stats(xs):
    xs = [float(x) for x in xs if math.isfinite(float(x))]
    if not xs:
        return {'n': 0, 'mean': None, 'sd': None}
    return {'n': len(xs), 'mean': mean(xs), 'sd': stdev(xs) if len(xs) > 1 else 0.0}


def summarize(records):
    by_method = defaultdict(list)
    for r in records:
        by_method[r['method']].append(r)
    out = []
    for m in ORDER:
        rs = by_method[m]
        out.append({
            'method': m,
            'n': len(rs),
            'global_gap_mean': stats([num(r['global_mrr_gap_to_exact']) for r in rs])['mean'],
            'global_gap_sd': stats([num(r['global_mrr_gap_to_exact']) for r in rs])['sd'],
            'forget_gap_mean': stats([num(r['forget_mrr_gap_to_exact']) for r in rs])['mean'],
            'forget_gap_sd': stats([num(r['forget_mrr_gap_to_exact']) for r in rs])['sd'],
            'global_mrr_mean': stats([num(r['global_mrr']) for r in rs])['mean'],
            'forget_mrr_mean': stats([num(r['forget_mrr']) for r in rs])['mean'],
            'train_sec_mean': stats([num(r['train_sec']) for r in rs])['mean'],
        })
    return out


def pareto(records):
    grouped = defaultdict(dict)
    for r in records:
        if r['method'] != 'ExactRetrain':
            grouped[r['_config']][r['method']] = r
    counts = {m: 0 for m in APPROX}
    restart_dominates = {m: 0 for m in ['SchemaCert-L5', 'Finetune', 'NG', 'GraphDPO']}
    for config, mm in grouped.items():
        if set(mm) != set(APPROX):
            raise RuntimeError(f'{config}: incomplete method set {sorted(mm)}')
        points = {
            m: (num(mm[m]['global_mrr_gap_to_exact']), num(mm[m]['forget_mrr_gap_to_exact']))
            for m in APPROX
        }
        for m, (g, f) in points.items():
            dominated = any(
                g2 <= g and f2 <= f and (g2 < g or f2 < f)
                for om, (g2, f2) in points.items() if om != m
            )
            if not dominated:
                counts[m] += 1
        rg, rf = points['SchemaCert+Restart-L5']
        for m in restart_dominates:
            g, f = points[m]
            if rg <= g and rf <= f and (rg < g or rf < f):
                restart_dominates[m] += 1
    return {
        'n_configs': len(grouped),
        'pareto_counts': counts,
        'restart_dominates_counts': restart_dominates,
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--expected', type=int, default=24)
    args = p.parse_args()

    root = Path(args.root)
    files = sorted(root.glob('*_common_shared_base.csv'))
    if len(files) != args.expected:
        raise RuntimeError(f'Expected {args.expected} shared-base CSVs, found {len(files)} in {root}')

    records = []
    for path in files:
        config = path.stem.removesuffix('_common_shared_base')
        if '_transe_entity_' not in config:
            raise RuntimeError(f'Cannot parse dataset from {config}')
        dataset = config.split('_transe_entity_', 1)[0]
        with open(path, newline='') as fh:
            rows = list(csv.DictReader(fh))
        methods = {r['method'] for r in rows}
        if methods != REQUIRED:
            raise RuntimeError(f'{path}: method set {sorted(methods)} != {sorted(REQUIRED)}')
        for r in rows:
            r = dict(r)
            r['_config'] = config
            r['_dataset'] = dataset
            records.append(r)

    overall = summarize(records)
    datasets = sorted({r['_dataset'] for r in records})
    result = {
        'n_csv': len(files),
        'datasets': datasets,
        'overall': overall,
        'overall_pareto': pareto(records),
        'per_dataset': {},
        'alignment': (
            'All approximate methods use the same official GraphDPO pretrained checkpoint '
            'per dataset/seed. ExactRetrain is the official fresh retained-data retrain. '
            'All metrics use the same common-support full-ranking evaluator and query budget.'
        ),
    }
    for d in datasets:
        rr = [r for r in records if r['_dataset'] == d]
        result['per_dataset'][d] = {'summary': summarize(rr), 'pareto': pareto(rr)}

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    csv_path = out / 'graphdpo_shared_common_summary.csv'
    json_path = out / 'graphdpo_shared_common_summary.json'
    with open(csv_path, 'w', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=list(overall[0].keys()))
        w.writeheader()
        w.writerows(overall)
    json_path.write_text(json.dumps(result, indent=2))

    print('=== FULLY SHARED-BASE COMMON ===')
    print('method\tn\tglobal_gap_mean\tforget_gap_mean')
    for r in overall:
        print(f"{r['method']}\t{r['n']}\t{r['global_gap_mean']:.6f}\t{r['forget_gap_mean']:.6f}")
    print('PARETO_COUNTS ' + json.dumps(result['overall_pareto']['pareto_counts'], sort_keys=True))
    print('RESTART_DOMINATES_COUNTS ' + json.dumps(result['overall_pareto']['restart_dominates_counts'], sort_keys=True))
    print(f'SHARED_SUMMARY_CSV={csv_path}')
    print(f'SHARED_SUMMARY_JSON={json_path}')
    print('SHARED_COMMON_COLLECT_OK')


if __name__ == '__main__':
    main()
