#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np

DATASETS=("FB15K-237","CoDEx-M")
SEEDS=(17,29,43)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",type=Path,required=True)
    ap.add_argument("--out",type=Path,required=True)
    args=ap.parse_args()
    cells=[]
    for ds in DATASETS:
        for seed in SEEDS:
            p=args.root/f"{ds}_seed{seed}_norm_oracle_audit_v2.json"
            if not p.is_file():
                raise FileNotFoundError(p)
            j=json.loads(p.read_text())
            a=np.load(args.root/f"{ds}_seed{seed}_norm_oracle_audit_v2_arrays.npz")
            cells.append((j,a))

    summary={"protocol":"B2-norm-match-oracle-audit-v2","by_dataset":{}}
    halt=False
    for ds in DATASETS:
        cc=[(j,a) for j,a in cells if j["dataset"]==ds]
        rr=np.concatenate([a["rl_ranks"].reshape(-1) for _,a in cc])
        ro=np.concatenate([a["oracle_ranks"].reshape(-1) for _,a in cc])
        rf=np.concatenate([a["ref_ranks"].reshape(-1) for _,a in cc])
        bn=np.concatenate([a["before_norm"] for _,a in cc])
        an=np.concatenate([a["after_norm"] for _,a in cc])
        rn=np.concatenate([a["ref_norm"] for _,a in cc])
        sc=np.concatenate([a["scales"] for _,a in cc])
        ts=np.concatenate([a["target_selected"].reshape(-1) for _,a in cc]).astype(bool)
        scores=np.concatenate([a["rl_scores"].reshape(-1) for _,a in cc])
        changed=ro!=rr
        promoted=ro<rr
        demoted=ro>rr
        rl_gap=float(np.abs(np.log10(rr)-np.log10(rf)).mean())
        oracle_gap=float(np.abs(np.log10(ro)-np.log10(rf)).mean())
        reduction=float((rl_gap-oracle_gap)/rl_gap)
        rec={
            "seeds":[j["seed"] for j,_ in cc],
            "query_directions":int(rr.size),
            "rl_logrank_gap":rl_gap,
            "norm_oracle_logrank_gap":oracle_gap,
            "relative_reduction":reduction,
            "rank_changed":int(changed.sum()),
            "rank_unchanged":int((~changed).sum()),
            "rank_promoted":int(promoted.sum()),
            "rank_demoted":int(demoted.sum()),
            "target_selected_directions":int(ts.sum()),
            "target_selected_changed":int((changed&ts).sum()),
            "context_only_changed":int((changed&~ts).sum()),
            "positive_score_target_selected":int(((scores>0)&ts).sum()),
            "positive_score_target_selected_promoted":int(((scores>0)&ts&promoted).sum()),
            "positive_score_target_selected_demoted":int(((scores>0)&ts&demoted).sum()),
            "negative_score_target_selected":int(((scores<0)&ts).sum()),
            "negative_score_target_selected_promoted":int(((scores<0)&ts&promoted).sum()),
            "negative_score_target_selected_demoted":int(((scores<0)&ts&demoted).sum()),
            "median_ZU_norm_before":float(np.median(bn)),
            "median_ZU_norm_after":float(np.median(an)),
            "median_ZU_norm_Ref20":float(np.median(rn)),
            "median_scale_factor":float(np.median(sc)),
            "nonselected_rows_bit_identical_all_cells":bool(all(j["rescaling"]["nonselected_rows_bit_identical"] for j,_ in cc)),
            "selected_rows_changed_all_cells":bool(all(j["rescaling"]["selected_rows_changed"]==j["selected_zero_support_entities"] for j,_ in cc)),
        }
        summary["by_dataset"][ds]=rec
        if reduction>0.30:
            halt=True

    summary["halt_mechanism_review"]=halt
    summary["halt_rule"]="true if corrected norm matching reduces the R+L log-rank gap by >30% on either graph"
    args.out.mkdir(parents=True,exist_ok=True)
    p=args.out/"B2_NORM_ORACLE_AUDIT_V2_SUMMARY.json"
    p.write_text(json.dumps(summary,indent=2)+"\n")
    print("=== B2 NORM ORACLE AUDIT V2 ===")
    for ds in DATASETS:
        x=summary["by_dataset"][ds]
        print(ds,
              f"RL={x['rl_logrank_gap']:.8f}",
              f"NormOracle={x['norm_oracle_logrank_gap']:.8f}",
              f"reduction={100*x['relative_reduction']:.2f}%",
              f"rank_changed={x['rank_changed']}/{x['query_directions']}",
              f"norms={x['median_ZU_norm_before']:.6f}->{x['median_ZU_norm_after']:.6f}",
              f"Ref20={x['median_ZU_norm_Ref20']:.6f}",
              f"scale={x['median_scale_factor']:.4f}")
    print("HALT_MECHANISM_REVIEW", halt)
    print(p)
    print("B2_NORM_ORACLE_AUDIT_COLLECT_OK")

if __name__=="__main__":
    main()
