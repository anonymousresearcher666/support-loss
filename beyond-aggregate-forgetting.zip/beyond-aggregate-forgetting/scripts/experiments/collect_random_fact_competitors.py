#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

EXPECTED_DATASETS = ["CoDEx-M", "FB15K-237", "NELL-995"]
EXPECTED_SEEDS = [17, 29, 43]
EXPECTED_FRACTIONS = [0.10, 0.20]
EXPECTED_METHODS = [
    "ExactRetrain",
    "BaseBeforeUnlearning",
    "SchemaCert-L5",
    "Finetune",
    "NG",
    "RL",
    "Fisher",
    "BS",
    "SSD",
    "GraphDPO",
    "SGU",
    "ZeroFisher",
]


def as_float(v):
    if v in (None, "", "None", "nan", "NaN"):
        return None
    return float(v)


def main() -> None:
    p = argparse.ArgumentParser(description="Collect the matched random-fact competitor campaign.")
    p.add_argument("--root", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--strict", action="store_true")
    args = p.parse_args()

    root = Path(args.root)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    records = []
    cells = {}
    for js in sorted(root.glob("*/random/f*/request_seed*/base_seed*/common/*_common_shared_base.json")):
        payload = json.loads(js.read_text())
        dataset = payload["dataset"]
        fraction = float(payload["fraction"])
        seed = int(payload["seed"])
        request_hash = payload["request_hash"]
        key = (dataset, seed, fraction)
        if key in cells:
            raise RuntimeError(f"Duplicate campaign cell {key}: {cells[key]} and {js}")
        cells[key] = str(js)
        for row in payload["rows"]:
            rec = {
                "dataset": dataset,
                "seed": seed,
                "fraction": fraction,
                "request_hash": request_hash,
                "method": row["method"],
                "source": row.get("source"),
                "global_mrr": row.get("global_mrr"),
                "forget_mrr": row.get("forget_mrr"),
                "global_mrr_gap_to_exact": row.get("global_mrr_gap_to_exact"),
                "forget_mrr_gap_to_exact": row.get("forget_mrr_gap_to_exact"),
                "train_sec": row.get("train_sec"),
                "global_h1": row.get("global_h1"),
                "global_h3": row.get("global_h3"),
                "global_h10": row.get("global_h10"),
                "forget_h1": row.get("forget_h1"),
                "forget_h3": row.get("forget_h3"),
                "forget_h10": row.get("forget_h10"),
            }
            records.append(rec)

    expected_cells = {
        (d, s, f)
        for d in EXPECTED_DATASETS
        for s in EXPECTED_SEEDS
        for f in EXPECTED_FRACTIONS
    }
    present_cells = set(cells)
    missing_cells = sorted(expected_cells - present_cells)
    extra_cells = sorted(present_cells - expected_cells)

    methods_by_cell = defaultdict(set)
    hashes_by_cell = defaultdict(set)
    for r in records:
        key = (r["dataset"], int(r["seed"]), float(r["fraction"]))
        methods_by_cell[key].add(r["method"])
        hashes_by_cell[key].add(r["request_hash"])

    missing_methods = {}
    for key in sorted(expected_cells & present_cells):
        miss = sorted(set(EXPECTED_METHODS) - methods_by_cell[key])
        if miss:
            missing_methods[str(key)] = miss

    hash_violations = {
        str(k): sorted(v)
        for k, v in hashes_by_cell.items()
        if len(v) != 1
    }

    combined = out / "combined_random_fact_competitors.csv"
    fields = [
        "dataset", "seed", "fraction", "request_hash", "method", "source",
        "global_mrr", "forget_mrr", "global_mrr_gap_to_exact",
        "forget_mrr_gap_to_exact", "train_sec", "global_h1", "global_h3",
        "global_h10", "forget_h1", "forget_h3", "forget_h10",
    ]
    with combined.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(records)

    metrics = [
        "global_mrr", "forget_mrr", "global_mrr_gap_to_exact",
        "forget_mrr_gap_to_exact", "train_sec",
    ]
    grouped = defaultdict(list)
    for r in records:
        grouped[r["method"]].append(r)

    agg_rows = []
    for method in sorted(grouped):
        rows = grouped[method]
        outrow = {"method": method, "n": len(rows)}
        for metric in metrics:
            vals = [as_float(r[metric]) for r in rows]
            vals = np.asarray([v for v in vals if v is not None], dtype=float)
            outrow[f"{metric}_mean"] = None if len(vals) == 0 else float(vals.mean())
            outrow[f"{metric}_std"] = None if len(vals) <= 1 else float(vals.std(ddof=1))
            outrow[f"{metric}_median"] = None if len(vals) == 0 else float(np.median(vals))
        agg_rows.append(outrow)

    aggregate = out / "aggregate_by_method.csv"
    if agg_rows:
        with aggregate.open("w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(agg_rows[0]))
            w.writeheader()
            w.writerows(agg_rows)

    summary = {
        "root": str(root),
        "expected_cells": len(expected_cells),
        "present_cells": len(present_cells),
        "records": len(records),
        "expected_methods": EXPECTED_METHODS,
        "missing_cells": [list(x) for x in missing_cells],
        "extra_cells": [list(x) for x in extra_cells],
        "missing_methods": missing_methods,
        "hash_violations": hash_violations,
        "complete": not missing_cells and not extra_cells and not missing_methods and not hash_violations,
    }
    (out / "collection_summary.json").write_text(json.dumps(summary, indent=2))

    print(json.dumps(summary, indent=2))
    print(f"COMBINED={combined}")
    print(f"AGGREGATE={aggregate}")
    if args.strict and not summary["complete"]:
        raise SystemExit(2)
    print("RANDOM_FACT_COMPETITOR_COLLECTION_OK")


if __name__ == "__main__":
    main()
