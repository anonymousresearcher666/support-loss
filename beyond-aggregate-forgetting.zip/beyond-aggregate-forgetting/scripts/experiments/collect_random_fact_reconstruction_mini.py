#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

DATASETS = ("FB15K-237", "CoDEx-M")
SEEDS = (17, 29, 43)
DEFAULT_FRACTION = 0.10
BASE_METHODS = (
    "ExactRetrain",
    "BaseBeforeUnlearning",
    "SchemaCert-L5",
    "Finetune",
    "NG",
    "GraphDPO",
    "SGU",
)
STYLE_BASE_METHODS = (
    "ExactRetrain",
    "SchemaCert-L5",
    "Finetune",
    "NG",
    "GraphDPO",
    "SGU",
)
RECON_PREFIXES = ("EndpointRestartRepair-E", "StarCoverEraseRestore-E")


def ftag(f: float) -> str:
    if np.isclose(f, 0.01):
        return "1"
    if np.isclose(f, 0.05):
        return "5"
    if np.isclose(f, 0.10):
        return "10"
    if np.isclose(f, 0.20):
        return "20"
    return str(float(f)).replace(".", "p")


def find_one(root: Path, pattern: str) -> Path:
    hits = sorted(root.glob(pattern))
    if len(hits) != 1:
        raise RuntimeError(f"Expected exactly one file for {root}/{pattern}, found {len(hits)}")
    return hits[0]


def find_optional_one(root: Path, pattern: str) -> Path | None:
    hits = sorted(root.glob(pattern))
    if len(hits) > 1:
        raise RuntimeError(f"Expected at most one file for {root}/{pattern}, found {len(hits)}")
    return hits[0] if hits else None


def is_recon_method(name: str) -> bool:
    return any(name.startswith(prefix) for prefix in RECON_PREFIXES)


def rows_by_method(payload: dict) -> dict[str, dict]:
    out = {}
    for row in payload["rows"]:
        method = row["method"]
        if method in out:
            raise RuntimeError(f"Duplicate method {method}")
        out[method] = row
    return out


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--baseline-root", required=True)
    p.add_argument("--reconstruction-root", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--fraction", type=float, default=DEFAULT_FRACTION)
    p.add_argument("--datasets", nargs="+", default=list(DATASETS))
    args = p.parse_args()

    fraction = float(args.fraction)
    datasets = tuple(args.datasets)
    baseline_root = Path(args.baseline_root)
    recon_root = Path(args.reconstruction_root)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    records = []
    structural = []
    missing_baseline_style = []
    for dataset in datasets:
        safe = dataset.replace("/", "_")
        for seed in SEEDS:
            cell = safe / Path("random") / f"f{ftag(fraction)}" / f"request_seed{seed}" / f"base_seed{seed}"
            bcell = baseline_root / cell
            rcell = recon_root / cell
            bpath = find_one(bcell / "common", "*_common_shared_base.json")
            rpath = find_one(rcell, "*_reconstruction.json")
            bstyle_path = find_optional_one(bcell / "graphdpo_style", "*_graphdpo_style_common.json")
            rstyle_path = find_one(rcell / "graphdpo_style", "*_graphdpo_style_common.json")

            bp = json.loads(bpath.read_text())
            rp = json.loads(rpath.read_text())
            bsp = None if bstyle_path is None else json.loads(bstyle_path.read_text())
            rsp = json.loads(rstyle_path.read_text())

            hashes = {bp["request_hash"], rp["request_hash"], rsp["request_hash"]}
            if bsp is not None:
                hashes.add(bsp["request_hash"])
            if len(hashes) != 1:
                raise RuntimeError(f"Request hash mismatch for {dataset} seed={seed}: {hashes}")
            if not np.isclose(float(bp["fraction"]), fraction):
                raise RuntimeError(
                    f"Wrong baseline fraction for {dataset} seed={seed}: "
                    f"expected {fraction}, found {bp['fraction']}"
                )

            by_method = rows_by_method(bp)
            base_style = {} if bsp is None else rows_by_method(bsp)
            recon_style = rows_by_method(rsp)
            missing = [m for m in BASE_METHODS if m not in by_method]
            if missing:
                raise RuntimeError(f"{dataset} seed={seed} missing baseline methods {missing}")
            if bsp is None:
                missing_baseline_style.append({"dataset": dataset, "seed": seed})
            else:
                missing_style = [m for m in STYLE_BASE_METHODS if m not in base_style]
                if missing_style:
                    raise RuntimeError(f"{dataset} seed={seed} missing baseline GraphDPO-style rows {missing_style}")

            recon_rows = [row for row in rp["rows"] if is_recon_method(row["method"])]
            if len(recon_rows) != 2:
                raise RuntimeError(f"{dataset} seed={seed} expected two reconstruction rows")
            for row in recon_rows:
                if row["method"] not in recon_style:
                    raise RuntimeError(f"{dataset} seed={seed} missing reconstruction GraphDPO-style row {row['method']}")

            chosen = [by_method[m] for m in BASE_METHODS] + recon_rows
            for row in chosen:
                method = row["method"]
                style = recon_style.get(method) if is_recon_method(method) else base_style.get(method)
                records.append(
                    {
                        "dataset": dataset,
                        "seed": seed,
                        "fraction": fraction,
                        "request_hash": bp["request_hash"],
                        "method": method,
                        "global_mrr": row.get("global_mrr"),
                        "forget_mrr": row.get("forget_mrr"),
                        "global_mrr_gap_to_exact": row.get("global_mrr_gap_to_exact"),
                        "forget_mrr_gap_to_exact": row.get("forget_mrr_gap_to_exact"),
                        "retain_mrr": None if style is None else style.get("retain_mrr"),
                        "graphdpo_mrr_avg": None if style is None else style.get("graphdpo_mrr_avg"),
                        "graphdpo_mrr_f1": None if style is None else style.get("graphdpo_mrr_f1"),
                        "train_sec": row.get("train_sec"),
                        "anchor_count": row.get("anchor_count"),
                        "anchor_fraction": row.get("anchor_fraction"),
                        "repair_triples": row.get("repair_triples"),
                        "repair_fraction": row.get("repair_fraction"),
                    }
                )
            structural.append(
                {
                    "dataset": dataset,
                    "seed": seed,
                    "request_hash": bp["request_hash"],
                    "forget_n": rp["forget_n"],
                    "retain_n": rp["retain_n"],
                    "entity_n": rp["entity_n"],
                    "endpoint_anchor_count": rp["endpoint"]["anchor_count"],
                    "endpoint_anchor_fraction": rp["endpoint"]["anchor_fraction"],
                    "endpoint_repair_fraction": rp["endpoint"]["repair_fraction"],
                    "star_anchor_count": rp["star_cover"]["anchor_count"],
                    "star_anchor_fraction": rp["star_cover"]["anchor_fraction"],
                    "star_repair_fraction": rp["star_cover"]["repair_fraction"],
                    "star_forget_coverage": rp["star_cover"]["forget_coverage"],
                }
            )

    combined = out / "combined_random_fact_reconstruction_mini.csv"
    with combined.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(records[0].keys()))
        w.writeheader()
        w.writerows(records)

    struct_path = out / "structural_random_fact_reconstruction_mini.csv"
    with struct_path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(structural[0].keys()))
        w.writeheader()
        w.writerows(structural)

    metrics = (
        "global_mrr",
        "forget_mrr",
        "global_mrr_gap_to_exact",
        "forget_mrr_gap_to_exact",
        "retain_mrr",
        "graphdpo_mrr_avg",
        "graphdpo_mrr_f1",
        "train_sec",
        "anchor_fraction",
        "repair_fraction",
    )
    grouped = defaultdict(list)
    for row in records:
        grouped[row["method"]].append(row)

    agg = []
    for method, rows in sorted(grouped.items()):
        rec = {"method": method, "n": len(rows)}
        for metric in metrics:
            vals = [r.get(metric) for r in rows]
            vals = np.asarray([float(v) for v in vals if v not in (None, "")], dtype=float)
            rec[f"{metric}_mean"] = None if len(vals) == 0 else float(vals.mean())
            rec[f"{metric}_std"] = None if len(vals) <= 1 else float(vals.std(ddof=1))
            rec[f"{metric}_median"] = None if len(vals) == 0 else float(np.median(vals))
        agg.append(rec)

    agg_path = out / "aggregate_random_fact_reconstruction_mini.csv"
    with agg_path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(agg[0].keys()))
        w.writeheader()
        w.writerows(agg)

    summary = {
        "datasets": list(datasets),
        "seeds": list(SEEDS),
        "fraction": fraction,
        "fraction_tag": ftag(fraction),
        "cells": len(datasets) * len(SEEDS),
        "records": len(records),
        "methods": sorted(grouped),
        "graphdpo_style_metrics": ["retain_mrr", "forget_mrr", "graphdpo_mrr_avg", "graphdpo_mrr_f1"],
        "baseline_graphdpo_style_complete": len(missing_baseline_style) == 0,
        "missing_baseline_graphdpo_style": missing_baseline_style,
        "combined": str(combined),
        "structural": str(struct_path),
        "aggregate": str(agg_path),
    }
    summary_path = out / "summary_random_fact_reconstruction_mini.json"
    summary_path.write_text(json.dumps(summary, indent=2))

    print(json.dumps(summary, indent=2))
    print("RANDOM_FACT_RECONSTRUCTION_MINI_COLLECT_OK")


if __name__ == "__main__":
    main()
