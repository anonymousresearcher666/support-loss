#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import math
import statistics
from collections import defaultdict
from pathlib import Path


NUMERIC = (
    "fraction",
    "eta_hvp",
    "boundary_ratio",
    "boundary_proxy_sqrt",
    "degree_mass_ratio",
    "parameter_fraction",
    "unique_work_fraction",
    "global_mrr_gap",
    "forgotten_mrr_gap",
    "parameter_distance_to_reference",
    "speedup_vs_reference",
)

GROUP_KEYS = ("dataset", "model", "policy", "fraction")
CORR_TARGETS = (
    "boundary_ratio",
    "boundary_proxy_sqrt",
    "degree_mass_ratio",
    "parameter_fraction",
    "unique_work_fraction",
    "global_mrr_gap",
    "forgotten_mrr_gap",
    "parameter_distance_to_reference",
    "speedup_vs_reference",
)
DELTA_TARGETS = (
    "eta_hvp",
    "boundary_ratio",
    "degree_mass_ratio",
    "parameter_fraction",
    "unique_work_fraction",
    "global_mrr_gap",
    "forgotten_mrr_gap",
    "parameter_distance_to_reference",
    "speedup_vs_reference",
)


def f(x):
    try:
        y = float(x)
    except Exception:
        return float("nan")
    return y


def finite(xs):
    return [x for x in xs if math.isfinite(x)]


def mean(xs):
    xs = finite(xs)
    return statistics.fmean(xs) if xs else float("nan")


def sd(xs):
    xs = finite(xs)
    return statistics.stdev(xs) if len(xs) >= 2 else 0.0 if xs else float("nan")


def quantile(xs, q):
    xs = sorted(finite(xs))
    if not xs:
        return float("nan")
    if len(xs) == 1:
        return xs[0]
    pos = q * (len(xs) - 1)
    lo = int(math.floor(pos)); hi = int(math.ceil(pos))
    if lo == hi:
        return xs[lo]
    a = pos - lo
    return xs[lo] * (1 - a) + xs[hi] * a


def pearson(xs, ys):
    pairs = [(x, y) for x, y in zip(xs, ys) if math.isfinite(x) and math.isfinite(y)]
    if len(pairs) < 3:
        return float("nan")
    x = [p[0] for p in pairs]; y = [p[1] for p in pairs]
    mx = statistics.fmean(x); my = statistics.fmean(y)
    dx = [v - mx for v in x]; dy = [v - my for v in y]
    den = math.sqrt(sum(v*v for v in dx) * sum(v*v for v in dy))
    return sum(a*b for a, b in zip(dx, dy)) / den if den > 0 else float("nan")


def ranks(xs):
    order = sorted(range(len(xs)), key=lambda i: xs[i])
    out = [0.0] * len(xs)
    i = 0
    while i < len(order):
        j = i + 1
        while j < len(order) and xs[order[j]] == xs[order[i]]:
            j += 1
        r = (i + 1 + j) / 2.0
        for k in range(i, j):
            out[order[k]] = r
        i = j
    return out


def spearman(xs, ys):
    pairs = [(x, y) for x, y in zip(xs, ys) if math.isfinite(x) and math.isfinite(y)]
    if len(pairs) < 3:
        return float("nan")
    x = [p[0] for p in pairs]; y = [p[1] for p in pairs]
    return pearson(ranks(x), ranks(y))


def load_rows(root: Path):
    rows = []
    for p in sorted(root.glob("*.csv")):
        with p.open(newline="") as h:
            try:
                r = next(csv.DictReader(h))
            except StopIteration:
                continue
        r["_file"] = str(p)
        for k in NUMERIC:
            r[k] = f(r.get(k, "nan"))
        r["hessian_damping_used"] = f(r.get("hessian_damping_used", "nan"))
        rows.append(r)
    return rows


def canonical(rows, damping):
    good, bad = [], []
    for r in rows:
        ok = (
            r.get("eta_status") == "ok"
            and math.isfinite(r["eta_hvp"])
            and math.isfinite(r["hessian_damping_used"])
            and abs(r["hessian_damping_used"] - damping) <= 1e-12
            and "max_iter_unconverged" not in r.get("eta_meta", "")
            and "max_iter_positive" not in r.get("eta_meta", "")
        )
        (good if ok else bad).append(r)
    return good, bad


def write_csv(path: Path, rows, fields):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as h:
        w = csv.DictWriter(h, fieldnames=fields)
        w.writeheader(); w.writerows(rows)


def corr_table(rows, condition_fields=()):
    grouped = defaultdict(list)
    if condition_fields:
        for r in rows:
            grouped[tuple(r.get(k) for k in condition_fields)].append(r)
    else:
        grouped[()] = list(rows)
    out = []
    for key in sorted(grouped, key=str):
        rs = grouped[key]
        eta = [r["eta_hvp"] for r in rs]
        for target in CORR_TARGETS:
            vals = [r[target] for r in rs]
            row = {k: v for k, v in zip(condition_fields, key)}
            row.update({
                "x": "eta_hvp", "y": target, "n": len(rs),
                "pearson_r": pearson(eta, vals),
                "spearman_rho": spearman(eta, vals),
            })
            out.append(row)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default="results_cluster/mechanism/coupling_real")
    ap.add_argument("--out", default="results_cluster/mechanism/coupling_analysis")
    ap.add_argument("--damping", type=float, default=0.01)
    args = ap.parse_args()

    root = Path(args.root); out = Path(args.out)
    rows = load_rows(root)
    good, bad = canonical(rows, args.damping)

    print(f"files={len(rows)} canonical={len(good)} rejected={len(bad)} fixed_damping={args.damping}")
    if bad:
        print("REJECTED:")
        for r in bad[:20]:
            print(" ", r["_file"], r.get("eta_status"), r.get("hessian_damping_used"))

    etas = [r["eta_hvp"] for r in good]
    overall = [{
        "n": len(good),
        "eta_mean": mean(etas),
        "eta_sd": sd(etas),
        "eta_min": min(etas) if etas else float("nan"),
        "eta_q25": quantile(etas, .25),
        "eta_median": quantile(etas, .50),
        "eta_q75": quantile(etas, .75),
        "eta_max": max(etas) if etas else float("nan"),
        "eta_lt_1_fraction": mean([1.0 if x < 1.0 else 0.0 for x in etas]),
        "eta_lt_0_8_fraction": mean([1.0 if x < .8 else 0.0 for x in etas]),
    }]
    write_csv(out / "coupling_overall.csv", overall, list(overall[0].keys()))

    groups = defaultdict(list)
    for r in good:
        groups[(r["dataset"], r["model"], r["policy"], r["fraction"])].append(r)

    grouped = []
    for key in sorted(groups, key=str):
        rs = groups[key]
        row = dict(zip(GROUP_KEYS, key)); row["n"] = len(rs)
        for m in NUMERIC:
            if m == "fraction":
                continue
            vals = [r[m] for r in rs]
            row[m + "_mean"] = mean(vals)
            row[m + "_sd"] = sd(vals)
        row["eta_min"] = min(r["eta_hvp"] for r in rs)
        row["eta_max"] = max(r["eta_hvp"] for r in rs)
        grouped.append(row)
    group_fields = list(grouped[0].keys()) if grouped else list(GROUP_KEYS) + ["n"]
    write_csv(out / "coupling_summary_by_group_fraction.csv", grouped, group_fields)

    fraction_rows = []
    for frac in sorted({r["fraction"] for r in good}):
        rs = [r for r in good if r["fraction"] == frac]
        fraction_rows.append({
            "fraction": frac,
            "n": len(rs),
            "eta_mean": mean([r["eta_hvp"] for r in rs]),
            "eta_sd": sd([r["eta_hvp"] for r in rs]),
            "eta_median": quantile([r["eta_hvp"] for r in rs], .5),
            "boundary_mean": mean([r["boundary_ratio"] for r in rs]),
            "parameter_fraction_mean": mean([r["parameter_fraction"] for r in rs]),
            "work_fraction_mean": mean([r["unique_work_fraction"] for r in rs]),
            "global_mrr_gap_mean": mean([r["global_mrr_gap"] for r in rs]),
            "forgotten_mrr_gap_mean": mean([r["forgotten_mrr_gap"] for r in rs]),
        })
    write_csv(out / "coupling_summary_by_fraction.csv", fraction_rows, list(fraction_rows[0].keys()))

    corr_specs = [
        ("coupling_correlations.csv", ()),
        ("coupling_correlations_by_policy.csv", ("policy",)),
        ("coupling_correlations_by_model.csv", ("model",)),
        ("coupling_correlations_by_model_policy.csv", ("model", "policy")),
        ("coupling_correlations_by_fraction.csv", ("fraction",)),
    ]
    corr_tables = {}
    for filename, fields in corr_specs:
        table = corr_table(good, fields)
        corr_tables[filename] = table
        write_csv(out / filename, table,
                  list(fields) + ["x", "y", "n", "pearson_r", "spearman_rho"])

    # Matched 5% -> 20% analysis for the same dataset/model/policy/seed.
    pairs = defaultdict(dict)
    for r in good:
        key = (r.get("dataset"), r.get("model"), r.get("policy"), r.get("seed"))
        pairs[key][round(r["fraction"], 8)] = r

    delta_rows = []
    for key in sorted(pairs, key=str):
        p = pairs[key]
        if 0.05 not in p or 0.20 not in p:
            continue
        lo, hi = p[0.05], p[0.20]
        row = {
            "dataset": key[0], "model": key[1], "policy": key[2], "seed": key[3],
            "fraction_lo": 0.05, "fraction_hi": 0.20,
        }
        for target in DELTA_TARGETS:
            row[target + "_05"] = lo[target]
            row[target + "_20"] = hi[target]
            row["delta_" + target] = hi[target] - lo[target]
        delta_rows.append(row)

    delta_fields = list(delta_rows[0].keys()) if delta_rows else ["dataset", "model", "policy", "seed"]
    write_csv(out / "coupling_matched_05_to_20.csv", delta_rows, delta_fields)

    delta_summary = []
    if delta_rows:
        for target in DELTA_TARGETS:
            vals = [r["delta_" + target] for r in delta_rows]
            delta_summary.append({
                "metric": target,
                "n": len(vals),
                "mean_delta_20_minus_05": mean(vals),
                "sd_delta": sd(vals),
                "median_delta": quantile(vals, .5),
                "positive_fraction": mean([1.0 if x > 0 else 0.0 for x in vals]),
                "negative_fraction": mean([1.0 if x < 0 else 0.0 for x in vals]),
            })
    write_csv(out / "coupling_matched_delta_summary.csv", delta_summary,
              ["metric", "n", "mean_delta_20_minus_05", "sd_delta", "median_delta", "positive_fraction", "negative_fraction"])

    delta_corr = []
    if delta_rows:
        de = [r["delta_eta_hvp"] for r in delta_rows]
        for target in DELTA_TARGETS:
            if target == "eta_hvp":
                continue
            vals = [r["delta_" + target] for r in delta_rows]
            delta_corr.append({
                "x": "delta_eta_hvp", "y": "delta_" + target, "n": len(delta_rows),
                "pearson_r": pearson(de, vals),
                "spearman_rho": spearman(de, vals),
            })
    write_csv(out / "coupling_matched_delta_correlations.csv", delta_corr,
              ["x", "y", "n", "pearson_r", "spearman_rho"])

    print("\nOVERALL ETA")
    for k, v in overall[0].items():
        print(f"{k:22s} {v}")

    print("\nBY FRACTION")
    for r in fraction_rows:
        print(
            f"fraction={r['fraction']:.2f} n={r['n']} eta={r['eta_mean']:.4f}±{r['eta_sd']:.4f} "
            f"median={r['eta_median']:.4f} boundary={r['boundary_mean']:.4f} "
            f"param={r['parameter_fraction_mean']:.4f} work={r['work_fraction_mean']:.4f} "
            f"gMRR={r['global_mrr_gap_mean']:.5f} fMRR={r['forgotten_mrr_gap_mean']:.5f}"
        )

    print("\nOVERALL CORRELATIONS WITH ETA")
    for r in corr_tables["coupling_correlations.csv"]:
        print(f"{r['y']:32s} Pearson={r['pearson_r']:+.4f}  Spearman={r['spearman_rho']:+.4f}")

    print("\nMATCHED 5% -> 20% DELTAS")
    print(f"matched pairs={len(delta_rows)}")
    for r in delta_summary:
        print(
            f"{r['metric']:32s} mean_delta={r['mean_delta_20_minus_05']:+.6f} "
            f"median={r['median_delta']:+.6f} positive={r['positive_fraction']:.3f}"
        )

    print("\nCORRELATIONS OF DELTA ETA WITH MATCHED DELTAS")
    for r in delta_corr:
        print(f"{r['y']:38s} Pearson={r['pearson_r']:+.4f}  Spearman={r['spearman_rho']:+.4f}")

    print("\nGROUP MEANS (dataset/model/policy/fraction)")
    for r in grouped:
        print(
            f"{r['dataset']:10s} {r['model']:8s} {r['policy']:8s} f={r['fraction']:.2f} n={r['n']} "
            f"eta={r['eta_hvp_mean']:.4f}±{r['eta_hvp_sd']:.4f} "
            f"boundary={r['boundary_ratio_mean']:.4f} "
            f"param={r['parameter_fraction_mean']:.4f} "
            f"work={r['unique_work_fraction_mean']:.4f} "
            f"gMRR={r['global_mrr_gap_mean']:.5f} "
            f"fMRR={r['forgotten_mrr_gap_mean']:.5f}"
        )

    print(f"\nwrote analysis under: {out}")


if __name__ == "__main__":
    main()
