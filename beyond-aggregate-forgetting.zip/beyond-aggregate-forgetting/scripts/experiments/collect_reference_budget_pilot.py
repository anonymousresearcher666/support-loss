#!/usr/bin/env python3
"""Strict per-query analysis of the full-split DistMult budget-control cohort.

Never substitute this cohort for the historical TransE common-evaluator suite.
Three seeds of one graph/request are replicates, not independent datasets.
"""
from __future__ import annotations
import argparse, csv, hashlib, itertools, json
from pathlib import Path
from statistics import mean
import numpy as np
from scripts.experiments.run_reference_budget_pilot import PROTOCOL

DATASETS=('FB15K-237','CoDEx-M')
SEEDS=(17,29,43)
METHODS=('Unchanged','ResetOnly','Local','ResetLocal','FullRetain','ResetFullRetain','ResetDenseSameWork')
BUDGETS=(20,50,100)
SETS=('test','forgotten','retained')


def prediction_metrics(x,y):
    out={}
    for q in SETS:
        a,b=1/x[q+'_ranks'],1/y[q+'_ranks']
        if a.shape!=b.shape or not np.isfinite(a).all() or not np.isfinite(b).all():
            raise ValueError('Incompatible or nonfinite rankings')
        out[q+'_mrr']=float(a.mean());out[q+'_reference_mrr']=float(b.mean())
        out[q+'_gap']=abs(float(a.mean()-b.mean()))
        out[q+'_rr_mae']=float(np.mean(np.abs(a-b)))
        out[q+'_top1_disagreement']=float(np.mean(x[q+'_top1']!=y[q+'_top1']))
    return out


def save_csv(path,rows):
    if not rows:raise ValueError('Empty result table')
    fields=sorted(set().union(*(r.keys() for r in rows)))
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)


def aggregate(rows,keys,fields):
    out=[]
    vals=sorted({tuple(r[k] for k in keys) for r in rows})
    for v in vals:
        rr=[r for r in rows if tuple(r[k] for k in keys)==v]
        r=dict(zip(keys,v));r['n']=len(rr)
        for f in fields:
            z=[float(x[f]) for x in rr]
            r[f+'_mean']=mean(z);r[f+'_min']=min(z);r[f+'_max']=max(z)
        out.append(r)
    return out


def collect(root):
    pred={};raws={};manifests={};input_hashes={}
    for ds in DATASETS:
        queries=None
        for seed in SEEDS:
            p=root/ds/f'seed{seed}'
            manifest=json.loads((p/'COMPLETE.json').read_text())
            if manifest['dataset']!=ds or manifest['seed']!=seed or manifest['protocol']!=PROTOCOL:
                raise ValueError(f'Incorrect protocol: {p}')
            raws[ds,seed]={r['label']:r for r in json.loads((p/'raw.json').read_text())}
            manifests[ds,seed]=manifest
            q=dict(np.load(p/'queries.npz'))
            if queries is None:queries=q
            for k in queries:np.testing.assert_array_equal(queries[k],q[k])
            keys=METHODS+tuple(f'Reference{k}' for k in BUDGETS)
            for key in keys:
                x=dict(np.load(p/f'{key}_predictions.npz'))
                for qs in SETS:
                    a=x[qs+'_ranks']
                    if a.shape != (2,len(q[qs])) or not np.isfinite(a).all() or not (a>=1).all():
                        raise ValueError(f'Invalid ranking output {p} {key}')
                    if abs((1/a).mean()-raws[ds,seed][key][qs+'_mrr'])>1e-14:
                        raise ValueError('Raw and per-query MRR disagree')
                pred[ds,seed,key]=x
                rel=str((p/f'{key}_predictions.npz').relative_to(root))
                input_hashes[rel]=hashlib.sha256((root/rel).read_bytes()).hexdigest()
            trained=[raws[ds,seed][m] for m in METHODS if m not in ('Unchanged','ResetOnly')]
            if {r['presentations'] for r in trained}!={5*manifest['retained_triples']}:
                raise ValueError('Unequal presentation budget')
            if len({r['steps'] for r in trained})!=1:raise ValueError('Unequal update count')
    pairs=[];cross=[];rrpairs=[];drift=[];robust=[]
    for ds in DATASETS:
        for budget in BUDGETS:
            for s,t in itertools.combinations(SEEDS,2):
                rrpairs.append({'dataset':ds,'budget':budget,'seed_a':s,'seed_b':t,
                  **prediction_metrics(pred[ds,s,f'Reference{budget}'],pred[ds,t,f'Reference{budget}'])})
            for seed in SEEDS:
                for method in METHODS:
                    for refseed in SEEDS:
                        row={'dataset':ds,'seed':seed,'reference_seed':refseed,'method':method,'budget':budget,
                         **prediction_metrics(pred[ds,seed,method],pred[ds,refseed,f'Reference{budget}'])}
                        cross.append(row)
                        if refseed==seed:pairs.append(row)
        for seed in SEEDS:
            for a,b in itertools.combinations(BUDGETS,2):
                drift.append({'dataset':ds,'seed':seed,'from_budget':a,'to_budget':b,
                  **prediction_metrics(pred[ds,seed,f'Reference{a}'],pred[ds,seed,f'Reference{b}'])})
            for method in METHODS:
                records=[r for r in cross if r['dataset']==ds and r['seed']==seed and r['method']==method]
                robust.append({'dataset':ds,'seed':seed,'method':method,
                    **{q+'_worst_gap':max(r[q+'_gap'] for r in records) for q in SETS},
                    **{q+'_mean_rr_mae':mean(r[q+'_rr_mae'] for r in records) for q in SETS}})
    assert len(pairs)==126 and len(cross)==378 and len(rrpairs)==18 and len(drift)==18
    fields=[q+s for q in SETS for s in ('_mrr','_reference_mrr','_gap','_rr_mae','_top1_disagreement')]
    agg=aggregate(pairs,['dataset','budget','method'],fields)
    variability=aggregate(rrpairs,['dataset','budget'],[q+s for q in SETS for s in ('_gap','_rr_mae','_top1_disagreement')])
    drifts=aggregate(drift,['dataset','from_budget','to_budget'],fields)
    for filename,rows in [('same_seed.csv',pairs),('cross_seed.csv',cross),('reference_pairs.csv',rrpairs),
                         ('reference_drift.csv',drift),('worst_reference.csv',robust),('aggregates.csv',agg),
                         ('reference_variability.csv',variability),('drift_aggregates.csv',drifts)]:
        save_csv(root/filename,rows)
    summary={'scope':'new full-split DistMult diagnostic; not the archived TransE/GraphDPO rescore',
       'graphs':2,'fixed_requests':2,'seed_replicates':6,'reference_trajectories':6,'reference_checkpoints':18,
       'optimized_controls':5,'same_seed_comparisons':126,'cross_seed_comparisons':378,
       'uncertainty':'Three-seed descriptive ranges; no population significance claimed',
       'maximum_budget_is_not_convergence':True,'protocol':PROTOCOL,
       'manifests':[manifests[k] for k in sorted(manifests)],'raw_prediction_sha256':input_hashes,
       'aggregates':agg,'reference_variability':variability,'reference_drift':drifts}
    (root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    return summary


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,required=True)
    a=ap.parse_args();s=collect(a.results)
    print(json.dumps({k:v for k,v in s.items() if k not in ('manifests','aggregates','reference_drift','raw_prediction_sha256')},indent=2))
if __name__=='__main__':main()
