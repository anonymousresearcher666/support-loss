#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import re
from collections import defaultdict
from pathlib import Path

import numpy as np

EPOCH_RE = re.compile(r"Epoch:(\d+)\s+Loss:([0-9eE+\-.]+)")
TIME_RE = re.compile(r"Snapshot\s+0\s+training time is\s+([0-9eE+\-.]+)")


def read_csvs(root: Path, suffix: str):
    rows=[]
    for p in sorted(root.rglob(f'*{suffix}')):
        with p.open(newline='',encoding='utf8') as f:
            for r in csv.DictReader(f):
                r['_source']=str(p); rows.append(r)
    return rows


def boot_ci(x, seed=1234, b=10000):
    x=np.asarray(x,dtype=float)
    rng=np.random.default_rng(seed)
    z=np.array([rng.choice(x,size=len(x),replace=True).mean() for _ in range(b)])
    return float(np.quantile(z,.025)), float(np.quantile(z,.975))


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--eval-root',required=True)
    ap.add_argument('--train-root',required=True)
    ap.add_argument('--out',required=True)
    args=ap.parse_args()
    er=Path(args.eval_root); tr=Path(args.train_root); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)

    primary_raw=read_csvs(er/'primary','_raw.csv')
    primary_gaps=read_csvs(er/'primary','_gaps.csv')
    rep_raw=read_csvs(er/'replicate','_raw.csv')
    rep_gaps=read_csvs(er/'replicate','_gaps.csv')
    if len(primary_raw)!=168: raise RuntimeError(f'primary raw expected 168 found {len(primary_raw)}')
    if len(primary_gaps)!=288: raise RuntimeError(f'primary gaps expected 288 found {len(primary_gaps)}')
    if len(rep_raw)!=26: raise RuntimeError(f'replicate raw expected 26 found {len(rep_raw)}')
    if len(rep_gaps)!=72: raise RuntimeError(f'replicate gaps expected 72 found {len(rep_gaps)}')

    # Primary 24-cell reference sensitivity: 4 methods x 3 reference protocols.
    methods=sorted(set(r['method'] for r in primary_gaps))
    refs=sorted(set(r['reference'] for r in primary_gaps))
    if refs != ['FiniteRetrain-20','FiniteRetrain-50','FiniteRetrain-Conv']:
        raise RuntimeError(f'unexpected primary refs {refs}')
    summary=[]
    for ref in refs:
        for method in methods:
            s=[r for r in primary_gaps if r['reference']==ref and r['method']==method]
            if len(s)!=24: raise RuntimeError(f'{ref}/{method}: expected24 found{len(s)}')
            dg=np.array([float(r['global_gap']) for r in s]); df=np.array([float(r['forgotten_gap']) for r in s])
            glo=boot_ci(dg, 1000+len(summary)*2); flo=boot_ci(df,2000+len(summary)*2)
            summary.append({
                'reference':ref,'method':method,'n':len(s),
                'global_gap_mean':float(dg.mean()),'global_gap_ci95_lo':glo[0],'global_gap_ci95_hi':glo[1],
                'forgotten_gap_mean':float(df.mean()),'forgotten_gap_ci95_lo':flo[0],'forgotten_gap_ci95_hi':flo[1],
            })

    # How much the reference itself moves between 20/50/Conv on each matched cell.
    primary_refs=[r for r in primary_raw if r['kind']=='reference']
    bycell=defaultdict(list)
    for r in primary_refs:
        bycell[(r['dataset'],r['fraction'],r['request_seed'])].append(r)
    if len(bycell)!=24 or any(len(v)!=3 for v in bycell.values()):
        raise RuntimeError('primary reference cell coverage mismatch')
    spreads=[]
    for key,v in sorted(bycell.items()):
        gm=np.array([float(x['global_mrr']) for x in v]); fm=np.array([float(x['forgotten_mrr']) for x in v])
        spreads.append({'dataset':key[0],'fraction':key[1],'request_seed':key[2],
                        'reference_global_mrr_range':float(gm.max()-gm.min()),
                        'reference_forgotten_mrr_range':float(fm.max()-fm.min())})

    # Independent-seed distribution on two representative requests.
    rep_refs=[r for r in rep_raw if r['kind']=='reference']
    rep_summary=[]
    for dataset in sorted(set(r['dataset'] for r in rep_refs)):
        for mode in ['FiniteRetrain-20','FiniteRetrain-50','FiniteRetrain-Conv']:
            s=[r for r in rep_refs if r['dataset']==dataset and r['label'].startswith(mode+'-s')]
            if len(s)!=3: raise RuntimeError(f'{dataset}/{mode}: expected3 refs found{len(s)}')
            gm=np.array([float(x['global_mrr']) for x in s]); fm=np.array([float(x['forgotten_mrr']) for x in s])
            rep_summary.append({'dataset':dataset,'mode':mode,'n_seeds':3,
                                'global_mrr_mean':float(gm.mean()),'global_mrr_std':float(gm.std(ddof=1)),
                                'forgotten_mrr_mean':float(fm.mean()),'forgotten_mrr_std':float(fm.std(ddof=1)),
                                'global_mrr_range':float(gm.max()-gm.min()),'forgotten_mrr_range':float(fm.max()-fm.min())})

    # Parse convergence traces and training times for all 90 new reference runs.
    metas=list(tr.rglob('meta.json')); logs=list(tr.rglob('stdout.log')); ckpts=list(tr.rglob('model_best.tar'))
    if len(metas)!=90 or len(logs)!=90 or len(ckpts)!=90:
        raise RuntimeError(f'train artifacts expected90 meta/log/ckpt got {len(metas)}/{len(logs)}/{len(ckpts)}')
    curves=[]; runtimes=[]
    for mp in metas:
        meta=json.loads(mp.read_text())
        lp=mp.with_name('stdout.log'); txt=lp.read_text(errors='replace')
        pts=[(int(e),float(l)) for e,l in EPOCH_RE.findall(txt)]
        tm=TIME_RE.findall(txt)
        if not tm: raise RuntimeError(f'missing training time in {lp}')
        runtimes.append({**meta,'training_sec':float(tm[-1]),'logged_points':len(pts),'last_logged_epoch':pts[-1][0] if pts else -1})
        for e,l in pts: curves.append({**meta,'epoch':e,'loss':l})

    # ordering stability: rank by mean sum of the two absolute gaps under each reference.
    ordering=[]
    for ref in refs:
        ss=[x for x in summary if x['reference']==ref]
        ranked=sorted(ss,key=lambda x:x['global_gap_mean']+x['forgotten_gap_mean'])
        for rank,x in enumerate(ranked,1): ordering.append({'reference':ref,'rank':rank,'method':x['method'],
            'mean_gap_sum':x['global_gap_mean']+x['forgotten_gap_mean']})

    def write(name, rows):
        if not rows: return
        with (out/name).open('w',newline='',encoding='utf8') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    write('reference_sensitivity_method_summary.csv',summary)
    write('reference_protocol_cell_spreads.csv',spreads)
    write('reference_seed_variability.csv',rep_summary)
    write('reference_training_curves.csv',curves)
    write('reference_training_runtime.csv',runtimes)
    write('reference_ordering.csv',ordering)

    obj={'primary_cells':24,'new_reference_runs':90,'method_summary':summary,'seed_variability':rep_summary,
         'mean_reference_global_range':float(np.mean([x['reference_global_mrr_range'] for x in spreads])),
         'mean_reference_forgotten_range':float(np.mean([x['reference_forgotten_mrr_range'] for x in spreads])),
         'ordering':ordering}
    (out/'reference_sensitivity_summary.json').write_text(json.dumps(obj,indent=2)+'\n')
    md=['# Finite retraining reference sensitivity','', '- Primary matched cells: 24', '- New retraining runs: 90',
        f"- Mean 20/50/Conv reference global-MRR range per cell: {obj['mean_reference_global_range']:.6g}",
        f"- Mean 20/50/Conv reference forgotten-MRR range per cell: {obj['mean_reference_forgotten_range']:.6g}",'',
        '| Reference | Method | global gap mean [95% CI] | forgotten gap mean [95% CI] |','|---|---|---:|---:|']
    for x in summary:
        md.append(f"| {x['reference']} | {x['method']} | {x['global_gap_mean']:.6f} [{x['global_gap_ci95_lo']:.6f},{x['global_gap_ci95_hi']:.6f}] | {x['forgotten_gap_mean']:.6f} [{x['forgotten_gap_ci95_lo']:.6f},{x['forgotten_gap_ci95_hi']:.6f}] |")
    md += ['', '## Independent retraining-seed variability', '', '| Dataset | Mode | global MRR mean+-sd | forgotten MRR mean+-sd |','|---|---|---:|---:|']
    for x in rep_summary:
        md.append(f"| {x['dataset']} | {x['mode']} | {x['global_mrr_mean']:.6f} +- {x['global_mrr_std']:.6f} | {x['forgotten_mrr_mean']:.6f} +- {x['forgotten_mrr_std']:.6f} |")
    (out/'REFERENCE_SENSITIVITY.md').write_text('\n'.join(md)+'\n')
    print('REFERENCE_SENSITIVITY_COLLECT_OK')
    print('\n'.join(md))

if __name__=='__main__': main()
