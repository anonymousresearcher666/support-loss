#!/usr/bin/env python3
from __future__ import annotations

import argparse, csv, json, math
from pathlib import Path
import numpy as np

METHODS = ['SchemaCert+Restart-L5','Finetune','NG','GraphDPO']


def boot_mean_ci(x, seed, b=20000):
    x=np.asarray(x,dtype=float); rng=np.random.default_rng(seed)
    z=np.empty(b)
    for i in range(b): z[i]=rng.choice(x,size=len(x),replace=True).mean()
    return float(x.mean()), float(np.quantile(z,.025)), float(np.quantile(z,.975))


def runtime_stats(x):
    x=np.asarray([v for v in x if math.isfinite(v)],dtype=float)
    return {'mean':float(x.mean()),'median':float(np.median(x)),
            'q25':float(np.quantile(x,.25)),'q75':float(np.quantile(x,.75)),
            'iqr':float(np.quantile(x,.75)-np.quantile(x,.25))}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--matched-root',required=True)
    ap.add_argument('--ablation-root',required=True)
    ap.add_argument('--out',required=True)
    args=ap.parse_args(); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)

    files=sorted(Path(args.matched_root).glob('*_common_shared_base.csv'))
    if len(files)!=24: raise RuntimeError(f'expected24 matched CSVs found{len(files)}')
    cells={}
    for p in files:
        rows=list(csv.DictReader(p.open()))
        mm={r['method']:r for r in rows}
        if not set(METHODS).issubset(mm): raise RuntimeError(f'{p}: missing methods')
        key=p.stem.removesuffix('_common_shared_base')
        cells[key]=mm

    summaries=[]; diffs=[]
    for mi,m in enumerate(METHODS):
        dg=np.array([float(mm[m]['global_mrr_gap_to_exact']) for mm in cells.values()])
        df=np.array([float(mm[m]['forget_mrr_gap_to_exact']) for mm in cells.values()])
        rt=np.array([float(mm[m]['train_sec']) for mm in cells.values()])
        mg=boot_mean_ci(dg,1000+mi); mf=boot_mean_ci(df,2000+mi)
        rs=runtime_stats(rt)
        summaries.append({'method':m,'n':24,
            'global_gap_mean':mg[0],'global_gap_ci95_lo':mg[1],'global_gap_ci95_hi':mg[2],
            'forgotten_gap_mean':mf[0],'forgotten_gap_ci95_lo':mf[1],'forgotten_gap_ci95_hi':mf[2],
            'runtime_mean_sec':rs['mean'],'runtime_median_sec':rs['median'],
            'runtime_q25_sec':rs['q25'],'runtime_q75_sec':rs['q75'],'runtime_iqr_sec':rs['iqr']})
    restart='SchemaCert+Restart-L5'
    for j,comp in enumerate(['Finetune','NG','GraphDPO']):
        gd=[]; fd=[]
        for mm in cells.values():
            gd.append(float(mm[restart]['global_mrr_gap_to_exact'])-float(mm[comp]['global_mrr_gap_to_exact']))
            fd.append(float(mm[restart]['forget_mrr_gap_to_exact'])-float(mm[comp]['forget_mrr_gap_to_exact']))
        g=boot_mean_ci(gd,3000+j); f=boot_mean_ci(fd,4000+j)
        diffs.append({'comparison':f'{restart} - {comp}','n':24,
            'global_gap_difference_mean':g[0],'global_diff_ci95_lo':g[1],'global_diff_ci95_hi':g[2],
            'forgotten_gap_difference_mean':f[0],'forgotten_diff_ci95_lo':f[1],'forgotten_diff_ci95_hi':f[2],
            'global_restart_better_cells':sum(x<0 for x in gd),
            'forgotten_restart_better_cells':sum(x<0 for x in fd),
            'both_restart_better_cells':sum((g0<0 and f0<0) for g0,f0 in zip(gd,fd))})

    # Exact-budget Boundary vs MatchedRandom structural ablation.
    afiles=sorted(Path(args.ablation_root).glob('*_schema_ablation.csv'))
    if len(afiles)!=36: raise RuntimeError(f'expected36 ablation CSVs found{len(afiles)}')
    ag=[]; af=[]
    for p in afiles:
        mm={r['method']:r for r in csv.DictReader(p.open())}
        b=mm['Restart+Boundary-L5']; r=mm['Restart+MatchedRandom-L5']
        ag.append(float(b['global_mrr_gap_to_exact'])-float(r['global_mrr_gap_to_exact']))
        af.append(float(b['forget_mrr_gap_to_exact'])-float(r['forget_mrr_gap_to_exact']))
    bg=boot_mean_ci(ag,5001); bf=boot_mean_ci(af,5002)
    ablation={'comparison':'Boundary - MatchedRandom','n':36,
        'global_gap_difference_mean':bg[0],'global_diff_ci95_lo':bg[1],'global_diff_ci95_hi':bg[2],
        'forgotten_gap_difference_mean':bf[0],'forgotten_diff_ci95_lo':bf[1],'forgotten_diff_ci95_hi':bf[2],
        'boundary_global_better_cells':sum(x<0 for x in ag),'boundary_forgotten_better_cells':sum(x<0 for x in af)}

    def write(name,rows):
        with (out/name).open('w',newline='',encoding='utf8') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0].keys()));w.writeheader();w.writerows(rows)
    write('matched_bootstrap_summary.csv',summaries)
    write('paired_method_differences.csv',diffs)
    write('boundary_vs_random_bootstrap.csv',[ablation])
    obj={'matched_cells':24,'bootstrap_resamples':20000,'summaries':summaries,'paired_differences':diffs,'boundary_vs_random':ablation}
    (out/'review_statistics.json').write_text(json.dumps(obj,indent=2)+'\n')
    md=['# Reviewer statistics','', 'Paired bootstrap uses 20,000 resamples of matched configuration cells. Negative paired differences favor SchemaCert+Restart-L5 or Boundary, respectively.','',
        '| Method | global gap mean [95% CI] | forgotten gap mean [95% CI] | runtime median [Q1,Q3] s |','|---|---:|---:|---:|']
    for x in summaries:
        md.append(f"| {x['method']} | {x['global_gap_mean']:.6f} [{x['global_gap_ci95_lo']:.6f},{x['global_gap_ci95_hi']:.6f}] | {x['forgotten_gap_mean']:.6f} [{x['forgotten_gap_ci95_lo']:.6f},{x['forgotten_gap_ci95_hi']:.6f}] | {x['runtime_median_sec']:.2f} [{x['runtime_q25_sec']:.2f},{x['runtime_q75_sec']:.2f}] |")
    md += ['', '| Paired difference | global mean diff [95% CI] | forgotten mean diff [95% CI] | both better |','|---|---:|---:|---:|']
    for x in diffs:
        md.append(f"| {x['comparison']} | {x['global_gap_difference_mean']:.6f} [{x['global_diff_ci95_lo']:.6f},{x['global_diff_ci95_hi']:.6f}] | {x['forgotten_gap_difference_mean']:.6f} [{x['forgotten_diff_ci95_lo']:.6f},{x['forgotten_diff_ci95_hi']:.6f}] | {x['both_restart_better_cells']}/24 |")
    md += ['', f"Boundary-MatchedRandom global diff: {ablation['global_gap_difference_mean']:.6g} [{ablation['global_diff_ci95_lo']:.6g},{ablation['global_diff_ci95_hi']:.6g}]",
           f"Boundary-MatchedRandom forgotten diff: {ablation['forgotten_gap_difference_mean']:.6g} [{ablation['forgotten_diff_ci95_lo']:.6g},{ablation['forgotten_diff_ci95_hi']:.6g}]"]
    (out/'REVIEW_STATISTICS.md').write_text('\n'.join(md)+'\n')
    print('REVIEW_STATISTICS_OK'); print('\n'.join(md))

if __name__=='__main__': main()
