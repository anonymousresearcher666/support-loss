#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

EXPECTED = {
    'RestartOnly',
    'Restart+Current-L5',
    'Restart+Boundary-L5',
    'Restart+MatchedRandom-L5',
}


def f(x):
    return float(x)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--expected-files', type=int, default=36)
    args = p.parse_args()

    root = Path(args.root)
    files = sorted(root.glob('*_schema_ablation.csv'))
    if len(files) != args.expected_files:
        raise RuntimeError(f'Expected {args.expected_files} schema-ablation CSVs, found {len(files)}')

    rows = []
    by_cfg = defaultdict(set)
    for path in files:
        with path.open(newline='') as h:
            rr = list(csv.DictReader(h))
        if len(rr) != 4:
            raise RuntimeError(f'{path}: expected 4 rows, found {len(rr)}')
        for r in rr:
            key = (r['dataset'], r['model'], r['seed'], r['fraction'], r['request_hash'])
            by_cfg[key].add(r['method'])
            rows.append(r)
    bad = {k: v for k, v in by_cfg.items() if v != EXPECTED}
    if bad:
        raise RuntimeError(f'Incomplete method sets in {len(bad)} configs; first={next(iter(bad.items()))}')
    if len(by_cfg) != 36:
        raise RuntimeError(f'Expected 36 unique configs, found {len(by_cfg)}')

    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0].keys())
    with (out / 'schema_ablation_combined.csv').open('w', newline='') as h:
        w = csv.DictWriter(h, fieldnames=fields); w.writeheader(); w.writerows(rows)

    groups = defaultdict(list)
    for r in rows:
        groups[(r['dataset'], r['model'], r['fraction'], r['method'])].append(r)
    agg = []
    for key, rr in sorted(groups.items()):
        d, m, frac, method = key
        agg.append({
            'dataset': d, 'model': m, 'fraction': frac, 'method': method,
            'n': len(rr),
            'global_gap_mean': sum(f(x['global_mrr_gap_to_exact']) for x in rr) / len(rr),
            'forget_gap_mean': sum(f(x['forget_mrr_gap_to_exact']) for x in rr) / len(rr),
            'parameter_fraction_mean': sum(f(x['parameter_fraction']) for x in rr) / len(rr),
            'work_unique_fraction_mean': sum(f(x['work_unique_fraction']) for x in rr) / len(rr),
            'train_sec_mean': sum(f(x['train_sec']) for x in rr) / len(rr),
        })
    af = list(agg[0].keys())
    with (out / 'schema_ablation_aggregate.csv').open('w', newline='') as h:
        w = csv.DictWriter(h, fieldnames=af); w.writeheader(); w.writerows(agg)

    # Direct matched-budget Boundary vs Random win counts at seed level.
    cfg_rows = defaultdict(dict)
    for r in rows:
        key = (r['dataset'], r['model'], r['seed'], r['fraction'], r['request_hash'])
        cfg_rows[key][r['method']] = r
    both = global_wins = forget_wins = 0
    for methods in cfg_rows.values():
        b = methods['Restart+Boundary-L5']; q = methods['Restart+MatchedRandom-L5']
        gw = f(b['global_mrr_gap_to_exact']) < f(q['global_mrr_gap_to_exact'])
        fw = f(b['forget_mrr_gap_to_exact']) < f(q['forget_mrr_gap_to_exact'])
        global_wins += int(gw); forget_wins += int(fw); both += int(gw and fw)
    summary = {
        'files': len(files), 'configs': len(cfg_rows), 'rows': len(rows),
        'methods': sorted(EXPECTED),
        'boundary_vs_matched_random_global_wins': global_wins,
        'boundary_vs_matched_random_forget_wins': forget_wins,
        'boundary_vs_matched_random_both_wins': both,
    }
    (out / 'schema_ablation_summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, sort_keys=True))


if __name__ == '__main__':
    main()
