#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,json
from pathlib import Path
import numpy as np

def ci(x,seed,b=10000):
    x=np.asarray(x,float);rng=np.random.default_rng(seed);z=np.array([rng.choice(x,len(x),replace=True).mean() for _ in range(b)])
    return float(x.mean()),float(np.quantile(z,.025)),float(np.quantile(z,.975))
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--out',required=True);args=ap.parse_args()
    files=sorted(Path(args.root).glob('*_sequential_2pct_x5.csv'))
    if len(files)!=6:raise RuntimeError(f'expected6 files found{len(files)}')
    rows=[]
    for p in files:rows+=list(csv.DictReader(p.open()))
    if len(rows)!=30:raise RuntimeError(f'expected30 rows found{len(rows)}')
    summary=[]
    for step in range(1,6):
        s=[r for r in rows if int(r['step'])==step]
        g=ci([float(r['global_gap_to_ref']) for r in s],700+step);f=ci([float(r['forget_gap_to_ref']) for r in s],800+step)
        summary.append({'step':step,'n':len(s),'mean_cumulative_fraction':float(np.mean([float(r['cumulative_fraction']) for r in s])),'global_gap_mean':g[0],'global_gap_ci95_lo':g[1],'global_gap_ci95_hi':g[2],'forget_gap_mean':f[0],'forget_gap_ci95_lo':f[1],'forget_gap_ci95_hi':f[2],'local_sec_median':float(np.median([float(r['local_sec']) for r in s]))})
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    with (out/'sequential_deletion_summary.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(summary[0].keys()));w.writeheader();w.writerows(summary)
    (out/'sequential_deletion_summary.json').write_text(json.dumps({'files':6,'rows':30,'summary':summary},indent=2)+'\n')
    md=['# Sequential deletion stress','', '| step | cumulative deletion | global gap [95% CI] | forgotten gap [95% CI] | median local s |','|---:|---:|---:|---:|---:|']
    for x in summary:md.append(f"| {x['step']} | {x['mean_cumulative_fraction']:.3f} | {x['global_gap_mean']:.6f} [{x['global_gap_ci95_lo']:.6f},{x['global_gap_ci95_hi']:.6f}] | {x['forget_gap_mean']:.6f} [{x['forget_gap_ci95_lo']:.6f},{x['forget_gap_ci95_hi']:.6f}] | {x['local_sec_median']:.3f} |")
    (out/'SEQUENTIAL_DELETION.md').write_text('\n'.join(md)+'\n');print('SEQUENTIAL_DELETION_COLLECT_OK');print('\n'.join(md))
if __name__=='__main__':main()
