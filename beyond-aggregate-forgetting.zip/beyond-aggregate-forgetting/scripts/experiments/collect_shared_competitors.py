#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

EXPECTED = [
    'ExactRetrain',
    'SchemaCert-L5',
    'SchemaCert+Restart-L5',
    'Finetune',
    'NG',
    'GraphDPO',
    'RL',
    'Fisher',
    'BS',
    'SSD',
    'SGU-Schema',
    'ZeroFisher',
]


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument('--root', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--require-datasets', nargs='*', default=['FB15K-237', 'WN18RR', 'CoDEx-L', 'YAGO3-10'])
    args = p.parse_args()

    root = Path(args.root)
    frames = []
    for f in sorted(root.glob('*_common_shared_base.csv')):
        stem = f.name.removesuffix('_common_shared_base.csv')
        marker = '_transe_entity_f'
        if marker not in stem or '_s' not in stem:
            continue
        dataset, rest = stem.split(marker, 1)
        frac_s, seed_s = rest.rsplit('_s', 1)
        df = pd.read_csv(f)
        df['dataset'] = dataset
        df['fraction'] = float(frac_s)
        df['seed'] = int(seed_s)
        df['file'] = f.name
        frames.append(df)

    if not frames:
        raise SystemExit(f'NO_COMMON_COMPETITOR_CSVS under {root}')
    x = pd.concat(frames, ignore_index=True)

    problems = []
    for dataset in args.require_datasets:
        for fraction in (0.1, 0.2):
            for seed in (17, 29, 43):
                q = x[(x.dataset == dataset) & (x.fraction == fraction) & (x.seed == seed)]
                got = set(q.method)
                missing = [m for m in EXPECTED if m not in got]
                if missing:
                    problems.append((dataset, fraction, seed, missing))
    if problems:
        for z in problems:
            print('MISSING', z)
        raise SystemExit(f'INCOMPLETE_CONFIGS={len(problems)}')

    metrics = [
        'global_mrr', 'forget_mrr',
        'global_mrr_gap_to_exact', 'forget_mrr_gap_to_exact',
        'train_sec',
    ]
    agg = (
        x.groupby(['dataset', 'fraction', 'method'], as_index=False)[metrics]
         .agg(['mean', 'std', 'count'])
    )
    agg.columns = ['_'.join(c).strip('_') for c in agg.columns.to_flat_index()]
    agg = agg.reset_index(drop=True)

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    raw_csv = out / 'shared_competitors_all_rows.csv'
    agg_csv = out / 'shared_competitors_three_seed_means.csv'
    x.sort_values(['dataset', 'fraction', 'seed', 'method']).to_csv(raw_csv, index=False)
    agg.to_csv(agg_csv, index=False)

    # Compact paper-oriented table, one row per dataset/fraction/method.
    view = agg[[
        'dataset', 'fraction', 'method',
        'global_mrr_gap_to_exact_mean',
        'forget_mrr_gap_to_exact_mean',
        'train_sec_mean',
        'global_mrr_gap_to_exact_std',
        'forget_mrr_gap_to_exact_std',
        'train_sec_std',
    ]].copy()
    view.to_csv(out / 'shared_competitors_paper_table.csv', index=False)

    print(f'ROWS={len(x)} CONFIG_MEANS={len(agg)}')
    print(f'RAW={raw_csv}')
    print(f'AGG={agg_csv}')
    print('\n=== PAPER TABLE ===')
    print(view.to_string(index=False))
    print('SHARED_COMPETITOR_COLLECT_OK')


if __name__ == '__main__':
    main()
