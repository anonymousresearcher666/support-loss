#!/usr/bin/env python3
"""Descriptive per-run comparisons; seeds, not queries, are replication units."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np


def collect(root, expected):
    manifests=sorted((root/'full').glob('*/*/*/seed*/COMPLETE.json'))
    if len(manifests)!=expected:
        raise ValueError(f'Expected {expected} complete runs, found {len(manifests)}; no partial paper table')
    rows=[]
    methods=['Unchanged','ResetOnly','Local','ResetLocal','FullRetain','ResetFullRetain','ResetDenseSameWork']
    for path in manifests:
        meta=json.loads(path.read_text());proto=meta['protocol']
        if proto['smoke']:raise ValueError('Smoke result in evidence directory')
        for ref in meta['reference_labels']:
            reference=np.load(path.parent/f'{ref}_predictions.npz')
            independent='Independent'+ref
            for method in methods+[independent]:
                candidate=np.load(path.parent/f'{method}_predictions.npz')
                for subset in ('forgotten','retained','test'):
                    for direction,k in [('head',0),('tail',1)]:
                        a=candidate[f'{subset}_ranks'][k];b=reference[f'{subset}_ranks'][k]
                        if a.shape!=b.shape or not np.isfinite(a).all() or not np.isfinite(b).all() or min(a.min(),b.min())<1:raise ValueError('Invalid ranks')
                        rows.append(dict(dataset=meta['dataset'],model=proto['model'],negative=proto['negative_rule'].split()[0],seed=meta['seed'],reference=ref,method=method,subset=subset,direction=direction,n_queries=len(a),candidate_mrr=float(np.mean(1/a)),reference_mrr=float(np.mean(1/b)),absolute_mrr_gap=float(abs(np.mean(1/a)-np.mean(1/b))),mean_absolute_logrank_gap=float(np.mean(abs(np.log(a)-np.log(b)))),median_candidate_rank=float(np.median(a)),median_reference_rank=float(np.median(b)),top1_disagreement=float(np.mean(candidate[f'{subset}_top1'][k]!=reference[f'{subset}_top1'][k])),hits10_status_disagreement=float(np.mean((a<=10)!=(b<=10))),candidate_hits10=float(np.mean(a<=10)),reference_hits10=float(np.mean(b<=10))))
    out=root/'cross_family_per_seed.csv'
    with out.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    (root/'ANALYSIS_SCOPE.txt').write_text('Each row is a seed-level descriptive comparison on paired fixed queries. IndependentReference is a retraining variability control. Query observations, head/tail directions, methods, and reference budgets are not independent replications. Top-1 and Hits@10 disagreement measure functional output differences, not privacy leakage or membership inference. Review base/retained/test utility before interpreting a family. Do not select families by favorable outcomes.\n')
    print(f'{len(manifests)} runs, {len(rows)} rows -> {out}')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--expected',type=int,default=72)
    a=p.parse_args();collect(a.root,a.expected)
