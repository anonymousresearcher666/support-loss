#!/usr/bin/env python3
"""Fail closed on missing runs; retain requests and seeds as units of analysis."""
import argparse,csv,hashlib,json
from pathlib import Path
import numpy as np
from dispatch_supportloss_request_validation import tasks

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);a=p.parse_args();rows=[];requests={};checks=0
 for dataset,model,stratum,request,seed in tasks():
  folder=a.root/stratum/f'request{request}'/'full'/'balanced'/dataset/model/f'seed{seed}'
  manifest=json.loads((folder/'COMPLETE.json').read_text());protocol=manifest['protocol']
  selection=a.root/'selection'/dataset/model/'SELECTED.json';sel=json.loads(selection.read_text())
  assert protocol['selection_sha256']==hashlib.sha256(selection.read_bytes()).hexdigest()
  assert manifest['file_hashes']==sel['files']
  assert (manifest['dataset'],protocol['model'],protocol['degree_stratum'],protocol['request_index'],manifest['seed'])==(dataset,model,stratum,request,seed)
  assert not protocol['smoke'] and protocol['base_epochs']==20 and protocol['reference_epochs']==[20,50,100]
  identity=(protocol['selected_entity'],manifest['forget_hash'])
  key=(dataset,stratum,request)
  if key in requests:assert requests[key]==identity
  requests[key]=identity
  raw=json.loads((folder/'raw.json').read_text())
  expected={'Base20','Unchanged','ResetOnly','Local','ResetLocal','FullRetain','ResetFullRetain','ResetDenseSameWork'}|{prefix+str(e) for prefix in ['Reference','IndependentReference'] for e in [20,50,100]}
  assert len(raw)==len(expected) and {x['label'] for x in raw}==expected
  with np.load(folder/'queries.npz',allow_pickle=False) as q:
   queries={k:q[k] for k in ['test','forgotten','retained','validation']}
   assert len(q['selected_entities'])==1 and q['selected_entities'][0]==identity[0]
   assert len(q['forget_indices'])==manifest['forgotten_triples']
  for item in raw:
   with np.load(folder/(item['label']+'_predictions.npz'),allow_pickle=False) as pred:
    for split,query in queries.items():
     ranks=pred[split+'_ranks'];assert ranks.shape==(2,len(query))
     assert np.isfinite(ranks).all() and (ranks>=1).all() and (ranks<=manifest['entities']).all()
     for name,value in [('mrr',np.mean(1/ranks)),('hits10',np.mean(ranks<=10))]:
      assert abs(float(value)-item[f'{split}_{name}'])<1e-12;checks+=1
  with np.load(folder/'ResetLocal_predictions.npz') as c,np.load(folder/'Reference100_predictions.npz') as r,np.load(folder/'IndependentReference100_predictions.npz') as n:
   for split,query in queries.items():
    cr,rr,nr=[x[split+'_ranks'] for x in [c,r,n]]
    row=dict(dataset=dataset,model=model,stratum=stratum,request=request,seed=seed,entity=identity[0],incident_degree=protocol['original_incident_degree'],split=split,n_queries=len(query),selected_lr=sel['selected_lr'],candidate_logrank_gap=float(abs(np.log10(cr)-np.log10(rr)).mean()),null_logrank_gap=float(abs(np.log10(nr)-np.log10(rr)).mean()))
    for k in [1,10,100,1000]:row[f'excess_hits{k}_disagreement_pp']=float(100*(np.mean((cr<=k)!=(rr<=k))-np.mean((nr<=k)!=(rr<=k))))
    rows.append(row)
 for dataset in ['FB15K-237','CoDEx-M']:
  ids=[value[0] for key,value in requests.items() if key[0]==dataset]
  assert len(ids)==9 and len(set(ids))==9
 target=a.root/'request_validation_per_seed.csv'
 with target.open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 (a.root/'REQUEST_AUDIT.json').write_text(json.dumps(dict(completed_runs=108,requests_per_graph=9,scalar_checks=checks,rows=len(rows),interpretation='Requests are nested within graph/degree stratum; training seeds repeat each request. Queries and directions are not independent replicates. No tuned-SOTA or convergence claim.'),indent=2)+'\n')
 print(target)
if __name__=='__main__':main()
