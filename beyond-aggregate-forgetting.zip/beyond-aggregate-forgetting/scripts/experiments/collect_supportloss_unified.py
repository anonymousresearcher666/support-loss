#!/usr/bin/env python3
"""Require all 36 fresh runs, recompute MRR, and emit replacement table data.
Never silently mix these results with pre-existing paper measurements.
"""
import argparse,csv,json
from pathlib import Path
import numpy as np
from scripts.experiments.run_supportloss_unified import TASKS, PROTOCOL


def collect(root):
    rows=[];checks=0;source=None;data_hashes={}
    for i,(dataset,policy,fraction,seed) in enumerate(TASKS):
        folder=root/f'task{i:02d}';m=json.loads((folder/'COMPLETE.json').read_text())
        if m['smoke'] or m['protocol']!=PROTOCOL or m['input_checkpoints']:
            raise ValueError('Not a fresh production run')
        if (m['dataset'],m['policy'],m['fraction'],m['seed'],m['task'])!=(dataset,policy,fraction,seed,i):
            raise ValueError('Task mismatch')
        versions=(m['source_sha256'],m['core_sha256'],m['torch'],m['numpy'])
        if source is not None and versions!=source:raise ValueError('Mixed code or runtime versions')
        source=versions
        if dataset in data_hashes and data_hashes[dataset]!=m['files']:raise ValueError('Dataset changed between runs')
        data_hashes[dataset]=m['files']
        raw=json.loads((folder/'raw.json').read_text());by_label={r['label']:r for r in raw}
        expected={'Unchanged','ResetOnly','Local','Reference20','IndependentReference20'}
        expected|={'ResetLocal'} if policy=='entity' else {'EndpointResetOnly','StarCoverResetOnly','EndpointE3','StarCoverE3'}
        if len(raw)!=len(expected) or set(by_label)!=expected:raise ValueError('Missing or repeated methods')
        with np.load(folder/'queries.npz',allow_pickle=False) as q:
            for label,r in by_label.items():
                with np.load(folder/f'{label}_predictions.npz',allow_pickle=False) as pred:
                    for split in ('test','forgotten','retained'):
                        ranks=pred[split+'_ranks']
                        if ranks.shape!=(2,len(q[split])) or not np.isfinite(ranks).all() or (ranks<1).any() or (ranks>len(q['candidates'])).any():raise ValueError('Invalid ranks')
                        if abs(float(np.mean(1/ranks))-r[split+'_mrr'])>1e-12:raise ValueError('MRR mismatch')
                        checks+=1
        for label,r in by_label.items():
            row=dict(dataset=dataset,policy=policy,fraction=fraction,seed=seed,actual_fraction=m['actual_fraction'],**r)
            for split in ('test','forgotten','retained'):
                row[split+'_gap']=abs(r[split+'_mrr']-by_label['Reference20'][split+'_mrr'])
            rows.append(row)
    with (root/'unified_per_seed.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    groups={}
    for r in rows:groups.setdefault((r['dataset'],r['policy'],r['fraction'],r['label']),[]).append(r)
    summary=[]
    for key,group in groups.items():
        if len(group)!=3:raise ValueError('Missing seeds')
        row=dict(zip(('dataset','policy','fraction','label'),key))
        for metric in ('test_mrr','forgotten_mrr','retained_mrr','test_gap','forgotten_gap','update_seconds'):
            values=[r[metric] for r in group];row[metric+'_mean']=float(np.mean(values));row[metric+'_seed_sd']=float(np.std(values,ddof=1))
        summary.append(row)
    with (root/'unified_summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
    (root/'UNIFIED_AUDIT.json').write_text(json.dumps(dict(completed_runs=36,checks=checks,
        imported_checkpoints=0,source=source,protocol=PROTOCOL,
        status='Ready for author review and replacement of Figure 1 and Tables 1/3; do not combine with previous aggregates.'),indent=2)+'\n')
    print('UNIFIED_AUDIT_COMPLETE',checks)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);a=p.parse_args();collect(a.root)
