#!/usr/bin/env python3
"""Post-hoc output distinguisher, not a certified privacy test.

Train/test are disjoint in BOTH query IDs and model seed. No model selection
uses this diagnostic. All thresholds, features and folds are fixed in code;
we report all methods and both datasets, never an attack's best test orientation.
"""
from __future__ import annotations
import argparse,csv,json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
from scipy.special import expit
from scipy.stats import rankdata
from scripts.experiments.collect_reference_budget_pilot import DATASETS,SEEDS,METHODS,BUDGETS


def features(p):
    scores=p['forgotten_scores'].mean(axis=0)
    ranks=np.log(p['forgotten_ranks']).T
    return np.column_stack([scores,ranks])


def roc_auc(labels,scores):
    labels=np.asarray(labels);scores=np.asarray(scores)
    if len(labels)!=len(scores) or not np.isfinite(scores).all():raise ValueError('Invalid scores')
    pos=labels==1;np_,nn=pos.sum(),(~pos).sum()
    if np_==0 or nn==0:raise ValueError('Both classes required')
    ranks=rankdata(scores,method='average')
    return float((ranks[pos].sum()-np_*(np_+1)/2)/(np_*nn))


def fit_attack(X,y):
    mu=X.mean(0);sd=X.std(0);sd[sd<1e-12]=1.
    Z=np.c_[(X-mu)/sd,np.ones(len(X))]
    def objective(w):
        z=Z@w
        loss=np.logaddexp(0,-(2*y-1)*z).mean()+.5*np.dot(w[:-1],w[:-1])/len(y)
        grad=Z.T@(expit(z)-y)/len(y);grad[:-1]+=w[:-1]/len(y)
        return loss,grad
    opt=minimize(objective,np.zeros(Z.shape[1]),jac=True,method='L-BFGS-B',options={'maxiter':1000,'gtol':1e-8,'ftol':1e-12,'maxls':50})
    residual=float(np.abs(objective(opt.x)[1]).max())
    if not opt.success and residual>1e-6:
        raise RuntimeError('Attack optimizer failed: '+str(opt.message))
    def classifier(x):return np.c_[(x-mu)/sd,np.ones(len(x))]@opt.x
    classifier.gradient_inf=residual
    classifier.solver_success=bool(opt.success)
    return classifier


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,required=True);a=ap.parse_args();root=a.results
    for ds in DATASETS:
        for seed in SEEDS:
            if not (root/ds/f'seed{seed}'/'COMPLETE.json').exists():raise RuntimeError('Incomplete source cohort')
    rows=[]
    for ds in DATASETS:
        p={}
        for seed in SEEDS:
            for method in METHODS+tuple(f'Reference{k}' for k in BUDGETS):
                p[seed,method]=features(np.load(root/ds/f'seed{seed}'/f'{method}_predictions.npz'))
        n=len(p[17,'Unchanged']);order=np.random.default_rng(271828).permutation(n)
        train_q,test_q=order[:n//2],order[n//2:]
        assert not set(train_q)&set(test_q)
        for budget in BUDGETS:
            ref=f'Reference{budget}'
            # Reference20-vs-longer-reference is a training-budget shift control.
            methods=METHODS+(('Reference20',) if budget!=20 else ())
            for method in methods:
                for heldout in SEEDS:
                    train_s=[s for s in SEEDS if s!=heldout]
                    X=np.concatenate([p[s,m][train_q] for s in train_s for m in [method,ref]])
                    y=np.tile(np.r_[np.ones(len(train_q)),np.zeros(len(train_q))],len(train_s))
                    classifier=fit_attack(X,y)
                    Xt=np.r_[p[heldout,method][test_q],p[heldout,ref][test_q]]
                    yt=np.r_[np.ones(len(test_q)),np.zeros(len(test_q))]
                    z=classifier(Xt)
                    rows.append({'dataset':ds,'method':method,'reference_budget':budget,'heldout_seed':heldout,
                        'train_query_count':len(train_q),'test_query_count':len(test_q),
                        'train_model_seeds':';'.join(map(str,train_s)),'roc_auc':roc_auc(yt,z),
                        'attack_gradient_inf':classifier.gradient_inf,'solver_success':classifier.solver_success,
                        'balanced_accuracy_at_zero_logit':float(np.mean((z>=0)==yt))})
    keys=list(rows[0])
    with (root/'output_distinguisher.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
    summary=[]
    for ds in DATASETS:
        for b in BUDGETS:
            for method in sorted({r['method'] for r in rows if r['dataset']==ds and r['reference_budget']==b}):
                rr=[r['roc_auc'] for r in rows if r['dataset']==ds and r['reference_budget']==b and r['method']==method]
                summary.append({'dataset':ds,'reference_budget':b,'method':method,'mean_auc':float(np.mean(rr)),
                                'min_auc':min(rr),'max_auc':max(rr),'folds':len(rr)})
    obj={'scope':'Post-hoc query-output removal distinguisher, not a membership or certified privacy guarantee',
       'features':['mean true score','log head rank','log tail rank'],'training':'standardized L2 logistic regression',
       'split':'disjoint query halves and leave-one-model-seed-out','query_split_seed':271828,
       'report_orientation':'AUC uses fitted logits as-is; no test-label orientation flipping',
       'limitations':'Two graphs, three seeds; correlated examples; no population confidence or attack completeness',
       'fold_count':len(rows),'summary':summary}
    (root/'output_distinguisher_summary.json').write_text(json.dumps(obj,indent=2)+'\n')
    print(json.dumps(obj,indent=2))
if __name__=='__main__':main()
