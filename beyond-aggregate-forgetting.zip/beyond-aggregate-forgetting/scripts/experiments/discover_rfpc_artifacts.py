#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, re
from pathlib import Path

NAME_RE=re.compile(r"(rfpc|w8|placement.*correct|correct.*placement)",re.I)
TEXT_RE=re.compile(
    r"Reference-Free Placement Correction|RFPC|0\.108719|0\.103599|"
    r"57\.55|59\.55|delta_v|w8_offsets|placement_did",
    re.I,
)
TEXT_EXT={".py",".json",".csv",".md",".txt",".yaml",".yml",".sh",".sbatch",".tex"}
MAX_BYTES=8_000_000

def sha256(p:Path)->str:
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",action="append",type=Path,required=True)
    ap.add_argument("--out",type=Path)
    args=ap.parse_args()
    hits=[]
    seen=set()
    for root in args.root:
        root=root.expanduser().resolve()
        if not root.exists():
            continue
        for p in root.rglob("*"):
            if not p.is_file():
                continue
            try:
                rel=str(p)
                name_hit=bool(NAME_RE.search(p.name))
                text_hit=False
                excerpts=[]
                if p.suffix.lower() in TEXT_EXT and p.stat().st_size<=MAX_BYTES:
                    try:
                        txt=p.read_text(errors="ignore")
                    except Exception:
                        txt=""
                    if txt:
                        for m in list(TEXT_RE.finditer(txt))[:8]:
                            text_hit=True
                            st=max(0,m.start()-120); en=min(len(txt),m.end()+220)
                            excerpts.append(txt[st:en].replace("\n"," "))
                if name_hit or text_hit:
                    key=str(p.resolve())
                    if key in seen: continue
                    seen.add(key)
                    rec={
                        "path":key,
                        "size":p.stat().st_size,
                        "sha256":sha256(p),
                        "name_hit":name_hit,
                        "text_hit":text_hit,
                        "excerpts":excerpts,
                    }
                    hits.append(rec)
            except (OSError,PermissionError):
                pass
    hits.sort(key=lambda x:(not x["name_hit"],not x["text_hit"],x["path"]))
    out={"roots":[str(r) for r in args.root],"hits":hits}
    print(json.dumps(out,indent=2))
    if args.out:
        args.out.parent.mkdir(parents=True,exist_ok=True)
        args.out.write_text(json.dumps(out,indent=2)+"\n")
    print(f"RFPC_DISCOVERY_OK hits={len(hits)}")

if __name__=="__main__":
    main()
