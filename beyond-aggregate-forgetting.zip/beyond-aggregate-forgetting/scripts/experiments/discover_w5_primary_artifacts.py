#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
from pathlib import Path

KEY_PATTERNS = (
    re.compile(r"RefA", re.I),
    re.compile(r"RefB", re.I),
    re.compile(r"independent", re.I),
    re.compile(r"mean_abs_log10_rank_gap", re.I),
    re.compile(r"logrank", re.I),
    re.compile(r"R\+L|Restart\+Local|restart.?local", re.I),
    re.compile(r"request_hash", re.I),
)
CKPT_RE = re.compile(r'([^\\s"\']+\\.(?:tar|pt|pth|ckpt))', re.I)


def score_text(text: str) -> tuple[int,list[str]]:
    hits=[]
    for p in KEY_PATTERNS:
        if p.search(text):
            hits.append(p.pattern)
    return len(hits), hits


def safe_read(path: Path, max_bytes: int) -> str:
    try:
        if path.stat().st_size > max_bytes:
            return ""
        return path.read_text(encoding="utf8", errors="ignore")
    except Exception:
        return ""


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root", action="append", default=[])
    ap.add_argument("--max-bytes", type=int, default=5_000_000)
    ap.add_argument("--out", type=Path, required=True)
    args=ap.parse_args()

    roots=[Path(x) for x in args.root if Path(x).exists()]
    args.out.mkdir(parents=True, exist_ok=True)

    evidence=[]
    ckpts=set()
    csvs=[]
    path_terms=("rank","null","retrain","reference","refa","refb","entity_request",
                "multi_delete","multidelete","restart","local","unlearn","review",
                "mechanism","experiments")
    skip_dirs={".git","__pycache__",".venv","venv","deps","node_modules"}

    for root in roots:
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in skip_dirs]
            dp=Path(dirpath)
            dpl=str(dp).lower()

            # In very broad roots, skip branches that have no experiment clue
            # once we are sufficiently deep below the root.
            try:
                depth=len(dp.relative_to(root).parts)
            except Exception:
                depth=0
            if depth >= 3 and not any(t in dpl for t in path_terms):
                dirnames[:] = []
                continue

            for name in filenames:
                p=dp/name
                low=name.lower()
                pl=str(p).lower()
                relevant_name=any(t in low or t in pl for t in path_terms)

                if p.suffix.lower() in {".json",".md",".txt",".csv",".out"}:
                    if not relevant_name and p.suffix.lower() != ".csv":
                        continue
                    text=safe_read(p,args.max_bytes)
                    if not text:
                        continue
                    s,h=score_text(text)
                    if s >= 2:
                        found=sorted(set(m.group(1) for m in CKPT_RE.finditer(text)))
                        for x in found:
                            xp=Path(x)
                            if not xp.is_absolute():
                                xp=(p.parent/xp).resolve()
                            ckpts.add(str(xp))
                        evidence.append({
                            "path":str(p),
                            "score":s,
                            "hits":h,
                            "checkpoint_strings":found[:30],
                        })
                    if p.suffix.lower()==".csv":
                        head=text.splitlines()[:2]
                        hdr=head[0].lower() if head else ""
                        if "rank" in hdr or "request_hash" in hdr or "logrank" in hdr:
                            csvs.append({"path":str(p),"header":head[0] if head else ""})

                elif p.suffix.lower() in {".tar",".pt",".pth",".ckpt"} and relevant_name:
                    ckpts.add(str(p))

    # Prioritize files mentioning both independent reference semantics and R+L.
    evidence.sort(key=lambda x:(-x["score"],x["path"]))
    existing_ckpts=[]
    missing_ckpts=[]
    for x in sorted(ckpts):
        (existing_ckpts if Path(x).exists() else missing_ckpts).append(x)

    payload={
        "roots":[str(x) for x in roots],
        "evidence_files":evidence[:500],
        "rankish_csvs":csvs[:1000],
        "existing_checkpoint_candidates":existing_ckpts[:2000],
        "missing_checkpoint_strings":missing_ckpts[:500],
    }
    (args.out/"W5_PRIMARY_ARTIFACT_DISCOVERY.json").write_text(json.dumps(payload,indent=2)+"\n")

    print("=== W5 PRIMARY ARTIFACT DISCOVERY ===")
    print(f"evidence_files={len(evidence)}")
    print(f"rankish_csvs={len(csvs)}")
    print(f"existing_checkpoint_candidates={len(existing_ckpts)}")
    print("=== TOP EVIDENCE ===")
    for x in evidence[:40]:
        print(json.dumps(x,sort_keys=True))
    print("=== EXISTING CHECKPOINT CANDIDATES ===")
    for x in existing_ckpts[:120]:
        print(x)
    print("W5_PRIMARY_ARTIFACT_DISCOVERY_OK")


if __name__=="__main__":
    main()
