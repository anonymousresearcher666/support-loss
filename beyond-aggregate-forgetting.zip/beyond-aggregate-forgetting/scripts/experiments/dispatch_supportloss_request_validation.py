#!/usr/bin/env python3
"""Deterministic SLURM array mapping; never submits jobs itself."""
import itertools,json,os,subprocess,sys
from pathlib import Path
MODELS=['distmult','complex']; DATASETS=['FB15K-237','CoDEx-M']; STRATA=['low','middle','high']; SEEDS=[17,29,43]
def tasks():return list(itertools.product(DATASETS,MODELS,STRATA,range(3),SEEDS))
def main():
 stage=os.environ['CAMPAIGN_STAGE']; i=int(os.environ['SLURM_ARRAY_TASK_ID']);out=Path(os.environ['CAMPAIGN_OUT']);data=os.environ['DATA_ROOT']
 scripts=Path(__file__).parent
 def run(script,args):subprocess.run([sys.executable,'-u',str(scripts/script),*map(str,args)],check=True)
 if stage=='tune':
  dataset,model=list(itertools.product(DATASETS,MODELS))[i]
  run('select_supportloss_learning_rate.py',['--data-root',data,'--dataset',dataset,'--model',model,'--out',out/'selection'])
 elif stage=='smoke':
  model,stratum=list(itertools.product(MODELS,STRATA))[i];dataset=DATASETS[0]
  selection=out/f'smoke_selection_{i}.json'
  selection.write_text(json.dumps(dict(dataset=dataset,model=model,selected_lr=.002,negative='balanced',epochs=20)))
  for request in range(3):run('run_supportloss_request_validation.py',['--smoke','--data-root',data,'--out',out,'--dataset',dataset,'--model',model,'--seed',17,'--negative','balanced','--selection',selection,'--request-stratum',stratum,'--request-index',request,'--device',os.environ.get('SMOKE_DEVICE','cuda:0')])
 elif stage=='full':
  dataset,model,stratum,request,seed=tasks()[i]
  run('run_supportloss_request_validation.py',['--data-root',data,'--out',out,'--dataset',dataset,'--model',model,'--seed',seed,'--negative','balanced','--selection',out/'selection'/dataset/model/'SELECTED.json','--request-stratum',stratum,'--request-index',request,'--device','cuda:0'])
 else:raise ValueError(stage)
if __name__=='__main__':main()
