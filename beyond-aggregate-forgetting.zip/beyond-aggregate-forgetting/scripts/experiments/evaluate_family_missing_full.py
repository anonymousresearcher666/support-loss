#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.train import clone_model, train_model
from schemacert.unlearn import local_retrain
from scripts.run_publication_families import filtered_lp, fresh, select_forget


def request_hash(forget: np.ndarray) -> str:
    x = np.ascontiguousarray(forget, dtype=np.int64)
    return hashlib.sha256(x.tobytes()).hexdigest()[:16]


def retained_positive_degrees(retain: np.ndarray, entity_ids: np.ndarray) -> dict[int, int]:
    return {
        int(e): int(((retain[:, 0] == int(e)) | (retain[:, 2] == int(e))).sum())
        for e in entity_ids
    }


def deterministic_family_restart(model, retain, selected_entities, seed):
    if model.__class__.__name__.lower() not in {'distmult', 'complex'}:
        raise NotImplementedError('This evaluator is intentionally DistMult/ComplEx only.')
    deg = retained_positive_degrees(retain, selected_entities)
    unsupported = np.asarray(
        [int(e) for e in selected_entities if deg[int(e)] == 0], dtype=np.int64
    )
    out = clone_model(model)
    st = time.time()
    if len(unsupported):
        g = torch.Generator(device='cpu')
        g.manual_seed(int(seed))
        fresh_table = torch.empty(
            tuple(out.entity.weight.shape), dtype=out.entity.weight.dtype, device='cpu'
        )
        nn.init.xavier_uniform_(fresh_table, generator=g)
        idx_cpu = torch.as_tensor(unsupported, dtype=torch.long)
        idx_dev = idx_cpu.to(out.entity.weight.device)
        with torch.no_grad():
            out.entity.weight[idx_dev] = fresh_table[idx_cpu].to(out.entity.weight.device)
            out.normalize_()
        if out.entity.weight.is_cuda:
            torch.cuda.synchronize()
    return out, time.time() - st, unsupported, deg


def metric_row(method, source, global_m, forget_m, train_sec, ref_global, ref_forget, extra=None):
    row = {
        'method': method,
        'source': source,
        'global_mrr': global_m['mrr'],
        'global_h1': global_m['h1'],
        'global_h3': global_m['h3'],
        'global_h10': global_m['h10'],
        'forget_mrr': forget_m['mrr'],
        'forget_h1': forget_m['h1'],
        'forget_h3': forget_m['h3'],
        'forget_h10': forget_m['h10'],
        'global_mrr_gap_to_exact': abs(global_m['mrr'] - ref_global),
        'forget_mrr_gap_to_exact': abs(forget_m['mrr'] - ref_forget),
        'train_sec': float(train_sec),
    }
    if extra:
        row.update(extra)
    return row


def evaluate(model, data, retain, forget, ne, args):
    truth = (retain, data.valid, data.test)
    forget_truth = (retain, data.valid, data.test, forget)
    global_m = filtered_lp(
        model, data.test, ne, truth, args.device,
        args.eval_batch, args.entity_chunk, args.eval_queries, args.seed,
    )
    forget_m = filtered_lp(
        model, forget, ne, forget_truth, args.device,
        args.eval_batch, args.entity_chunk, args.forget_eval_queries, args.seed,
    )
    return global_m, forget_m


def main():
    p = argparse.ArgumentParser(
        description='Complete missing DistMult/ComplEx entity-deletion configurations with exact retrain, bare SchemaCert, Restart-Before, and full finetune.'
    )
    p.add_argument('--dataset', required=True, choices=['WN18RR', 'CoDEx-L', 'YAGO3-10'])
    p.add_argument('--model', required=True, choices=['distmult', 'complex'])
    p.add_argument('--seed', required=True, type=int)
    p.add_argument('--fractions', nargs='+', type=float, default=[0.10, 0.20])
    p.add_argument('--data-root', default='data')
    p.add_argument('--out', required=True)
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--threads', type=int, default=1)
    p.add_argument('--dim', type=int, default=128)
    p.add_argument('--epochs', type=int, default=20)
    p.add_argument('--ref-epochs', type=int, default=20)
    p.add_argument('--local-epochs', type=int, default=5)
    p.add_argument('--batch-size', type=int, default=4096)
    p.add_argument('--lr', type=float, default=0.002)
    p.add_argument('--local-lr', type=float, default=0.001)
    p.add_argument('--l2', type=float, default=1e-6)
    p.add_argument('--hops', type=int, default=1)
    p.add_argument('--eval-batch', type=int, default=16)
    p.add_argument('--entity-chunk', type=int, default=4096)
    p.add_argument('--eval-queries', type=int, default=1000)
    p.add_argument('--forget-eval-queries', type=int, default=1000)
    args = p.parse_args()

    torch.set_num_threads(max(1, args.threads))
    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    ne, nr = len(data.entities), len(data.relations)

    # One deterministic base per dataset/model/seed, shared by both deletion fractions.
    base = fresh(args.model, ne, nr, args.dim, args.seed, args.device)
    base_stats = train_model(
        base, data.train, ne, args.epochs, args.batch_size, args.lr, args.l2,
        args.seed, args.device,
    )
    base_global = filtered_lp(
        base, data.test, ne, (data.train, data.valid, data.test), args.device,
        args.eval_batch, args.entity_chunk, args.eval_queries, args.seed,
    )

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    records = []

    for frac in args.fractions:
        fi, meta = select_forget(
            data.train, frac, args.seed + int(frac * 10000), policy='entity'
        )
        forget = data.train[fi]
        keep = np.ones(len(data.train), dtype=bool)
        keep[fi] = False
        retain = data.train[keep]
        selected = np.asarray(meta.get('entities', []), dtype=np.int64)
        if len(selected) == 0:
            raise RuntimeError('Entity policy returned no selected entities.')

        # Gold reference: fresh retrain on retained data, same model family and training recipe.
        exact = fresh(args.model, ne, nr, args.dim, args.seed, args.device)
        exact_stats = train_model(
            exact, retain, ne, args.ref_epochs, args.batch_size, args.lr, args.l2,
            args.seed, args.device,
        )
        exact_global, exact_forget = evaluate(exact, data, retain, forget, ne, args)
        ref_global = exact_global['mrr']
        ref_forget = exact_forget['mrr']

        # Bare SchemaCert local update from the shared base.
        local, _, _ = local_retrain(
            base, data.train, fi, ne, args.hops, args.local_epochs,
            args.batch_size, args.local_lr, args.l2, args.seed, args.device,
        )
        local_global, local_forget = evaluate(local.model, data, retain, forget, ne, args)

        # Primary support-aware variant: deterministic restart BEFORE local update.
        restart_seed = (
            int(args.seed) * 1000003
            + int(round(frac * 1000000))
            + 17027
        ) & 0x7FFFFFFF
        restarted_base, restart_sec, unsupported, deg = deterministic_family_restart(
            base, retain, selected, restart_seed
        )
        restart_local, _, _ = local_retrain(
            restarted_base, data.train, fi, ne, args.hops, args.local_epochs,
            args.batch_size, args.local_lr, args.l2, args.seed, args.device,
        )
        restart_global, restart_forget = evaluate(
            restart_local.model, data, retain, forget, ne, args
        )

        # Full finetune baseline follows the historical family protocol.
        ft = clone_model(base)
        ft_stats = train_model(
            ft, retain, ne, args.local_epochs, args.batch_size, args.local_lr,
            args.l2, args.seed + 31, args.device,
        )
        ft_global, ft_forget = evaluate(ft, data, retain, forget, ne, args)

        common_extra = {
            'dataset': args.dataset,
            'model': args.model,
            'policy': 'entity',
            'seed': args.seed,
            'fraction': frac,
            'forget_n': len(forget),
            'request_hash': request_hash(forget),
            'request_meta': json.dumps(meta, separators=(',', ':')),
            'base_mrr': base_global['mrr'],
            'base_train_sec': base_stats.seconds,
            'selected_entities': len(selected),
            'unsupported_selected_count': int(len(unsupported)),
            'unsupported_selected_entities': json.dumps(unsupported.tolist()),
        }

        rows = [
            metric_row(
                'ExactRetrain', 'fresh retained-data retrain', exact_global, exact_forget,
                exact_stats.seconds, ref_global, ref_forget, common_extra,
            ),
            metric_row(
                f'SchemaCert-L{args.local_epochs}', 'bare SchemaCert local update',
                local_global, local_forget, local.seconds, ref_global, ref_forget,
                {**common_extra,
                 'parameter_fraction': local.parameter_fraction,
                 'local_triples': local.local_triples,
                 'work_unique_triples': local.work_unique_triples},
            ),
            metric_row(
                f'SchemaCert+Restart-L{args.local_epochs}',
                'support-aware deterministic restart BEFORE SchemaCert local update',
                restart_global, restart_forget, restart_sec + restart_local.seconds,
                ref_global, ref_forget,
                {**common_extra,
                 'restart_sec': restart_sec,
                 'parameter_fraction': restart_local.parameter_fraction,
                 'local_triples': restart_local.local_triples,
                 'work_unique_triples': restart_local.work_unique_triples,
                 'selected_entity_retained_positive_degree': json.dumps(deg, sort_keys=True)},
            ),
            metric_row(
                'FullFinetune', 'full retained-data finetune from shared base',
                ft_global, ft_forget, ft_stats.seconds, ref_global, ref_forget, common_extra,
            ),
        ]
        records.extend(rows)

        print(
            f'FAMILY_MISSING dataset={args.dataset} model={args.model} seed={args.seed} '
            f'fraction={frac:g} forget_n={len(forget)} unsupported={len(unsupported)}/{len(selected)} '
            f'request={request_hash(forget)}'
        )
        print('method\tglobal_mrr\tforget_mrr\tglobal_gap_exact\tforget_gap_exact\ttrain_sec')
        for r in rows:
            print(
                f"{r['method']}\t{r['global_mrr']:.6f}\t{r['forget_mrr']:.6f}\t"
                f"{r['global_mrr_gap_to_exact']:.6f}\t{r['forget_mrr_gap_to_exact']:.6f}\t"
                f"{r['train_sec']:.3f}"
            )

        del exact, local, restarted_base, restart_local, ft
        if args.device.startswith('cuda'):
            torch.cuda.empty_cache()

    stem = f'{args.dataset}_{args.model}_entity_s{args.seed}_missing_full'
    csv_path = out / f'{stem}.csv'
    json_path = out / f'{stem}.json'

    # Rows intentionally carry method-specific diagnostics. Build the CSV
    # schema from the union of keys across all rows rather than from the first
    # ExactRetrain row, otherwise DictWriter raises on later SchemaCert fields.
    fieldnames = list(dict.fromkeys(key for row in records for key in row.keys()))
    with csv_path.open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(records)
    json_path.write_text(json.dumps(records, indent=2))

    print(f'FAMILY_MISSING_CSV={csv_path}')
    print(f'FAMILY_MISSING_JSON={json_path}')
    print('FAMILY_MISSING_FULL_OK')


if __name__ == '__main__':
    main()
