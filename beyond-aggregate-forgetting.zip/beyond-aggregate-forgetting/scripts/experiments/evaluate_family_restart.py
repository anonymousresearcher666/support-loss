#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.train import clone_model, train_model
from schemacert.unlearn import local_retrain
from scripts.run_publication_families import filtered_lp, fresh, select_forget


def _float(row, key):
    x = row.get(key, '')
    if x in ('', None, 'nan', 'NaN'):
        return None
    return float(x)


def _request_hash(forget: np.ndarray) -> str:
    x = np.ascontiguousarray(forget, dtype=np.int64)
    return hashlib.sha256(x.tobytes()).hexdigest()[:16]


def _canonical_row(path: Path, dataset: str, model: str, seed: int, fraction: float):
    with path.open(newline='') as f:
        rows = list(csv.DictReader(f))
    hit = [
        r for r in rows
        if r.get('dataset') == dataset
        and str(r.get('model', '')).lower() == model.lower()
        and r.get('policy') == 'entity'
        and int(r.get('seed', -1)) == seed
        and abs(float(r.get('fraction', -1)) - fraction) < 1e-12
    ]
    if len(hit) != 1:
        raise RuntimeError(
            f'Expected one canonical row for {dataset}/{model}/s{seed}/f{fraction}; got {len(hit)}'
        )
    return hit[0]


def retained_positive_degrees(retain: np.ndarray, entity_ids: np.ndarray) -> dict[int, int]:
    return {
        int(e): int(((retain[:, 0] == int(e)) | (retain[:, 2] == int(e))).sum())
        for e in entity_ids
    }


def deterministic_family_restart(
    model,
    retain: np.ndarray,
    selected_entities: np.ndarray,
    seed: int,
):
    """Restart unsupported selected entity rows BEFORE SchemaCert local update.

    DistMult and ComplEx use Xavier-uniform entity initialization in the native
    SchemaCert family implementation. We therefore draw a fresh deterministic
    Xavier-uniform table and copy only zero-positive-support selected rows.
    The restart seed is request controlled and intentionally differs from the
    model initialization seed, so this is not a restoration of initial rows.
    """
    if model.__class__.__name__.lower() not in {'distmult', 'complex'}:
        raise NotImplementedError('This evaluator is intentionally DistMult/ComplEx only.')

    deg = retained_positive_degrees(retain, selected_entities)
    unsupported = np.asarray(
        [int(e) for e in selected_entities if deg[int(e)] == 0], dtype=np.int64
    )
    out = clone_model(model)
    st = time.time()
    if len(unsupported):
        g = torch.Generator(device='cpu')
        g.manual_seed(int(seed))
        fresh_table = torch.empty(
            tuple(out.entity.weight.shape),
            dtype=out.entity.weight.dtype,
            device='cpu',
        )
        nn.init.xavier_uniform_(fresh_table, generator=g)
        idx_cpu = torch.as_tensor(unsupported, dtype=torch.long)
        idx_dev = idx_cpu.to(out.entity.weight.device)
        with torch.no_grad():
            out.entity.weight[idx_dev] = fresh_table[idx_cpu].to(out.entity.weight.device)
            out.normalize_()
        if out.entity.weight.is_cuda:
            torch.cuda.synchronize()
    return out, time.time() - st, unsupported, deg


def _metric_row(method, source, global_m, forget_m, train_sec, ref_global, ref_forget, extra=None):
    row = {
        'method': method,
        'source': source,
        'global_mrr': global_m.get('mrr'),
        'global_h1': global_m.get('h1'),
        'global_h3': global_m.get('h3'),
        'global_h10': global_m.get('h10'),
        'forget_mrr': forget_m.get('mrr'),
        'forget_h1': forget_m.get('h1'),
        'forget_h3': forget_m.get('h3'),
        'forget_h10': forget_m.get('h10'),
        'global_mrr_gap_to_exact': abs(global_m['mrr'] - ref_global) if global_m.get('mrr') is not None else None,
        'forget_mrr_gap_to_exact': abs(forget_m['mrr'] - ref_forget) if forget_m.get('mrr') is not None else None,
        'train_sec': train_sec,
    }
    if extra:
        row.update(extra)
    return row


def _canonical_metrics(row, prefix: str):
    if prefix == 'reference':
        return {
            'mrr': _float(row, 'reference_mrr'),
            'h1': _float(row, 'reference_h1'),
            'h3': _float(row, 'reference_h3'),
            'h10': _float(row, 'reference_h10'),
        }, {
            'mrr': _float(row, 'forget_reference_mrr'),
            'h1': _float(row, 'forget_reference_h1'),
            'h3': _float(row, 'forget_reference_h3'),
            'h10': _float(row, 'forget_reference_h10'),
        }
    if prefix == 'local':
        return {
            'mrr': _float(row, 'local_mrr'),
            'h1': _float(row, 'local_h1'),
            'h3': _float(row, 'local_h3'),
            'h10': _float(row, 'local_h10'),
        }, {
            'mrr': _float(row, 'forget_local_mrr'),
            'h1': _float(row, 'forget_local_h1'),
            'h3': _float(row, 'forget_local_h3'),
            'h10': _float(row, 'forget_local_h10'),
        }
    if prefix == 'full_finetune':
        return {
            'mrr': _float(row, 'full_finetune_mrr'),
            'h1': _float(row, 'full_finetune_h1'),
            'h3': _float(row, 'full_finetune_h3'),
            'h10': _float(row, 'full_finetune_h10'),
        }, {
            'mrr': _float(row, 'forget_full_finetune_mrr'),
            'h1': _float(row, 'forget_full_finetune_h1'),
            'h3': _float(row, 'forget_full_finetune_h3'),
            'h10': _float(row, 'forget_full_finetune_h10'),
        }
    raise KeyError(prefix)


def main():
    p = argparse.ArgumentParser(
        description='Evaluate generic SchemaCert Restart-Before against canonical DistMult/ComplEx retrains.'
    )
    p.add_argument('--dataset', required=True)
    p.add_argument('--model', required=True, choices=['distmult', 'complex'])
    p.add_argument('--seed', required=True, type=int)
    p.add_argument('--fractions', nargs='+', type=float, default=[0.10, 0.20])
    p.add_argument('--data-root', default='data')
    p.add_argument('--canonical-root', default='results_cluster/policy128_entitylocal_v2')
    p.add_argument('--out', required=True)
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--threads', type=int, default=1)
    p.add_argument('--dim', type=int, default=128)
    p.add_argument('--epochs', type=int, default=20)
    p.add_argument('--local-epochs', type=int, default=5)
    p.add_argument('--batch-size', type=int, default=4096)
    p.add_argument('--lr', type=float, default=0.002)
    p.add_argument('--local-lr', type=float, default=0.001)
    p.add_argument('--l2', type=float, default=1e-6)
    p.add_argument('--hops', type=int, default=1)
    p.add_argument('--eval-batch', type=int, default=16)
    p.add_argument('--entity-chunk', type=int, default=4096)
    p.add_argument('--eval-queries', type=int, default=1000)
    p.add_argument('--forget-eval-queries', type=int, default=1000)
    p.add_argument('--base-mrr-tol', type=float, default=5e-4)
    args = p.parse_args()

    torch.set_num_threads(max(1, args.threads))
    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    ne, nr = len(data.entities), len(data.relations)

    canonical_path = Path(args.canonical_root) / f'{args.dataset}_{args.model}_entity_s{args.seed}.csv'
    if not canonical_path.is_file():
        raise FileNotFoundError(canonical_path)

    # The historical family runner did not persist base checkpoints. Rebuild the
    # deterministic base once per dataset/model/seed, then reuse it for both
    # fractions. Exact retrain metrics themselves are reused from the audited
    # canonical CSV and are NOT recomputed here.
    base = fresh(args.model, ne, nr, args.dim, args.seed, args.device)
    base_stats = train_model(
        base, data.train, ne, args.epochs, args.batch_size, args.lr, args.l2,
        args.seed, args.device,
    )
    base_lp = filtered_lp(
        base, data.test, ne, (data.train, data.valid, data.test), args.device,
        args.eval_batch, args.entity_chunk, args.eval_queries, args.seed,
    )

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    all_records = []
    for frac in args.fractions:
        canonical = _canonical_row(canonical_path, args.dataset, args.model, args.seed, frac)
        if int(float(canonical.get('dim', args.dim))) != args.dim:
            raise RuntimeError(f'Canonical dim mismatch: {canonical.get("dim")} vs {args.dim}')
        if int(float(canonical.get('epochs', args.epochs))) != args.epochs:
            raise RuntimeError(f'Canonical base epoch mismatch: {canonical.get("epochs")} vs {args.epochs}')

        fi, meta = select_forget(
            data.train, frac, args.seed + int(frac * 10000), policy='entity'
        )
        forget = data.train[fi]
        keep = np.ones(len(data.train), dtype=bool)
        keep[fi] = False
        retain = data.train[keep]
        selected = np.asarray(meta.get('entities', []), dtype=np.int64)
        if len(selected) == 0:
            raise RuntimeError('Entity policy returned no selected entities.')

        old_meta = json.loads(canonical.get('request_meta', '{}'))
        if old_meta != meta:
            raise RuntimeError(
                f'Canonical request mismatch for {args.dataset}/{args.model}/s{args.seed}/f{frac}: '
                f'old={old_meta} reconstructed={meta}'
            )
        if int(float(canonical.get('forget_n', -1))) != len(forget):
            raise RuntimeError('Canonical forget_n mismatch.')

        canonical_base = _float(canonical, 'base_mrr')
        base_delta = abs(base_lp['mrr'] - canonical_base)
        if base_delta > args.base_mrr_tol:
            raise RuntimeError(
                f'Reconstructed base MRR drift {base_delta:.6g} exceeds tolerance '
                f'{args.base_mrr_tol}; canonical={canonical_base:.9f} rebuilt={base_lp["mrr"]:.9f}'
            )

        restart_seed = (
            int(args.seed) * 1000003
            + int(round(frac * 1000000))
            + 17027
        ) & 0x7FFFFFFF
        restarted_base, restart_sec, unsupported, deg = deterministic_family_restart(
            base, retain, selected, restart_seed
        )
        restart_local, _, _ = local_retrain(
            restarted_base, data.train, fi, ne, args.hops, args.local_epochs,
            args.batch_size, args.local_lr, args.l2, args.seed, args.device,
        )

        truth = (retain, data.valid, data.test)
        forget_truth = (retain, data.valid, data.test, forget)
        restart_global = filtered_lp(
            restart_local.model, data.test, ne, truth, args.device,
            args.eval_batch, args.entity_chunk, args.eval_queries, args.seed,
        )
        restart_forget = filtered_lp(
            restart_local.model, forget, ne, forget_truth, args.device,
            args.eval_batch, args.entity_chunk, args.forget_eval_queries, args.seed,
        )

        exact_global, exact_forget = _canonical_metrics(canonical, 'reference')
        if exact_global['mrr'] is None or exact_forget['mrr'] is None:
            raise RuntimeError('Canonical exact-retrain MRR metrics are missing.')
        local_global, local_forget = _canonical_metrics(canonical, 'local')
        ft_global, ft_forget = _canonical_metrics(canonical, 'full_finetune')

        req_hash = _request_hash(forget)
        common_extra = {
            'dataset': args.dataset,
            'model': args.model,
            'policy': 'entity',
            'seed': args.seed,
            'fraction': frac,
            'request_hash': req_hash,
            'forget_n': len(forget),
        }
        rows = [
            _metric_row(
                'ExactRetrain', 'canonical policy128_entitylocal_v2 reference',
                exact_global, exact_forget, _float(canonical, 'reference_retrain_sec'),
                exact_global['mrr'], exact_forget['mrr'], common_extra,
            ),
            _metric_row(
                f'SchemaCert-L{args.local_epochs}', 'canonical policy128_entitylocal_v2 local result',
                local_global, local_forget, _float(canonical, 'local_sec'),
                exact_global['mrr'], exact_forget['mrr'], common_extra,
            ),
            _metric_row(
                'FullFinetune', 'canonical policy128_entitylocal_v2 full finetune',
                ft_global, ft_forget, _float(canonical, 'full_finetune_sec'),
                exact_global['mrr'], exact_forget['mrr'], common_extra,
            ),
            _metric_row(
                f'SchemaCert+Restart-L{args.local_epochs}',
                'support-aware deterministic Xavier restart BEFORE SchemaCert local update',
                restart_global, restart_forget, restart_sec + restart_local.seconds,
                exact_global['mrr'], exact_forget['mrr'],
                {
                    **common_extra,
                    'restart_sec': restart_sec,
                    'restart_seed': restart_seed,
                    'unsupported_selected_count': int(len(unsupported)),
                    'selected_count': int(len(selected)),
                    'parameter_fraction': restart_local.parameter_fraction,
                    'work_unique_triples': restart_local.work_unique_triples,
                },
            ),
        ]

        stem = f'{args.dataset}_{args.model}_entity_f{frac:g}_s{args.seed}_restart'
        csv_path = out / f'{stem}.csv'
        json_path = out / f'{stem}.json'
        fieldnames = []
        for r in rows:
            for k in r:
                if k not in fieldnames:
                    fieldnames.append(k)
        with csv_path.open('w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            w.writerows(rows)
        json_path.write_text(json.dumps({
            'dataset': args.dataset,
            'model': args.model,
            'policy': 'entity',
            'seed': args.seed,
            'fraction': frac,
            'request_hash': req_hash,
            'request_meta': meta,
            'canonical_csv': str(canonical_path),
            'canonical_result_schema_version': canonical.get('result_schema_version'),
            'canonical_reference_reused': True,
            'canonical_reference_retrain_sec': _float(canonical, 'reference_retrain_sec'),
            'base_rebuild': {
                'seconds': base_stats.seconds,
                'canonical_mrr': canonical_base,
                'rebuilt_mrr': base_lp['mrr'],
                'absolute_delta': base_delta,
                'tolerance': args.base_mrr_tol,
            },
            'restart': {
                'ordering': 'BEFORE local update',
                'seed': restart_seed,
                'selected_entities': selected.tolist(),
                'retained_positive_degree': deg,
                'unsupported_selected_entities': unsupported.tolist(),
                'unsupported_selected_count': int(len(unsupported)),
                'initializer': 'native family Xavier-uniform; fresh request-controlled draw',
                'local_epochs': args.local_epochs,
                'hops': args.hops,
            },
            'rows': rows,
        }, indent=2))
        all_records.extend(rows)

        print(
            f'FAMILY_RESTART dataset={args.dataset} model={args.model} seed={args.seed} '
            f'fraction={frac:g} request={req_hash} unsupported={len(unsupported)}/{len(selected)} '
            f'base_delta={base_delta:.3g}'
        )
        print('method\tglobal_mrr\tforget_mrr\tglobal_gap_exact\tforget_gap_exact\ttrain_sec')
        for r in rows:
            print(
                f"{r['method']}\t{r['global_mrr']:.6f}\t{r['forget_mrr']:.6f}\t"
                f"{r['global_mrr_gap_to_exact']:.6f}\t{r['forget_mrr_gap_to_exact']:.6f}\t"
                f"{r['train_sec'] if r['train_sec'] is not None else float('nan'):.3f}"
            )
        print(f'FAMILY_RESTART_CSV={csv_path}')
        print(f'FAMILY_RESTART_JSON={json_path}')

    print(f'FAMILY_RESTART_TASK_OK rows={len(all_records)}')


if __name__ == '__main__':
    main()
