#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
import random
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.train import clone_model, train_model
from schemacert.unlearn import local_retrain
from scripts.experiments.evaluate_family_restart import (
    _canonical_metrics,
    _canonical_row,
    _float,
    _metric_row,
    _request_hash,
)
from scripts.experiments.evaluate_family_restart_extended import deterministic_xavier_restart
from scripts.run_publication_families import filtered_lp, fresh, select_forget

SUPPORTED = {'rotate', 'pairre', 'compounde'}


def _build_adjacency(train: np.ndarray):
    adj: dict[int, list[tuple[int, int]]] = {}
    for h, r, t in train:
        h, r, t = int(h), int(r), int(t)
        adj.setdefault(h, []).append((t, r))
        adj.setdefault(t, []).append((h, r))
    return adj


def _build_relation_index(train: np.ndarray):
    out: dict[int, list[tuple[int, int]]] = {}
    for h, r, t in train:
        out.setdefault(int(r), []).append((int(h), int(t)))
    return out


def _query_match_entity(query, relation_index, adjacency, labels, rng: random.Random):
    """Family-agnostic port of the public SGU entity query matching logic."""
    qh, qr, qt = map(int, query)
    mh = mt = None
    for h, t in relation_index.get(qr, []):
        if h != qh and t != qt:
            mh, mt = h, t
            break
    qhn = list(adjacency.get(qh, ()))
    qtn = list(adjacency.get(qt, ()))
    rng.shuffle(qhn)
    rng.shuffle(qtn)
    mhn = list(adjacency.get(mh, ())) if mh is not None else []
    mtn = list(adjacency.get(mt, ())) if mt is not None else []
    rng.shuffle(mhn)
    rng.shuffle(mtn)
    e1 = next((n for n, _ in qhn if n != qt), None)
    e2 = next((n for n, _ in qtn if n != qh), None)
    e3 = None
    e4 = None
    if mh is not None and mt is not None and e1 is not None:
        e3 = next((n for n, _ in mhn if n != mt and labels[n] == labels[e1]), None)
    if mh is not None and mt is not None and e2 is not None:
        e4 = next((n for n, _ in mtn if n != mh and labels[n] == labels[e2]), None)
    return e1, e2, e3, e4


def sgu_family_adapted(base, train, forget, *, seed, device, n_clusters=3, lr=1e-5, max_attempts=20):
    """Matched SGU adaptation using the native entity representation of each family.

    The structural matching and cosine-difference objective follow the public SGU
    entity update.  The only family-specific object is the pretrained entity table.
    This is a matched adaptation, not an author-produced checkpoint.
    """
    try:
        from sklearn.cluster import KMeans
    except Exception as exc:
        raise RuntimeError('SGU family adaptation requires scikit-learn') from exc

    model = clone_model(base).to(device)
    st = time.time()
    weights = model.entity.weight.detach().cpu().numpy()
    labels = KMeans(n_clusters=int(n_clusters), random_state=0, n_init=10).fit(weights).labels_
    adjacency = _build_adjacency(train)
    relation_index = _build_relation_index(train)
    rng = random.Random(int(seed))
    opt = torch.optim.Adam(model.parameters(), lr=float(lr))
    used = 0
    skipped = 0
    total_loss = 0.0
    for query in forget:
        e1 = e2 = e3 = e4 = None
        attempts = 0
        while (e1 is None or e2 is None or e3 is None or e4 is None) and attempts < int(max_attempts):
            e1, e2, e3, e4 = _query_match_entity(query, relation_index, adjacency, labels, rng)
            attempts += 1
        if e1 is None or e2 is None or e3 is None or e4 is None:
            skipped += 1
            continue
        idx = torch.as_tensor([e1, e2, e3, e4], dtype=torch.long, device=device)
        emb = model.entity(idx)
        loss = 1.0 - F.cosine_similarity(emb[0] - emb[1], emb[2] - emb[3], dim=0)
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()
        model.normalize_()
        total_loss += float(loss.detach().cpu())
        used += 1
    if model.entity.weight.is_cuda:
        torch.cuda.synchronize()
    sec = time.time() - st
    if used == 0:
        raise RuntimeError('SGU adaptation produced zero usable forgotten triples')
    return model, sec, {
        'implementation': 'matched family-aware adaptation of public SGU entity update',
        'clusters': int(n_clusters),
        'lr': float(lr),
        'max_attempts': int(max_attempts),
        'forgotten_triples': int(len(forget)),
        'used_triples': int(used),
        'skipped_triples': int(skipped),
        'mean_update_loss': float(total_loss / max(used, 1)),
    }


def _selected_orientation(forget: np.ndarray, selected: set[int]):
    """Match export_graphdpo_request.py: selected head wins ties, else selected tail."""
    is_head = []
    for h, _, t in forget:
        h, t = int(h), int(t)
        is_head.append(bool(h in selected or t not in selected))
    return np.asarray(is_head, dtype=bool)


def _retained_neighbors(retain: np.ndarray):
    out: dict[int, set[int]] = {}
    for h, _, t in retain:
        h, t = int(h), int(t)
        out.setdefault(h, set()).add(t)
        out.setdefault(t, set()).add(h)
    return out


def _graphdpo_pairs(forget, retain, selected_entities, n_entities, seed):
    """Forward-triple adaptation of GraphDPO far-boundary preference sampling.

    Native SchemaCert families do not double relation IDs with explicit inverse
    relations, so we preserve the GraphDPO preference construction on forward
    triples only.  The forgotten endpoint orientation is exactly the one used by
    our matched TransE request exporter.
    """
    selected = set(map(int, selected_entities))
    orient = _selected_orientation(forget, selected)
    neigh = _retained_neighbors(retain)
    rng = random.Random(int(seed))
    pos = []
    neg = []
    linked = set()
    for i, (h, r, t) in enumerate(forget):
        h, r, t = int(h), int(r), int(t)
        anchor = h if orient[i] else t
        linked.add(anchor)
        forbidden = set(neigh.get(anchor, ()))
        forbidden.update((h, t, anchor))
        replacement = rng.randrange(int(n_entities))
        tries = 0
        while replacement in forbidden and tries < 50:
            replacement = rng.randrange(int(n_entities))
            tries += 1
        if orient[i]:
            pos.append((replacement, r, t))
        else:
            pos.append((h, r, replacement))
        neg.append((h, r, t))

    # GraphDPO distills retained neighbors of forgotten entities and replays
    # retained triples incident to the forgetting boundary.  For zero-support
    # entity-star requests these sets are often empty; we record that explicitly.
    distill_entities = set()
    boundary_mask = np.zeros(len(retain), dtype=bool)
    if linked:
        linked_arr = np.asarray(sorted(linked), dtype=np.int64)
        boundary_mask = np.isin(retain[:, 0], linked_arr) | np.isin(retain[:, 2], linked_arr)
        for h, _, t in retain[boundary_mask]:
            h, t = int(h), int(t)
            if h in linked:
                distill_entities.add(t)
            if t in linked:
                distill_entities.add(h)
    return (
        np.asarray(pos, dtype=np.int64),
        np.asarray(neg, dtype=np.int64),
        retain[boundary_mask],
        np.asarray(sorted(distill_entities), dtype=np.int64),
        orient,
    )


def _random_negatives(pos: np.ndarray, original_neg: np.ndarray, n_entities: int, neg_ratio: int, rng):
    b = len(pos)
    out = np.repeat(pos[:, None, :], int(neg_ratio), axis=1)
    out[:, 0, :] = original_neg
    if int(neg_ratio) > 1:
        for j in range(1, int(neg_ratio)):
            corrupt_head = rng.random(b) < 0.5
            labels = rng.integers(0, int(n_entities), size=b, dtype=np.int64)
            out[corrupt_head, j, 0] = labels[corrupt_head]
            out[~corrupt_head, j, 2] = labels[~corrupt_head]
    return out


def _margin_loss(model, pos, neg, margin: float, device: str):
    pt = torch.as_tensor(pos, dtype=torch.long, device=device)
    nt = torch.as_tensor(neg.reshape(-1, 3), dtype=torch.long, device=device)
    sp = model.score(pt).float()
    sn = model.score(nt).float().reshape(len(pos), -1)
    return F.relu(float(margin) - sp[:, None] + sn).mean()


def _graphdpo_preference_loss(model, old, pos, neg, beta: float, device: str):
    pt = torch.as_tensor(pos, dtype=torch.long, device=device)
    nt = torch.as_tensor(neg, dtype=torch.long, device=device)
    new_pos = model.score(pt).float()
    new_neg = model.score(nt).float()
    with torch.no_grad():
        old_pos = old.score(pt).float()
        old_neg = old.score(nt).float()
    # Same batch-level log-softmax construction as the public GraphDPO DPO loss,
    # expressed in our native convention where a larger KGE score is better.
    diff = (
        F.log_softmax(new_pos, dim=-1) - F.log_softmax(old_pos, dim=-1)
        - F.log_softmax(new_neg, dim=-1) + F.log_softmax(old_neg, dim=-1)
    )
    return -F.log_softmax(float(beta) * diff, dim=-1).mean()


def graphdpo_family_adapted(
    base,
    forget,
    retain,
    selected_entities,
    n_entities,
    *,
    seed,
    device,
    epochs=20,
    batch_size=1024,
    lr=1e-3,
    neg_ratio=10,
    margin=8.0,
    dpo_beta=1.0,
    dpo_lambda=0.1,
    distill_lambda=0.001,
):
    """Matched GraphDPO-style adaptation on native family scoring functions.

    This preserves GraphDPO's far-boundary preference pairs, DPO term, embedding
    distillation and boundary replay, but uses the exact canonical family base and
    forward-triple representation.  It is deliberately labelled an adaptation.
    """
    model = clone_model(base).to(device)
    old = clone_model(base).to(device)
    old.eval()
    for p in old.parameters():
        p.requires_grad_(False)

    pos, neg, boundary, distill_entities, orient = _graphdpo_pairs(
        forget, retain, selected_entities, n_entities, seed + 310001
    )
    if len(pos) == 0:
        raise RuntimeError('GraphDPO adaptation generated zero preference pairs')

    rng = np.random.default_rng(int(seed) + 310101)
    opt = torch.optim.Adam(model.parameters(), lr=float(lr))
    st = time.time()
    losses = []
    for _ in range(int(epochs)):
        order = rng.permutation(len(pos))
        epoch_loss = 0.0
        nseen = 0
        for start in range(0, len(order), int(batch_size)):
            ids = order[start:start + int(batch_size)]
            pbatch = pos[ids]
            fbatch = neg[ids]
            nbat = _random_negatives(pbatch, fbatch, n_entities, neg_ratio, rng)
            loss = _margin_loss(model, pbatch, nbat, margin, device)
            loss = loss + float(dpo_lambda) * _graphdpo_preference_loss(
                model, old, pbatch, fbatch, dpo_beta, device
            )
            if len(distill_entities):
                di = torch.as_tensor(distill_entities, dtype=torch.long, device=device)
                loss = loss + float(distill_lambda) * F.huber_loss(
                    model.entity(di), old.entity(di), reduction='sum'
                )
            # Public GraphDPO distills relation embeddings globally.
            loss = loss + float(distill_lambda) * F.huber_loss(
                model.relation.weight, old.relation.weight, reduction='sum'
            )
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
            model.normalize_()
            epoch_loss += float(loss.detach().cpu()) * len(ids)
            nseen += len(ids)

        # Boundary recall: replay retained triples incident to linked forgotten endpoints.
        if len(boundary):
            b_order = rng.permutation(len(boundary))
            for start in range(0, len(b_order), int(batch_size)):
                ids = b_order[start:start + int(batch_size)]
                bpos = boundary[ids]
                bneg = _random_negatives(bpos, bpos, n_entities, neg_ratio, rng)
                # Avoid using the positive itself as the first negative in replay.
                bneg[:, 0, 0] = rng.integers(0, int(n_entities), size=len(ids))
                loss = _margin_loss(model, bpos, bneg, margin, device)
                opt.zero_grad(set_to_none=True)
                loss.backward()
                opt.step()
                model.normalize_()
        losses.append(float(epoch_loss / max(nseen, 1)))

    if model.entity.weight.is_cuda:
        torch.cuda.synchronize()
    sec = time.time() - st
    with torch.no_grad():
        pt = torch.as_tensor(pos, dtype=torch.long, device=device)
        nt = torch.as_tensor(neg, dtype=torch.long, device=device)
        pref_rate = float((model.score(pt) > model.score(nt)).float().mean().cpu())
    if not all(math.isfinite(x) for x in losses) or not math.isfinite(pref_rate):
        raise RuntimeError('GraphDPO adaptation produced non-finite diagnostics')
    return model, sec, {
        'implementation': 'matched GraphDPO-style family adaptation; not author-produced checkpoint',
        'official_components_preserved': ['far preference pairs', 'DPO', 'distillation', 'boundary replay'],
        'forward_triples_only': True,
        'epochs': int(epochs),
        'batch_size': int(batch_size),
        'lr': float(lr),
        'neg_ratio': int(neg_ratio),
        'margin': float(margin),
        'dpo_beta': float(dpo_beta),
        'dpo_lambda': float(dpo_lambda),
        'distill_lambda': float(distill_lambda),
        'preference_pairs': int(len(pos)),
        'boundary_replay_triples': int(len(boundary)),
        'distill_entities': int(len(distill_entities)),
        'selected_head_fraction': float(orient.mean()) if len(orient) else None,
        'final_preference_accuracy': pref_rate,
        'loss_first': losses[0] if losses else None,
        'loss_last': losses[-1] if losses else None,
    }


def _eval(model, data, forget, retain, ne, args):
    truth = (retain, data.valid, data.test)
    forget_truth = (retain, data.valid, data.test, forget)
    gm = filtered_lp(
        model, data.test, ne, truth, args.device,
        args.eval_batch, args.entity_chunk, args.eval_queries, args.seed,
    )
    fm = filtered_lp(
        model, forget, ne, forget_truth, args.device,
        args.eval_batch, args.entity_chunk, args.forget_eval_queries, args.seed,
    )
    return gm, fm


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--dataset', required=True)
    p.add_argument('--model', required=True, choices=sorted(SUPPORTED))
    p.add_argument('--seed', required=True, type=int)
    p.add_argument('--fractions', nargs='+', type=float, default=[0.10, 0.20])
    p.add_argument('--data-root', default='data')
    p.add_argument('--canonical-root', default='results_cluster/policy128_entitylocal_v2')
    p.add_argument('--out', required=True)
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--threads', type=int, default=1)
    p.add_argument('--dim', type=int, default=128)
    p.add_argument('--epochs', type=int, default=20)
    p.add_argument('--local-epochs', type=int, default=5)
    p.add_argument('--batch-size', type=int, default=4096)
    p.add_argument('--lr', type=float, default=0.002)
    p.add_argument('--local-lr', type=float, default=0.001)
    p.add_argument('--l2', type=float, default=1e-6)
    p.add_argument('--hops', type=int, default=1)
    p.add_argument('--eval-batch', type=int, default=16)
    p.add_argument('--entity-chunk', type=int, default=4096)
    p.add_argument('--eval-queries', type=int, default=1000)
    p.add_argument('--forget-eval-queries', type=int, default=1000)
    p.add_argument('--base-mrr-tol', type=float, default=5e-4)
    p.add_argument('--sgu-clusters', type=int, default=3)
    p.add_argument('--sgu-lr', type=float, default=1e-5)
    p.add_argument('--graphdpo-epochs', type=int, default=20)
    p.add_argument('--graphdpo-batch-size', type=int, default=1024)
    p.add_argument('--graphdpo-lr', type=float, default=1e-3)
    p.add_argument('--graphdpo-neg-ratio', type=int, default=10)
    p.add_argument('--graphdpo-margin', type=float, default=8.0)
    args = p.parse_args()

    torch.set_num_threads(max(1, args.threads))
    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    ne, nr = len(data.entities), len(data.relations)
    canonical_path = Path(args.canonical_root) / f'{args.dataset}_{args.model}_entity_s{args.seed}.csv'
    if not canonical_path.is_file():
        raise FileNotFoundError(canonical_path)

    # One deterministic base rebuild per dataset/model/seed, reused for both fractions.
    base = fresh(args.model, ne, nr, args.dim, args.seed, args.device)
    base_stats = train_model(
        base, data.train, ne, args.epochs, args.batch_size, args.lr, args.l2,
        args.seed, args.device,
    )
    base_lp = filtered_lp(
        base, data.test, ne, (data.train, data.valid, data.test), args.device,
        args.eval_batch, args.entity_chunk, args.eval_queries, args.seed,
    )
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    for frac in args.fractions:
        canonical = _canonical_row(canonical_path, args.dataset, args.model, args.seed, frac)
        if int(float(canonical.get('dim', args.dim))) != args.dim:
            raise RuntimeError('Canonical dimension mismatch')
        if int(float(canonical.get('epochs', args.epochs))) != args.epochs:
            raise RuntimeError('Canonical base-epoch mismatch')
        fi, meta = select_forget(data.train, frac, args.seed + int(frac * 10000), policy='entity')
        forget = data.train[fi]
        keep = np.ones(len(data.train), dtype=bool)
        keep[fi] = False
        retain = data.train[keep]
        selected = np.asarray(meta.get('entities', []), dtype=np.int64)
        old_meta = json.loads(canonical.get('request_meta', '{}'))
        if old_meta != meta or int(float(canonical.get('forget_n', -1))) != len(forget):
            raise RuntimeError('Canonical request reconstruction mismatch')
        canonical_base = _float(canonical, 'base_mrr')
        if canonical_base is None:
            raise RuntimeError('Canonical base MRR missing')
        base_delta = abs(base_lp['mrr'] - canonical_base)
        if base_delta > args.base_mrr_tol:
            raise RuntimeError(
                f'Base MRR drift {base_delta:.6g} exceeds {args.base_mrr_tol}: '
                f'canonical={canonical_base:.9f} rebuilt={base_lp["mrr"]:.9f}'
            )

        exact_global, exact_forget = _canonical_metrics(canonical, 'reference')
        bare_global, bare_forget = _canonical_metrics(canonical, 'local')
        ft_global, ft_forget = _canonical_metrics(canonical, 'full_finetune')
        if any(x['mrr'] is None for x in (exact_global, exact_forget, bare_global, bare_forget, ft_global, ft_forget)):
            raise RuntimeError('Canonical MRR metrics missing')

        restart_seed = (
            int(args.seed) * 1000003 + int(round(frac * 1000000)) + 17027
        ) & 0x7FFFFFFF
        restarted, restart_sec, unsupported, deg = deterministic_xavier_restart(
            base, retain, selected, restart_seed
        )
        restart_local, _, _ = local_retrain(
            restarted, data.train, fi, ne, args.hops, args.local_epochs,
            args.batch_size, args.local_lr, args.l2, args.seed, args.device,
        )
        restart_global, restart_forget = _eval(restart_local.model, data, forget, retain, ne, args)

        sgu_model, sgu_sec, sgu_meta = sgu_family_adapted(
            base, data.train, forget,
            seed=args.seed, device=args.device,
            n_clusters=args.sgu_clusters, lr=args.sgu_lr,
        )
        sgu_global, sgu_forget = _eval(sgu_model, data, forget, retain, ne, args)

        gdpo_model, gdpo_sec, gdpo_meta = graphdpo_family_adapted(
            base, forget, retain, selected, ne,
            seed=args.seed, device=args.device,
            epochs=args.graphdpo_epochs,
            batch_size=args.graphdpo_batch_size,
            lr=args.graphdpo_lr,
            neg_ratio=args.graphdpo_neg_ratio,
            margin=args.graphdpo_margin,
        )
        gdpo_global, gdpo_forget = _eval(gdpo_model, data, forget, retain, ne, args)

        ref_g = exact_global['mrr']
        ref_f = exact_forget['mrr']
        req_hash = _request_hash(forget)
        common = {
            'dataset': args.dataset,
            'model': args.model,
            'policy': 'entity',
            'seed': args.seed,
            'fraction': frac,
            'request_hash': req_hash,
            'forget_n': int(len(forget)),
        }
        rows = [
            _metric_row('ExactRetrain', 'canonical L5-v2 reference', exact_global, exact_forget,
                        _float(canonical, 'reference_retrain_sec'), ref_g, ref_f, common),
            _metric_row(f'SchemaCert-L{args.local_epochs}', 'canonical L5-v2 local result',
                        bare_global, bare_forget, _float(canonical, 'local_sec'), ref_g, ref_f, common),
            _metric_row('FullFinetune', 'canonical L5-v2 full finetune', ft_global, ft_forget,
                        _float(canonical, 'full_finetune_sec'), ref_g, ref_f, common),
            _metric_row(
                f'SchemaCert+Restart-L{args.local_epochs}',
                'deterministic unsupported-row Xavier restart BEFORE local update',
                restart_global, restart_forget, restart_sec + restart_local.seconds, ref_g, ref_f,
                {**common, 'restart_sec': restart_sec, 'restart_seed': restart_seed,
                 'selected_count': int(len(selected)),
                 'unsupported_selected_count': int(len(unsupported)),
                 'unsupported_fraction': float(len(unsupported) / max(len(selected), 1)),
                 'parameter_fraction': restart_local.parameter_fraction,
                 'work_unique_triples': restart_local.work_unique_triples},
            ),
            _metric_row('SGU-FamilyAdapted', 'matched family-aware SGU adaptation',
                        sgu_global, sgu_forget, sgu_sec, ref_g, ref_f, {**common, **sgu_meta}),
            _metric_row('GraphDPO-FamilyAdapted', 'matched GraphDPO-style family adaptation',
                        gdpo_global, gdpo_forget, gdpo_sec, ref_g, ref_f, {**common, **gdpo_meta}),
        ]
        for row in rows:
            for key in ('global_mrr', 'forget_mrr', 'global_mrr_gap_to_exact', 'forget_mrr_gap_to_exact'):
                value = row.get(key)
                if value is None or not math.isfinite(float(value)):
                    raise RuntimeError(f'Non-finite {key} in {row["method"]}')

        stem = f'{args.dataset}_{args.model}_entity_f{frac:g}_s{args.seed}_family_competitors'
        csv_path = out / f'{stem}.csv'
        json_path = out / f'{stem}.json'
        fields = []
        for row in rows:
            for key in row:
                if key not in fields:
                    fields.append(key)
        with csv_path.open('w', newline='') as h:
            w = csv.DictWriter(h, fieldnames=fields)
            w.writeheader()
            w.writerows(rows)
        json_path.write_text(json.dumps({
            'dataset': args.dataset,
            'model': args.model,
            'seed': args.seed,
            'fraction': frac,
            'request_hash': req_hash,
            'request_meta': meta,
            'canonical_csv': str(canonical_path),
            'base_rebuild': {'seconds': base_stats.seconds, 'canonical_mrr': canonical_base,
                             'rebuilt_mrr': base_lp['mrr'], 'absolute_delta': base_delta,
                             'tolerance': args.base_mrr_tol},
            'restart': {'selected_count': int(len(selected)),
                        'unsupported_selected_count': int(len(unsupported)),
                        'all_selected_zero_support': bool(len(unsupported) == len(selected)),
                        'positive_degree_min': int(min(deg.values())) if deg else None,
                        'positive_degree_max': int(max(deg.values())) if deg else None},
            'sgu': sgu_meta,
            'graphdpo': gdpo_meta,
            'rows': rows,
        }, indent=2))
        print(
            f'FAMILY_COMPETITOR_OK dataset={args.dataset} model={args.model} seed={args.seed} f={frac} '
            f'restart=({rows[3]["global_mrr_gap_to_exact"]:.6f},{rows[3]["forget_mrr_gap_to_exact"]:.6f}) '
            f'sgu=({rows[4]["global_mrr_gap_to_exact"]:.6f},{rows[4]["forget_mrr_gap_to_exact"]:.6f}) '
            f'graphdpo=({rows[5]["global_mrr_gap_to_exact"]:.6f},{rows[5]["forget_mrr_gap_to_exact"]:.6f})'
        )


if __name__ == '__main__':
    main()
