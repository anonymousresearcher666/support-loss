#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.train import clone_model, train_model
from schemacert.unlearn import local_retrain
from scripts.experiments.evaluate_family_restart import (
    _canonical_metrics,
    _canonical_row,
    _float,
    _metric_row,
    _request_hash,
    retained_positive_degrees,
)
from scripts.run_publication_families import filtered_lp, fresh, select_forget


SUPPORTED = {'rotate', 'pairre', 'compounde'}


def deterministic_xavier_restart(model, retain, selected_entities, seed: int):
    """Restart unsupported selected entity rows before the local correction.

    RotatE, PairRE and CompoundE all initialize their entity tables with
    Xavier-uniform weights in schemacert.family_models.  We therefore create a
    deterministic fresh Xavier table and copy only selected rows that have zero
    positive retained support.  Relation parameters are never modified.
    """
    name = model.__class__.__name__.lower()
    if name not in SUPPORTED:
        raise NotImplementedError(f'Unsupported family for this campaign: {name}')

    deg = retained_positive_degrees(retain, selected_entities)
    unsupported = np.asarray(
        [int(e) for e in selected_entities if deg[int(e)] == 0], dtype=np.int64
    )
    out = clone_model(model)
    st = time.time()
    if len(unsupported):
        g = torch.Generator(device='cpu')
        g.manual_seed(int(seed))
        fresh_table = torch.empty(
            tuple(out.entity.weight.shape),
            dtype=out.entity.weight.dtype,
            device='cpu',
        )
        nn.init.xavier_uniform_(fresh_table, generator=g)
        idx_cpu = torch.as_tensor(unsupported, dtype=torch.long)
        idx_dev = idx_cpu.to(out.entity.weight.device)
        with torch.no_grad():
            out.entity.weight[idx_dev] = fresh_table[idx_cpu].to(out.entity.weight.device)
            out.normalize_()
        if out.entity.weight.is_cuda:
            torch.cuda.synchronize()
    return out, time.time() - st, unsupported, deg


def main():
    p = argparse.ArgumentParser(
        description='Targeted Restart-Before extension for RotatE, PairRE and CompoundE.'
    )
    p.add_argument('--dataset', required=True)
    p.add_argument('--model', required=True, choices=sorted(SUPPORTED))
    p.add_argument('--seed', required=True, type=int)
    p.add_argument('--fractions', nargs='+', type=float, default=[0.10, 0.20])
    p.add_argument('--data-root', default='data')
    p.add_argument('--canonical-root', default='results_cluster/policy128_entitylocal_v2')
    p.add_argument('--out', required=True)
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--threads', type=int, default=1)
    p.add_argument('--dim', type=int, default=128)
    p.add_argument('--epochs', type=int, default=20)
    p.add_argument('--local-epochs', type=int, default=5)
    p.add_argument('--batch-size', type=int, default=4096)
    p.add_argument('--lr', type=float, default=0.002)
    p.add_argument('--local-lr', type=float, default=0.001)
    p.add_argument('--l2', type=float, default=1e-6)
    p.add_argument('--hops', type=int, default=1)
    p.add_argument('--eval-batch', type=int, default=16)
    p.add_argument('--entity-chunk', type=int, default=4096)
    p.add_argument('--eval-queries', type=int, default=1000)
    p.add_argument('--forget-eval-queries', type=int, default=1000)
    p.add_argument('--base-mrr-tol', type=float, default=5e-4)
    args = p.parse_args()

    torch.set_num_threads(max(1, args.threads))
    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    ne, nr = len(data.entities), len(data.relations)

    canonical_path = Path(args.canonical_root) / f'{args.dataset}_{args.model}_entity_s{args.seed}.csv'
    if not canonical_path.is_file():
        raise FileNotFoundError(canonical_path)

    # Historical broad-family runs did not persist base checkpoints. Rebuild
    # the deterministic base once, verify it against canonical base MRR, then
    # reuse it for both deletion fractions. ExactRetrain and bare SchemaCert
    # metrics are reused from the audited canonical CSV and are not recomputed.
    base = fresh(args.model, ne, nr, args.dim, args.seed, args.device)
    base_stats = train_model(
        base, data.train, ne, args.epochs, args.batch_size, args.lr, args.l2,
        args.seed, args.device,
    )
    base_lp = filtered_lp(
        base, data.test, ne, (data.train, data.valid, data.test), args.device,
        args.eval_batch, args.entity_chunk, args.eval_queries, args.seed,
    )

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    for frac in args.fractions:
        canonical = _canonical_row(canonical_path, args.dataset, args.model, args.seed, frac)
        if int(float(canonical.get('dim', args.dim))) != args.dim:
            raise RuntimeError(f'Canonical dim mismatch: {canonical.get("dim")} vs {args.dim}')
        if int(float(canonical.get('epochs', args.epochs))) != args.epochs:
            raise RuntimeError(
                f'Canonical base epoch mismatch: {canonical.get("epochs")} vs {args.epochs}'
            )

        fi, meta = select_forget(
            data.train, frac, args.seed + int(frac * 10000), policy='entity'
        )
        forget = data.train[fi]
        keep = np.ones(len(data.train), dtype=bool)
        keep[fi] = False
        retain = data.train[keep]
        selected = np.asarray(meta.get('entities', []), dtype=np.int64)
        if len(selected) == 0:
            raise RuntimeError('Entity policy returned no selected entities.')

        old_meta = json.loads(canonical.get('request_meta', '{}'))
        if old_meta != meta:
            raise RuntimeError(
                f'Canonical request mismatch for {args.dataset}/{args.model}/s{args.seed}/f{frac}: '
                f'old={old_meta} reconstructed={meta}'
            )
        if int(float(canonical.get('forget_n', -1))) != len(forget):
            raise RuntimeError('Canonical forget_n mismatch.')

        canonical_base = _float(canonical, 'base_mrr')
        if canonical_base is None:
            raise RuntimeError('Canonical base MRR is missing.')
        base_delta = abs(base_lp['mrr'] - canonical_base)
        if base_delta > args.base_mrr_tol:
            raise RuntimeError(
                f'Reconstructed base MRR drift {base_delta:.6g} exceeds tolerance '
                f'{args.base_mrr_tol}; canonical={canonical_base:.9f} rebuilt={base_lp["mrr"]:.9f}'
            )

        restart_seed = (
            int(args.seed) * 1000003
            + int(round(frac * 1000000))
            + 17027
        ) & 0x7FFFFFFF
        restarted_base, restart_sec, unsupported, deg = deterministic_xavier_restart(
            base, retain, selected, restart_seed
        )
        restart_local, _, _ = local_retrain(
            restarted_base, data.train, fi, ne, args.hops, args.local_epochs,
            args.batch_size, args.local_lr, args.l2, args.seed, args.device,
        )

        truth = (retain, data.valid, data.test)
        forget_truth = (retain, data.valid, data.test, forget)
        restart_global = filtered_lp(
            restart_local.model, data.test, ne, truth, args.device,
            args.eval_batch, args.entity_chunk, args.eval_queries, args.seed,
        )
        restart_forget = filtered_lp(
            restart_local.model, forget, ne, forget_truth, args.device,
            args.eval_batch, args.entity_chunk, args.forget_eval_queries, args.seed,
        )

        exact_global, exact_forget = _canonical_metrics(canonical, 'reference')
        local_global, local_forget = _canonical_metrics(canonical, 'local')
        if exact_global['mrr'] is None or exact_forget['mrr'] is None:
            raise RuntimeError('Canonical ExactRetrain metrics are missing.')
        if local_global['mrr'] is None or local_forget['mrr'] is None:
            raise RuntimeError('Canonical SchemaCert-L5 metrics are missing.')

        req_hash = _request_hash(forget)
        common = {
            'dataset': args.dataset,
            'model': args.model,
            'policy': 'entity',
            'seed': args.seed,
            'fraction': frac,
            'request_hash': req_hash,
            'forget_n': len(forget),
        }
        rows = [
            _metric_row(
                'ExactRetrain', 'canonical policy128_entitylocal_v2 reference',
                exact_global, exact_forget, _float(canonical, 'reference_retrain_sec'),
                exact_global['mrr'], exact_forget['mrr'], common,
            ),
            _metric_row(
                f'SchemaCert-L{args.local_epochs}', 'canonical policy128_entitylocal_v2 local result',
                local_global, local_forget, _float(canonical, 'local_sec'),
                exact_global['mrr'], exact_forget['mrr'], common,
            ),
            _metric_row(
                f'SchemaCert+Restart-L{args.local_epochs}',
                'deterministic unsupported-row Xavier restart BEFORE SchemaCert local update',
                restart_global, restart_forget, restart_sec + restart_local.seconds,
                exact_global['mrr'], exact_forget['mrr'],
                {
                    **common,
                    'restart_sec': restart_sec,
                    'restart_seed': restart_seed,
                    'unsupported_selected_count': int(len(unsupported)),
                    'selected_count': int(len(selected)),
                    'unsupported_fraction': float(len(unsupported) / max(len(selected), 1)),
                    'parameter_fraction': restart_local.parameter_fraction,
                    'work_unique_triples': restart_local.work_unique_triples,
                },
            ),
        ]

        stem = f'{args.dataset}_{args.model}_entity_f{frac:g}_s{args.seed}_restart_ext'
        csv_path = out / f'{stem}.csv'
        json_path = out / f'{stem}.json'
        fieldnames = []
        for r in rows:
            for k in r:
                if k not in fieldnames:
                    fieldnames.append(k)
        with csv_path.open('w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            w.writerows(rows)

        json_path.write_text(json.dumps({
            'dataset': args.dataset,
            'model': args.model,
            'policy': 'entity',
            'seed': args.seed,
            'fraction': frac,
            'request_hash': req_hash,
            'request_meta': meta,
            'canonical_csv': str(canonical_path),
            'canonical_reference_reused': True,
            'canonical_bare_schemacert_reused': True,
            'base_rebuild': {
                'seconds': base_stats.seconds,
                'canonical_mrr': canonical_base,
                'rebuilt_mrr': base_lp['mrr'],
                'absolute_delta': base_delta,
                'tolerance': args.base_mrr_tol,
            },
            'restart': {
                'ordering': 'BEFORE local update',
                'initializer': 'deterministic Xavier-uniform entity rows',
                'relation_parameters_modified': False,
                'seed': restart_seed,
                'selected_count': int(len(selected)),
                'unsupported_selected_count': int(len(unsupported)),
                'unsupported_fraction': float(len(unsupported) / max(len(selected), 1)),
                'all_selected_zero_support': bool(len(unsupported) == len(selected)),
                'positive_degree_min': int(min(deg.values())) if deg else None,
                'positive_degree_max': int(max(deg.values())) if deg else None,
            },
            'rows': rows,
        }, indent=2))
        print(
            f'OK dataset={args.dataset} model={args.model} seed={args.seed} fraction={frac} '
            f'unsupported={len(unsupported)}/{len(selected)} '
            f'bare_dG={rows[1]["global_mrr_gap_to_exact"]:.6g} '
            f'bare_dF={rows[1]["forget_mrr_gap_to_exact"]:.6g} '
            f'restart_dG={rows[2]["global_mrr_gap_to_exact"]:.6g} '
            f'restart_dF={rows[2]["forget_mrr_gap_to_exact"]:.6g}'
        )


if __name__ == '__main__':
    main()
