#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from scripts.run_publication_families import filtered_lp, select_forget


def parse_named(items: list[str]) -> dict[str, str]:
    out: dict[str, str] = {}
    for item in items:
        if '=' not in item:
            raise ValueError(f"Expected NAME=PATH, got: {item}")
        name, path = item.split('=', 1)
        name, path = name.strip(), path.strip()
        if not name or not path:
            raise ValueError(f"Expected NAME=PATH, got: {item}")
        if name in out:
            raise ValueError(f"Duplicate label: {name}")
        out[name] = path
    return out


def as_float(row: dict[str, str], key: str) -> float | None:
    value = row.get(key, '')
    if value is None or value == '' or str(value).lower() in {'none', 'nan'}:
        return None
    return float(value)


def as_int(row: dict[str, str], key: str) -> int | None:
    value = as_float(row, key)
    return None if value is None else int(round(value))


def select_schema_row(path: str, dataset: str, model: str, policy: str, seed: int, fraction: float) -> dict[str, str]:
    hits = []
    with open(path, newline='') as f:
        for row in csv.DictReader(f):
            if row.get('dataset') != dataset:
                continue
            if row.get('model', '').lower() != model.lower():
                continue
            if row.get('policy') != policy:
                continue
            if int(float(row.get('seed', '-1'))) != seed:
                continue
            if not np.isclose(float(row.get('fraction', 'nan')), fraction, rtol=0.0, atol=1e-12):
                continue
            hits.append(row)
    if len(hits) != 1:
        raise RuntimeError(f"Expected exactly one matching row in {path}, found {len(hits)}")
    return hits[0]


def graphdpo_vocab(all_data_path: Path):
    entity2id: dict[str, int] = {}
    relation2id: dict[str, int] = {}
    ent_num = 0
    rel_num = 0
    with open(all_data_path, encoding='utf-8') as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) < 3:
                continue
            h, r, t = parts[:3]
            if h not in entity2id:
                entity2id[h] = ent_num
                ent_num += 1
            if r not in relation2id:
                relation2id[r] = rel_num
                relation2id[r + '_inv'] = rel_num + 1
                rel_num += 2
            if t not in entity2id:
                entity2id[t] = ent_num
                ent_num += 1
    return entity2id, relation2id


def map_to_graphdpo(arr: np.ndarray, data, entity2id: dict[str, int], relation2id: dict[str, int]) -> np.ndarray:
    missing_e = [name for name in data.entities if name not in entity2id]
    missing_r = [name for name in data.relations if name not in relation2id]
    if missing_e:
        raise RuntimeError(f"GraphDPO vocabulary misses {len(missing_e)} SchemaCert entities; first={missing_e[:5]}")
    if missing_r:
        raise RuntimeError(f"GraphDPO vocabulary misses {len(missing_r)} SchemaCert relations; first={missing_r[:5]}")
    e_map = np.asarray([entity2id[name] for name in data.entities], dtype=np.int64)
    r_map = np.asarray([relation2id[name] for name in data.relations], dtype=np.int64)
    out = np.asarray(arr, dtype=np.int64).copy()
    if len(out):
        out[:, 0] = e_map[out[:, 0]]
        out[:, 1] = r_map[out[:, 1]]
        out[:, 2] = e_map[out[:, 2]]
    return out


def triple_names(data, arr: np.ndarray) -> list[str]:
    return [
        f"{data.entities[int(h)]}\t{data.relations[int(r)]}\t{data.entities[int(t)]}"
        for h, r, t in arr
    ]


def request_fingerprint(data, forget: np.ndarray) -> str:
    payload = '\n'.join(sorted(triple_names(data, forget))).encode('utf-8')
    return hashlib.sha256(payload).hexdigest()[:16]


def verify_exported_request(request_dir: Path, data, forget: np.ndarray, dataset: str, policy: str, seed: int, fraction: float):
    manifest_path = request_dir / 'manifest.json'
    snapshot_path = request_dir / '0' / '0.txt'
    all_data_path = request_dir / 'all_data.txt'
    for path in (manifest_path, snapshot_path, all_data_path):
        if not path.is_file():
            raise FileNotFoundError(path)
    manifest = json.loads(manifest_path.read_text())
    expected = {
        'dataset': dataset,
        'policy': policy,
        'seed': seed,
    }
    for key, value in expected.items():
        if manifest.get(key) != value:
            raise RuntimeError(f"Request manifest mismatch for {key}: {manifest.get(key)!r} != {value!r}")
    if not np.isclose(float(manifest.get('fraction')), fraction, rtol=0.0, atol=1e-12):
        raise RuntimeError(f"Request manifest fraction mismatch: {manifest.get('fraction')} != {fraction}")
    if int(manifest.get('forget_n', -1)) != len(forget):
        raise RuntimeError(f"Request manifest forget_n mismatch: {manifest.get('forget_n')} != {len(forget)}")

    exported = []
    with open(snapshot_path, encoding='utf-8') as f:
        for line in f:
            parts = line.rstrip('\n').split('\t')
            if len(parts) < 3:
                continue
            exported.append('\t'.join(parts[:3]))
    expected_names = triple_names(data, forget)
    if Counter(exported) != Counter(expected_names):
        only_export = list((Counter(exported) - Counter(expected_names)).elements())[:5]
        only_expected = list((Counter(expected_names) - Counter(exported)).elements())[:5]
        raise RuntimeError(
            "Exported GraphDPO forget request differs from SchemaCert request: "
            f"export_only={only_export}, schemacert_only={only_expected}"
        )
    return manifest, all_data_path


class GraphDPOTransEAdapter(nn.Module):
    """Rank-equivalent adapter for the official GraphDPO TransE checkpoints.

    GraphDPO ranks with sigmoid(9 - ||norm(h)+norm(r)-norm(t)||_1).  The sigmoid
    and additive constant are monotone, so negative L1 distance gives identical
    rankings while exposing the score/score_candidates API used by SchemaCert.
    """

    def __init__(self, entity_weight: torch.Tensor, relation_weight: torch.Tensor):
        super().__init__()
        self.register_buffer('entity_weight', entity_weight.detach().clone())
        self.register_buffer('relation_weight', relation_weight.detach().clone())

    @staticmethod
    def _norm(x: torch.Tensor) -> torch.Tensor:
        return F.normalize(x, p=2, dim=-1)

    def score(self, x: torch.Tensor) -> torch.Tensor:
        h = self._norm(self.entity_weight[x[:, 0]])
        r = self._norm(self.relation_weight[x[:, 1]])
        t = self._norm(self.entity_weight[x[:, 2]])
        return -torch.linalg.vector_norm(h + r - t, ord=1, dim=-1)

    def score_candidates(self, kind: str, a: torch.Tensor, b: torch.Tensor, cand: torch.Tensor) -> torch.Tensor:
        e = self._norm(self.entity_weight[cand])
        if kind == 'tail':
            h = self._norm(self.entity_weight[a])
            r = self._norm(self.relation_weight[b])
            q = h + r
            return -torch.linalg.vector_norm(q[:, None, :] - e[None, :, :], ord=1, dim=-1)
        if kind == 'head':
            r = self._norm(self.relation_weight[a])
            t = self._norm(self.entity_weight[b])
            return -torch.linalg.vector_norm(e[None, :, :] + r[:, None, :] - t[:, None, :], ord=1, dim=-1)
        raise KeyError(kind)


def load_graphdpo_checkpoint(path: str, n_entities: int, n_relations_with_inverse: int) -> GraphDPOTransEAdapter:
    checkpoint = torch.load(path, map_location='cpu')
    state = checkpoint.get('state_dict', checkpoint)
    try:
        ent = state['ent_embeddings.weight']
        rel = state['rel_embeddings.weight']
    except KeyError as exc:
        raise RuntimeError(f"Checkpoint {path} is not a GraphDPO TransE checkpoint") from exc
    if ent.ndim != 2 or rel.ndim != 2 or ent.shape[1] != rel.shape[1]:
        raise RuntimeError(f"Unexpected GraphDPO embedding shapes: entities={tuple(ent.shape)}, relations={tuple(rel.shape)}")
    if ent.shape[0] != n_entities:
        raise RuntimeError(f"Entity-count mismatch: checkpoint={ent.shape[0]} vocab={n_entities}")
    if rel.shape[0] != n_relations_with_inverse:
        raise RuntimeError(f"Relation-count mismatch: checkpoint={rel.shape[0]} vocab={n_relations_with_inverse}")
    return GraphDPOTransEAdapter(ent, rel)


def parse_native_time(path: str | None) -> float | None:
    if not path:
        return None
    text = Path(path).read_text(errors='ignore')
    hits = re.findall(r'Sum_Training_Time:([0-9eE+\-.]+)', text)
    if hits:
        return float(hits[-1])
    hits = re.findall(r'Snapshot\s+\d+\s+training time is\s+([0-9eE+\-.]+)', text)
    return float(hits[-1]) if hits else None


def metric_row(method: str, source: str, metrics: dict, forget_metrics: dict, train_sec: float | None,
               ref: dict[str, float], request_hash: str) -> dict:
    row = {
        'method': method,
        'source': source,
        'global_mrr': metrics.get('mrr'),
        'global_h1': metrics.get('h1'),
        'global_h3': metrics.get('h3'),
        'global_h10': metrics.get('h10'),
        'forget_mrr': forget_metrics.get('mrr'),
        'forget_h1': forget_metrics.get('h1'),
        'forget_h3': forget_metrics.get('h3'),
        'forget_h10': forget_metrics.get('h10'),
        'train_sec': train_sec,
        'eval_rankings': metrics.get('n'),
        'forget_eval_rankings': forget_metrics.get('n'),
        'request_hash': request_hash,
    }
    row['global_mrr_gap_to_exact'] = None if row['global_mrr'] is None else abs(row['global_mrr'] - ref['global_mrr'])
    row['forget_mrr_gap_to_exact'] = None if row['forget_mrr'] is None else abs(row['forget_mrr'] - ref['forget_mrr'])
    return row


def schema_metrics(row: dict[str, str], prefix: str) -> dict:
    return {
        'mrr': as_float(row, f'{prefix}_mrr'),
        'h1': as_float(row, f'{prefix}_h1'),
        'h3': as_float(row, f'{prefix}_h3'),
        'h10': as_float(row, f'{prefix}_h10'),
        'n': as_int(row, 'eval_rankings'),
    }


def schema_forget_metrics(row: dict[str, str], prefix: str) -> dict:
    return {
        'mrr': as_float(row, f'forget_{prefix}_mrr'),
        'h1': as_float(row, f'forget_{prefix}_h1'),
        'h3': as_float(row, f'forget_{prefix}_h3'),
        'h10': as_float(row, f'forget_{prefix}_h10'),
        'n': as_int(row, 'forget_eval_rankings'),
    }


def main():
    p = argparse.ArgumentParser(description='Evaluate official GraphDPO-family checkpoints with the SchemaCert filtered-LP evaluator.')
    p.add_argument('--dataset', required=True)
    p.add_argument('--policy', default='entity', choices=['entity', 'relation', 'random'])
    p.add_argument('--fraction', required=True, type=float)
    p.add_argument('--seed', required=True, type=int)
    p.add_argument('--model', default='transe')
    p.add_argument('--data-root', default='data')
    p.add_argument('--request-dir', required=True)
    p.add_argument('--schema', action='append', default=[], help='Repeated LABEL=SchemaCertCSV; first row defines exact-retrain reference.')
    p.add_argument('--external', action='append', default=[], help='Repeated LABEL=GraphDPOCheckpoint')
    p.add_argument('--external-log', action='append', default=[], help='Repeated LABEL=GraphDPONativeLog for training time.')
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--eval-batch', type=int, default=16)
    p.add_argument('--entity-chunk', type=int, default=4096)
    p.add_argument('--eval-queries', type=int, default=1000)
    p.add_argument('--forget-eval-queries', type=int, default=1000)
    p.add_argument('--out', required=True)
    args = p.parse_args()

    if args.model.lower() != 'transe':
        raise NotImplementedError('The current official GraphDPO baseline campaign uses TransE; common adapter is intentionally TransE-only.')
    schemas = parse_named(args.schema)
    externals = parse_named(args.external)
    external_logs = parse_named(args.external_log)
    if not schemas:
        raise ValueError('At least one --schema LABEL=CSV is required')
    if not externals:
        raise ValueError('At least one --external LABEL=CHECKPOINT is required')
    unknown_logs = set(external_logs) - set(externals)
    if unknown_logs:
        raise ValueError(f"Logs supplied for unknown external methods: {sorted(unknown_logs)}")

    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    fi, meta = select_forget(data.train, args.fraction, args.seed + int(args.fraction * 10000), args.policy)
    forget = data.train[fi]
    keep = np.ones(len(data.train), dtype=bool)
    keep[fi] = False
    retain = data.train[keep]
    req_hash = request_fingerprint(data, forget)

    request_dir = Path(args.request_dir)
    manifest, all_data_path = verify_exported_request(
        request_dir, data, forget, args.dataset, args.policy, args.seed, args.fraction
    )
    entity2id, relation2id = graphdpo_vocab(all_data_path)

    schema_rows: dict[str, dict[str, str]] = {}
    for label, path in schemas.items():
        row = select_schema_row(path, args.dataset, args.model, args.policy, args.seed, args.fraction)
        if as_int(row, 'forget_n') != len(forget):
            raise RuntimeError(f"{label}: SchemaCert forget_n={as_int(row, 'forget_n')} but reconstructed request has {len(forget)}")
        schema_rows[label] = row

    first_label = next(iter(schema_rows))
    first = schema_rows[first_label]
    ref_global = schema_metrics(first, 'reference')
    ref_forget = schema_forget_metrics(first, 'reference')
    if ref_global['mrr'] is None or ref_forget['mrr'] is None:
        raise RuntimeError(f"{first_label} lacks extended reference metrics needed for the common comparison")
    expected_eval_n = 2 * min(len(data.test), args.eval_queries)
    expected_forget_n = 2 * min(len(forget), args.forget_eval_queries)
    if ref_global['n'] is not None and ref_global['n'] != expected_eval_n:
        raise RuntimeError(f"SchemaCert eval_rankings={ref_global['n']} but this evaluator would use {expected_eval_n}; match --eval-queries first")
    if ref_forget['n'] is not None and ref_forget['n'] != expected_forget_n:
        raise RuntimeError(f"SchemaCert forget_eval_rankings={ref_forget['n']} but this evaluator would use {expected_forget_n}; match --forget-eval-queries first")

    for label, row in schema_rows.items():
        other_ref = schema_metrics(row, 'reference')
        other_forget = schema_forget_metrics(row, 'reference')
        if not np.isclose(other_ref['mrr'], ref_global['mrr'], rtol=0.0, atol=1e-12):
            raise RuntimeError(f"{label} has a different exact-retrain global reference MRR")
        if not np.isclose(other_forget['mrr'], ref_forget['mrr'], rtol=0.0, atol=1e-12):
            raise RuntimeError(f"{label} has a different exact-retrain forget reference MRR")

    ref = {'global_mrr': ref_global['mrr'], 'forget_mrr': ref_forget['mrr']}
    rows = []
    rows.append(metric_row(
        'ExactRetrain', 'SchemaCert exact retrain', ref_global, ref_forget,
        as_float(first, 'reference_retrain_sec'), ref, req_hash
    ))
    for label, row in schema_rows.items():
        rows.append(metric_row(
            label, 'SchemaCert local update', schema_metrics(row, 'local'), schema_forget_metrics(row, 'local'),
            as_float(row, 'local_sec'), ref, req_hash
        ))

    mapped_test = map_to_graphdpo(data.test, data, entity2id, relation2id)
    mapped_forget = map_to_graphdpo(forget, data, entity2id, relation2id)
    mapped_retain = map_to_graphdpo(retain, data, entity2id, relation2id)
    mapped_valid = map_to_graphdpo(data.valid, data, entity2id, relation2id)
    truth = (mapped_retain, mapped_valid, mapped_test)
    forget_truth = (mapped_retain, mapped_valid, mapped_test, mapped_forget)

    for label, checkpoint in externals.items():
        model = load_graphdpo_checkpoint(checkpoint, len(entity2id), len(relation2id))
        global_metrics = filtered_lp(
            model, mapped_test, len(entity2id), truth, args.device,
            args.eval_batch, args.entity_chunk, args.eval_queries, args.seed,
        )
        forget_metrics = filtered_lp(
            model, mapped_forget, len(entity2id), forget_truth, args.device,
            args.eval_batch, args.entity_chunk, args.forget_eval_queries, args.seed,
        )
        rows.append(metric_row(
            label, 'official GraphDPO-family checkpoint / SchemaCert evaluator',
            global_metrics, forget_metrics, parse_native_time(external_logs.get(label)), ref, req_hash,
        ))
        del model
        if args.device.startswith('cuda'):
            torch.cuda.empty_cache()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    stem = f"{args.dataset}_{args.model}_{args.policy}_f{args.fraction:g}_s{args.seed}_common"
    csv_path = out / f'{stem}.csv'
    json_path = out / f'{stem}.json'
    fieldnames = list(rows[0].keys())
    with open(csv_path, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)
    payload = {
        'dataset': args.dataset,
        'model': args.model,
        'policy': args.policy,
        'fraction': args.fraction,
        'seed': args.seed,
        'forget_n': len(forget),
        'request_hash': req_hash,
        'request_meta': meta,
        'graphdpo_manifest': manifest,
        'evaluator': {
            'name': 'SchemaCert filtered_lp',
            'eval_queries': args.eval_queries,
            'forget_eval_queries': args.forget_eval_queries,
            'eval_batch': args.eval_batch,
            'entity_chunk': args.entity_chunk,
        },
        'rows': rows,
    }
    json_path.write_text(json.dumps(payload, indent=2))

    print(f"REQUEST_OK hash={req_hash} forget_n={len(forget)} exported_request_matches=1")
    print(f"EXACT global_mrr={ref['global_mrr']:.6f} forget_mrr={ref['forget_mrr']:.6f}")
    print('method\tglobal_mrr\tforget_mrr\tglobal_gap_exact\tforget_gap_exact\ttrain_sec')
    for row in rows:
        train = 'NA' if row['train_sec'] is None else f"{row['train_sec']:.3f}"
        print(
            f"{row['method']}\t{row['global_mrr']:.6f}\t{row['forget_mrr']:.6f}\t"
            f"{row['global_mrr_gap_to_exact']:.6f}\t{row['forget_mrr_gap_to_exact']:.6f}\t{train}"
        )
    print(f"COMMON_EVAL_CSV={csv_path}")
    print(f"COMMON_EVAL_JSON={json_path}")


if __name__ == '__main__':
    main()
