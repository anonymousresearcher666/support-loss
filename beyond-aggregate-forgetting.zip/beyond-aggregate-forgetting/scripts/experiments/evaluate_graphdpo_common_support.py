#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import torch
from torch import nn

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.train import train_model
from schemacert.unlearn import local_retrain
from scripts.run_publication_families import filtered_lp, fresh, select_forget
from scripts.experiments.evaluate_graphdpo_common import (
    as_int,
    graphdpo_vocab,
    load_graphdpo_checkpoint,
    metric_row,
    parse_named,
    parse_native_time,
    request_fingerprint,
    select_schema_row,
    verify_exported_request,
)


def parse_named_int(items: list[str]) -> dict[str, int]:
    raw = parse_named(items)
    return {k: int(v) for k, v in raw.items()}


def supported_mask(arr: np.ndarray, data, entity2id: dict[str, int], relation2id: dict[str, int]) -> np.ndarray:
    if len(arr) == 0:
        return np.zeros(0, dtype=bool)
    out = np.zeros(len(arr), dtype=bool)
    for i, (h, r, t) in enumerate(arr):
        out[i] = (
            data.entities[int(h)] in entity2id
            and data.relations[int(r)] in relation2id
            and data.entities[int(t)] in entity2id
        )
    return out


def map_supported(arr: np.ndarray, data, entity2id: dict[str, int], relation2id: dict[str, int]) -> np.ndarray:
    out = np.empty((len(arr), 3), dtype=np.int64)
    for i, (h, r, t) in enumerate(arr):
        hn = data.entities[int(h)]
        rn = data.relations[int(r)]
        tn = data.entities[int(t)]
        if hn not in entity2id or rn not in relation2id or tn not in entity2id:
            raise RuntimeError(f'Attempted to map unsupported triple: {(hn, rn, tn)}')
        out[i] = (entity2id[hn], relation2id[rn], entity2id[tn])
    return out


class SchemaCertCommonAdapter(nn.Module):
    """Expose a SchemaCert model on the GraphDPO training-vocabulary ID space.

    This is required for a genuinely common filtered-LP evaluation: both the
    query set and the candidate entity universe are exactly the same for the
    SchemaCert and GraphDPO-family models.
    """

    def __init__(self, model: nn.Module, common_entity_to_schema: np.ndarray,
                 common_relation_to_schema: np.ndarray):
        super().__init__()
        self.model = model
        self.register_buffer(
            'entity_map', torch.as_tensor(common_entity_to_schema, dtype=torch.long)
        )
        self.register_buffer(
            'relation_map', torch.as_tensor(common_relation_to_schema, dtype=torch.long)
        )

    def score(self, x: torch.Tensor) -> torch.Tensor:
        y = x.clone()
        y[:, 0] = self.entity_map[x[:, 0]]
        y[:, 1] = self.relation_map[x[:, 1]]
        y[:, 2] = self.entity_map[x[:, 2]]
        return self.model.score(y)

    def score_candidates(self, kind: str, a: torch.Tensor, b: torch.Tensor,
                         cand: torch.Tensor) -> torch.Tensor:
        ec = self.entity_map[cand]
        if kind == 'tail':
            return self.model.score_candidates(
                'tail', self.entity_map[a], self.relation_map[b], ec
            )
        if kind == 'head':
            return self.model.score_candidates(
                'head', self.relation_map[a], self.entity_map[b], ec
            )
        raise KeyError(kind)


def evaluate_common(model, test_q: np.ndarray, forget_q: np.ndarray, ne: int,
                    truth: tuple[np.ndarray, ...], forget_truth: tuple[np.ndarray, ...],
                    args):
    global_metrics = filtered_lp(
        model, test_q, ne, truth, args.device,
        args.eval_batch, args.entity_chunk, args.eval_queries, args.seed,
    )
    forget_metrics = filtered_lp(
        model, forget_q, ne, forget_truth, args.device,
        args.eval_batch, args.entity_chunk, args.forget_eval_queries, args.seed,
    )
    return global_metrics, forget_metrics


def main():
    p = argparse.ArgumentParser(
        description='Closed-world common evaluator for SchemaCert and official GraphDPO-family checkpoints.'
    )
    p.add_argument('--dataset', required=True)
    p.add_argument('--policy', default='entity', choices=['entity', 'relation', 'random'])
    p.add_argument('--fraction', required=True, type=float)
    p.add_argument('--seed', required=True, type=int)
    p.add_argument('--model', default='transe')
    p.add_argument('--data-root', default='data')
    p.add_argument('--request-dir', required=True)
    p.add_argument('--schema', action='append', default=[], help='Repeated LABEL=SchemaCertCSV for request/config verification.')
    p.add_argument('--schema-local-epochs', action='append', default=[], help='Repeated LABEL=EPOCHS; recomputed on the common candidate universe.')
    p.add_argument('--external', action='append', default=[], help='Repeated LABEL=GraphDPOCheckpoint')
    p.add_argument('--external-log', action='append', default=[], help='Repeated LABEL=GraphDPONativeLog')
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--threads', type=int, default=1)
    p.add_argument('--dim', type=int, default=128)
    p.add_argument('--epochs', type=int, default=20)
    p.add_argument('--ref-epochs', type=int, default=20)
    p.add_argument('--batch-size', type=int, default=4096)
    p.add_argument('--lr', type=float, default=0.002)
    p.add_argument('--local-lr', type=float, default=0.001)
    p.add_argument('--l2', type=float, default=1e-6)
    p.add_argument('--hops', type=int, default=1)
    p.add_argument('--eval-batch', type=int, default=16)
    p.add_argument('--entity-chunk', type=int, default=4096)
    p.add_argument('--eval-queries', type=int, default=1000)
    p.add_argument('--forget-eval-queries', type=int, default=1000)
    p.add_argument('--out', required=True)
    args = p.parse_args()

    if args.model.lower() != 'transe':
        raise NotImplementedError('Current GraphDPO campaign is TransE-only.')

    schemas = parse_named(args.schema)
    schema_epochs = parse_named_int(args.schema_local_epochs)
    externals = parse_named(args.external)
    external_logs = parse_named(args.external_log)
    if not schemas or not externals:
        raise ValueError('At least one --schema and one --external are required.')
    if set(schema_epochs) != set(schemas):
        raise ValueError(
            f'--schema-local-epochs labels must exactly match --schema labels: '
            f'schema={sorted(schemas)} local_epochs={sorted(schema_epochs)}'
        )
    unknown_logs = set(external_logs) - set(externals)
    if unknown_logs:
        raise ValueError(f'Logs supplied for unknown external methods: {sorted(unknown_logs)}')

    torch.set_num_threads(max(1, args.threads))
    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    ne_full, nr_full = len(data.entities), len(data.relations)
    fi, meta = select_forget(
        data.train, args.fraction, args.seed + int(args.fraction * 10000), args.policy
    )
    forget = data.train[fi]
    keep = np.ones(len(data.train), dtype=bool)
    keep[fi] = False
    retain = data.train[keep]
    req_hash = request_fingerprint(data, forget)

    request_dir = Path(args.request_dir)
    manifest, all_data_path = verify_exported_request(
        request_dir, data, forget, args.dataset, args.policy, args.seed, args.fraction
    )
    entity2id, relation2id = graphdpo_vocab(all_data_path)

    # Verify that the published SchemaCert rows refer to exactly this request.
    schema_rows = {}
    for label, path in schemas.items():
        row = select_schema_row(path, args.dataset, args.model, args.policy, args.seed, args.fraction)
        if as_int(row, 'forget_n') != len(forget):
            raise RuntimeError(
                f'{label}: SchemaCert forget_n={as_int(row, "forget_n")} '
                f'but reconstructed request has {len(forget)}'
            )
        schema_rows[label] = row

    # GraphDPO builds its embedding vocabulary from all_data.txt, which our
    # exporter correctly fills with TRAIN triples only. Test-only entities have
    # no GraphDPO embedding and cannot be scored. Do not invent embeddings and
    # do not leak test triples into training: use the common closed-world support.
    train_mask = supported_mask(data.train, data, entity2id, relation2id)
    retain_mask = supported_mask(retain, data, entity2id, relation2id)
    valid_mask = supported_mask(data.valid, data, entity2id, relation2id)
    test_mask = supported_mask(data.test, data, entity2id, relation2id)
    forget_mask = supported_mask(forget, data, entity2id, relation2id)
    if not forget_mask.all():
        raise RuntimeError('Forget request contains triples outside GraphDPO training vocabulary.')
    if not train_mask.all():
        raise RuntimeError('GraphDPO all_data.txt should contain the complete SchemaCert training support.')
    if test_mask.sum() == 0:
        raise RuntimeError('No SchemaCert test triples remain on the GraphDPO training-vocabulary support.')

    retain_c = map_supported(retain[retain_mask], data, entity2id, relation2id)
    valid_c = map_supported(data.valid[valid_mask], data, entity2id, relation2id)
    test_c = map_supported(data.test[test_mask], data, entity2id, relation2id)
    forget_c = map_supported(forget, data, entity2id, relation2id)
    truth_c = (retain_c, valid_c, test_c)
    forget_truth_c = (retain_c, valid_c, test_c, forget_c)

    # Common ID -> SchemaCert ID maps. The GraphDPO relation dictionary contains
    # inverse relations too; queries use only the forward relation IDs.
    schema_entity_by_name = {name: i for i, name in enumerate(data.entities)}
    schema_relation_by_name = {name: i for i, name in enumerate(data.relations)}
    common_entity_to_schema = np.empty(len(entity2id), dtype=np.int64)
    for name, idx in entity2id.items():
        common_entity_to_schema[idx] = schema_entity_by_name[name]
    common_relation_to_schema = np.zeros(len(relation2id), dtype=np.int64)
    for name, idx in relation2id.items():
        if name.endswith('_inv'):
            continue
        common_relation_to_schema[idx] = schema_relation_by_name[name]

    # Recompute SchemaCert states from the same base/config so that SchemaCert
    # and GraphDPO-family checkpoints are evaluated on the SAME query subset and
    # the SAME candidate entity universe. Stored full-universe CSV metrics are
    # deliberately not mixed into this table.
    base = fresh(args.model, ne_full, nr_full, args.dim, args.seed, args.device)
    base_stats = train_model(
        base, data.train, ne_full, args.epochs, args.batch_size,
        args.lr, args.l2, args.seed, args.device,
    )
    exact = fresh(args.model, ne_full, nr_full, args.dim, args.seed, args.device)
    exact_stats = train_model(
        exact, retain, ne_full, args.ref_epochs, args.batch_size,
        args.lr, args.l2, args.seed, args.device,
    )

    exact_adapter = SchemaCertCommonAdapter(
        exact, common_entity_to_schema, common_relation_to_schema
    ).to(args.device)
    exact_global, exact_forget = evaluate_common(
        exact_adapter, test_c, forget_c, len(entity2id), truth_c, forget_truth_c, args
    )
    ref = {'global_mrr': exact_global['mrr'], 'forget_mrr': exact_forget['mrr']}
    rows = [
        metric_row(
            'ExactRetrain', 'SchemaCert exact retrain / common closed-world evaluator',
            exact_global, exact_forget, exact_stats.seconds, ref, req_hash,
        )
    ]

    for label in schemas:
        local_epochs = schema_epochs[label]
        local, _, _ = local_retrain(
            base, data.train, fi, ne_full, args.hops, local_epochs,
            args.batch_size, args.local_lr, args.l2, args.seed, args.device,
        )
        adapter = SchemaCertCommonAdapter(
            local.model, common_entity_to_schema, common_relation_to_schema
        ).to(args.device)
        global_metrics, forget_metrics = evaluate_common(
            adapter, test_c, forget_c, len(entity2id), truth_c, forget_truth_c, args
        )
        rows.append(metric_row(
            label,
            f'SchemaCert local update L{local_epochs} / common closed-world evaluator',
            global_metrics, forget_metrics, local.seconds, ref, req_hash,
        ))
        del adapter, local
        if args.device.startswith('cuda'):
            torch.cuda.empty_cache()

    for label, checkpoint in externals.items():
        model = load_graphdpo_checkpoint(checkpoint, len(entity2id), len(relation2id)).to(args.device)
        global_metrics, forget_metrics = evaluate_common(
            model, test_c, forget_c, len(entity2id), truth_c, forget_truth_c, args
        )
        rows.append(metric_row(
            label,
            'official GraphDPO-family checkpoint / common closed-world evaluator',
            global_metrics, forget_metrics, parse_native_time(external_logs.get(label)),
            ref, req_hash,
        ))
        del model
        if args.device.startswith('cuda'):
            torch.cuda.empty_cache()

    missing_entities = [name for name in data.entities if name not in entity2id]
    missing_relations = [name for name in data.relations if name not in relation2id]
    support = {
        'graphdpo_entities': len(entity2id),
        'schemacert_entities': len(data.entities),
        'missing_test_vocab_entities': len(missing_entities),
        'missing_test_vocab_entity_examples': missing_entities[:10],
        'missing_relations': len(missing_relations),
        'test_triples_full': len(data.test),
        'test_triples_common': int(test_mask.sum()),
        'test_coverage': float(test_mask.mean()),
        'valid_triples_full': len(data.valid),
        'valid_triples_common': int(valid_mask.sum()),
        'forget_triples': len(forget),
        'forget_triples_common': int(forget_mask.sum()),
    }

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    stem = f'{args.dataset}_{args.model}_{args.policy}_f{args.fraction:g}_s{args.seed}_common_support'
    csv_path = out / f'{stem}.csv'
    json_path = out / f'{stem}.json'
    with open(csv_path, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    json_path.write_text(json.dumps({
        'dataset': args.dataset,
        'model': args.model,
        'policy': args.policy,
        'fraction': args.fraction,
        'seed': args.seed,
        'forget_n': len(forget),
        'request_hash': req_hash,
        'request_meta': meta,
        'graphdpo_manifest': manifest,
        'support': support,
        'schema_csv_rows_used_for_verification_only': schema_rows,
        'recomputed_config': {
            'dim': args.dim,
            'epochs': args.epochs,
            'ref_epochs': args.ref_epochs,
            'batch_size': args.batch_size,
            'lr': args.lr,
            'local_lr': args.local_lr,
            'l2': args.l2,
            'hops': args.hops,
            'base_train_sec': base_stats.seconds,
        },
        'rows': rows,
    }, indent=2))

    print(
        f'COMMON_SUPPORT request={req_hash} graphdpo_entities={len(entity2id)} '
        f'schemacert_entities={len(data.entities)} missing_entities={len(missing_entities)} '
        f'test={int(test_mask.sum())}/{len(data.test)} coverage={float(test_mask.mean()):.6f}'
    )
    print(f'EXACT common_global_mrr={ref["global_mrr"]:.6f} common_forget_mrr={ref["forget_mrr"]:.6f}')
    print('method\tglobal_mrr\tforget_mrr\tglobal_gap_exact\tforget_gap_exact\ttrain_sec')
    for row in rows:
        train = 'NA' if row['train_sec'] is None else f'{row["train_sec"]:.3f}'
        print(
            f'{row["method"]}\t{row["global_mrr"]:.6f}\t{row["forget_mrr"]:.6f}\t'
            f'{row["global_mrr_gap_to_exact"]:.6f}\t{row["forget_mrr_gap_to_exact"]:.6f}\t{train}'
        )
    print(f'COMMON_EVAL_CSV={csv_path}')
    print(f'COMMON_EVAL_JSON={json_path}')


if __name__ == '__main__':
    main()
