#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import time
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.train import clone_model, train_model
from schemacert.unlearn import local_retrain
from scripts.run_publication_families import fresh, select_forget
from scripts.experiments.evaluate_graphdpo_common import (
    as_int,
    graphdpo_vocab,
    load_graphdpo_checkpoint,
    metric_row,
    parse_named,
    parse_native_time,
    request_fingerprint,
    select_schema_row,
    verify_exported_request,
)
from scripts.experiments.evaluate_graphdpo_common_support import (
    SchemaCertCommonAdapter,
    evaluate_common,
    map_supported,
    supported_mask,
)


def retained_positive_degrees(retain: np.ndarray, entity_ids: np.ndarray) -> dict[int, int]:
    out: dict[int, int] = {}
    for e in entity_ids:
        e = int(e)
        out[e] = int(((retain[:, 0] == e) | (retain[:, 2] == e)).sum())
    return out


def support_aware_reset(model, init_model, retain: np.ndarray, selected: np.ndarray) -> tuple[torch.nn.Module, float, np.ndarray, dict[int, int]]:
    deg = retained_positive_degrees(retain, selected)
    unsupported = np.asarray([e for e in selected if deg[int(e)] == 0], dtype=np.int64)
    m = clone_model(model)
    st = time.time()
    if len(unsupported):
        idx = torch.as_tensor(unsupported, dtype=torch.long, device=m.entity.weight.device)
        with torch.no_grad():
            src = init_model.entity.weight.detach().to(m.entity.weight.device)
            m.entity.weight[idx] = src[idx]
            m.normalize_()
        if m.entity.weight.is_cuda:
            torch.cuda.synchronize()
    return m, time.time() - st, unsupported, deg


def main():
    p = argparse.ArgumentParser(
        description='Common closed-world evaluator including SchemaCert support-aware reset.'
    )
    p.add_argument('--dataset', required=True)
    p.add_argument('--policy', default='entity', choices=['entity'])
    p.add_argument('--fraction', required=True, type=float)
    p.add_argument('--seed', required=True, type=int)
    p.add_argument('--model', default='transe')
    p.add_argument('--data-root', default='data')
    p.add_argument('--request-dir', required=True)
    p.add_argument('--schema-csv', required=True)
    p.add_argument('--schema-local-epochs', type=int, default=5)
    p.add_argument('--external', action='append', default=[])
    p.add_argument('--external-log', action='append', default=[])
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--threads', type=int, default=1)
    p.add_argument('--dim', type=int, default=128)
    p.add_argument('--epochs', type=int, default=20)
    p.add_argument('--ref-epochs', type=int, default=20)
    p.add_argument('--batch-size', type=int, default=4096)
    p.add_argument('--lr', type=float, default=0.002)
    p.add_argument('--local-lr', type=float, default=0.001)
    p.add_argument('--l2', type=float, default=1e-6)
    p.add_argument('--hops', type=int, default=1)
    p.add_argument('--eval-batch', type=int, default=16)
    p.add_argument('--entity-chunk', type=int, default=4096)
    p.add_argument('--eval-queries', type=int, default=1000)
    p.add_argument('--forget-eval-queries', type=int, default=1000)
    p.add_argument('--out', required=True)
    args = p.parse_args()

    if args.model.lower() != 'transe':
        raise NotImplementedError('Current GraphDPO competitor campaign is TransE-only.')

    externals = parse_named(args.external)
    external_logs = parse_named(args.external_log)
    if not externals:
        raise ValueError('At least one --external competitor checkpoint is required.')
    unknown_logs = set(external_logs) - set(externals)
    if unknown_logs:
        raise ValueError(f'Logs supplied for unknown external methods: {sorted(unknown_logs)}')

    torch.set_num_threads(max(1, args.threads))
    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    ne_full, nr_full = len(data.entities), len(data.relations)
    fi, meta = select_forget(
        data.train, args.fraction, args.seed + int(args.fraction * 10000), args.policy
    )
    forget = data.train[fi]
    keep = np.ones(len(data.train), dtype=bool)
    keep[fi] = False
    retain = data.train[keep]
    req_hash = request_fingerprint(data, forget)

    selected = np.asarray(meta.get('entities', []), dtype=np.int64)
    if len(selected) == 0:
        raise RuntimeError('Entity policy returned no selected entities.')

    schema_row = select_schema_row(
        args.schema_csv, args.dataset, args.model, args.policy, args.seed, args.fraction
    )
    if as_int(schema_row, 'forget_n') != len(forget):
        raise RuntimeError(
            f'SchemaCert CSV forget_n={as_int(schema_row, "forget_n")} '
            f'but reconstructed request has {len(forget)}'
        )

    request_dir = Path(args.request_dir)
    manifest, all_data_path = verify_exported_request(
        request_dir, data, forget, args.dataset, args.policy, args.seed, args.fraction
    )
    entity2id, relation2id = graphdpo_vocab(all_data_path)

    train_mask = supported_mask(data.train, data, entity2id, relation2id)
    retain_mask = supported_mask(retain, data, entity2id, relation2id)
    valid_mask = supported_mask(data.valid, data, entity2id, relation2id)
    test_mask = supported_mask(data.test, data, entity2id, relation2id)
    forget_mask = supported_mask(forget, data, entity2id, relation2id)
    if not train_mask.all():
        raise RuntimeError('GraphDPO training vocabulary does not cover full SchemaCert training support.')
    if not forget_mask.all():
        raise RuntimeError('Forget request is not fully covered by GraphDPO training vocabulary.')
    if test_mask.sum() == 0:
        raise RuntimeError('No common-support test triples remain.')

    retain_c = map_supported(retain[retain_mask], data, entity2id, relation2id)
    valid_c = map_supported(data.valid[valid_mask], data, entity2id, relation2id)
    test_c = map_supported(data.test[test_mask], data, entity2id, relation2id)
    forget_c = map_supported(forget, data, entity2id, relation2id)
    truth_c = (retain_c, valid_c, test_c)
    forget_truth_c = (retain_c, valid_c, test_c, forget_c)

    schema_entity_by_name = {name: i for i, name in enumerate(data.entities)}
    schema_relation_by_name = {name: i for i, name in enumerate(data.relations)}
    common_entity_to_schema = np.empty(len(entity2id), dtype=np.int64)
    for name, idx in entity2id.items():
        common_entity_to_schema[idx] = schema_entity_by_name[name]
    common_relation_to_schema = np.zeros(len(relation2id), dtype=np.int64)
    for name, idx in relation2id.items():
        if name.endswith('_inv'):
            continue
        common_relation_to_schema[idx] = schema_relation_by_name[name]

    base = fresh(args.model, ne_full, nr_full, args.dim, args.seed, args.device)
    base_stats = train_model(
        base, data.train, ne_full, args.epochs, args.batch_size,
        args.lr, args.l2, args.seed, args.device,
    )
    exact = fresh(args.model, ne_full, nr_full, args.dim, args.seed, args.device)
    exact_stats = train_model(
        exact, retain, ne_full, args.ref_epochs, args.batch_size,
        args.lr, args.l2, args.seed, args.device,
    )
    init_same = fresh(args.model, ne_full, nr_full, args.dim, args.seed, args.device)

    exact_adapter = SchemaCertCommonAdapter(
        exact, common_entity_to_schema, common_relation_to_schema
    ).to(args.device)
    exact_global, exact_forget = evaluate_common(
        exact_adapter, test_c, forget_c, len(entity2id), truth_c, forget_truth_c, args
    )
    ref = {'global_mrr': exact_global['mrr'], 'forget_mrr': exact_forget['mrr']}
    rows = [
        metric_row(
            'ExactRetrain', 'SchemaCert exact retrain / common closed-world evaluator',
            exact_global, exact_forget, exact_stats.seconds, ref, req_hash,
        )
    ]

    local, _, _ = local_retrain(
        base, data.train, fi, ne_full, args.hops, args.schema_local_epochs,
        args.batch_size, args.local_lr, args.l2, args.seed, args.device,
    )
    local_adapter = SchemaCertCommonAdapter(
        local.model, common_entity_to_schema, common_relation_to_schema
    ).to(args.device)
    local_global, local_forget = evaluate_common(
        local_adapter, test_c, forget_c, len(entity2id), truth_c, forget_truth_c, args
    )
    rows.append(metric_row(
        f'SchemaCert-L{args.schema_local_epochs}',
        f'SchemaCert local update L{args.schema_local_epochs} / common closed-world evaluator',
        local_global, local_forget, local.seconds, ref, req_hash,
    ))

    reset_model, reset_sec, unsupported, deg = support_aware_reset(
        local.model, init_same, retain, selected
    )
    reset_adapter = SchemaCertCommonAdapter(
        reset_model, common_entity_to_schema, common_relation_to_schema
    ).to(args.device)
    reset_global, reset_forget = evaluate_common(
        reset_adapter, test_c, forget_c, len(entity2id), truth_c, forget_truth_c, args
    )
    rows.append(metric_row(
        f'SchemaCert+Reset-L{args.schema_local_epochs}',
        'SchemaCert local update + support-aware reset / common closed-world evaluator',
        reset_global, reset_forget, local.seconds + reset_sec, ref, req_hash,
    ))

    for label, checkpoint in externals.items():
        model = load_graphdpo_checkpoint(checkpoint, len(entity2id), len(relation2id)).to(args.device)
        global_metrics, forget_metrics = evaluate_common(
            model, test_c, forget_c, len(entity2id), truth_c, forget_truth_c, args
        )
        rows.append(metric_row(
            label,
            'official GraphDPO-family checkpoint / common closed-world evaluator',
            global_metrics, forget_metrics, parse_native_time(external_logs.get(label)),
            ref, req_hash,
        ))
        del model
        if args.device.startswith('cuda'):
            torch.cuda.empty_cache()

    missing_entities = [name for name in data.entities if name not in entity2id]
    support = {
        'graphdpo_entities': len(entity2id),
        'schemacert_entities': len(data.entities),
        'missing_test_vocab_entities': len(missing_entities),
        'test_triples_full': len(data.test),
        'test_triples_common': int(test_mask.sum()),
        'test_coverage': float(test_mask.mean()),
        'forget_triples': len(forget),
        'forget_triples_common': int(forget_mask.sum()),
        'selected_entities': selected.tolist(),
        'selected_entity_retained_positive_degree': deg,
        'unsupported_selected_entities': unsupported.tolist(),
        'unsupported_selected_count': int(len(unsupported)),
    }

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    stem = f'{args.dataset}_{args.model}_{args.policy}_f{args.fraction:g}_s{args.seed}_common_support_reset'
    csv_path = out / f'{stem}.csv'
    json_path = out / f'{stem}.json'
    with open(csv_path, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    json_path.write_text(json.dumps({
        'dataset': args.dataset,
        'model': args.model,
        'policy': args.policy,
        'fraction': args.fraction,
        'seed': args.seed,
        'forget_n': len(forget),
        'request_hash': req_hash,
        'request_meta': meta,
        'graphdpo_manifest': manifest,
        'support': support,
        'schema_csv_row_used_for_verification_only': schema_row,
        'recomputed_config': {
            'dim': args.dim,
            'epochs': args.epochs,
            'ref_epochs': args.ref_epochs,
            'schema_local_epochs': args.schema_local_epochs,
            'batch_size': args.batch_size,
            'lr': args.lr,
            'local_lr': args.local_lr,
            'l2': args.l2,
            'hops': args.hops,
            'base_train_sec': base_stats.seconds,
            'reset_sec': reset_sec,
        },
        'rows': rows,
    }, indent=2))

    print(
        f'COMMON_SUPPORT_RESET request={req_hash} graphdpo_entities={len(entity2id)} '
        f'schemacert_entities={len(data.entities)} test={int(test_mask.sum())}/{len(data.test)} '
        f'coverage={float(test_mask.mean()):.6f} unsupported={len(unsupported)}/{len(selected)}'
    )
    print('method\tglobal_mrr\tforget_mrr\tglobal_gap_exact\tforget_gap_exact\ttrain_sec')
    for r in rows:
        print(
            f"{r['method']}\t{r['global_mrr']:.6f}\t{r['forget_mrr']:.6f}\t"
            f"{r['global_mrr_gap_to_exact']:.6f}\t{r['forget_mrr_gap_to_exact']:.6f}\t"
            f"{r['train_sec']:.3f}"
        )
    print(f'COMMON_RESET_CSV={csv_path}')
    print(f'COMMON_RESET_JSON={json_path}')
    print('COMMON_EVAL_RESET_OK')


if __name__ == '__main__':
    main()
