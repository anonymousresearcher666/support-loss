#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.graphdpo_shared import (
    deterministic_xavier_restart,
    load_graphdpo_shared_checkpoint,
    local_retrain_graphdpo_shared,
)
from scripts.run_publication_families import select_forget
from scripts.experiments.evaluate_graphdpo_common import (
    graphdpo_vocab,
    metric_row,
    parse_named,
    parse_native_time,
    request_fingerprint,
    verify_exported_request,
)
from scripts.experiments.evaluate_graphdpo_common_support import (
    evaluate_common,
    map_supported,
    supported_mask,
)


def main() -> None:
    p = argparse.ArgumentParser(
        description=(
            'Fully aligned common evaluator: SchemaCert, Finetune, NG and GraphDPO '
            'share the exact same official GraphDPO pretrained TransE checkpoint.'
        )
    )
    p.add_argument('--dataset', required=True)
    p.add_argument('--policy', default='entity', choices=['entity'])
    p.add_argument('--fraction', required=True, type=float)
    p.add_argument('--seed', required=True, type=int)
    p.add_argument('--data-root', default='data')
    p.add_argument('--request-dir', required=True)
    p.add_argument('--base-checkpoint', required=True)
    p.add_argument('--exact-checkpoint', required=True)
    p.add_argument('--exact-log')
    p.add_argument('--external', action='append', default=[])
    p.add_argument('--external-log', action='append', default=[])
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--threads', type=int, default=1)
    p.add_argument('--schema-local-epochs', type=int, default=5)
    p.add_argument('--schema-local-lr', type=float, default=1e-4)
    p.add_argument('--batch-size', type=int, default=1024)
    p.add_argument('--hops', type=int, default=1)
    p.add_argument('--margin', type=float, default=8.0)
    p.add_argument('--neg-ratio', type=int, default=10)
    p.add_argument('--eval-batch', type=int, default=16)
    p.add_argument('--entity-chunk', type=int, default=4096)
    p.add_argument('--eval-queries', type=int, default=1000)
    p.add_argument('--forget-eval-queries', type=int, default=1000)
    p.add_argument('--out', required=True)
    args = p.parse_args()

    externals = parse_named(args.external)
    external_logs = parse_named(args.external_log)
    unknown_logs = set(external_logs) - set(externals)
    if unknown_logs:
        raise ValueError(f'Logs supplied for unknown external methods: {sorted(unknown_logs)}')

    torch.set_num_threads(max(1, int(args.threads)))
    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    fi, meta = select_forget(
        data.train,
        args.fraction,
        args.seed + int(args.fraction * 10000),
        args.policy,
    )
    forget = data.train[fi]
    keep = np.ones(len(data.train), dtype=bool)
    keep[fi] = False
    retain = data.train[keep]
    req_hash = request_fingerprint(data, forget)

    request_dir = Path(args.request_dir)
    manifest, all_data_path = verify_exported_request(
        request_dir,
        data,
        forget,
        args.dataset,
        args.policy,
        args.seed,
        args.fraction,
    )
    entity2id, relation2id = graphdpo_vocab(all_data_path)

    train_mask = supported_mask(data.train, data, entity2id, relation2id)
    retain_mask = supported_mask(retain, data, entity2id, relation2id)
    valid_mask = supported_mask(data.valid, data, entity2id, relation2id)
    test_mask = supported_mask(data.test, data, entity2id, relation2id)
    forget_mask = supported_mask(forget, data, entity2id, relation2id)
    if not train_mask.all():
        raise RuntimeError('GraphDPO training vocabulary does not cover full training support')
    if not forget_mask.all():
        raise RuntimeError('Forget request is not fully covered by GraphDPO training vocabulary')
    if test_mask.sum() == 0:
        raise RuntimeError('No common-support test triples remain')

    # Row order is unchanged by mapping, hence the SchemaCert forget indices are
    # valid on train_c as well.
    train_c = map_supported(data.train, data, entity2id, relation2id)
    retain_c = map_supported(retain[retain_mask], data, entity2id, relation2id)
    valid_c = map_supported(data.valid[valid_mask], data, entity2id, relation2id)
    test_c = map_supported(data.test[test_mask], data, entity2id, relation2id)
    forget_c = map_supported(forget, data, entity2id, relation2id)
    truth_c = (retain_c, valid_c, test_c)
    forget_truth_c = (retain_c, valid_c, test_c, forget_c)

    selected_schema = np.asarray(meta.get('entities', []), dtype=np.int64)
    if len(selected_schema) == 0:
        raise RuntimeError('Entity policy returned no selected entities')
    selected_common = np.asarray(
        [entity2id[data.entities[int(e)]] for e in selected_schema], dtype=np.int64
    )

    # THE key alignment invariant: this exact checkpoint is the starting state
    # for SchemaCert, Finetune, NG, and GraphDPO.  No SchemaCert-native base
    # training occurs in this evaluator.
    base = load_graphdpo_shared_checkpoint(args.base_checkpoint).to(args.device)
    if base.entity.num_embeddings != len(entity2id):
        raise RuntimeError(
            f'Base entity count {base.entity.num_embeddings} != common vocab {len(entity2id)}'
        )
    if base.relation.num_embeddings != len(relation2id):
        raise RuntimeError(
            f'Base relation count {base.relation.num_embeddings} != common vocab {len(relation2id)}'
        )

    exact = load_graphdpo_shared_checkpoint(args.exact_checkpoint).to(args.device)
    exact_global, exact_forget = evaluate_common(
        exact,
        test_c,
        forget_c,
        len(entity2id),
        truth_c,
        forget_truth_c,
        args,
    )
    ref = {'global_mrr': exact_global['mrr'], 'forget_mrr': exact_forget['mrr']}
    rows = [
        metric_row(
            'ExactRetrain',
            'official GraphDPO TransE fresh retrain on retained data / common evaluator',
            exact_global,
            exact_forget,
            parse_native_time(args.exact_log),
            ref,
            req_hash,
        )
    ]

    local, _ = local_retrain_graphdpo_shared(
        base,
        train_c,
        fi,
        len(entity2id),
        hops=args.hops,
        epochs=args.schema_local_epochs,
        batch_size=args.batch_size,
        lr=args.schema_local_lr,
        seed=args.seed,
        device=args.device,
        neg_ratio=args.neg_ratio,
        margin=args.margin,
    )
    local_global, local_forget = evaluate_common(
        local.model,
        test_c,
        forget_c,
        len(entity2id),
        truth_c,
        forget_truth_c,
        args,
    )
    rows.append(
        metric_row(
            f'SchemaCert-L{args.schema_local_epochs}',
            'SchemaCert locality on shared GraphDPO checkpoint/objective',
            local_global,
            local_forget,
            local.seconds,
            ref,
            req_hash,
        )
    )

    restarted, restart_sec, unsupported, deg = deterministic_xavier_restart(
        base,
        retain_c,
        selected_common,
        seed=args.seed + 700001 + int(args.fraction * 10000),
    )
    restart_local, _ = local_retrain_graphdpo_shared(
        restarted,
        train_c,
        fi,
        len(entity2id),
        hops=args.hops,
        epochs=args.schema_local_epochs,
        batch_size=args.batch_size,
        lr=args.schema_local_lr,
        seed=args.seed,
        device=args.device,
        neg_ratio=args.neg_ratio,
        margin=args.margin,
    )
    restart_global, restart_forget = evaluate_common(
        restart_local.model,
        test_c,
        forget_c,
        len(entity2id),
        truth_c,
        forget_truth_c,
        args,
    )
    rows.append(
        metric_row(
            f'SchemaCert+Restart-L{args.schema_local_epochs}',
            'support-aware deterministic restart BEFORE SchemaCert local update on shared base',
            restart_global,
            restart_forget,
            restart_sec + restart_local.seconds,
            ref,
            req_hash,
        )
    )

    for label, checkpoint in externals.items():
        model = load_graphdpo_shared_checkpoint(checkpoint).to(args.device)
        global_metrics, forget_metrics = evaluate_common(
            model,
            test_c,
            forget_c,
            len(entity2id),
            truth_c,
            forget_truth_c,
            args,
        )
        rows.append(
            metric_row(
                label,
                'official GraphDPO-family checkpoint / same common evaluator',
                global_metrics,
                forget_metrics,
                parse_native_time(external_logs.get(label)),
                ref,
                req_hash,
            )
        )
        del model
        if args.device.startswith('cuda'):
            torch.cuda.empty_cache()

    support = {
        'graphdpo_entities': len(entity2id),
        'graphdpo_relations_with_inverse': len(relation2id),
        'test_triples_full': len(data.test),
        'test_triples_common': int(test_mask.sum()),
        'test_coverage': float(test_mask.mean()),
        'forget_triples': len(forget),
        'selected_entities_schema_ids': selected_schema.tolist(),
        'selected_entities_common_ids': selected_common.tolist(),
        'selected_entity_retained_positive_degree': deg,
        'unsupported_selected_entities_common_ids': unsupported.tolist(),
        'unsupported_selected_count': int(len(unsupported)),
    }

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    stem = (
        f'{args.dataset}_transe_{args.policy}_f{args.fraction:g}_s{args.seed}'
        '_common_shared_base'
    )
    csv_path = out / f'{stem}.csv'
    json_path = out / f'{stem}.json'
    with open(csv_path, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    json_path.write_text(
        json.dumps(
            {
                'dataset': args.dataset,
                'model': 'transe',
                'policy': args.policy,
                'fraction': args.fraction,
                'seed': args.seed,
                'forget_n': len(forget),
                'request_hash': req_hash,
                'graphdpo_manifest': manifest,
                'base_checkpoint': str(args.base_checkpoint),
                'exact_checkpoint': str(args.exact_checkpoint),
                'alignment_invariant': (
                    'SchemaCert, Finetune, NG and GraphDPO start from the same '
                    'official GraphDPO pretrained checkpoint; exact retrain is the '
                    'official fresh retained-data retrain reference.'
                ),
                'evaluation_budget': {
                    'global_query_triples': args.eval_queries,
                    'forgotten_query_triples': args.forget_eval_queries,
                },
                'schema_update': {
                    'local_epochs': args.schema_local_epochs,
                    'local_lr': args.schema_local_lr,
                    'batch_size': args.batch_size,
                    'hops': args.hops,
                    'margin': args.margin,
                    'neg_ratio': args.neg_ratio,
                    'objective': 'GraphDPO-compatible normalized-L1 TransE margin objective',
                },
                'support': support,
                'rows': rows,
            },
            indent=2,
        )
    )

    print(
        f'SHARED_BASE request={req_hash} dataset={args.dataset} seed={args.seed} '
        f'fraction={args.fraction} test={int(test_mask.sum())}/{len(data.test)} '
        f'unsupported={len(unsupported)}/{len(selected_common)}'
    )
    print('method\tglobal_mrr\tforget_mrr\tglobal_gap_exact\tforget_gap_exact\ttrain_sec')
    for r in rows:
        print(
            f"{r['method']}\t{r['global_mrr']:.6f}\t{r['forget_mrr']:.6f}\t"
            f"{r['global_mrr_gap_to_exact']:.6f}\t{r['forget_mrr_gap_to_exact']:.6f}\t"
            f"{r['train_sec'] if r['train_sec'] is not None else float('nan'):.3f}"
        )
    print(f'SHARED_BASE_CSV={csv_path}')
    print(f'SHARED_BASE_JSON={json_path}')
    print('SHARED_BASE_EVAL_OK')


if __name__ == '__main__':
    main()
