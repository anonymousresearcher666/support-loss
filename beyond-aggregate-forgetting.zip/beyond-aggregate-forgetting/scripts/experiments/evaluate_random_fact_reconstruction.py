#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.graphdpo_shared import (
    _graphdpo_facts,
    _margin_batch,
    clone_shared,
    load_graphdpo_shared_checkpoint,
    local_retrain_graphdpo_shared,
)
from scripts.run_publication_families import select_forget
from scripts.experiments.evaluate_graphdpo_common import (
    graphdpo_vocab,
    metric_row,
    request_fingerprint,
    verify_exported_request,
)
from scripts.experiments.evaluate_graphdpo_common_support import (
    evaluate_common,
    map_supported,
    supported_mask,
)


def restart_rows_all(model, entity_ids: np.ndarray, seed: int, device: str):
    ids = np.asarray(sorted(set(map(int, entity_ids))), dtype=np.int64)
    out = clone_shared(model).to(device)
    st = time.time()
    if len(ids):
        g = torch.Generator(device="cpu")
        g.manual_seed(int(seed))
        fresh = torch.empty(
            out.entity.weight.shape,
            dtype=out.entity.weight.dtype,
            device="cpu",
        )
        nn.init.xavier_normal_(fresh, generator=g)
        idx_cpu = torch.as_tensor(ids, dtype=torch.long)
        idx_dev = idx_cpu.to(out.entity.weight.device)
        with torch.no_grad():
            out.entity.weight[idx_dev] = fresh[idx_cpu].to(out.entity.weight.device)
        if out.entity.weight.is_cuda:
            torch.cuda.synchronize()
    return out, time.time() - st


def retained_degrees(retain: np.ndarray, n_entities: int) -> np.ndarray:
    deg = np.zeros(int(n_entities), dtype=np.int64)
    if len(retain):
        np.add.at(deg, retain[:, 0], 1)
        np.add.at(deg, retain[:, 2], 1)
    return deg


def cost_aware_star_cover(forget: np.ndarray, retain: np.ndarray, n_entities: int) -> np.ndarray:
    """Deterministic low-cost vertex-cover heuristic for the forgotten edge set.

    Each forgotten triple is represented by its head/tail entity edge. For each
    edge we initially select the endpoint with lower retained degree, then prune
    redundant selected vertices from highest to lowest retained-degree cost.
    The result is guaranteed to cover every forgotten triple but is not claimed
    to be a minimum vertex cover.
    """
    if len(forget) == 0:
        return np.empty(0, dtype=np.int64)
    deg = retained_degrees(retain, n_entities)
    selected: set[int] = set()
    incident: dict[int, list[int]] = {}
    edges: list[tuple[int, int]] = []
    for i, (h, _, t) in enumerate(forget):
        h, t = int(h), int(t)
        edges.append((h, t))
        incident.setdefault(h, []).append(i)
        if t != h:
            incident.setdefault(t, []).append(i)
        if h == t:
            selected.add(h)
        elif deg[h] < deg[t]:
            selected.add(h)
        elif deg[t] < deg[h]:
            selected.add(t)
        else:
            selected.add(min(h, t))

    cover_count = np.zeros(len(edges), dtype=np.int16)
    for i, (h, t) in enumerate(edges):
        cover_count[i] = int(h in selected) + (int(t in selected) if t != h else 0)
        if cover_count[i] == 0:
            raise RuntimeError("Internal cover construction failure")

    for v in sorted(selected, key=lambda x: (int(deg[x]), x), reverse=True):
        inc = incident.get(v, [])
        if inc and all(int(cover_count[i]) >= 2 for i in inc):
            selected.remove(v)
            for i in inc:
                cover_count[i] -= 1

    if np.any(cover_count <= 0):
        raise RuntimeError("Pruned star cover does not cover all forgotten facts")
    return np.asarray(sorted(selected), dtype=np.int64)


def repair_from_retained_star(
    model,
    retain: np.ndarray,
    anchors: np.ndarray,
    n_entities: int,
    epochs: int,
    batch_size: int,
    lr: float,
    seed: int,
    device: str,
    neg_ratio: int,
    margin: float,
):
    anchors = np.asarray(sorted(set(map(int, anchors))), dtype=np.int64)
    m = clone_shared(model).to(device)
    mask = np.isin(retain[:, 0], anchors) | np.isin(retain[:, 2], anchors)
    repair_forward = retain[mask]
    facts = _graphdpo_facts(repair_forward)
    st = time.time()
    if len(facts) and len(anchors) and int(epochs) > 0:
        entity_mask = torch.zeros_like(m.entity.weight)
        entity_mask[torch.as_tensor(anchors, dtype=torch.long, device=device)] = 1.0
        hook = m.entity.weight.register_hook(lambda g, mk=entity_mask: g * mk)
        m.relation.weight.requires_grad_(False)
        opt = torch.optim.Adam([m.entity.weight], lr=float(lr))
        rng = np.random.default_rng(int(seed))
        try:
            for _ in range(int(epochs)):
                order = rng.permutation(len(facts))
                for start in range(0, len(order), int(batch_size)):
                    pos = facts[order[start:start + int(batch_size)]]
                    opt.zero_grad(set_to_none=True)
                    loss = _margin_batch(
                        m, pos, int(n_entities), int(neg_ratio), float(margin), rng, device
                    )
                    loss.backward()
                    opt.step()
        finally:
            hook.remove()
            m.relation.weight.requires_grad_(True)
    if m.entity.weight.is_cuda:
        torch.cuda.synchronize()
    return m, time.time() - st, int(len(repair_forward))


def save_shared(model, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "state_dict": {
                "ent_embeddings.weight": model.entity.weight.detach().cpu(),
                "rel_embeddings.weight": model.relation.weight.detach().cpu(),
            }
        },
        path,
    )


def add_struct(row: dict, stats: dict | None) -> dict:
    stats = stats or {}
    for key in (
        "anchor_count",
        "anchor_fraction",
        "repair_triples",
        "repair_fraction",
        "restart_sec",
        "repair_sec",
        "forget_coverage",
    ):
        row[key] = stats.get(key)
    return row


def main() -> None:
    p = argparse.ArgumentParser(
        description="Batched random-fact reconstruction variants on the shared GraphDPO TransE base."
    )
    p.add_argument("--dataset", required=True)
    p.add_argument("--fraction", type=float, default=0.10)
    p.add_argument("--seed", type=int, required=True)
    p.add_argument("--data-root", required=True)
    p.add_argument("--request-dir", required=True)
    p.add_argument("--base-checkpoint", required=True)
    p.add_argument("--exact-checkpoint", required=True)
    p.add_argument("--device", default="cuda:0")
    p.add_argument("--threads", type=int, default=1)
    p.add_argument("--epochs", type=int, default=3)
    p.add_argument("--lr", type=float, default=1e-4)
    p.add_argument("--batch-size", type=int, default=1024)
    p.add_argument("--neg-ratio", type=int, default=10)
    p.add_argument("--margin", type=float, default=8.0)
    p.add_argument("--eval-queries", type=int, default=1000)
    p.add_argument("--forget-eval-queries", type=int, default=1000)
    p.add_argument("--eval-batch", type=int, default=16)
    p.add_argument("--entity-chunk", type=int, default=4096)
    p.add_argument("--out", required=True)
    args = p.parse_args()

    torch.set_num_threads(max(1, int(args.threads)))
    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    fi, _ = select_forget(
        data.train,
        args.fraction,
        args.seed + int(args.fraction * 10000),
        "random",
    )
    forget = data.train[fi]
    keep = np.ones(len(data.train), dtype=bool)
    keep[fi] = False
    retain = data.train[keep]
    req_hash = request_fingerprint(data, forget)

    request_dir = Path(args.request_dir)
    manifest, all_data_path = verify_exported_request(
        request_dir,
        data,
        forget,
        args.dataset,
        "random",
        args.seed,
        args.fraction,
    )
    if manifest.get("request_hash") and manifest["request_hash"] != req_hash:
        raise RuntimeError("Request hash mismatch")
    entity2id, relation2id = graphdpo_vocab(all_data_path)

    train_mask = supported_mask(data.train, data, entity2id, relation2id)
    retain_mask = supported_mask(retain, data, entity2id, relation2id)
    valid_mask = supported_mask(data.valid, data, entity2id, relation2id)
    test_mask = supported_mask(data.test, data, entity2id, relation2id)
    forget_mask = supported_mask(forget, data, entity2id, relation2id)
    if not train_mask.all() or not forget_mask.all() or int(test_mask.sum()) == 0:
        raise RuntimeError("Common GraphDPO support invariant failed")

    train_c = map_supported(data.train, data, entity2id, relation2id)
    retain_c = map_supported(retain[retain_mask], data, entity2id, relation2id)
    valid_c = map_supported(data.valid[valid_mask], data, entity2id, relation2id)
    test_c = map_supported(data.test[test_mask], data, entity2id, relation2id)
    forget_c = map_supported(forget, data, entity2id, relation2id)
    truth_c = (retain_c, valid_c, test_c)
    forget_truth_c = (retain_c, valid_c, test_c, forget_c)

    base = load_graphdpo_shared_checkpoint(args.base_checkpoint).to(args.device)
    exact = load_graphdpo_shared_checkpoint(args.exact_checkpoint).to(args.device)
    if base.entity.num_embeddings != len(entity2id):
        raise RuntimeError("Base checkpoint vocabulary mismatch")

    exact_global, exact_forget = evaluate_common(
        exact, test_c, forget_c, len(entity2id), truth_c, forget_truth_c, args
    )
    ref = {"global_mrr": exact_global["mrr"], "forget_mrr": exact_forget["mrr"]}
    rows = [
        add_struct(
            metric_row(
                "ExactRetrain",
                "official GraphDPO TransE retained-data retrain / common evaluator",
                exact_global,
                exact_forget,
                None,
                ref,
                req_hash,
            ),
            None,
        )
    ]

    local, _ = local_retrain_graphdpo_shared(
        base,
        train_c,
        fi,
        len(entity2id),
        hops=1,
        epochs=5,
        batch_size=args.batch_size,
        lr=args.lr,
        seed=args.seed,
        device=args.device,
        neg_ratio=args.neg_ratio,
        margin=args.margin,
    )
    lg, lf = evaluate_common(
        local.model, test_c, forget_c, len(entity2id), truth_c, forget_truth_c, args
    )
    rows.append(
        add_struct(
            metric_row(
                "SchemaCert-L5",
                "existing direct random-fact SchemaCert update",
                lg,
                lf,
                local.seconds,
                ref,
                req_hash,
            ),
            {
                "anchor_count": len(local.affected_entities),
                "anchor_fraction": len(local.affected_entities) / len(entity2id),
                "repair_triples": local.work_unique_triples,
                "repair_fraction": local.work_unique_triples / max(1, len(retain_c)),
                "restart_sec": 0.0,
                "repair_sec": local.seconds,
                "forget_coverage": 1.0,
            },
        )
    )

    endpoint_anchors = np.unique(np.r_[forget_c[:, 0], forget_c[:, 2]]).astype(np.int64)
    ep0, ep_restart = restart_rows_all(
        base, endpoint_anchors, args.seed + 810001, args.device
    )
    ep_model, ep_repair, ep_repair_n = repair_from_retained_star(
        ep0,
        retain_c,
        endpoint_anchors,
        len(entity2id),
        args.epochs,
        args.batch_size,
        args.lr,
        args.seed + 810101,
        args.device,
        args.neg_ratio,
        args.margin,
    )
    eg, ef = evaluate_common(
        ep_model, test_c, forget_c, len(entity2id), truth_c, forget_truth_c, args
    )
    ep_stats = {
        "anchor_count": int(len(endpoint_anchors)),
        "anchor_fraction": float(len(endpoint_anchors) / len(entity2id)),
        "repair_triples": ep_repair_n,
        "repair_fraction": float(ep_repair_n / max(1, len(retain_c))),
        "restart_sec": ep_restart,
        "repair_sec": ep_repair,
        "forget_coverage": 1.0,
    }
    rows.append(
        add_struct(
            metric_row(
                f"EndpointRestartRepair-E{args.epochs}",
                "restart all endpoints touched by D_f, then repair from retained endpoint neighbourhoods",
                eg,
                ef,
                ep_restart + ep_repair,
                ref,
                req_hash,
            ),
            ep_stats,
        )
    )

    star_anchors = cost_aware_star_cover(forget_c, retain_c, len(entity2id))
    covered = np.isin(forget_c[:, 0], star_anchors) | np.isin(forget_c[:, 2], star_anchors)
    coverage = float(covered.mean()) if len(covered) else 1.0
    if coverage != 1.0:
        raise RuntimeError(f"Star cover coverage is {coverage}, expected 1.0")
    st0, st_restart = restart_rows_all(
        base, star_anchors, args.seed + 820001, args.device
    )
    st_model, st_repair, st_repair_n = repair_from_retained_star(
        st0,
        retain_c,
        star_anchors,
        len(entity2id),
        args.epochs,
        args.batch_size,
        args.lr,
        args.seed + 820101,
        args.device,
        args.neg_ratio,
        args.margin,
    )
    sg, sf = evaluate_common(
        st_model, test_c, forget_c, len(entity2id), truth_c, forget_truth_c, args
    )
    st_stats = {
        "anchor_count": int(len(star_anchors)),
        "anchor_fraction": float(len(star_anchors) / len(entity2id)),
        "repair_triples": st_repair_n,
        "repair_fraction": float(st_repair_n / max(1, len(retain_c))),
        "restart_sec": st_restart,
        "repair_sec": st_repair,
        "forget_coverage": coverage,
    }
    rows.append(
        add_struct(
            metric_row(
                f"StarCoverEraseRestore-E{args.epochs}",
                "cost-aware entity-star erase cover followed by selective retained-star restoration",
                sg,
                sf,
                st_restart + st_repair,
                ref,
                req_hash,
            ),
            st_stats,
        )
    )

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    stem = f"{args.dataset}_random_f{args.fraction:g}_s{args.seed}_reconstruction"
    save_shared(ep_model, out / f"{stem}_endpoint.tar")
    save_shared(st_model, out / f"{stem}_starcover.tar")

    csv_path = out / f"{stem}.csv"
    fields = list(rows[0].keys())
    with csv_path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)

    payload = {
        "dataset": args.dataset,
        "fraction": args.fraction,
        "seed": args.seed,
        "request_hash": req_hash,
        "forget_n": int(len(forget_c)),
        "retain_n": int(len(retain_c)),
        "entity_n": int(len(entity2id)),
        "epochs": int(args.epochs),
        "algorithm_note": (
            "EndpointRestartRepair restarts every endpoint touched by D_f. "
            "StarCoverEraseRestore uses a deterministic retained-degree-aware cover; "
            "it is a heuristic cover and is not claimed to be minimum. Both repair only "
            "from retained facts and never train on D_f."
        ),
        "endpoint": ep_stats,
        "star_cover": st_stats,
        "rows": rows,
    }
    json_path = out / f"{stem}.json"
    json_path.write_text(json.dumps(payload, indent=2))

    print(
        f"RECONSTRUCTION request={req_hash} dataset={args.dataset} fraction={args.fraction} "
        f"seed={args.seed} forget={len(forget_c)}"
    )
    print(
        f"ENDPOINT anchors={ep_stats['anchor_count']}/{len(entity2id)} "
        f"repair={ep_repair_n}/{len(retain_c)}"
    )
    print(
        f"STARCOVER anchors={st_stats['anchor_count']}/{len(entity2id)} "
        f"repair={st_repair_n}/{len(retain_c)} coverage={coverage:.6f}"
    )
    print("method\tglobal_mrr\tforget_mrr\tdG\tdF\ttime")
    for row in rows:
        t = row["train_sec"] if row["train_sec"] is not None else float("nan")
        print(
            f"{row['method']}\t{row['global_mrr']:.6f}\t{row['forget_mrr']:.6f}\t"
            f"{row['global_mrr_gap_to_exact']:.6f}\t{row['forget_mrr_gap_to_exact']:.6f}\t{t:.3f}"
        )
    print(f"RECONSTRUCTION_CSV={csv_path}")
    print(f"RECONSTRUCTION_JSON={json_path}")
    print("RANDOM_FACT_RECONSTRUCTION_OK")


if __name__ == "__main__":
    main()
