#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.graphdpo_shared import (
    deterministic_xavier_restart,
    load_graphdpo_shared_checkpoint,
    local_retrain_graphdpo_shared,
)
from scripts.run_publication_families import select_forget
from scripts.experiments.evaluate_graphdpo_common import (
    graphdpo_vocab,
    parse_named,
    request_fingerprint,
    verify_exported_request,
)
from scripts.experiments.evaluate_graphdpo_common_support import (
    evaluate_common,
    map_supported,
    supported_mask,
)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--dataset', required=True)
    p.add_argument('--fraction', required=True, type=float)
    p.add_argument('--request-seed', required=True, type=int)
    p.add_argument('--data-root', default='data')
    p.add_argument('--request-dir', required=True)
    p.add_argument('--base-checkpoint', required=True)
    p.add_argument('--reference', action='append', default=[], help='LABEL=checkpoint')
    p.add_argument('--external', action='append', default=[], help='LABEL=checkpoint')
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--eval-queries', type=int, default=1000)
    p.add_argument('--forget-eval-queries', type=int, default=1000)
    p.add_argument('--entity-chunk', type=int, default=4096)
    p.add_argument('--eval-batch', type=int, default=16)
    p.add_argument('--out', required=True)
    args = p.parse_args()

    refs = parse_named(args.reference)
    ext = parse_named(args.external)
    if not refs:
        raise ValueError('at least one --reference LABEL=path is required')

    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    fi, meta = select_forget(
        data.train,
        args.fraction,
        args.request_seed + int(args.fraction * 10000),
        'entity',
    )
    forget = data.train[fi]
    keep = np.ones(len(data.train), dtype=bool); keep[fi] = False
    retain = data.train[keep]
    request_dir = Path(args.request_dir)
    manifest, all_data_path = verify_exported_request(
        request_dir, data, forget, args.dataset, 'entity',
        args.request_seed, args.fraction,
    )
    req_hash = request_fingerprint(data, forget)
    entity2id, relation2id = graphdpo_vocab(all_data_path)

    retain_mask = supported_mask(retain, data, entity2id, relation2id)
    valid_mask = supported_mask(data.valid, data, entity2id, relation2id)
    test_mask = supported_mask(data.test, data, entity2id, relation2id)
    forget_mask = supported_mask(forget, data, entity2id, relation2id)
    if not forget_mask.all() or test_mask.sum() == 0:
        raise RuntimeError('request/test not fully evaluable on common support')
    retain_c = map_supported(retain[retain_mask], data, entity2id, relation2id)
    valid_c = map_supported(data.valid[valid_mask], data, entity2id, relation2id)
    test_c = map_supported(data.test[test_mask], data, entity2id, relation2id)
    forget_c = map_supported(forget, data, entity2id, relation2id)
    train_c = map_supported(data.train, data, entity2id, relation2id)
    truth_c = (retain_c, valid_c, test_c)
    forget_truth_c = (retain_c, valid_c, test_c, forget_c)

    # Pass the parsed evaluator namespace itself. Copying a partial list of
    # fields previously dropped `device` and `seed`. Query sampling must
    # use the same request seed for EVERY retraining reference.
    ea = argparse.Namespace(**vars(args), seed=args.request_seed)

    raw = []
    def eval_ckpt(label, path, kind):
        model = load_graphdpo_shared_checkpoint(path).to(args.device)
        gm, fm = evaluate_common(
            model, test_c, forget_c, len(entity2id), truth_c, forget_truth_c, ea
        )
        raw.append({
            'dataset': args.dataset, 'fraction': args.fraction,
            'request_seed': args.request_seed, 'request_hash': req_hash,
            'kind': kind, 'label': label, 'checkpoint': str(path),
            'global_mrr': float(gm['mrr']), 'forgotten_mrr': float(fm['mrr']),
        })
        del model
        if args.device.startswith('cuda'): torch.cuda.empty_cache()

    for label, path in refs.items(): eval_ckpt(label, path, 'reference')
    for label, path in ext.items(): eval_ckpt(label, path, 'external')

    # Recompute Restart-L5 once from the same base/request so its raw behavior can
    # be compared against every retraining reference without reusing one reference
    # to construct the intervention.
    selected_schema = np.asarray(meta.get('entities', []), dtype=np.int64)
    selected_common = np.asarray(
        [entity2id[data.entities[int(e)]] for e in selected_schema], dtype=np.int64
    )
    base = load_graphdpo_shared_checkpoint(args.base_checkpoint).to(args.device)
    restarted, _, unsupported, _ = deterministic_xavier_restart(
        base, retain_c, selected_common,
        seed=args.request_seed + 700001 + int(args.fraction * 10000),
    )
    local, _ = local_retrain_graphdpo_shared(
        restarted, train_c, fi, len(entity2id), hops=1, epochs=5,
        batch_size=1024, lr=1e-4, seed=args.request_seed,
        device=args.device, neg_ratio=10, margin=8.0,
    )
    gm, fm = evaluate_common(
        local.model, test_c, forget_c, len(entity2id), truth_c, forget_truth_c, ea
    )
    raw.append({
        'dataset': args.dataset, 'fraction': args.fraction,
        'request_seed': args.request_seed, 'request_hash': req_hash,
        'kind': 'method', 'label': 'SchemaCert+Restart-L5', 'checkpoint': '<recomputed>',
        'global_mrr': float(gm['mrr']), 'forgotten_mrr': float(fm['mrr']),
        'unsupported_selected': int(len(unsupported)),
    })

    refrows = [r for r in raw if r['kind'] == 'reference']
    methods = [r for r in raw if r['kind'] in {'method','external'}]
    gaps = []
    for m in methods:
        for r in refrows:
            gaps.append({
                'dataset': args.dataset, 'fraction': args.fraction,
                'request_seed': args.request_seed, 'request_hash': req_hash,
                'method': m['label'], 'reference': r['label'],
                'method_global_mrr': m['global_mrr'],
                'method_forgotten_mrr': m['forgotten_mrr'],
                'reference_global_mrr': r['global_mrr'],
                'reference_forgotten_mrr': r['forgotten_mrr'],
                'global_gap': abs(m['global_mrr'] - r['global_mrr']),
                'forgotten_gap': abs(m['forgotten_mrr'] - r['forgotten_mrr']),
            })

    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    stem = f"{args.dataset}_f{int(round(args.fraction*100)):02d}_reqs{args.request_seed}"
    with (out / f'{stem}_raw.csv').open('w', newline='') as f:
        fields = sorted(set().union(*(x.keys() for x in raw)))
        w=csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(raw)
    with (out / f'{stem}_gaps.csv').open('w', newline='') as f:
        w=csv.DictWriter(f, fieldnames=list(gaps[0].keys())); w.writeheader(); w.writerows(gaps)
    (out / f'{stem}.json').write_text(json.dumps({
        'manifest': manifest, 'request_hash': req_hash,
        'references': list(refs), 'methods': [x['label'] for x in methods],
        'n_raw': len(raw), 'n_gaps': len(gaps),
    }, indent=2)+'\n')
    print(f'REFERENCE_SENSITIVITY_EVAL_OK raw={len(raw)} gaps={len(gaps)}')

if __name__ == '__main__': main()
