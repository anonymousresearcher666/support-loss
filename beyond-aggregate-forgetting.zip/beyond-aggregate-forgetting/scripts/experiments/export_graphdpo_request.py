#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from scripts.run_publication_families import select_forget


def main():
    p=argparse.ArgumentParser();p.add_argument('--dataset',required=True);p.add_argument('--policy',choices=['entity','relation'],required=True)
    p.add_argument('--fraction',type=float,required=True);p.add_argument('--seed',type=int,required=True);p.add_argument('--data-root',default='data');p.add_argument('--out',required=True)
    a=p.parse_args();data=deterministic_holdout(load_dataset(*infer_paths(a.dataset,a.data_root)),seed=17)
    fi,meta=select_forget(data.train,a.fraction,a.seed+int(a.fraction*10000),a.policy);forget=data.train[fi]
    out=Path(a.out);(out/'0').mkdir(parents=True,exist_ok=True)
    def triple_str(x):
        h,r,t=map(int,x);return data.entities[h],data.relations[r],data.entities[t]
    with open(out/'all_data.txt','w') as f:
        for x in data.train:
            h,r,t=triple_str(x);f.write(f'{h}\t{r}\t{t}\n')
    chosen=set(meta.get('entities',[]))
    with open(out/'0'/'0.txt','w') as f:
        for x in forget:
            hi,ri,ti=map(int,x);h,r,t=triple_str(x)
            # GraphDPO requires one endpoint label per forgotten triple. For entity
            # requests we preserve the selected forgotten endpoint. Relation requests
            # are exported for pipeline testing only and are marked in metadata.
            if a.policy=='entity':
                fe=h if hi in chosen else (t if ti in chosen else h)
            else:
                fe=h
            f.write(f'{h}\t{r}\t{t}\t{fe}\n')
    manifest={'dataset':a.dataset,'policy':a.policy,'fraction':a.fraction,'seed':a.seed,'forget_n':int(len(fi)),'request_meta':meta,
              'graphdpo_relation_warning': a.policy=='relation'}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps(manifest))
if __name__=='__main__':main()
