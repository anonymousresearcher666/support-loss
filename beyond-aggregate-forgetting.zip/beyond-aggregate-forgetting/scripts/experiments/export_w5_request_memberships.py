#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,hashlib,json
from pathlib import Path
import numpy as np
from schemacert.data import deterministic_holdout,infer_paths,load_dataset
from scripts.experiments.run_entity_request_robustness import (
    degrees,fullstar_stratum,exact_card_high,incident,hsh,
)

CELLS=[
("CoDEx-M",17,"exact-card-high","5c6282657d322566"),
("CoDEx-M",17,"fullstar-high","3eca9c5248a68294"),
("CoDEx-M",43,"exact-card-high","14489106d36e915a"),
("CoDEx-M",43,"fullstar-high","5da58a3a2307423e"),
("FB15K-237",17,"exact-card-high","591dadfb01d85bd5"),
("FB15K-237",17,"fullstar-high","50c742ffcf0f9457"),
("FB15K-237",43,"exact-card-high","02e7d7116e8708c7"),
("FB15K-237",43,"fullstar-high","ecd8d79a2f39e42f"),
("NELL-995",17,"exact-card-high","230de1cd1c065be1"),
("NELL-995",17,"fullstar-high","4fa6a96c5a9c23fa"),
("NELL-995",43,"exact-card-high","eacc9f4c8ffcb188"),
("NELL-995",43,"fullstar-high","ab84659992c603ee"),
]

def write_csv(p,fields,rows):
    with p.open("w",newline="",encoding="utf8") as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def file_sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1<<20),b""): h.update(b)
    return h.hexdigest()

def exact_trace(train,deg,target,seed,expected_idx,expected_sel):
    nz=np.flatnonzero(deg>0); q=np.quantile(deg[nz],2/3); pool=nz[deg[nz]>q]
    rng=np.random.default_rng(seed); order=pool[rng.permutation(len(pool))]
    chosen=set(); sel=[]; trunc={"occurred":False}; considered=[]
    for pos,e0 in enumerate(order,start=1):
        e=int(e0)
        cand=[int(i) for i in incident(train,np.asarray([e])) if int(i) not in chosen]
        if not cand:
            considered.append({"pool_order_position":pos,"entity_id":e,"selected":False,"action":"skip_fully_overlapped"})
            continue
        sel.append(e); need=target-len(chosen)
        if need<=0:
            considered.append({"pool_order_position":pos,"entity_id":e,"selected":True,"selection_order":len(sel),"action":"selected_then_stop_target_met"})
            break
        if len(cand)<=need:
            chosen.update(cand)
            considered.append({"pool_order_position":pos,"entity_id":e,"selected":True,"selection_order":len(sel),"new_candidate_count":len(cand),"contributed_count":len(cand),"action":"full_new_star"})
        else:
            picked=[int(x) for x in rng.choice(np.asarray(cand,dtype=np.int64),need,replace=False)]
            ps=set(picked);chosen.update(ps)
            trunc={
                "occurred":True,"entity_id":e,"selection_order":len(sel),
                "pool_order_position":pos,"need_before":need,
                "candidate_new_train_indices":cand,
                "rng_picked_train_indices_in_draw_order":picked,
                "deleted_from_truncated_star_train_indices_sorted":sorted(ps),
                "not_deleted_from_truncated_star_train_indices":[i for i in cand if i not in ps],
            }
            considered.append({"pool_order_position":pos,"entity_id":e,"selected":True,"selection_order":len(sel),"new_candidate_count":len(cand),"contributed_count":len(picked),"action":"truncate_final_star"})
            break
    got=np.asarray(sorted(chosen),dtype=np.int64)
    if not np.array_equal(got,expected_idx): raise RuntimeError("exact-card replay index mismatch")
    if sel!=list(map(int,expected_sel)): raise RuntimeError("exact-card replay selected-order mismatch")
    return trunc,considered,float(q),int(len(pool))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--data-root",default="data")
    ap.add_argument("--null-root",type=Path,default=Path("results_cluster/review/multi_delete_independent_null_v1"))
    ap.add_argument("--out",type=Path,default=Path("results_cluster/review/w5_request_memberships_v1"))
    args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    cache={};summary=[];manifest={"training_launched":False,"holdout_seed":17,"cells":[]}

    for dataset,seed,mode,req_hash in CELLS:
        if dataset not in cache:
            data=deterministic_holdout(load_dataset(*infer_paths(dataset,args.data_root)),seed=17)
            cache[dataset]=(data,degrees(data.train,len(data.entities)))
        data,deg=cache[dataset];train=np.asarray(data.train,dtype=np.int64)
        target=max(1,int(round(.10*len(train))))
        if mode=="fullstar-high":
            build_seed=seed+9003
            idx,sel,meta=fullstar_stratum(train,deg,"high",target,build_seed)
            trunc={"occurred":False};considered=[]
            for j,e in enumerate(map(int,sel),start=1):
                considered.append({"entity_id":e,"selection_order":j,"action":"full_star"})
            rule="high-degree pool; seeded permutation; union full incident stars until union size >= target"
            q2=float(meta["q2"])
        else:
            build_seed=seed+9101
            idx,sel,meta=exact_card_high(train,deg,target,build_seed)
            trunc,considered,q2,_=exact_trace(train,deg,target,build_seed,idx,sel)
            rule="high-degree pool; seeded permutation; add previously unchosen incident triples; RNG-truncate final star to exact target"
        got=hsh(train[idx])
        if got!=req_hash: raise RuntimeError(f"{dataset} s{seed} {mode}: hash {got} != {req_hash}")

        base=f"{dataset}_s{seed}_{mode}_{req_hash}"
        js=args.null_root/f"{base}_independent_null.json"
        m=json.loads(js.read_text())
        if int(m["forget_n"])!=len(idx) or int(m["selected_n"])!=len(sel):
            raise RuntimeError(f"{base}: companion count mismatch")

        selected=list(map(int,sel));S=set(selected);ordr={e:i+1 for i,e in enumerate(selected)}
        member_count={e:0 for e in selected};rows=[]
        trunc_deleted=set(trunc.get("deleted_from_truncated_star_train_indices_sorted",[]))
        trunc_e=trunc.get("entity_id")

        for ii in map(int,idx):
            h,r,t=map(int,train[ii]);mem=[]
            if h in S: mem.append(h)
            if t in S and t!=h: mem.append(t)
            if not mem: raise RuntimeError(f"{base}: no selected membership for train index {ii}")
            for e in mem: member_count[e]+=1
            intro=min(mem,key=lambda e:ordr[e])
            rows.append({
                "dataset":dataset,"seed":seed,"mode":mode,"request_hash":req_hash,
                "train_index":ii,"h":h,"r":r,"t":t,
                "membership_count":len(mem),"selected_entity_memberships":"|".join(map(str,mem)),
                "head_is_selected":int(h in S),"tail_is_selected":int(t in S),
                "head_selection_order":ordr.get(h,""),"tail_selection_order":ordr.get(t,""),
                "introduced_by_entity_id":intro,"introduced_by_selection_order":ordr[intro],
                "introduced_in_truncated_final_star":int(ii in trunc_deleted and intro==trunc_e),
            })

        selected_rows=[]
        for e in selected:
            selected_rows.append({
                "dataset":dataset,"seed":seed,"mode":mode,"request_hash":req_hash,
                "entity_id":e,"selection_order":ordr[e],"entity_degree":int(deg[e]),
                "final_deleted_membership_count":member_count[e],
                "is_truncation_entity":int(trunc.get("occurred",False) and trunc.get("entity_id")==e),
            })

        dp=args.out/f"{base}_deleted_triples_membership.csv"
        sp=args.out/f"{base}_selected_entities.csv"
        tp=args.out/f"{base}_selection_trace.json"
        write_csv(dp,["dataset","seed","mode","request_hash","train_index","h","r","t","membership_count","selected_entity_memberships","head_is_selected","tail_is_selected","head_selection_order","tail_selection_order","introduced_by_entity_id","introduced_by_selection_order","introduced_in_truncated_final_star"],rows)
        write_csv(sp,["dataset","seed","mode","request_hash","entity_id","selection_order","entity_degree","final_deleted_membership_count","is_truncation_entity"],selected_rows)
        trace={
            "dataset":dataset,"seed":seed,"mode":mode,"request_hash":req_hash,
            "request_hash_verified":True,"train_n":len(train),"target_n":target,
            "forget_n":len(idx),"selected_n":len(sel),"construction_seed":build_seed,
            "degree_high_threshold_q2":q2,"construction_rule":rule,
            "selected_entity_ids_in_order":selected,"considered_entity_trace":considered,
            "exact_card_truncation":trunc,
            "membership_semantics":"Every selected endpoint touching a deleted triple is retained; multiple memberships are not collapsed.",
            "train_index_semantics":"Zero-based row index in deterministic_holdout(..., seed=17).train.",
            "reference_seed_a":m.get("reference_seed_a"),"reference_seed_b":m.get("reference_seed_b"),
        }
        tp.write_text(json.dumps(trace,indent=2)+"\n")
        multi=sum(int(x["membership_count"])>1 for x in rows)
        summary.append({
            "dataset":dataset,"seed":seed,"mode":mode,"request_hash":req_hash,
            "train_n":len(train),"target_n":target,"forget_n":len(idx),"selected_n":len(sel),
            "construction_seed":build_seed,"multi_membership_deleted_triples":multi,
            "truncation_occurred":int(trunc.get("occurred",False)),
            "truncation_entity_id":trunc.get("entity_id",""),
            "truncation_deleted_count":len(trunc.get("deleted_from_truncated_star_train_indices_sorted",[])),
            "truncation_omitted_count":len(trunc.get("not_deleted_from_truncated_star_train_indices",[])),
        })
        manifest["cells"].append({"dataset":dataset,"seed":seed,"mode":mode,"request_hash":req_hash,"files":[dp.name,sp.name,tp.name]})
        print(f"OK {base} forget={len(idx)} selected={len(sel)} multi={multi} trunc={trunc.get('occurred',False)}")

    sm=args.out/"W5_REQUEST_MAPPING_SUMMARY.csv"
    write_csv(sm,["dataset","seed","mode","request_hash","train_n","target_n","forget_n","selected_n","construction_seed","multi_membership_deleted_triples","truncation_occurred","truncation_entity_id","truncation_deleted_count","truncation_omitted_count"],summary)
    mp=args.out/"W5_REQUEST_MAPPING_MANIFEST.json";mp.write_text(json.dumps(manifest,indent=2)+"\n")
    hp=args.out/"MANIFEST.sha256"
    with hp.open("w") as f:
        for p in sorted(x for x in args.out.iterdir() if x.is_file() and x!=hp):
            f.write(f"{file_sha(p)}  {p.name}\n")
    print("W5_REQUEST_MEMBERSHIP_EXPORT_OK")
    print(f"out={args.out}")

if __name__=="__main__": main()
