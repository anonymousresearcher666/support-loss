#!/usr/bin/env python3
"""Inspect historical W8/RFPC artifacts without assuming their exact layout.

The script is read-only.  It searches the supplied W8 root, identifies likely
per-cell result files and offset artifacts, and prints enough schema information
to build the B3/W12 reanalysis without silently guessing field names.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, os
from pathlib import Path

LIKELY = ("rfpc","w8","variant","placement","offset","calibr","cell","result","summary")
SKIP = ("aggregate_bootstrap","discovery")

def sha256(p: Path) -> str:
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def json_schema(p: Path):
    try:
        obj=json.loads(p.read_text(errors="ignore"))
    except Exception as e:
        return {"error":str(e)}
    out={"type":type(obj).__name__}
    if isinstance(obj,dict):
        out["keys"]=list(obj.keys())[:80]
        # expose a compact set of nested dictionaries potentially containing metrics
        nested={}
        for k,v in obj.items():
            if isinstance(v,dict):
                nested[k]=list(v.keys())[:50]
        out["nested_keys"]=nested
    elif isinstance(obj,list):
        out["length"]=len(obj)
        if obj and isinstance(obj[0],dict):
            out["row_keys"]=list(obj[0].keys())[:80]
            out["first_row"]=obj[0]
    return out

def csv_schema(p: Path):
    try:
        with p.open(newline="",encoding="utf8",errors="ignore") as f:
            r=csv.DictReader(f)
            rows=[]
            for i,row in enumerate(r):
                rows.append(row)
                if i>=2: break
        return {"columns":r.fieldnames or [],"sample_rows":rows}
    except Exception as e:
        return {"error":str(e)}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",type=Path,required=True)
    ap.add_argument("--out",type=Path)
    args=ap.parse_args()
    root=args.root.resolve()
    if not root.exists(): raise FileNotFoundError(root)

    files=[]
    for p in root.rglob("*"):
        if not p.is_file(): continue
        low=str(p).lower()
        if any(s in low for s in SKIP): continue
        if p.suffix.lower() not in {".json",".csv",".npz",".pt",".pth"}: continue
        if not any(s in low for s in LIKELY): continue
        rec={
            "path":str(p),
            "relative":str(p.relative_to(root)),
            "size":p.stat().st_size,
            "sha256":sha256(p),
            "ext":p.suffix.lower(),
        }
        if p.suffix.lower()==".json":
            rec["schema"]=json_schema(p)
        elif p.suffix.lower()==".csv":
            rec["schema"]=csv_schema(p)
        files.append(rec)

    # Prefer files that look per-cell rather than global.
    def score(x):
        s=x["relative"].lower()
        v=0
        for token in ("seed17","seed29","seed43","fb15","codex","nell","fullstar","exact-card"):
            if token in s:v+=3
        for token in ("offset","cell","result","summary"):
            if token in s:v+=1
        return (-v,x["relative"])
    files.sort(key=score)

    out={
        "root":str(root),
        "n_files":len(files),
        "files":files[:250],
    }
    txt=json.dumps(out,indent=2)
    print(txt)
    if args.out:
        args.out.parent.mkdir(parents=True,exist_ok=True)
        args.out.write_text(txt+"\n")
    print("W8_ARTIFACT_SCHEMA_INSPECTION_OK",len(files))

if __name__=="__main__":
    main()
