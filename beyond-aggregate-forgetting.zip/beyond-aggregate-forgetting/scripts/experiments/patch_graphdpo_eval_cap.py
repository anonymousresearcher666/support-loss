#!/usr/bin/env python3
"""Patch a GraphDPO worktree so internal validation uses a bounded ranking sample.

This changes only GraphDPO's internal pretrain/unlearning validation datasets used
for checkpoint selection and native reporting. It does not change the training
examples, negative sampling, optimizer, or SchemaCert's downstream common-support
evaluator.
"""

from __future__ import annotations

import argparse
from pathlib import Path

MARKER = "SCHEMACERT_EVAL_CAP_PATCH"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--graphdpo-root", required=True)
    parser.add_argument("--max-rankings", type=int, default=2000)
    args = parser.parse_args()

    if args.max_rankings <= 0:
        raise ValueError("--max-rankings must be positive")

    path = Path(args.graphdpo_root) / "src" / "data_load" / "data_loader.py"
    text = path.read_text()

    if MARKER in text:
        print(f"GRAPHDPO_EVAL_CAP_ALREADY_PATCHED path={path}")
        return

    header = "from src.utils import *\n"
    if header not in text:
        raise RuntimeError(f"Unexpected GraphDPO data_loader.py header: {path}")

    helper = f'''from src.utils import *\n\n# {MARKER}\n# Cap only internal full-ranking validation/checkpoint-selection work.\n# Sampling is deterministic for each seed and dataset split.\n_SCHEMACERT_MAX_RANKINGS = {args.max_rankings}\n\ndef _schemacert_cap_eval(items, seed_offset, seed):\n    if len(items) <= _SCHEMACERT_MAX_RANKINGS:\n        return items\n    import random as _random\n    _rng = _random.Random(int(seed) + int(seed_offset))\n    _idx = sorted(_rng.sample(range(len(items)), _SCHEMACERT_MAX_RANKINGS))\n    return [items[i] for i in _idx]\n'''
    text = text.replace(header, helper, 1)

    pretrain_old = "        self.test = self.build_facts()\n"
    pretrain_new = (
        "        self.test = self.build_facts()\n"
        "        self.test = _schemacert_cap_eval(self.test, 101, self.args.seed)\n"
    )
    if text.count(pretrain_old) != 1:
        raise RuntimeError(
            f"Expected exactly one TestDataset constructor pattern, found {text.count(pretrain_old)}"
        )
    text = text.replace(pretrain_old, pretrain_new, 1)

    split_old = "        self.valid, self.test = self.build_facts()\n"
    split_new = (
        "        self.valid, self.test = self.build_facts()\n"
        "        self.valid = _schemacert_cap_eval(self.valid, 201, self.args.seed)\n"
        "        self.test = _schemacert_cap_eval(self.test, 202, self.args.seed)\n"
    )
    nsplit = text.count(split_old)
    if nsplit < 2:
        raise RuntimeError(
            f"Expected Forget/Reserve validation constructors, found only {nsplit}"
        )
    text = text.replace(split_old, split_new)

    path.write_text(text)
    print(
        f"GRAPHDPO_EVAL_CAP_PATCHED path={path} max_rankings={args.max_rankings} "
        f"split_constructors={nsplit}"
    )


if __name__ == "__main__":
    main()
