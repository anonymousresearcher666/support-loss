"""Recreate the reference-budget TeX tables and four-panel display from raw results."""
from pathlib import Path
import json,csv,shutil,hashlib
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,required=True);ap.add_argument('--repo',type=Path,default=Path('.'));args=ap.parse_args()
root=args.results;repo=args.repo;sec=repo/'paper/sections'
s=json.loads((root/'summary.json').read_text());a=json.loads((root/'output_distinguisher_summary.json').read_text())
G={(r['dataset'],r['budget'],r['method']):r for r in s['aggregates']}
# Narrative values below describe the archived six-run cohort. Fail closed
# instead of silently emitting stale prose for a different experiment.
if round(G['CoDEx-M',100,'ResetLocal']['test_gap_mean'],5)!=0.02858:
    raise ValueError('Different cohort: regenerate numerical narrative before rendering')
A={(r['dataset'],r['reference_budget'],r['method']):r for r in a['summary']}
names={'Unchanged':'Unchanged','ResetOnly':'Reset only','Local':'Local','ResetLocal':'Reset+Local','FullRetain':'Full retained FT','ResetFullRetain':'Reset+full FT','ResetDenseSameWork':'Reset+dense, same work'}
methods=list(names)
tex=r'''\begin{table}[!ht]
\centering\small
\caption{New full-split DistMult study. Each entry is the mean test/forgotten MRR gap over three seeds, computed per seed before averaging. Columns change only the retained-reference checkpoint; method predictions are fixed. All five iterative controls receive the same number of positive presentations and optimizer steps.}
\label{tab:reference-budget-full}
\setlength{\tabcolsep}{7pt}
\begin{tabular}{@{}llccc@{}}\toprule
Dataset & Method & Ref20 & Ref50 & Ref100\\\midrule
'''
for ds in ['FB15K-237','CoDEx-M']:
 for j,m in enumerate(methods):
  vals=[f"{G[ds,b,m]['test_gap_mean']:.5f}/{G[ds,b,m]['forgotten_gap_mean']:.5f}" for b in [20,50,100]]
  tex+=(ds if j==0 else '')+' & '+names[m]+' & '+' & '.join(vals)+r'\\'+'\n'
 if ds=='FB15K-237':tex+=r'\midrule'+'\n'
tex+=r'''\bottomrule\end{tabular}
\end{table}

\paragraph{The reconstruction effect survives the reference-budget test.}
Reset+Local has smaller forgotten gaps than both Local and reset-only in all 18 matched seed--budget comparisons (six underlying replications). Its mean forgotten gap changes only .00696 to .00699 on FB15K-237 and .00249 to .00249 on CoDEx-M when the reference changes from 20 to 100 epochs. By contrast, the local update without reconstruction remains at approximately .333 and .143. A longer reference therefore does not explain away the support-loss effect in this cohort.

\paragraph{Global fidelity does depend on the reference and the control.}
Reset+Local is not uniformly best. Against reset plus full retained finetuning, it wins on forgotten fidelity in 15/18 comparisons but on test fidelity in only 6/18. At 100 epochs, full retained finetuning after the same reset has a smaller mean test gap on both graphs. Reset+Local instead has the smaller forgotten mean. The dense-same-work control changes only parameter masking and gives a larger forgotten gap in all 18 comparisons. These results support a reconstruction effect and a localization trade-off, not universal superiority of a local optimizer.

\begin{table}[!ht]
\centering\small
\caption{Test-set scalar versus per-query fidelity. $E_{\rm RR}$ is mean absolute reciprocal-rank difference on identical queries. Method rows average three coupled-seed comparisons; reference-pair rows average the three independent-seed pairs within a budget. These are descriptive means, not confidence intervals.}
\label{tab:query-fidelity}
\begin{tabular}{@{}llrrrr@{}}\toprule
 & &\multicolumn{2}{c}{Ref20}&\multicolumn{2}{c}{Ref100}\\
\cmidrule(lr){3-4}\cmidrule(l){5-6}
Dataset&Comparison&$\Delta M$&$E_{\rm RR}$&$\Delta M$&$E_{\rm RR}$\\\midrule
'''
V={(r['dataset'],r['budget']):r for r in s['reference_variability']}
for ds in ['FB15K-237','CoDEx-M']:
 for label,m in [('Reset+Local vs ref','ResetLocal'),('Ref vs independent ref',None)]:
  vals=[]
  for b in [20,100]:
   r=G[ds,b,m] if m else V[ds,b]
   vals += [f"{r['test_gap_mean']:.5f}",f"{r['test_rr_mae_mean']:.5f}"]
  tex+=ds+' & '+label+' & '+' & '.join(vals)+r'\\'+'\n'
tex+=r'''\bottomrule\end{tabular}
\end{table}

\paragraph{Aggregate agreement hides prediction-level differences.}
On CoDEx-M, Reset+Local's test gap to Ref20 is .00488 but its per-query discrepancy is .05469; to Ref100 these become .02858 and .08943. Independent retraining seeds themselves produce substantial per-query variation (Table~\ref{tab:query-fidelity}), so zero disagreement is not the expected behavioral baseline. Nevertheless, a small aggregate MRR gap alone does not establish agreement of individual predictions. The mean test MRR of the reference changes .15587 to .13844 on FB15K-237 and .15379 to .17749 on CoDEx-M between 20 and 100 epochs. More training therefore changes the reference in different directions on the two graphs and must not be equated with universally improved held-out performance.
'''
tex+=r'''
\subsection{An output-based distinguishability diagnostic}
After completing the fixed training cohort, we fit a simple diagnostic classifier; no model or hyperparameter is selected using its results. A standardized, $L_2$-regularized logistic regression distinguishes an unlearned model's outputs from a retained reference's outputs on forgotten queries. Its three features are the true-triple score, log head rank, and log tail rank. Training uses half of the fixed query IDs and two model seeds; testing uses the other query half and the held-out seed. Both queries and model seeds are disjoint between fitting and evaluation. Each held-out fold has 128 queries per class. The split seed, features, penalty, and solver are fixed in the supplied script, and test labels are never used to reverse the fitted score orientation.

The study reports 138 folds: all seven interventions, three reference budgets, two graphs, and three held-out seeds, plus Ref20-versus-Ref50/Ref100 budget-shift controls. The latter measure distinguishability caused solely by additional retained training. We do not treat correlated query outputs as independent model samples or derive population confidence intervals from them. This is a removal-output distinguisher on noiseless behavioral checkpoints, not a membership test for arbitrary training facts, a complete adversary suite, or a test of the interval-verified Gaussian mechanism.

\begin{table}[!ht]
\centering\small
\caption{Held-out output-distinguisher AUC, averaged over three disjoint-model-seed folds. AUC .5 denotes chance ordering; larger values mean that this fitted classifier distinguishes the two output sources. All methods and both tested reference budgets are shown. Ref20 against itself is omitted rather than used as a tautological null. The complete Ref50 folds and ranges are in the raw records.}
\label{tab:output-distinguishability}
\begin{tabular}{@{}lrrrr@{}}\toprule
&\multicolumn{2}{c}{FB15K-237}&\multicolumn{2}{c}{CoDEx-M}\\
\cmidrule(lr){2-3}\cmidrule(l){4-5}
Candidate&Ref20&Ref100&Ref20&Ref100\\\midrule
'''
for m in methods+['Reference20']:
 vals=[]
 for ds in ['FB15K-237','CoDEx-M']:
  for b in [20,100]:vals.append(f"{A[ds,b,m]['mean_auc']:.4f}" if (ds,b,m) in A else '--')
 tex+=names.get(m,'Ref20 (budget shift)')+' & '+' & '.join(vals)+r'\\'+'\n'
tex+=r'''\bottomrule\end{tabular}
\end{table}

The small forgotten-MRR gaps do not make these noiseless updates indistinguishable. Against Ref100, Reset+Local yields AUC .9864 on FB15K-237 and 1.0000 on CoDEx-M. Even independently trained Ref20 versus Ref100 is distinguishable (AUC .8621 and .9854), showing that training budget itself changes the output distribution. These outcomes narrow the practical claim: reconstruction strongly reduces inherited forgotten performance, but does not reproduce every aspect of a retained-model distribution. They motivate the verified release gate rather than replacing it, and do not extend its assumptions to the large-scale models.
'''
(sec/'reference_budget_tables.tex').write_text(tex)
# Compact primary display: actual 100-epoch comparisons, not a pooled leaderboard.
main=r'''\begin{wraptable}{r}{.53\linewidth}
\centering\caption{Full-split DistMult: test/forgotten gaps to Ref100 (three seeds). Optimized rows have equal step counts.}
\label{tab:human-reference-controls}
\scriptsize\setlength{\tabcolsep}{2.7pt}
\begin{tabular}{@{}lcc@{}}\toprule
Variant & FB15K-237 & CoDEx-M\\\midrule
'''
for m in ['ResetOnly','ResetLocal','ResetFullRetain']:
 main+=names[m]+' & '+' & '.join(f"{G[ds,100,m]['test_gap_mean']:.4f}/{G[ds,100,m]['forgotten_gap_mean']:.4f}" for ds in ['FB15K-237','CoDEx-M'])+r'\\'+'\n'
main+=r'''\bottomrule\end{tabular}
\end{wraptable}
'''
(sec/'reference_budget_main_table.tex').write_text(main)
# Derived four-panel numerical display, reproducible source arrays in JSON.
coords=lambda vals:' '.join(f'({x},{y:.9g})' for x,y in vals)
fig=r'''\begin{figure}[!ht]
\centering
\begin{tikzpicture}
\begin{groupplot}[humanaxis,group style={group size=4 by 1,horizontal sep=.9cm},scale only axis,width=.168\linewidth,height=1.95cm]
\nextgroupplot[title={(a) Verified pass (\%)},xmode=log,xmin=5e-11,xmax=2e-6,xtick={1e-10,1e-8,1e-6},ymin=0,ymax=105,ytick={0,50,100},xlabel={tolerance $\tau_p$}]
\addplot[scorange,mark=square*,mark size=1.6pt] coordinates {(1e-10,61.11111)(1e-8,89.81481)(1e-6,100)};
\addplot[scblue,mark=*,mark size=1.5pt] coordinates {(1e-10,0)(1e-8,0)(1e-6,100)};
\nextgroupplot[title={(b) Pass / 108},ymin=0,ymax=122,ytick={0,54,108},symbolic x coords={Keep,Reset,Local},xtick=data,xlabel={$\tau_p=10^{-6}$},ybar,bar width=8pt,nodes near coords,every node near coord/.append style={font=\scriptsize}]
\addplot[scblue,fill=scblue!65] coordinates {(Keep,24)(Reset,28)(Local,108)};
\nextgroupplot[title={(c) Forgotten gap},ymode=log,ymin=.001,ymax=.7,ytick={.001,.01,.1},xmin=15,xmax=105,xtick={20,50,100},xlabel={reference epochs}]
'''
for ds,style in [('FB15K-237','solid'),('CoDEx-M','dashed')]:
 for m,color,mark in [('Local','scorange','square*'),('ResetLocal','scblue','*')]:
  fig+=f'\\addplot[{style},{color},mark={mark},mark size=1.6pt] coordinates {{'+coords([(b,G[ds,b,m]['forgotten_gap_mean']) for b in [20,50,100]])+'};\n'
fig+=r'''\nextgroupplot[title={(d) Output AUC},ymin=.48,ymax=1.04,ytick={.5,.75,1},xmin=.5,xmax=2.5,xtick={1,2},xticklabels={Reset+L,Ref20},xlabel={versus Ref100}]
'''
for ds,color,mark in [('FB15K-237','scblue','*'),('CoDEx-M','scorange','square*')]:
 fig+=f'\\addplot[only marks,{color},mark={mark},mark size=2pt] coordinates {{'+coords([(j+1,A[ds,100,m]['mean_auc']) for j,m in enumerate(['ResetLocal','Reference20'])])+'};\n'
fig+=r'''\end{groupplot}
\end{tikzpicture}
\caption{Verification and full-scale stress tests. (a,b) Verified first-region (blue) and with-expansion (orange) passes; unchanged/reset/local controls. (c) DistMult forgotten gaps: Local orange, Reset+Local blue; FB15K-237 solid, CoDEx-M dashed. (d) Output-distinguisher AUC: FB15K-237 blue, CoDEx-M orange; high values reveal distinguishability. Panels (c,d) are three-seed means on noiseless models. Protocols and all folds: Appendices I--J.}
\label{fig:human-stress}
\end{figure}
'''
(sec/'human_stress_figure.tex').write_text(fig)
