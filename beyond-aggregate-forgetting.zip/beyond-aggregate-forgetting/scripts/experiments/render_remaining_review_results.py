"""Render new controls from measured CSVs, with no imputed cells or best-of selection."""
from pathlib import Path
import argparse,csv,json


def read(p):
    with p.open() as f:return list(csv.DictReader(f))


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,required=True)
    ap.add_argument('--paper',type=Path,default=Path('paper'));a=ap.parse_args()
    root=a.results;sec=a.paper/'sections'
    A={(r['dataset'],int(r['reference_budget']),r['candidate'],r['features']):r for r in read(root/'feature_attack_summary.csv')}
    B={(r['dataset'],int(r['reference_budget']),r['method'],int(r['budget'])):r for r in read(root/'budget_summary.csv')}
    D={(r['dataset'],r['candidate']):r for r in read(root/'damage_summary.csv')}
    mean=lambda r,k:float(r[k+'_mean'])
    dslist=['FB15K-237','CoDEx-M'];names={'ResetLocal':'Reset+Local','ResetOnly':'Reset only','AllFresh':'AllFresh','AllZero':'AllZero','IndependentRef20Null':'Independent Ref20'}
    t=r'''\begin{table}[!ht]
\centering\small
\caption{Feature ablations against Ref20. Entries are held-out-model/query AUC means over three folds, with descriptive min--max ranges below for the null. High rank-only AUC cannot be explained by a difference in raw-score scale alone. The independent-reference null uses six distinct trained models per graph.}
\label{tab:remaining-auc}
\setlength{\tabcolsep}{6pt}
\begin{tabular}{@{}llrrr@{}}\toprule
Graph & Candidate & Score only & Ranks only & Joint\\\midrule
'''
    for ds in dslist:
        for cand in names:
            vals=[mean(A[ds,20,cand,f],'roc_auc') for f in ['score','ranks','joint']]
            t+=ds+' & '+names[cand]+' & '+' & '.join(f'{v:.4f}' for v in vals)+r'\\'+'\n'
        t+=r'\midrule'+'\n'
    t+=r'''\bottomrule\end{tabular}
\end{table}
'''
    t+='\\paragraph{The discrepancy is not just score calibration.}\n'
    for ds in dslist:
        r=[mean(A[ds,20,'ResetLocal',f],'roc_auc') for f in ['score','ranks','joint']]
        n=A[ds,20,'IndependentRef20Null','joint']
        t+=f"On {ds}, Reset+Local has score/rank/joint AUC {r[0]:.4f}/{r[1]:.4f}/{r[2]:.4f}. The independent same-budget reference comparison has joint mean {mean(n,'roc_auc'):.4f} (fold range {float(n['roc_auc_min']):.4f}--{float(n['roc_auc_max']):.4f}). "
    t+='The rank-only results demonstrate a ranking mismatch in this cohort, rather than merely a removable global score calibration. The nonzero null variation cautions against equating every AUC departure from .5 with a deletion effect. Three seed-pair folds are insufficient for a distribution-free threshold or significance claim.\n\n'
    t+=r'''\begin{table}[!ht]
\centering\small
\caption{Utility and forgotten performance of destructive controls. Retained MRR uses retained training queries; test MRR uses held-out test queries. Means span three model seeds per graph. Reset+Local denotes its five-budget endpoint. Low forgotten MRR alone can reward a model whose useful predictions were destroyed.}
\label{tab:remaining-damage}
\begin{tabular}{@{}llrrr@{}}\toprule
Graph & Candidate & Test MRR & Retained MRR & Forgotten MRR\\\midrule
'''
    for ds in dslist:
        for cand in ['Reference20','ResetLocal','AllFresh','AllZero']:
            r=D[ds,cand]
            t+=ds+' & '+names.get(cand,cand)+' & '+' & '.join(f"{mean(r,k):.6f}" for k in ['test_mrr','retained_mrr','forgotten_mrr'])+r'\\'+'\n'
        t+=r'\midrule'+'\n'
    t+=r'''\bottomrule\end{tabular}
\end{table}
\paragraph{Damage and removal are different questions.}
The destructive controls must be judged jointly with test/retained utility, not only forgotten MRR or classifier AUC. AllZero produces tied scores and AllFresh removes every learned row, whereas support-aware reconstruction retains most inherited parameters. Neither successful discrimination nor poor forgotten ranking alone establishes arbitrary fact extraction. These controls strengthen interpretation of the negative result; they do not turn the noiseless method into a certified removal mechanism.
'''
    direction=read(root/'directional_summary.csv')
    dr={(r['dataset'],r['comparison'],r['rank_side']):r for r in direction}
    med={(r['dataset'],r['candidate']):r for r in read(root/'directional_medians.csv')}
    t+=r'''\paragraph{Exploratory head--tail follow-up.}
After the primary feature ablation, we examined head-only and tail-only ranks with the same held-out splits. This additional 24-fold analysis is exploratory, not part of the earlier fixed feature grid; no model selection uses it.
\begin{center}\small
\begin{tabular}{@{}lrrrr@{}}\toprule
&\multicolumn{2}{c}{Update vs Ref20 AUC}&\multicolumn{2}{c}{Median tail rank}\\
\cmidrule(lr){2-3}\cmidrule(l){4-5}
Graph&Head only&Tail only&Reset+Local&Ref20\\\midrule
'''
    for ds in dslist:
        h=mean(dr[ds,'update','head'],'roc_auc');ta=mean(dr[ds,'update','tail'],'roc_auc')
        l=mean(med[ds,'ResetLocal'],'tail_median_rank');r=mean(med[ds,'Reference20'],'tail_median_rank')
        t+=f"{ds} & {h:.4f} & {ta:.4f} & {l:.1f} & {r:.1f}"+r'\\'+'\n'
    t+=r'''\bottomrule\end{tabular}\end{center}
Median ranks are averaged over the three model seeds. Tail ranks carry a strong signal in this tail-corruption cohort, while combining head and tail ranks is stronger still on FB15K-237. This descriptive localization is not a causal attribution to the negative sampler or a claim about every embedding family. A strictly increasing common transformation of candidate scores preserves their ranks, so score calibration alone cannot remove a rank-only distinguisher's observed signal.
'''
    (sec/'remaining_feature_tables.tex').write_text(t)
    t=''
    for ref in [20,100]:
        t+=rf'''\begin{{table}}[!ht]
\centering\small
\caption{{Fixed-grid repair budgets against Ref{ref}. Entries are mean test/forgotten gaps over three seeds. Budget $b$ denotes $b|R|$ positive presentations. Every compared iterative strategy has the same update count at a given $b$. The dense-same-work control changes the mask but not the positive or negative stream.}}
\label{{tab:remaining-budget-{ref}}}
\setlength{{\tabcolsep}}{{5pt}}
\begin{{tabular}}{{@{{}}lrccc@{{}}}}\toprule
Graph & $b$ & Reset+Local & Reset+full FT & Dense same work\\\midrule
'''
        for ds in dslist:
            for b in [0,1,3,5,10]:
                vals=[]
                for m in ['ResetLocal','ResetFullRetain','ResetDenseSameWork']:
                    r=B[ds,ref,m,b];vals.append(f"{mean(r,'test_gap'):.5f}/{mean(r,'forgotten_gap'):.5f}")
                t+=ds+' & '+str(b)+' & '+' & '.join(vals)+r'\\'+'\n'
            t+=r'\midrule'+'\n'
        t+=r'''\bottomrule\end{tabular}
\end{table}
'''
    t+=r'''\paragraph{There is a budget-dependent trade-off, not one dominant repair.}
At one retained-set-equivalent presentation budget, full retained repair has a smaller mean forgotten gap on both graphs. At budget 10, local repair has the smaller forgotten gap in all six seed comparisons to either Ref20 or Ref100. Against Ref20, the local/full forgotten means are '''
    for i,ds in enumerate(dslist):
        l=B[ds,20,'ResetLocal',10];f=B[ds,20,'ResetFullRetain',10]
        t+=f"{mean(l,'forgotten_gap'):.5f}/{mean(f,'forgotten_gap'):.5f} on {ds}"+(' and ' if i==0 else '. ')
    t+=r'''On FB15K-237, full retained repair nevertheless has the smaller mean test gap at every positive budget shown. On CoDEx-M, local repair wins both gaps at budget 10 against Ref20 in all three seeds, but the mean test preference reverses against Ref100. Thus the preferred intervention depends on the declared reference, available repair work, and which fidelity coordinate matters. The experiment does not identify a reference-independent best method or an automatically selected operating policy.
'''
    (sec/'remaining_budget_tables.tex').write_text(t)
    # Four main panels retain the table-plus-panels presentation. Explicit in-panel
    # legends identify methods and graph line styles; no fitted frontier is implied.
    g=r'''\begin{figure}[!ht]
\centering
\begin{tikzpicture}
\begin{groupplot}[humanaxis,group style={group size=4 by 1,horizontal sep=.95cm},scale only axis,width=.166\linewidth,height=2.15cm]
\nextgroupplot[title={(a) Verified pass (\%)},xmode=log,xmin=5e-11,xmax=2e-6,xtick={1e-10,1e-8,1e-6},ymin=0,ymax=105,ytick={0,50,100},xlabel={tolerance $\tau_p$},legend style={font=\tiny,draw=none,at={(.02,.97)},anchor=north west,fill=white,inner sep=1pt}]
\addplot[scblue,mark=*,mark size=1.3pt] coordinates {(1e-10,0)(1e-8,0)(1e-6,100)};
\addlegendentry{First region}
\addplot[scorange,mark=square*,mark size=1.3pt] coordinates {(1e-10,61.11111)(1e-8,89.81481)(1e-6,100)};
\addlegendentry{+Expansion}
'''
    for metric,title,ys in [('test_gap','(b) Test gap',r'ymin=0,ymax=.04,ytick={0,.02,.04}'),('forgotten_gap','(c) Forgotten gap',r'ymode=log,ymin=.0005,ymax=.1,ytick={.001,.01,.1}')]:
        g+=rf'''\nextgroupplot[title={{{title}}},xmin=-.3,xmax=10.3,xtick={{0,5,10}},xlabel={{budget $b$}}, {ys},legend style={{font=\tiny,draw=none,at={{(.98,.97)}},anchor=north east,fill=white,inner sep=1pt}}]
'''
        for i,(ds,style) in enumerate([('FB15K-237','solid'),('CoDEx-M','dashed')]):
            for j,(m,color,mark,label) in enumerate([('ResetLocal','scblue','*','Reset+Local'),('ResetFullRetain','scorange','square*','Reset+FT')]):
                coords=' '.join(f"({b},{mean(B[ds,20,m,b],metric):.10g})" for b in [0,1,3,5,10])
                g+=rf'\addplot[{style},{color},mark={mark},mark size=1.2pt] coordinates {{{coords}}};'+'\n'
                if i==0:g+=r'\addlegendentry{'+label+'}\n'
                else:g+=r'\addlegendentry{'+('CM Local' if j==0 else 'CM FT')+'}\n'
    g+=r'''\nextgroupplot[title={(d) Output AUC},ymin=0,ymax=1.07,ytick={0,.5,1},xmin=.7,xmax=3.3,xtick={1,2,3},xticklabels={S,R,J},xlabel={feature set},legend style={font=\tiny,draw=none,at={(.98,.03)},anchor=south east,fill=white,inner sep=1pt}]
'''
    for cand,ds,color,style,mark,label in [('ResetLocal','FB15K-237','scblue','solid','*','FB update'),('ResetLocal','CoDEx-M','scblue','dashed','square*','CM update'),('IndependentRef20Null','FB15K-237','scorange','solid','*','FB ref-null'),('IndependentRef20Null','CoDEx-M','scorange','dashed','square*','CM ref-null')]:
        coords=' '.join(f"({j+1},{mean(A[ds,20,cand,f],'roc_auc'):.10g})" for j,f in enumerate(['score','ranks','joint']))
        g+=rf'\addplot[{color},{style},mark={mark},mark size=1.4pt] coordinates {{{coords}}};'+'\n'+r'\addlegendentry{'+label+'}\n'
    g+=r'''\end{groupplot}
\end{tikzpicture}
\caption{Verification and targeted behavioral controls. (a) Controlled anchored-DistMult acceptance. (b,c) Fixed-grid repair gaps to Ref20; solid FB15K-237 (FB), dashed CoDEx-M (CM). Budgets count retained-set-equivalent presentations, not seconds. (d) Score-only (S), ranks-only (R), and joint (J) AUC against Ref20, alongside independently trained same-budget references. Panels (b--d) are three-seed means on noiseless full-split DistMult; all folds, destructive controls, and Ref100 results appear in Appendix L.}
\label{fig:human-stress}
\end{figure}
'''
    (sec/'human_stress_figure.tex').write_text(g)
    out={'derived_from':str(root),'feature_table':'remaining_feature_tables.tex','budget_table':'remaining_budget_tables.tex','figure':'human_stress_figure.tex','rows':{'attack':len(A),'budgets':len(B),'damage':len(D)}}
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
