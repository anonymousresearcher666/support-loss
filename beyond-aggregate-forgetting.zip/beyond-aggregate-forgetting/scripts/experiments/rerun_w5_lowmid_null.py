#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import time
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.train import train_model
from schemacert.unlearn import local_retrain
from scripts.run_publication_families import fresh
from scripts.experiments.evaluate_family_restart import deterministic_family_restart
from scripts.experiments.run_entity_request_robustness import degrees, fullstar_stratum, hsh
from scripts.experiments.rerun_w5_mean_tie import (
    add_payload,
    rank_both_f32,
    save_checkpoint,
    summarize,
)


MODES = {
    "fullstar-low": ("low", 9001),
    "fullstar-mid": ("mid", 9002),
}


def historical_request_hash(root: Path, dataset: str, seed: int, mode: str):
    name = f"{dataset}_distmult_s{seed}_entity_request_robustness.csv"
    hits = sorted(root.rglob(name))
    if not hits:
        raise FileNotFoundError(
            f"Could not find historical robustness CSV {name} below {root}"
        )

    hashes = set()
    source_rows = []
    for path in hits:
        with path.open(newline="", encoding="utf8") as f:
            for row in csv.DictReader(f):
                if row.get("request_mode") == mode:
                    rh = row.get("request_hash")
                    if rh:
                        hashes.add(rh)
                        source_rows.append((str(path), row.get("method"), rh))

    if len(hashes) != 1:
        raise RuntimeError(
            f"Historical request hash for {dataset} s{seed} {mode} is not unique: "
            f"{sorted(hashes)}; rows={source_rows[:20]}"
        )
    return next(iter(hashes)), sorted({x[0] for x in source_rows})


def filtered_lp_query_sample(forget: np.ndarray, seed: int, max_queries: int = 1000):
    # Exact sampling convention used by scripts/run_publication_families.py::filtered_lp.
    if max_queries and len(forget) > max_queries:
        rng = np.random.default_rng(seed)
        pos = rng.choice(len(forget), max_queries, replace=False)
    else:
        pos = np.arange(len(forget), dtype=np.int64)
    return np.asarray(pos, dtype=np.int64), np.asarray(forget[pos], dtype=np.int64)


def main():
    ap = argparse.ArgumentParser(
        description="Extend the W5 independent-retraining null to fullstar-low/mid."
    )
    ap.add_argument("--dataset", required=True, choices=["FB15K-237", "CoDEx-M", "NELL-995"])
    ap.add_argument("--seed", required=True, type=int, choices=[17, 29, 43])
    ap.add_argument("--data-root", required=True)
    ap.add_argument(
        "--historical-results-root",
        required=True,
        help="Root containing the original entity_request_robustness CSVs."
    )
    ap.add_argument("--out", required=True)
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--fraction", type=float, default=.10)
    ap.add_argument("--dim", type=int, default=128)
    ap.add_argument("--epochs", type=int, default=20)
    ap.add_argument("--local-epochs", type=int, default=5)
    ap.add_argument("--batch-size", type=int, default=4096)
    ap.add_argument("--lr", type=float, default=.002)
    ap.add_argument("--local-lr", type=float, default=.001)
    ap.add_argument("--l2", type=float, default=1e-6)
    ap.add_argument("--eval-batch", type=int, default=16)
    ap.add_argument("--entity-chunk", type=int, default=4096)
    ap.add_argument("--max-queries", type=int, default=1000)
    args = ap.parse_args()

    torch.set_num_threads(1)
    hist_root = Path(args.historical_results_root)
    out_root = Path(args.out)
    cell_root = out_root / args.dataset / f"seed{args.seed}"
    cell_root.mkdir(parents=True, exist_ok=True)

    data = deterministic_holdout(
        load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17
    )
    ne, nr = len(data.entities), len(data.relations)
    target = max(1, int(round(args.fraction * len(data.train))))
    deg = degrees(data.train, ne)

    started = time.time()
    base = fresh("distmult", ne, nr, args.dim, args.seed, args.device)
    base_stats = train_model(
        base, data.train, ne, args.epochs, args.batch_size,
        args.lr, args.l2, args.seed, args.device
    )
    save_checkpoint(
        cell_root / "Base20.pt", base,
        {
            "dataset": args.dataset,
            "seed": args.seed,
            "role": "base",
            "epochs": args.epochs,
            "train_seconds": base_stats.seconds,
        },
    )

    summaries = []
    for mode, (stratum, seed_offset) in MODES.items():
        fi, selected, request_meta = fullstar_stratum(
            data.train, deg, stratum, target, args.seed + seed_offset
        )
        forget = data.train[fi]
        request_hash = hsh(forget)

        expected_hash, historical_csvs = historical_request_hash(
            hist_root, args.dataset, args.seed, mode
        )
        if request_hash != expected_hash:
            raise RuntimeError(
                f"HARD GATE FAILED {args.dataset} s{args.seed} {mode}: "
                f"request_hash={request_hash} historical={expected_hash}"
            )

        keep = np.ones(len(data.train), dtype=bool)
        keep[fi] = False
        retain = data.train[keep]

        qpos, q = filtered_lp_query_sample(
            forget, args.seed, max_queries=args.max_queries
        )
        query_train_index = np.asarray(fi[qpos], dtype=np.int64)

        # Explicit integrity checks for every sampled query.
        if not np.array_equal(q, data.train[query_train_index]):
            raise RuntimeError("sampled queries do not map back to original train rows")

        mode_dir = cell_root / f"{mode}_{request_hash}"
        mode_dir.mkdir(parents=True, exist_ok=True)
        truth = (retain, data.valid, data.test, forget)
        payload = {
            "queries": q,
            "query_forget_local_index": qpos,
            "query_train_index": query_train_index,
            "forget_indices": np.asarray(fi, dtype=np.int64),
            "selected_entities": np.asarray(selected, dtype=np.int64),
        }
        model_summaries = []

        restart_seed = (
            args.seed * 1000003 + len(fi) * 97 + 17027
        ) & 0x7fffffff
        restarted, restart_sec, unsupported, _ = deterministic_family_restart(
            base, retain, selected, restart_seed
        )
        local, _, _ = local_retrain(
            restarted, data.train, fi, ne, 1, args.local_epochs,
            args.batch_size, args.local_lr, args.l2, args.seed, args.device
        )
        candidate_model = local.model
        save_checkpoint(
            mode_dir / "SchemaCert_plus_Restart_L5.pt",
            candidate_model,
            {
                "dataset": args.dataset,
                "seed": args.seed,
                "mode": mode,
                "request_hash": request_hash,
                "role": "candidate",
                "restart_seed": restart_seed,
                "local_epochs": args.local_epochs,
                "restart_seconds": restart_sec,
                "local_seconds": local.seconds,
            },
        )
        candidate_ranks = rank_both_f32(
            candidate_model, q, ne, truth, args.device,
            args.eval_batch, args.entity_chunk
        )
        add_payload(payload, "candidate", candidate_ranks)
        model_summaries.append(summarize("candidate", candidate_ranks, None))
        del candidate_model, local, restarted
        if args.device.startswith("cuda"):
            torch.cuda.empty_cache()

        refa_seed = args.seed + 500003
        refa = fresh("distmult", ne, nr, args.dim, refa_seed, args.device)
        refa_stats = train_model(
            refa, retain, ne, args.epochs, args.batch_size,
            args.lr, args.l2, refa_seed, args.device
        )
        save_checkpoint(
            mode_dir / "RefA_FiniteRetrain20.pt",
            refa,
            {
                "dataset": args.dataset,
                "seed": args.seed,
                "mode": mode,
                "request_hash": request_hash,
                "role": "reference_a",
                "reference_seed": refa_seed,
                "epochs": args.epochs,
                "train_seconds": refa_stats.seconds,
            },
        )
        refa_ranks = rank_both_f32(
            refa, q, ne, truth, args.device,
            args.eval_batch, args.entity_chunk
        )
        add_payload(payload, "refA", refa_ranks)
        model_summaries.append(summarize("refA", refa_ranks, None))
        del refa
        if args.device.startswith("cuda"):
            torch.cuda.empty_cache()

        refb_seed = args.seed + 700003
        refb = fresh("distmult", ne, nr, args.dim, refb_seed, args.device)
        refb_stats = train_model(
            refb, retain, ne, args.epochs, args.batch_size,
            args.lr, args.l2, refb_seed, args.device
        )
        save_checkpoint(
            mode_dir / "RefB_IndependentRetrain20.pt",
            refb,
            {
                "dataset": args.dataset,
                "seed": args.seed,
                "mode": mode,
                "request_hash": request_hash,
                "role": "reference_b",
                "reference_seed": refb_seed,
                "epochs": args.epochs,
                "train_seconds": refb_stats.seconds,
            },
        )
        refb_ranks = rank_both_f32(
            refb, q, ne, truth, args.device,
            args.eval_batch, args.entity_chunk
        )
        add_payload(payload, "refB", refb_ranks)
        model_summaries.append(summarize("refB", refb_ranks, None))
        del refb
        if args.device.startswith("cuda"):
            torch.cuda.empty_cache()

        np.savez_compressed(mode_dir / "mean_tie_rank_audit.npz", **payload)
        cell_summary = {
            "dataset": args.dataset,
            "seed": args.seed,
            "mode": mode,
            "request_hash": request_hash,
            "historical_request_hash": expected_hash,
            "historical_robustness_csvs": historical_csvs,
            "request_hash_exact_match": True,
            "forget_n": int(len(fi)),
            "selected_n": int(len(selected)),
            "unsupported_n": int(len(unsupported)),
            "reference_seed_a": int(refa_seed),
            "reference_seed_b": int(refb_seed),
            "restart_seed": int(restart_seed),
            "queries": int(len(q)),
            "query_source": (
                "deterministic filtered_lp convention: np.random.default_rng(seed)"
                ".choice(len(forget), max_queries, replace=False)"
            ),
            "request_metadata": request_meta,
            "rank_rule_optimistic": "1 + n_greater",
            "rank_rule_mean_tie": "1 + n_greater + 0.5 * n_equal_competitors",
            "evaluation_dtype": "float32",
            "model_summaries": model_summaries,
        }
        (mode_dir / "summary.json").write_text(
            json.dumps(cell_summary, indent=2) + "\n"
        )
        summaries.append(cell_summary)
        print(
            "W5_LOWMID_NULL_CELL_OK",
            args.dataset, args.seed, mode, request_hash,
            json.dumps(model_summaries),
            flush=True,
        )

    complete = {
        "dataset": args.dataset,
        "seed": args.seed,
        "base_train_seconds": base_stats.seconds,
        "elapsed_seconds": time.time() - started,
        "cells": summaries,
    }
    (cell_root / "COMPLETE.json").write_text(
        json.dumps(complete, indent=2) + "\n"
    )
    print("W5_LOWMID_NULL_JOB_COMPLETE", args.dataset, args.seed, flush=True)


if __name__ == "__main__":
    main()
