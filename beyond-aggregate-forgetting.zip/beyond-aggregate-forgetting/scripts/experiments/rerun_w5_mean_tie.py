#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import time
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.train import train_model
from schemacert.unlearn import local_retrain
from scripts.run_publication_families import filter_maps, fresh
from scripts.experiments.evaluate_family_restart import deterministic_family_restart
from scripts.experiments.run_entity_request_robustness import (
    degrees,
    exact_card_high,
    fullstar_stratum,
    hsh,
)

EXPECTED_HASH = {
    ("FB15K-237", 17, "exact-card-high"): "591dadfb01d85bd5",
    ("FB15K-237", 17, "fullstar-high"): "50c742ffcf0f9457",
    ("FB15K-237", 43, "exact-card-high"): "02e7d7116e8708c7",
    ("FB15K-237", 43, "fullstar-high"): "ecd8d79a2f39e42f",
    ("CoDEx-M", 17, "exact-card-high"): "5c6282657d322566",
    ("CoDEx-M", 17, "fullstar-high"): "3eca9c5248a68294",
    ("CoDEx-M", 43, "exact-card-high"): "14489106d36e915a",
    ("CoDEx-M", 43, "fullstar-high"): "5da58a3a2307423e",
    ("NELL-995", 17, "exact-card-high"): "230de1cd1c065be1",
    ("NELL-995", 17, "fullstar-high"): "4fa6a96c5a9c23fa",
    ("NELL-995", 43, "exact-card-high"): "eacc9f4c8ffcb188",
    ("NELL-995", 43, "fullstar-high"): "ab84659992c603ee",
}


def candidate_csv(root: Path, dataset: str, seed: int, mode: str, request_hash: str) -> Path:
    if dataset == "NELL-995":
        d = root / "nell_entity_request_rank_dump_v1" / f"seed{seed}"
    else:
        d = root / "entity_request_rank_dump_v1"
    return d / f"{dataset}_s{seed}_{mode}_{request_hash}_forgotten_query_ranks.csv"


def null_npz(root: Path, dataset: str, seed: int, mode: str, request_hash: str) -> Path:
    return root / "multi_delete_independent_null_v1" / (
        f"{dataset}_s{seed}_{mode}_{request_hash}_independent_null.npz"
    )


def load_exact_queries(path: Path, request_hash: str, train: np.ndarray, fi: np.ndarray):
    if not path.is_file():
        raise FileNotFoundError(path)
    with path.open(newline="") as f:
        rows = list(csv.DictReader(f))
    rows.sort(key=lambda x: int(x["query_pos"]))
    if len(rows) != 1000:
        raise RuntimeError(f"{path}: expected 1000 queries, got {len(rows)}")
    got_hashes = {r["request_hash"] for r in rows}
    if got_hashes != {request_hash}:
        raise RuntimeError(f"{path}: request hashes {got_hashes} != {request_hash}")

    q = np.asarray([[int(r["h"]), int(r["r"]), int(r["t"])] for r in rows], dtype=np.int64)
    for pos, r in enumerate(rows):
        li = int(r["forget_local_index"])
        ti = int(r["train_index"])
        if li < 0 or li >= len(fi):
            raise RuntimeError(f"query {pos}: invalid forget_local_index={li}")
        if int(fi[li]) != ti:
            raise RuntimeError(f"query {pos}: fi[{li}]={int(fi[li])} != train_index={ti}")
        if not np.array_equal(train[ti], q[pos]):
            raise RuntimeError(f"query {pos}: triple != train[train_index]")
    return rows, q


def save_checkpoint(path: Path, model, meta: dict):
    state = {k: v.detach().cpu() for k, v in model.state_dict().items()}
    torch.save({"state_dict": state, **meta}, path)


@torch.no_grad()
def rank_both_f32(model, q: np.ndarray, ne: int, truth, device: str, batch: int, chunk: int):
    tails, heads = filter_maps(*truth)
    cand_full = torch.arange(ne, dtype=torch.long, device=device)
    model.to(device)
    model.eval()

    out = {}
    for side in ("head", "tail"):
        true_scores = []
        n_greater = []
        n_equal = []

        for st in range(0, len(q), batch):
            b = q[st:st + batch]
            bt = torch.as_tensor(b, dtype=torch.long, device=device)
            true = model.score(bt).float()
            B = len(b)
            gt = torch.zeros(B, dtype=torch.long, device=device)
            eq = torch.zeros(B, dtype=torch.long, device=device)

            for cs in range(0, ne, chunk):
                ce = min(ne, cs + chunk)
                cand = cand_full[cs:ce]
                if side == "tail":
                    sc = model.score_candidates("tail", bt[:, 0], bt[:, 1], cand).float()
                else:
                    sc = model.score_candidates("head", bt[:, 1], bt[:, 2], cand).float()

                for j, (h, r, t) in enumerate(b):
                    target = int(t) if side == "tail" else int(h)
                    filt = tails.get((int(h), int(r)), ()) if side == "tail" else heads.get((int(r), int(t)), ())
                    for x in filt:
                        x = int(x)
                        if x != target and cs <= x < ce:
                            sc[j, x - cs] = -torch.inf
                    # Exclude the evaluated target from the tie count. This does
                    # not alter the old optimistic greater-than count.
                    if cs <= target < ce:
                        sc[j, target - cs] = -torch.inf

                gt += (sc > true[:, None]).sum(1)
                eq += (sc == true[:, None]).sum(1)

            true_scores.append(true.detach().cpu().numpy().astype(np.float32, copy=False))
            n_greater.append(gt.cpu().numpy())
            n_equal.append(eq.cpu().numpy())

        true_score = np.concatenate(true_scores)
        greater = np.concatenate(n_greater).astype(np.int64, copy=False)
        equal = np.concatenate(n_equal).astype(np.int64, copy=False)
        optimistic = 1 + greater
        mean_tie = 1.0 + greater.astype(np.float64) + 0.5 * equal.astype(np.float64)
        out[side] = {
            "true_score": true_score,
            "n_greater": greater,
            "n_equal_competitors": equal,
            "optimistic_rank": optimistic,
            "mean_tie_rank": mean_tie,
        }
    return out


def old_ranks_from_csv(rows, label: str):
    return {
        "head": np.asarray([int(float(r[f"{label}_head_rank"])) for r in rows], dtype=np.int64),
        "tail": np.asarray([int(float(r[f"{label}_tail_rank"])) for r in rows], dtype=np.int64),
    }


def summarize(label: str, ranks: dict, old: dict | None):
    parts = {}
    for side in ("head", "tail"):
        a = ranks[side]
        rec = {
            "queries": int(len(a["optimistic_rank"])),
            "queries_with_competing_ties": int((a["n_equal_competitors"] > 0).sum()),
            "tie_fraction": float((a["n_equal_competitors"] > 0).mean()),
            "mean_equal_competitors": float(a["n_equal_competitors"].mean()),
            "max_equal_competitors": int(a["n_equal_competitors"].max(initial=0)),
            "mean_tie_changed_fraction": float((a["mean_tie_rank"] != a["optimistic_rank"]).mean()),
        }
        if old is not None:
            rec["old_optimistic_exact_match_fraction"] = float(
                (a["optimistic_rank"] == old[side]).mean()
            )
            rec["old_optimistic_max_abs_delta"] = int(
                np.abs(a["optimistic_rank"] - old[side]).max(initial=0)
            )
        parts[side] = rec

    eq_all = np.concatenate([ranks[s]["n_equal_competitors"] for s in ("head", "tail")])
    mean_all = np.concatenate([ranks[s]["mean_tie_rank"] for s in ("head", "tail")])
    opt_all = np.concatenate([ranks[s]["optimistic_rank"] for s in ("head", "tail")])
    rec = {
        "rankings": int(len(opt_all)),
        "queries_with_competing_ties": int((eq_all > 0).sum()),
        "tie_fraction": float((eq_all > 0).mean()),
        "mean_equal_competitors": float(eq_all.mean()),
        "max_equal_competitors": int(eq_all.max(initial=0)),
        "mean_tie_changed_fraction": float((mean_all != opt_all).mean()),
    }
    if old is not None:
        old_all = np.concatenate([old[s] for s in ("head", "tail")])
        rec["old_optimistic_exact_match_fraction"] = float((opt_all == old_all).mean())
        rec["old_optimistic_max_abs_delta"] = int(np.abs(opt_all - old_all).max(initial=0))
    parts["all"] = rec
    return {"label": label, **parts}


def add_payload(payload: dict, label: str, ranks: dict):
    for side in ("head", "tail"):
        for k, v in ranks[side].items():
            payload[f"{label}_{side}_{k}"] = v


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True, choices=["FB15K-237", "CoDEx-M", "NELL-995"])
    ap.add_argument("--seed", required=True, type=int, choices=[17, 29, 43])
    ap.add_argument("--data-root", required=True)
    ap.add_argument("--old-results-root", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--fraction", type=float, default=.10)
    ap.add_argument("--dim", type=int, default=128)
    ap.add_argument("--epochs", type=int, default=20)
    ap.add_argument("--local-epochs", type=int, default=5)
    ap.add_argument("--batch-size", type=int, default=4096)
    ap.add_argument("--lr", type=float, default=.002)
    ap.add_argument("--local-lr", type=float, default=.001)
    ap.add_argument("--l2", type=float, default=1e-6)
    ap.add_argument("--eval-batch", type=int, default=16)
    ap.add_argument("--entity-chunk", type=int, default=4096)
    args = ap.parse_args()

    torch.set_num_threads(1)
    old_root = Path(args.old_results_root)
    out_root = Path(args.out)
    cell_root = out_root / args.dataset / f"seed{args.seed}"
    cell_root.mkdir(parents=True, exist_ok=True)

    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    ne, nr = len(data.entities), len(data.relations)
    target = max(1, int(round(args.fraction * len(data.train))))
    deg = degrees(data.train, ne)

    started = time.time()
    base = fresh("distmult", ne, nr, args.dim, args.seed, args.device)
    base_stats = train_model(
        base, data.train, ne, args.epochs, args.batch_size,
        args.lr, args.l2, args.seed, args.device
    )
    save_checkpoint(
        cell_root / "Base20.pt", base,
        {"dataset": args.dataset, "seed": args.seed, "role": "base",
         "epochs": args.epochs, "train_seconds": base_stats.seconds},
    )

    summaries = []
    for mode in ("fullstar-high", "exact-card-high"):
        if mode == "fullstar-high":
            fi, selected, request_meta = fullstar_stratum(
                data.train, deg, "high", target, args.seed + 9003
            )
        else:
            fi, selected, request_meta = exact_card_high(
                data.train, deg, target, args.seed + 9101
            )

        forget = data.train[fi]
        request_hash = hsh(forget)
        expected = EXPECTED_HASH.get((args.dataset, args.seed, mode))
        if expected is not None and request_hash != expected:
            raise RuntimeError(
                f"HARD GATE FAILED {args.dataset} s{args.seed} {mode}: "
                f"request_hash={request_hash} expected={expected}"
            )

        keep = np.ones(len(data.train), dtype=bool)
        keep[fi] = False
        retain = data.train[keep]

        csv_path = candidate_csv(old_root, args.dataset, args.seed, mode, request_hash)
        rows, q = load_exact_queries(csv_path, request_hash, data.train, fi)
        old_candidate = old_ranks_from_csv(rows, "SchemaCert_plus_Restart_L5")
        old_refa = old_ranks_from_csv(rows, "FiniteRetrain_20")

        null_path = null_npz(old_root, args.dataset, args.seed, mode, request_hash)
        old_refb = None
        null_query_exact_match = None
        if null_path.is_file():
            z = np.load(null_path, allow_pickle=False)
            if "queries" in z.files:
                null_query_exact_match = bool(np.array_equal(np.asarray(z["queries"]), q))
            if null_query_exact_match and all(
                k in z.files for k in ("refB_head_rank", "refB_tail_rank")
            ):
                old_refb = {
                    "head": np.asarray(z["refB_head_rank"], dtype=np.int64),
                    "tail": np.asarray(z["refB_tail_rank"], dtype=np.int64),
                }

        mode_dir = cell_root / f"{mode}_{request_hash}"
        mode_dir.mkdir(parents=True, exist_ok=True)
        truth = (retain, data.valid, data.test, forget)
        payload = {
            "queries": q,
            "forget_indices": np.asarray(fi, dtype=np.int64),
            "selected_entities": np.asarray(selected, dtype=np.int64),
        }
        model_summaries = []

        # Candidate: deterministic family restart + local retraining.
        restart_seed = (args.seed * 1000003 + len(fi) * 97 + 17027) & 0x7fffffff
        restarted, restart_sec, unsupported, _ = deterministic_family_restart(
            base, retain, selected, restart_seed
        )
        local, _, _ = local_retrain(
            restarted, data.train, fi, ne, 1, args.local_epochs,
            args.batch_size, args.local_lr, args.l2, args.seed, args.device
        )
        candidate_model = local.model
        save_checkpoint(
            mode_dir / "SchemaCert_plus_Restart_L5.pt", candidate_model,
            {"dataset": args.dataset, "seed": args.seed, "mode": mode,
             "request_hash": request_hash, "role": "candidate",
             "restart_seed": restart_seed, "local_epochs": args.local_epochs,
             "restart_seconds": restart_sec, "local_seconds": local.seconds},
        )
        candidate_ranks = rank_both_f32(
            candidate_model, q, ne, truth, args.device, args.eval_batch, args.entity_chunk
        )
        add_payload(payload, "candidate", candidate_ranks)
        model_summaries.append(summarize("candidate", candidate_ranks, old_candidate))
        del candidate_model, local, restarted
        if args.device.startswith("cuda"):
            torch.cuda.empty_cache()

        # Reference A: exact seed/protocol used by the W5 primary cohort.
        refa_seed = args.seed + 500003
        t0 = time.time()
        refa = fresh("distmult", ne, nr, args.dim, refa_seed, args.device)
        refa_stats = train_model(
            refa, retain, ne, args.epochs, args.batch_size,
            args.lr, args.l2, refa_seed, args.device
        )
        save_checkpoint(
            mode_dir / "RefA_FiniteRetrain20.pt", refa,
            {"dataset": args.dataset, "seed": args.seed, "mode": mode,
             "request_hash": request_hash, "role": "reference_a",
             "reference_seed": refa_seed, "epochs": args.epochs,
             "train_seconds": refa_stats.seconds},
        )
        refa_ranks = rank_both_f32(
            refa, q, ne, truth, args.device, args.eval_batch, args.entity_chunk
        )
        add_payload(payload, "refA", refa_ranks)
        model_summaries.append(summarize("refA", refa_ranks, old_refa))
        del refa
        if args.device.startswith("cuda"):
            torch.cuda.empty_cache()

        # Reference B: independent retained-data retraining used by the W5 null.
        refb_seed = args.seed + 700003
        refb = fresh("distmult", ne, nr, args.dim, refb_seed, args.device)
        refb_stats = train_model(
            refb, retain, ne, args.epochs, args.batch_size,
            args.lr, args.l2, refb_seed, args.device
        )
        save_checkpoint(
            mode_dir / "RefB_IndependentRetrain20.pt", refb,
            {"dataset": args.dataset, "seed": args.seed, "mode": mode,
             "request_hash": request_hash, "role": "reference_b",
             "reference_seed": refb_seed, "epochs": args.epochs,
             "train_seconds": refb_stats.seconds},
        )
        refb_ranks = rank_both_f32(
            refb, q, ne, truth, args.device, args.eval_batch, args.entity_chunk
        )
        add_payload(payload, "refB", refb_ranks)
        model_summaries.append(summarize("refB", refb_ranks, old_refb))
        del refb
        if args.device.startswith("cuda"):
            torch.cuda.empty_cache()

        np.savez_compressed(mode_dir / "mean_tie_rank_audit.npz", **payload)
        cell_summary = {
            "dataset": args.dataset,
            "seed": args.seed,
            "mode": mode,
            "request_hash": request_hash,
            "forget_n": int(len(fi)),
            "selected_n": int(len(selected)),
            "unsupported_n": int(len(unsupported)),
            "reference_seed_a": int(refa_seed),
            "reference_seed_b": int(refb_seed),
            "restart_seed": int(restart_seed),
            "queries": int(len(q)),
            "candidate_csv": str(csv_path),
            "independent_null_npz": str(null_path),
            "null_query_exact_match": null_query_exact_match,
            "request_metadata": request_meta,
            "rank_rule_optimistic": "1 + n_greater",
            "rank_rule_mean_tie": "1 + n_greater + 0.5 * n_equal_competitors",
            "evaluation_dtype": "float32",
            "model_summaries": model_summaries,
        }
        (mode_dir / "summary.json").write_text(json.dumps(cell_summary, indent=2) + "\n")
        summaries.append(cell_summary)
        print(
            "W5_MEAN_TIE_CELL_OK",
            args.dataset, args.seed, mode, request_hash,
            json.dumps(model_summaries),
            flush=True,
        )

    complete = {
        "dataset": args.dataset,
        "seed": args.seed,
        "base_train_seconds": base_stats.seconds,
        "elapsed_seconds": time.time() - started,
        "cells": summaries,
    }
    (cell_root / "COMPLETE.json").write_text(json.dumps(complete, indent=2) + "\n")
    print("W5_MEAN_TIE_JOB_COMPLETE", args.dataset, args.seed, flush=True)


if __name__ == "__main__":
    main()
