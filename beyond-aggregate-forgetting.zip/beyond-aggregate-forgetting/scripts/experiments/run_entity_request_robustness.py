#!/usr/bin/env python3
from __future__ import annotations

import argparse, csv, hashlib, json, math, time
from pathlib import Path
import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.train import train_model
from schemacert.unlearn import local_retrain
from scripts.run_publication_families import filtered_lp, fresh
from scripts.experiments.evaluate_family_restart import deterministic_family_restart


def hsh(x): return hashlib.sha256(np.ascontiguousarray(x,dtype=np.int64).tobytes()).hexdigest()[:16]

def degrees(train, ne):
    d=np.bincount(np.r_[train[:,0],train[:,2]],minlength=ne)
    return d.astype(np.int64)

def incident(train, ents):
    return np.flatnonzero(np.isin(train[:,0],ents)|np.isin(train[:,2],ents))

def fullstar_stratum(train, deg, stratum, target_n, seed):
    nz=np.flatnonzero(deg>0); qs=np.quantile(deg[nz],[1/3,2/3])
    if stratum=='low': pool=nz[deg[nz]<=qs[0]]
    elif stratum=='mid': pool=nz[(deg[nz]>qs[0])&(deg[nz]<=qs[1])]
    elif stratum=='high': pool=nz[deg[nz]>qs[1]]
    else: raise KeyError(stratum)
    rng=np.random.default_rng(seed); order=pool[rng.permutation(len(pool))]
    sel=[]; idx=np.array([],dtype=np.int64)
    for e in order:
        sel.append(int(e)); idx=incident(train,np.asarray(sel,dtype=np.int64))
        if len(idx)>=target_n: break
    if len(idx)==0: raise RuntimeError(f'empty {stratum} request')
    return np.sort(idx),np.asarray(sel,dtype=np.int64),{'stratum':stratum,'q1':float(qs[0]),'q2':float(qs[1])}

def exact_card_high(train, deg, target_n, seed):
    # Greedily accumulate high-degree entity stars, truncating only the final
    # star to hit the requested triple cardinality exactly.
    nz=np.flatnonzero(deg>0); q=np.quantile(deg[nz],2/3); pool=nz[deg[nz]>q]
    rng=np.random.default_rng(seed); order=pool[rng.permutation(len(pool))]
    chosen=set(); sel=[]
    for e in order:
        cand=[int(i) for i in incident(train,np.asarray([e])) if int(i) not in chosen]
        if not cand: continue
        sel.append(int(e))
        need=target_n-len(chosen)
        if need<=0: break
        if len(cand)<=need: chosen.update(cand)
        else:
            picked=rng.choice(np.asarray(cand),need,replace=False); chosen.update(map(int,picked)); break
    if len(chosen)!=target_n: raise RuntimeError(f'exact-card request got {len(chosen)} != {target_n}')
    return np.asarray(sorted(chosen),dtype=np.int64),np.asarray(sel,dtype=np.int64),{'stratum':'high','exact_cardinality':True}

def partial_star_high(train, deg, target_n, seed):
    # Delete entity-centric triples while preserving >=1 retained positive edge
    # for every selected entity throughout request construction. This global
    # support-aware construction avoids overlap between neighboring selected
    # stars silently zeroing a row that was safe when considered in isolation.
    nz=np.flatnonzero(deg>=2); q=np.quantile(deg[nz],2/3); pool=nz[deg[nz]>q]
    rng=np.random.default_rng(seed); order=pool[rng.permutation(len(pool))]
    chosen=set(); sel=[]; selected=set(); deleted_deg=np.zeros_like(deg)

    def can_delete(i, selected_after):
        h=int(train[i,0]); t=int(train[i,2])
        touched=(h,) if h==t else (h,t)
        for v in touched:
            if v in selected_after:
                inc=1
                if deleted_deg[v] + inc >= deg[v]:
                    return False
        return True

    for e0 in order:
        e=int(e0)
        # An entity is selectable only if it still has at least two retained
        # incident positives before we start deleting from its partial star.
        if deg[e]-deleted_deg[e] < 2:
            continue
        selected_after=set(selected); selected_after.add(e)
        cand=[int(i) for i in incident(train,np.asarray([e])) if int(i) not in chosen]
        if len(cand)<2:
            continue
        cand=list(rng.permutation(np.asarray(cand,dtype=np.int64)))
        k=min(max(1,len(cand)//2),target_n-len(chosen))
        if k<=0: break
        accepted=[]
        for i in cand:
            if len(accepted)>=k: break
            if not can_delete(int(i), selected_after):
                continue
            h=int(train[i,0]); t=int(train[i,2])
            accepted.append(int(i))
            deleted_deg[h]+=1
            if t!=h: deleted_deg[t]+=1
        if not accepted:
            continue
        sel.append(e); selected.add(e); chosen.update(accepted)
        if len(chosen)>=target_n: break

    idx=np.asarray(sorted(chosen),dtype=np.int64)
    if len(idx)==0: raise RuntimeError('partial-star request empty')
    # Final hard retained-support gate for selected rows.
    keep=np.ones(len(train),dtype=bool); keep[idx]=False; ret=train[keep]
    rd=degrees(ret,int(max(train[:,0].max(),train[:,2].max()))+1)
    bad=[int(e) for e in sel if e>=len(rd) or rd[e]==0]
    if bad: raise RuntimeError(f'partial-star accidentally zeroed support for {bad[:10]}')
    return idx,np.asarray(sel,dtype=np.int64),{
        'stratum':'high','partial_star':True,'target_n':target_n,
        'realized_n':len(idx),'support_safe_greedy':True,
    }

def evalm(model,data,retain,forget,ne,args):
    g=filtered_lp(model,data.test,ne,(retain,data.valid,data.test),args.device,args.eval_batch,args.entity_chunk,args.eval_queries,args.seed)
    f=filtered_lp(model,forget,ne,(retain,data.valid,data.test,forget),args.device,args.eval_batch,args.entity_chunk,args.forget_eval_queries,args.seed)
    return g,f

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--dataset',required=True); ap.add_argument('--seed',type=int,required=True)
    ap.add_argument('--data-root',default='data'); ap.add_argument('--out',required=True); ap.add_argument('--device',default='cuda:0')
    ap.add_argument('--fraction',type=float,default=.10); ap.add_argument('--dim',type=int,default=128); ap.add_argument('--epochs',type=int,default=20)
    ap.add_argument('--local-epochs',type=int,default=5); ap.add_argument('--batch-size',type=int,default=4096); ap.add_argument('--lr',type=float,default=.002)
    ap.add_argument('--local-lr',type=float,default=.001); ap.add_argument('--l2',type=float,default=1e-6); ap.add_argument('--eval-batch',type=int,default=16)
    ap.add_argument('--entity-chunk',type=int,default=4096); ap.add_argument('--eval-queries',type=int,default=1000); ap.add_argument('--forget-eval-queries',type=int,default=1000)
    args=ap.parse_args(); torch.set_num_threads(1)
    data=deterministic_holdout(load_dataset(*infer_paths(args.dataset,args.data_root)),seed=17); ne,nr=len(data.entities),len(data.relations)
    base=fresh('distmult',ne,nr,args.dim,args.seed,args.device); base_stats=train_model(base,data.train,ne,args.epochs,args.batch_size,args.lr,args.l2,args.seed,args.device)
    deg=degrees(data.train,ne); target=max(1,int(round(args.fraction*len(data.train))))
    reqs=[]
    for j,s in enumerate(['low','mid','high']):
        reqs.append((f'fullstar-{s}',)+fullstar_stratum(data.train,deg,s,target,args.seed+9001+j))
    reqs.append(('exact-card-high',)+exact_card_high(data.train,deg,target,args.seed+9101))
    reqs.append(('partial-star-high',)+partial_star_high(data.train,deg,target,args.seed+9201))
    rows=[]
    for name,fi,selected,meta in reqs:
        forget=data.train[fi]; keep=np.ones(len(data.train),dtype=bool);keep[fi]=False;retain=data.train[keep]
        restart_seed=(args.seed*1000003+len(fi)*97+17027)&0x7fffffff
        restarted,restart_sec,unsupported,rdeg=deterministic_family_restart(base,retain,selected,restart_seed)
        bare,_,_=local_retrain(base,data.train,fi,ne,1,args.local_epochs,args.batch_size,args.local_lr,args.l2,args.seed,args.device)
        rloc,_,_=local_retrain(restarted,data.train,fi,ne,1,args.local_epochs,args.batch_size,args.local_lr,args.l2,args.seed,args.device)
        st=time.time(); ref=fresh('distmult',ne,nr,args.dim,args.seed+500003,args.device); refstats=train_model(ref,retain,ne,args.epochs,args.batch_size,args.lr,args.l2,args.seed+500003,args.device); refsec=time.time()-st
        rg,rf=evalm(ref,data,retain,forget,ne,args); bg,bf=evalm(bare.model,data,retain,forget,ne,args); sg,sf=evalm(rloc.model,data,retain,forget,ne,args)
        common={'dataset':args.dataset,'model':'distmult','seed':args.seed,'request_mode':name,'target_fraction':args.fraction,'forget_n':len(fi),'realized_fraction':len(fi)/len(data.train),'selected_n':len(selected),'unsupported_n':len(unsupported),'unsupported_fraction':len(unsupported)/max(len(selected),1),'request_hash':hsh(forget),'metadata':json.dumps(meta,sort_keys=True)}
        for method,g,f,sec in [('FiniteRetrain-20',rg,rf,refsec),('SchemaCert-L5',bg,bf,bare.seconds),('SchemaCert+Restart-L5',sg,sf,restart_sec+rloc.seconds)]:
            rows.append({**common,'method':method,'global_mrr':g['mrr'],'forget_mrr':f['mrr'],'global_gap_to_ref':abs(g['mrr']-rg['mrr']),'forget_gap_to_ref':abs(f['mrr']-rf['mrr']),'train_sec':sec})
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True); p=out/f'{args.dataset}_distmult_s{args.seed}_entity_request_robustness.csv'
    with p.open('w',newline='') as f: w=csv.DictWriter(f,fieldnames=list(rows[0].keys()));w.writeheader();w.writerows(rows)
    (p.with_suffix('.json')).write_text(json.dumps({'dataset':args.dataset,'seed':args.seed,'base_train_sec':base_stats.seconds,'rows':rows},indent=2)+'\n')
    print(f'ENTITY_REQUEST_ROBUSTNESS_OK requests=5 rows={len(rows)} out={p}')
if __name__=='__main__': main()
