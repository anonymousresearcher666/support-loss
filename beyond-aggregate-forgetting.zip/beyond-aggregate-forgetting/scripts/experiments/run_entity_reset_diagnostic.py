#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import time
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.train import clone_model, train_model
from schemacert.unlearn import local_retrain
from scripts.run_publication_families import fresh, select_forget
from scripts.experiments.run_samebase_ng_pilot import evaluate, request_fingerprint, row


def reset_selected_entities(model, source, entity_ids: np.ndarray) -> float:
    if not hasattr(model, 'entity') or not hasattr(model.entity, 'weight'):
        raise RuntimeError('Entity reset diagnostic requires model.entity.weight')
    st = time.time()
    idx = torch.as_tensor(entity_ids, dtype=torch.long, device=model.entity.weight.device)
    with torch.no_grad():
        src = source.entity.weight.detach().to(model.entity.weight.device)
        model.entity.weight[idx] = src[idx]
        model.normalize_()
    if model.entity.weight.is_cuda:
        torch.cuda.synchronize()
    return time.time() - st


def retained_positive_degrees(retain: np.ndarray, entity_ids: np.ndarray) -> dict[int, int]:
    deg = {}
    for e in entity_ids:
        e = int(e)
        deg[e] = int(((retain[:, 0] == e) | (retain[:, 2] == e)).sum())
    return deg


def eval_and_add(rows, method, model, seconds, data, retain, forget, exact_global, exact_forget, req_hash, args):
    g, f = evaluate(
        model, data, retain, forget, args.device, args.eval_batch, args.entity_chunk,
        args.eval_queries, args.forget_eval_queries, args.seed,
    )
    rows.append(row(method, g, f, seconds, exact_global, exact_forget, req_hash))


def main():
    p = argparse.ArgumentParser(description='Diagnose entity-star deletion memory carryover via targeted embedding reset.')
    p.add_argument('--dataset', default='FB15K-237')
    p.add_argument('--model', default='transe')
    p.add_argument('--policy', default='entity', choices=['entity'])
    p.add_argument('--fraction', type=float, default=0.05)
    p.add_argument('--seed', type=int, default=17)
    p.add_argument('--alt-reset-seed', type=int, default=100017)
    p.add_argument('--data-root', default='data')
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--threads', type=int, default=1)
    p.add_argument('--dim', type=int, default=128)
    p.add_argument('--epochs', type=int, default=20)
    p.add_argument('--ref-epochs', type=int, default=20)
    p.add_argument('--local-epochs', type=int, default=5)
    p.add_argument('--batch-size', type=int, default=4096)
    p.add_argument('--lr', type=float, default=0.002)
    p.add_argument('--local-lr', type=float, default=0.001)
    p.add_argument('--l2', type=float, default=1e-6)
    p.add_argument('--hops', type=int, default=1)
    p.add_argument('--eval-batch', type=int, default=16)
    p.add_argument('--entity-chunk', type=int, default=4096)
    p.add_argument('--eval-queries', type=int, default=1000)
    p.add_argument('--forget-eval-queries', type=int, default=1000)
    p.add_argument('--out', required=True)
    args = p.parse_args()

    torch.set_num_threads(max(1, args.threads))
    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    ne, nr = len(data.entities), len(data.relations)
    fi, meta = select_forget(data.train, args.fraction, args.seed + int(args.fraction * 10000), args.policy)
    forget = data.train[fi]
    keep = np.ones(len(data.train), dtype=bool)
    keep[fi] = False
    retain = data.train[keep]
    req_hash = request_fingerprint(data, forget)

    selected = np.asarray(meta.get('entities', []), dtype=np.int64)
    if len(selected) == 0:
        raise RuntimeError('Entity policy returned no selected entities')
    deg = retained_positive_degrees(retain, selected)
    zero_support = sum(v == 0 for v in deg.values())

    base = fresh(args.model, ne, nr, args.dim, args.seed, args.device)
    base_stats = train_model(
        base, data.train, ne, args.epochs, args.batch_size, args.lr, args.l2, args.seed, args.device
    )
    exact = fresh(args.model, ne, nr, args.dim, args.seed, args.device)
    exact_stats = train_model(
        exact, retain, ne, args.ref_epochs, args.batch_size, args.lr, args.l2, args.seed, args.device
    )
    init_same = fresh(args.model, ne, nr, args.dim, args.seed, args.device)
    init_alt = fresh(args.model, ne, nr, args.dim, args.alt_reset_seed, args.device)

    exact_global, exact_forget = evaluate(
        exact, data, retain, forget, args.device, args.eval_batch, args.entity_chunk,
        args.eval_queries, args.forget_eval_queries, args.seed,
    )
    base_global, base_forget = evaluate(
        base, data, retain, forget, args.device, args.eval_batch, args.entity_chunk,
        args.eval_queries, args.forget_eval_queries, args.seed,
    )
    rows = [
        row('ExactRetrain', exact_global, exact_forget, exact_stats.seconds, exact_global, exact_forget, req_hash),
        row('BaseBeforeUnlearning', base_global, base_forget, 0.0, exact_global, exact_forget, req_hash),
    ]

    reset_same = clone_model(base).to(args.device)
    sec = reset_selected_entities(reset_same, init_same, selected)
    eval_and_add(rows, 'ResetOnly-SameInit', reset_same, sec, data, retain, forget, exact_global, exact_forget, req_hash, args)

    reset_alt = clone_model(base).to(args.device)
    sec_alt = reset_selected_entities(reset_alt, init_alt, selected)
    eval_and_add(rows, 'ResetOnly-FreshInit', reset_alt, sec_alt, data, retain, forget, exact_global, exact_forget, req_hash, args)

    local, _, _ = local_retrain(
        base, data.train, fi, ne, args.hops, args.local_epochs, args.batch_size,
        args.local_lr, args.l2, args.seed, args.device,
    )
    eval_and_add(rows, f'SchemaCert-L{args.local_epochs}', local.model, local.seconds, data, retain, forget, exact_global, exact_forget, req_hash, args)

    local_reset_after = clone_model(local.model).to(args.device)
    reset_after_sec = reset_selected_entities(local_reset_after, init_same, selected)
    eval_and_add(rows, f'SchemaCert-L{args.local_epochs}-ResetAfter', local_reset_after,
                 local.seconds + reset_after_sec, data, retain, forget, exact_global, exact_forget, req_hash, args)

    base_reset_before = clone_model(base).to(args.device)
    reset_before_sec = reset_selected_entities(base_reset_before, init_same, selected)
    local_before, _, _ = local_retrain(
        base_reset_before, data.train, fi, ne, args.hops, args.local_epochs, args.batch_size,
        args.local_lr, args.l2, args.seed, args.device,
    )
    eval_and_add(rows, f'SchemaCert-ResetBefore-L{args.local_epochs}', local_before.model,
                 reset_before_sec + local_before.seconds, data, retain, forget, exact_global, exact_forget, req_hash, args)

    ft = clone_model(base).to(args.device)
    ft_stats = train_model(
        ft, retain, ne, args.local_epochs, args.batch_size, args.local_lr,
        args.l2, args.seed + 31, args.device,
    )
    eval_and_add(rows, f'FullFinetune-L{args.local_epochs}', ft, ft_stats.seconds, data, retain, forget, exact_global, exact_forget, req_hash, args)

    ft_reset = clone_model(ft).to(args.device)
    ft_reset_sec = reset_selected_entities(ft_reset, init_same, selected)
    eval_and_add(rows, f'FullFinetune-L{args.local_epochs}-ResetAfter', ft_reset,
                 ft_stats.seconds + ft_reset_sec, data, retain, forget, exact_global, exact_forget, req_hash, args)

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    stem = f'{args.dataset}_{args.model}_{args.policy}_f{args.fraction:g}_s{args.seed}_entity_reset'
    csv_path = out / f'{stem}.csv'
    json_path = out / f'{stem}.json'
    with open(csv_path, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    json_path.write_text(json.dumps({
        'config': vars(args),
        'forget_n': int(len(forget)),
        'request_hash': req_hash,
        'request_meta': meta,
        'selected_entities': selected.tolist(),
        'selected_entity_retained_positive_degree': deg,
        'zero_support_selected_entities': int(zero_support),
        'base_train_sec': base_stats.seconds,
        'rows': rows,
    }, indent=2))

    print(
        f'REQUEST hash={req_hash} forget_n={len(forget)} selected_entities={len(selected)} '
        f'zero_support={zero_support}/{len(selected)} max_retained_degree={max(deg.values())}'
    )
    print('method\tglobal_mrr\tforget_mrr\tglobal_gap_exact\tforget_gap_exact\tupdate_sec')
    for r in rows:
        print(
            f"{r['method']}\t{r['global_mrr']:.6f}\t{r['forget_mrr']:.6f}\t"
            f"{r['global_mrr_gap_to_exact']:.6f}\t{r['forget_mrr_gap_to_exact']:.6f}\t{r['update_sec']:.6f}"
        )
    print(f'ENTITY_RESET_CSV={csv_path}')
    print(f'ENTITY_RESET_JSON={json_path}')
    print('ENTITY_RESET_DIAGNOSTIC_OK')


if __name__ == '__main__':
    main()
