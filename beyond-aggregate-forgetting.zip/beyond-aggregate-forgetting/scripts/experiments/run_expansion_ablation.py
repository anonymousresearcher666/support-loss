#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
import time
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.family_models import make_model
from schemacert.train import clone_model, train_model
from schemacert.unlearn import local_retrain
from scripts.run_publication_families import filtered_lp, param_dist, select_forget
from scripts.experiments.run_real_coupling import affected_mask, make_hvp, spectral_eta


def fresh(name, ne, nr, dim, seed, device):
    torch.manual_seed(seed)
    np.random.seed(seed)
    if device.startswith('cuda'):
        torch.cuda.manual_seed_all(seed)
    return make_model(name, ne, nr, dim).to(device)


def eval_pair(model, ref, test, forget, retain, valid, ne, args):
    truth = (retain, valid, test)
    a = filtered_lp(model, test, ne, truth, args.device, 8, args.entity_chunk, args.eval_queries, args.seed)
    b = filtered_lp(ref, test, ne, truth, args.device, 8, args.entity_chunk, args.eval_queries, args.seed)
    ftruth = (retain, valid, test, forget)
    af = filtered_lp(model, forget, ne, ftruth, args.device, 8, args.entity_chunk, args.forget_eval_queries, args.seed)
    bf = filtered_lp(ref, forget, ne, ftruth, args.device, 8, args.entity_chunk, args.forget_eval_queries, args.seed)
    return abs(a['mrr'] - b['mrr']), abs(af['mrr'] - bf['mrr'])


def fixed_curvature_pool(retain, n, seed):
    """One uniform retained-triple pool shared by every expansion level.

    The expansion ablation is meant to vary only the A/C partition.  Reusing
    the same positive triples, and later the same negative-corruption seed,
    prevents curvature-sampling noise from masquerading as an expansion
    effect.  This protocol is intentionally labelled fixed_uniform and is
    used for within-request trends rather than direct comparison to the
    boundary-stratified main coupling table.
    """
    rng = np.random.default_rng(seed)
    k = min(int(n), len(retain))
    if k == len(retain):
        return retain.copy()
    idx = np.sort(rng.choice(len(retain), k, replace=False))
    return retain[idx]


def boundary_stats(retain, ae, ar):
    aeh = np.isin(retain[:, 0], ae)
    aet = np.isin(retain[:, 2], ae)
    arr = np.isin(retain[:, 1], ar)
    cross = (aeh ^ aet) | (arr & ~(aeh & aet))
    return float(cross.mean()), int(cross.sum())


def coupling_for_region(base, curvature_pool, retain, ae, ar, ne, args):
    br, bn = boundary_stats(retain, ae, ar)
    mask = affected_mask(base, ae, ar, args.device)
    if bool(mask.all()) or bool((~mask).sum() == 0):
        meta = {'status': 'full', 'cg_iters': 0, 'eta2': 0.0}
        return 0.0, br, bn, meta

    # Same curvature pool and corruption seed for hops 1/2/3.  Only the mask
    # changes across expansion levels.
    hvp, _, _ = make_hvp(
        base,
        curvature_pool,
        ne,
        args.seed + 2000,
        args.l2,
        args.damping,
        args.device,
    )
    eta, meta = spectral_eta(
        hvp,
        mask,
        args.power_iters,
        args.cg_iters,
        args.seed + 3000,
    )
    return eta, br, bn, meta


def run(args):
    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    ne, nr = len(data.entities), len(data.relations)

    base = fresh(args.model, ne, nr, args.dim, args.seed, args.device)
    train_model(base, data.train, ne, args.epochs, args.batch_size, args.lr, args.l2, args.seed, args.device)

    fi, request_meta = select_forget(
        data.train,
        args.fraction,
        args.seed + int(args.fraction * 10000),
        args.policy,
    )
    forget = data.train[fi]
    retain = np.delete(data.train, fi, axis=0)

    ref = fresh(args.model, ne, nr, args.dim, args.seed, args.device)
    ref_stats = train_model(ref, retain, ne, args.ref_epochs, args.batch_size, args.lr, args.l2, args.seed, args.device)

    curvature_pool = fixed_curvature_pool(retain, args.curvature_sample, args.seed + 1000)
    rows = []

    for hops in (1, 2, 3):
        t0 = time.time()
        loc, retain2, _ = local_retrain(
            base,
            data.train,
            fi,
            ne,
            hops,
            args.local_epochs,
            args.batch_size,
            args.local_lr,
            args.l2,
            args.seed,
            args.device,
        )
        gg, fg = eval_pair(loc.model, ref, data.test, forget, retain2, data.valid, ne, args)
        eta, br, bn, eta_meta = coupling_for_region(
            base,
            curvature_pool,
            retain2,
            loc.affected_entities,
            loc.affected_relations,
            ne,
            args,
        )
        rows.append(dict(
            dataset=args.dataset,
            model=args.model,
            policy=args.policy,
            seed=args.seed,
            fraction=args.fraction,
            level=f'hops{hops}',
            hops=hops,
            request_meta=json.dumps(request_meta, separators=(',', ':')),
            eta_hvp=eta,
            eta_status=eta_meta.get('status', 'unknown'),
            eta_meta=json.dumps(eta_meta, separators=(',', ':')),
            hessian_damping_used=args.damping,
            curvature_sampling='fixed_uniform',
            curvature_sample_n=int(len(curvature_pool)),
            boundary_ratio=br,
            boundary_proxy_sqrt=math.sqrt(max(br, 0.0)),
            boundary_n=bn,
            global_mrr_gap=gg,
            forgotten_mrr_gap=fg,
            parameter_distance_to_reference=param_dist(loc.model, ref),
            parameter_fraction=loc.parameter_fraction,
            unique_work_fraction=loc.work_unique_triples / max(len(retain2), 1),
            local_sec=loc.seconds,
            speedup_vs_reference=ref_stats.seconds / max(loc.seconds, 1e-12),
            wall_sec=time.time() - t0,
        ))
        del loc

    ft = clone_model(base)
    t0 = time.time()
    fs = train_model(ft, retain, ne, args.local_epochs, args.batch_size, args.local_lr, args.l2, args.seed + 31, args.device)
    gg, fg = eval_pair(ft, ref, data.test, forget, retain, data.valid, ne, args)
    rows.append(dict(
        dataset=args.dataset,
        model=args.model,
        policy=args.policy,
        seed=args.seed,
        fraction=args.fraction,
        level='full_finetune',
        hops=-1,
        request_meta=json.dumps(request_meta, separators=(',', ':')),
        eta_hvp=0.0,
        eta_status='full',
        eta_meta=json.dumps({'status': 'full', 'cg_iters': 0, 'eta2': 0.0}, separators=(',', ':')),
        hessian_damping_used=args.damping,
        curvature_sampling='fixed_uniform',
        curvature_sample_n=int(len(curvature_pool)),
        boundary_ratio=0.0,
        boundary_proxy_sqrt=0.0,
        boundary_n=0,
        global_mrr_gap=gg,
        forgotten_mrr_gap=fg,
        parameter_distance_to_reference=param_dist(ft, ref),
        parameter_fraction=1.0,
        unique_work_fraction=1.0,
        local_sec=fs.seconds,
        speedup_vs_reference=ref_stats.seconds / max(fs.seconds, 1e-12),
        wall_sec=time.time() - t0,
    ))

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    stem = f'{args.dataset}_{args.model}_{args.policy}_f{args.fraction:.2f}_s{args.seed}'
    with open(out / f'{stem}.json', 'w') as f:
        json.dump(rows, f, indent=2)
    with open(out / f'{stem}.csv', 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys())
        w.writeheader()
        w.writerows(rows)
    for row in rows:
        print(json.dumps(row, sort_keys=True), flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--dataset', required=True)
    p.add_argument('--model', choices=['transe', 'complex', 'distmult'], required=True)
    p.add_argument('--policy', choices=['entity', 'relation'], required=True)
    p.add_argument('--seed', type=int, required=True)
    p.add_argument('--fraction', type=float, required=True)
    p.add_argument('--data-root', default='data')
    p.add_argument('--out', required=True)
    p.add_argument('--device', default='cuda')
    p.add_argument('--dim', type=int, default=128)
    p.add_argument('--epochs', type=int, default=20)
    p.add_argument('--ref-epochs', type=int, default=20)
    p.add_argument('--local-epochs', type=int, default=5)
    p.add_argument('--batch-size', type=int, default=32768)
    p.add_argument('--lr', type=float, default=.002)
    p.add_argument('--local-lr', type=float, default=.001)
    p.add_argument('--l2', type=float, default=1e-6)
    p.add_argument('--eval-queries', type=int, default=500)
    p.add_argument('--forget-eval-queries', type=int, default=500)
    p.add_argument('--entity-chunk', type=int, default=8192)
    p.add_argument('--curvature-sample', type=int, default=1024)
    p.add_argument('--damping', type=float, default=0.01)
    p.add_argument('--power-iters', type=int, default=4)
    p.add_argument('--cg-iters', type=int, default=32)
    run(p.parse_args())


if __name__ == '__main__':
    main()
