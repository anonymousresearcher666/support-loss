#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.train import clone_model, train_model
from schemacert.unlearn import local_retrain
from scripts.run_publication_families import fresh, filtered_lp
from scripts.experiments.evaluate_family_restart import deterministic_family_restart
from scripts.experiments.run_entity_request_robustness import (
    degrees,
    exact_card_high,
    fullstar_stratum,
    hsh,
    partial_star_high,
)
from scripts.experiments.evaluate_random_fact_reconstruction import cost_aware_star_cover


def evalm(model, data, retain, forget, ne, args):
    g = filtered_lp(
        model, data.test, ne, (retain, data.valid, data.test), args.device,
        args.eval_batch, args.entity_chunk, args.eval_queries, args.seed,
    )
    f = filtered_lp(
        model, forget, ne, (retain, data.valid, data.test, forget), args.device,
        args.eval_batch, args.entity_chunk, args.forget_eval_queries, args.seed,
    )
    return g, f


def restart_rows_all(model, entity_ids: np.ndarray, seed: int):
    ids = np.asarray(sorted(set(map(int, entity_ids))), dtype=np.int64)
    out = clone_model(model)
    st = time.time()
    if len(ids):
        gen = torch.Generator(device='cpu')
        gen.manual_seed(int(seed))
        fresh_rows = torch.empty(
            out.entity.weight.shape,
            dtype=out.entity.weight.dtype,
            device='cpu',
        )
        nn.init.xavier_normal_(fresh_rows, generator=gen)
        idx_cpu = torch.as_tensor(ids, dtype=torch.long)
        idx_dev = idx_cpu.to(out.entity.weight.device)
        with torch.no_grad():
            out.entity.weight[idx_dev] = fresh_rows[idx_cpu].to(out.entity.weight.device)
        if out.entity.weight.is_cuda:
            torch.cuda.synchronize()
    return out, time.time() - st


def retained_degree(retain: np.ndarray, ne: int) -> np.ndarray:
    d = np.zeros(ne, dtype=np.int64)
    if len(retain):
        np.add.at(d, retain[:, 0], 1)
        np.add.at(d, retain[:, 2], 1)
    return d


def repair_star(model, retain, anchors, ne, args, seed):
    anchors = np.asarray(sorted(set(map(int, anchors))), dtype=np.int64)
    mask = np.isin(retain[:, 0], anchors) | np.isin(retain[:, 2], anchors)
    repair = retain[mask]
    emask = np.zeros_like(model.entity.weight.detach().cpu().numpy(), dtype=np.float32)
    if len(anchors):
        emask[anchors, :] = 1.0
    rmask = np.zeros_like(model.relation.weight.detach().cpu().numpy(), dtype=np.float32)
    stats = train_model(
        model,
        repair,
        ne,
        epochs=args.repair_epochs,
        batch_size=args.batch_size,
        lr=args.repair_lr,
        l2=args.l2,
        seed=seed,
        device=args.device,
        trainable_masks=[
            (model.entity.weight, emask),
            (model.relation.weight, rmask),
        ],
    ) if len(repair) and len(anchors) else None
    return model, (stats.seconds if stats else 0.0), int(len(repair))


def method_row(common, method, g, f, sec, rg, rf, extra=None):
    row = {
        **common,
        'method': method,
        'global_mrr': g['mrr'],
        'forget_mrr': f['mrr'],
        'global_gap_to_ref': abs(g['mrr'] - rg['mrr']),
        'forget_gap_to_ref': abs(f['mrr'] - rf['mrr']),
        'train_sec': sec,
        'anchor_count': None,
        'anchor_fraction': None,
        'repair_triples': None,
        'repair_fraction': None,
        'forget_coverage': None,
        'restart_sec': None,
        'repair_sec': None,
    }
    if extra:
        row.update(extra)
    return row


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dataset', default='NELL-995')
    ap.add_argument('--seed', type=int, required=True)
    ap.add_argument('--fraction', type=float, default=.10)
    ap.add_argument('--data-root', default='data')
    ap.add_argument('--out', required=True)
    ap.add_argument('--device', default='cuda:0')
    ap.add_argument('--dim', type=int, default=128)
    ap.add_argument('--epochs', type=int, default=20)
    ap.add_argument('--local-epochs', type=int, default=5)
    ap.add_argument('--repair-epochs', type=int, default=3)
    ap.add_argument('--batch-size', type=int, default=4096)
    ap.add_argument('--lr', type=float, default=.002)
    ap.add_argument('--local-lr', type=float, default=.001)
    ap.add_argument('--repair-lr', type=float, default=.001)
    ap.add_argument('--l2', type=float, default=1e-6)
    ap.add_argument('--eval-batch', type=int, default=16)
    ap.add_argument('--entity-chunk', type=int, default=4096)
    ap.add_argument('--eval-queries', type=int, default=1000)
    ap.add_argument('--forget-eval-queries', type=int, default=1000)
    args = ap.parse_args()

    torch.set_num_threads(1)
    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    ne, nr = len(data.entities), len(data.relations)
    base = fresh('distmult', ne, nr, args.dim, args.seed, args.device)
    base_stats = train_model(
        base, data.train, ne, args.epochs, args.batch_size, args.lr, args.l2,
        args.seed, args.device,
    )
    deg = degrees(data.train, ne)
    target = max(1, int(round(args.fraction * len(data.train))))

    requests = [
        ('fullstar-high',) + fullstar_stratum(data.train, deg, 'high', target, args.seed + 9003),
        ('exact-card-high',) + exact_card_high(data.train, deg, target, args.seed + 9101),
        ('partial-star-high',) + partial_star_high(data.train, deg, target, args.seed + 9201),
    ]

    rows = []
    request_manifest = []
    for name, fi, selected, meta in requests:
        forget = data.train[fi]
        keep = np.ones(len(data.train), dtype=bool)
        keep[fi] = False
        retain = data.train[keep]
        req_hash = hsh(forget)
        rdeg = retained_degree(retain, ne)
        unsupported = np.asarray([int(e) for e in selected if rdeg[int(e)] == 0], dtype=np.int64)

        ref = fresh('distmult', ne, nr, args.dim, args.seed + 500003, args.device)
        st = time.time()
        train_model(ref, retain, ne, args.epochs, args.batch_size, args.lr, args.l2,
                    args.seed + 500003, args.device)
        refsec = time.time() - st
        rg, rf = evalm(ref, data, retain, forget, ne, args)

        bare, _, _ = local_retrain(
            base, data.train, fi, ne, 1, args.local_epochs, args.batch_size,
            args.local_lr, args.l2, args.seed, args.device,
        )
        bg, bf = evalm(bare.model, data, retain, forget, ne, args)

        restart_seed = (args.seed * 1000003 + len(fi) * 97 + 17027) & 0x7fffffff
        restarted, restart_sec, restart_unsupported, _ = deterministic_family_restart(
            base, retain, selected, restart_seed,
        )
        rloc, _, _ = local_retrain(
            restarted, data.train, fi, ne, 1, args.local_epochs, args.batch_size,
            args.local_lr, args.l2, args.seed, args.device,
        )
        sg, sf = evalm(rloc.model, data, retain, forget, ne, args)

        endpoint = np.unique(np.r_[forget[:, 0], forget[:, 2]]).astype(np.int64)
        ep0, ep_restart = restart_rows_all(base, endpoint, restart_seed + 1001)
        epm, ep_repair, ep_n = repair_star(ep0, retain, endpoint, ne, args, args.seed + 31001)
        eg, ef = evalm(epm, data, retain, forget, ne, args)

        cover = cost_aware_star_cover(forget, retain, ne)
        sc0, sc_restart = restart_rows_all(base, cover, restart_seed + 2001)
        scm, sc_repair, sc_n = repair_star(sc0, retain, cover, ne, args, args.seed + 32001)
        cg, cf = evalm(scm, data, retain, forget, ne, args)

        common = {
            'dataset': args.dataset,
            'model': 'distmult',
            'seed': args.seed,
            'request_mode': name,
            'target_fraction': args.fraction,
            'forget_n': len(fi),
            'realized_fraction': len(fi) / len(data.train),
            'selected_n': len(selected),
            'unsupported_n': len(unsupported),
            'unsupported_fraction': len(unsupported) / max(len(selected), 1),
            'request_hash': req_hash,
            'metadata': json.dumps(meta, sort_keys=True),
        }
        rows.append(method_row(common, 'FiniteRetrain-20', rg, rf, refsec, rg, rf))
        rows.append(method_row(common, 'SchemaCert-L5', bg, bf, bare.seconds, rg, rf))
        rows.append(method_row(common, 'SchemaCert+Restart-L5', sg, sf, restart_sec + rloc.seconds, rg, rf))
        rows.append(method_row(common, 'EndpointEraseRestore-E3', eg, ef, ep_restart + ep_repair, rg, rf, {
            'anchor_count': len(endpoint),
            'anchor_fraction': len(endpoint) / ne,
            'repair_triples': ep_n,
            'repair_fraction': ep_n / max(len(retain), 1),
            'forget_coverage': 1.0,
            'restart_sec': ep_restart,
            'repair_sec': ep_repair,
        }))
        cover_ok = bool(np.all(np.isin(forget[:, 0], cover) | np.isin(forget[:, 2], cover)))
        if not cover_ok:
            raise RuntimeError(f'StarCover failed forgotten-edge coverage for {name} seed={args.seed}')
        rows.append(method_row(common, 'StarCoverEraseRestore-E3', cg, cf, sc_restart + sc_repair, rg, rf, {
            'anchor_count': len(cover),
            'anchor_fraction': len(cover) / ne,
            'repair_triples': sc_n,
            'repair_fraction': sc_n / max(len(retain), 1),
            'forget_coverage': 1.0,
            'restart_sec': sc_restart,
            'repair_sec': sc_repair,
        }))
        request_manifest.append({
            'request_mode': name,
            'request_hash': req_hash,
            'forget_n': int(len(fi)),
            'selected_n': int(len(selected)),
            'unsupported_n': int(len(unsupported)),
            'unsupported_fraction': len(unsupported) / max(len(selected), 1),
            'restart_reported_unsupported_n': int(len(restart_unsupported)),
        })

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    stem = out / f'{args.dataset}_distmult_s{args.seed}_request_aware_reconstruction'
    with stem.with_suffix('.csv').open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    stem.with_suffix('.json').write_text(json.dumps({
        'dataset': args.dataset,
        'seed': args.seed,
        'model': 'distmult',
        'dim': args.dim,
        'fraction': args.fraction,
        'base_train_sec': base_stats.seconds,
        'repair_epochs': args.repair_epochs,
        'requests': request_manifest,
        'rows': rows,
    }, indent=2) + '\n')
    print(f'NELL_REQUEST_AWARE_OK seed={args.seed} requests={len(requests)} rows={len(rows)} out={stem}.csv')


if __name__ == '__main__':
    main()
