
#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.graphdpo_shared import load_graphdpo_shared_checkpoint
from scripts.run_publication_families import select_forget
from scripts.experiments.evaluate_graphdpo_common import (
    graphdpo_vocab,
    parse_named,
    request_fingerprint,
    verify_exported_request,
)
from scripts.experiments.evaluate_graphdpo_common_support import (
    map_supported,
    supported_mask,
)


METHODS = ("Finetune", "GraphDPO", "SGU")


def sha_seed(*parts: object) -> int:
    raw = "|".join(map(str, parts)).encode("utf8")
    return int.from_bytes(hashlib.sha256(raw).digest()[:8], "little") & 0x7FFFFFFF


def endpoint_degree(triples: np.ndarray, ne: int) -> np.ndarray:
    out = np.zeros(ne, dtype=np.int64)
    if len(triples):
        np.add.at(out, triples[:, 0], 1)
        np.add.at(out, triples[:, 2], 1)
    return out


def choose_matched_pairs(
    touched: np.ndarray,
    retained_degree: np.ndarray,
    original_degree: np.ndarray,
    max_pairs: int,
    target_seed: int,
    control_seed: int,
) -> tuple[np.ndarray, np.ndarray, dict]:
    """Exact-match touched and untouched entities on retained endpoint degree.

    We first construct the complete pool of feasible one-to-one exact-degree
    pairs within each retained-degree stratum, then deterministically subsample
    at most max_pairs pairs. This prevents the target-first greedy matching used
    by v1 from leaving high-degree targets with systematically lower-degree
    controls.
    """
    ne = len(retained_degree)
    touched_mask = np.zeros(ne, dtype=bool)
    touched_mask[np.asarray(touched, dtype=np.int64)] = True

    target_pool = np.flatnonzero(touched_mask & (retained_degree > 0))
    control_pool = np.flatnonzero((~touched_mask) & (retained_degree > 0))
    if len(target_pool) == 0 or len(control_pool) == 0:
        raise RuntimeError(
            f"No support-retaining probe possible: targets={len(target_pool)} "
            f"controls={len(control_pool)}"
        )

    rng_t = np.random.default_rng(target_seed)
    rng_c = np.random.default_rng(control_seed)
    feasible_pairs: list[tuple[int, int]] = []
    exact_degrees = sorted(
        set(map(int, retained_degree[target_pool]))
        & set(map(int, retained_degree[control_pool]))
    )

    for deg in exact_degrees:
        ts = target_pool[retained_degree[target_pool] == deg].copy()
        cs = control_pool[retained_degree[control_pool] == deg].copy()
        rng_t.shuffle(ts)
        rng_c.shuffle(cs)

        # Within exact retained-degree strata, prefer controls whose original
        # degree is closest to the target's original degree. Untouched controls
        # satisfy original_degree == retained_degree, so this is a secondary
        # deterministic diagnostic rather than a second exact-match constraint.
        used = np.zeros(len(cs), dtype=bool)
        for t in ts:
            avail = np.flatnonzero(~used)
            if len(avail) == 0:
                break
            cd = np.abs(original_degree[cs[avail]] - original_degree[int(t)])
            j_local = int(np.argmin(cd))
            j = int(avail[j_local])
            feasible_pairs.append((int(t), int(cs[j])))
            used[j] = True

    if not feasible_pairs:
        raise RuntimeError("No exact retained-degree target/control pairs exist")

    rng_pair = np.random.default_rng(
        sha_seed(target_seed, control_seed, "exact-retained-degree-pairs-v2")
    )
    if len(feasible_pairs) > max_pairs:
        ids = np.sort(
            rng_pair.choice(len(feasible_pairs), int(max_pairs), replace=False)
        )
        feasible_pairs = [feasible_pairs[int(i)] for i in ids]

    targets = np.asarray([x[0] for x in feasible_pairs], dtype=np.int64)
    controls = np.asarray([x[1] for x in feasible_pairs], dtype=np.int64)
    retained_mismatch = np.abs(
        retained_degree[targets] - retained_degree[controls]
    )
    if np.any(retained_mismatch != 0):
        raise RuntimeError(
            f"HARD MATCHING GATE FAILED: max retained-degree mismatch="
            f"{int(retained_mismatch.max())}"
        )

    meta = {
        "matching_version": "exact-retained-degree-v2",
        "eligible_touched_positive_support": int(len(target_pool)),
        "eligible_untouched_positive_support": int(len(control_pool)),
        "exact_degree_strata": int(len(exact_degrees)),
        "feasible_exact_pairs_before_subsample": int(
            sum(
                min(
                    int(np.sum(retained_degree[target_pool] == d)),
                    int(np.sum(retained_degree[control_pool] == d)),
                )
                for d in exact_degrees
            )
        ),
        "probed_pairs": int(len(targets)),
        "target_retained_degree_mean": float(np.mean(retained_degree[targets])),
        "control_retained_degree_mean": float(np.mean(retained_degree[controls])),
        "target_original_degree_mean": float(np.mean(original_degree[targets])),
        "control_original_degree_mean": float(np.mean(original_degree[controls])),
        "mean_abs_retained_degree_mismatch": float(np.mean(retained_mismatch)),
        "max_abs_retained_degree_mismatch": int(retained_mismatch.max(initial=0)),
        "mean_abs_original_degree_mismatch": float(
            np.mean(np.abs(original_degree[targets] - original_degree[controls]))
        ),
    }
    return targets, controls, meta


def build_false_contexts(
    side: str,
    retain: np.ndarray,
    targets: np.ndarray,
    controls: np.ndarray,
    all_true: set[tuple[int, int, int]],
    seed: int,
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    out = np.empty((len(targets), 2), dtype=np.int64)

    for i, (target, control) in enumerate(zip(targets, controls)):
        target = int(target)
        control = int(control)
        found = False
        for _ in range(100000):
            h, r, t = map(int, retain[int(rng.integers(0, len(retain)))])
            if target in (h, t) or control in (h, t):
                continue
            if side == "tail":
                ctx = (h, r)
                xt = (h, r, target)
                xc = (h, r, control)
            else:
                ctx = (r, t)
                xt = (target, r, t)
                xc = (control, r, t)
            if xt not in all_true and xc not in all_true:
                out[i] = ctx
                found = True
                break
        if not found:
            raise RuntimeError(
                f"Could not construct false {side} context for "
                f"target={target} control={control}"
            )
    return out


@torch.no_grad()
def mean_tie_target_ranks(
    model,
    side: str,
    contexts: np.ndarray,
    targets: np.ndarray,
    ne: int,
    device: str,
    batch: int,
    chunk: int,
) -> np.ndarray:
    model = model.to(device)
    model.eval()
    cand_all = torch.arange(ne, dtype=torch.long, device=device)
    ranks = []

    for st in range(0, len(contexts), batch):
        ctx = np.asarray(contexts[st:st + batch], dtype=np.int64)
        tgt = np.asarray(targets[st:st + batch], dtype=np.int64)

        if side == "tail":
            triples = np.c_[ctx[:, 0], ctx[:, 1], tgt]
            a = torch.as_tensor(ctx[:, 0], dtype=torch.long, device=device)
            b = torch.as_tensor(ctx[:, 1], dtype=torch.long, device=device)
        else:
            triples = np.c_[tgt, ctx[:, 0], ctx[:, 1]]
            a = torch.as_tensor(ctx[:, 0], dtype=torch.long, device=device)
            b = torch.as_tensor(ctx[:, 1], dtype=torch.long, device=device)

        xt = torch.as_tensor(triples, dtype=torch.long, device=device)
        tgt_t = torch.as_tensor(tgt, dtype=torch.long, device=device)
        true = model.score(xt).float()
        gt = torch.zeros(len(ctx), dtype=torch.long, device=device)
        eq = torch.zeros(len(ctx), dtype=torch.long, device=device)

        for cs in range(0, ne, chunk):
            ce = min(ne, cs + chunk)
            cand = cand_all[cs:ce]
            sc = model.score_candidates(side, a, b, cand).float()
            for j, target in enumerate(tgt):
                target = int(target)
                if cs <= target < ce:
                    sc[j, target - cs] = -torch.inf
            gt += (sc > true[:, None]).sum(1)
            eq += (sc == true[:, None]).sum(1)

        rank = 1.0 + gt.double() + 0.5 * eq.double()
        ranks.append(rank.cpu().numpy())

    return np.concatenate(ranks).astype(np.float64, copy=False)


def summary(x: np.ndarray) -> dict:
    x = np.asarray(x, dtype=float)
    return {
        "n": int(len(x)),
        "mean": float(np.mean(x)),
        "median": float(np.median(x)),
        "q05": float(np.quantile(x, 0.05)),
        "q95": float(np.quantile(x, 0.95)),
    }


def main():
    p = argparse.ArgumentParser(
        description=(
            "Background-placement probe on touched but still-supported entities "
            "for published KGU methods."
        )
    )
    p.add_argument("--dataset", choices=["FB15K-237", "CoDEx-M"], required=True)
    p.add_argument("--fraction", type=float, default=0.10)
    p.add_argument("--request-seed", type=int, choices=[17, 29, 43], required=True)
    p.add_argument("--data-root", type=Path, required=True)
    p.add_argument("--request-dir", type=Path, required=True)
    p.add_argument("--ref-a", type=Path, required=True)
    p.add_argument("--ref-b", type=Path, required=True)
    p.add_argument("--method", action="append", default=[], help="LABEL=checkpoint")
    p.add_argument("--device", default="cuda:0")
    p.add_argument("--max-pairs", type=int, default=256)
    p.add_argument("--eval-batch", type=int, default=16)
    p.add_argument("--entity-chunk", type=int, default=4096)
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()

    if args.max_pairs != 256:
        raise RuntimeError("W9 protocol is frozen: --max-pairs must be 256")

    methods = parse_named(args.method)
    if set(methods) != set(METHODS):
        raise RuntimeError(
            f"Expected exactly methods={sorted(METHODS)}, got {sorted(methods)}"
        )

    torch.set_num_threads(1)
    data = deterministic_holdout(
        load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17
    )
    fi, _ = select_forget(
        data.train,
        args.fraction,
        args.request_seed + int(args.fraction * 10000),
        "random",
    )
    forget = data.train[fi]
    keep = np.ones(len(data.train), dtype=bool)
    keep[fi] = False
    retain = data.train[keep]
    req_hash = request_fingerprint(data, forget)

    manifest, all_data_path = verify_exported_request(
        args.request_dir,
        data,
        forget,
        args.dataset,
        "random",
        args.request_seed,
        args.fraction,
    )
    if manifest.get("request_hash") and manifest["request_hash"] != req_hash:
        raise RuntimeError(
            f"Request hash mismatch: manifest={manifest.get('request_hash')} reconstructed={req_hash}"
        )

    entity2id, relation2id = graphdpo_vocab(all_data_path)
    train_mask = supported_mask(data.train, data, entity2id, relation2id)
    retain_mask = supported_mask(retain, data, entity2id, relation2id)
    valid_mask = supported_mask(data.valid, data, entity2id, relation2id)
    test_mask = supported_mask(data.test, data, entity2id, relation2id)
    forget_mask = supported_mask(forget, data, entity2id, relation2id)
    if not forget_mask.all():
        raise RuntimeError("Forgotten triples are not fully covered by common vocabulary")

    train_c = map_supported(data.train[train_mask], data, entity2id, relation2id)
    retain_c = map_supported(retain[retain_mask], data, entity2id, relation2id)
    valid_c = map_supported(data.valid[valid_mask], data, entity2id, relation2id)
    test_c = map_supported(data.test[test_mask], data, entity2id, relation2id)
    forget_c = map_supported(forget, data, entity2id, relation2id)

    ne = len(entity2id)
    touched = np.unique(forget_c[:, [0, 2]])
    retained_degree = endpoint_degree(retain_c, ne)
    original_degree = endpoint_degree(train_c, ne)
    zero_support_touched = touched[retained_degree[touched] == 0]

    target_seed = sha_seed(
        args.dataset, args.request_seed, req_hash, "published-placement-targets-v2"
    )
    control_seed = sha_seed(
        args.dataset, args.request_seed, req_hash, "published-placement-controls-v2"
    )
    targets, controls, match_meta = choose_matched_pairs(
        touched,
        retained_degree,
        original_degree,
        args.max_pairs,
        target_seed,
        control_seed,
    )
    if match_meta["mean_abs_retained_degree_mismatch"] != 0.0:
        raise RuntimeError(
            "HARD MATCHING GATE FAILED: retained-degree mismatch must be exactly zero"
        )
    if match_meta["probed_pairs"] < 128:
        raise RuntimeError(
            f"HARD MATCHING GATE FAILED: only {match_meta['probed_pairs']} exact pairs; "
            "protocol requires at least 128"
        )

    all_true_arr = np.concatenate([train_c, valid_c, test_c], axis=0)
    all_true = {tuple(map(int, row)) for row in all_true_arr}
    context_seed = sha_seed(
        args.dataset, args.request_seed, req_hash, "published-placement-contexts-v2"
    )
    head_ctx = build_false_contexts(
        "head", retain_c, targets, controls, all_true, context_seed
    )
    tail_ctx = build_false_contexts(
        "tail", retain_c, targets, controls, all_true, context_seed + 1
    )

    checkpoints = {"RefA": str(args.ref_a), "RefB": str(args.ref_b), **methods}
    rank_store: dict[str, dict[str, dict[str, np.ndarray]]] = {}
    for label, path in checkpoints.items():
        model = load_graphdpo_shared_checkpoint(path)
        rank_store[label] = {}
        for side, ctx in (("head", head_ctx), ("tail", tail_ctx)):
            rank_store[label][side] = {
                "target": mean_tie_target_ranks(
                    model, side, ctx, targets, ne, args.device,
                    args.eval_batch, args.entity_chunk,
                ),
                "control": mean_tie_target_ranks(
                    model, side, ctx, controls, ne, args.device,
                    args.eval_batch, args.entity_chunk,
                ),
            }
        del model
        if args.device.startswith("cuda"):
            torch.cuda.empty_cache()

    args.out.mkdir(parents=True, exist_ok=True)
    stem = f"{args.dataset}_seed{args.request_seed}_{req_hash}_published_placement_v2"
    rows = []
    method_summary = {}

    for method in METHODS:
        all_target_promo = []
        all_control_promo = []
        all_did = []
        side_summary = {}

        for side, ctx in (("head", head_ctx), ("tail", tail_ctx)):
            ra_t = rank_store["RefA"][side]["target"]
            rb_t = rank_store["RefB"][side]["target"]
            ra_c = rank_store["RefA"][side]["control"]
            rb_c = rank_store["RefB"][side]["control"]
            m_t = rank_store[method][side]["target"]
            m_c = rank_store[method][side]["control"]

            target_promo = 0.5 * (np.log10(ra_t) + np.log10(rb_t)) - np.log10(m_t)
            control_promo = 0.5 * (np.log10(ra_c) + np.log10(rb_c)) - np.log10(m_c)
            did = target_promo - control_promo

            all_target_promo.append(target_promo)
            all_control_promo.append(control_promo)
            all_did.append(did)
            side_summary[side] = {
                "target_promotion": summary(target_promo),
                "control_promotion": summary(control_promo),
                "difference_in_differences": summary(did),
            }

            for i in range(len(targets)):
                row = {
                    "dataset": args.dataset,
                    "request_seed": int(args.request_seed),
                    "request_hash": req_hash,
                    "method": method,
                    "side": side,
                    "probe_id": int(i),
                    "target": int(targets[i]),
                    "control": int(controls[i]),
                    "target_retained_degree": int(retained_degree[targets[i]]),
                    "control_retained_degree": int(retained_degree[controls[i]]),
                    "target_original_degree": int(original_degree[targets[i]]),
                    "control_original_degree": int(original_degree[controls[i]]),
                    "context_a": int(ctx[i, 0]),
                    "context_b": int(ctx[i, 1]),
                    "rank_candidate_target": float(m_t[i]),
                    "rank_refA_target": float(ra_t[i]),
                    "rank_refB_target": float(rb_t[i]),
                    "rank_candidate_control": float(m_c[i]),
                    "rank_refA_control": float(ra_c[i]),
                    "rank_refB_control": float(rb_c[i]),
                    "target_promotion": float(target_promo[i]),
                    "control_promotion": float(control_promo[i]),
                    "did": float(did[i]),
                }
                rows.append(row)

        method_summary[method] = {
            "target_promotion": summary(np.concatenate(all_target_promo)),
            "control_promotion": summary(np.concatenate(all_control_promo)),
            "difference_in_differences": summary(np.concatenate(all_did)),
            "sides": side_summary,
        }

    csv_path = args.out / f"{stem}_rows.csv"
    with csv_path.open("w", newline="", encoding="utf8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    payload = {
        "protocol": "published-method-placement-v2",
        "dataset": args.dataset,
        "request_seed": int(args.request_seed),
        "fraction": float(args.fraction),
        "request_hash": req_hash,
        "common_vocab_entities": int(ne),
        "forget_n": int(len(forget_c)),
        "touched_entities": int(len(touched)),
        "zero_retained_support_touched": int(len(zero_support_touched)),
        "positive_retained_support_touched": int(np.sum(retained_degree[touched] > 0)),
        "target_seed": int(target_seed),
        "control_seed": int(control_seed),
        "context_seed": int(context_seed),
        "matching": match_meta,
        "rank_definition": "unfiltered full-vocabulary mean-tie rank on synthetic false contexts",
        "promotion_definition": (
            "0.5*(log10 RefA rank + log10 RefB rank) - log10 candidate rank"
        ),
        "primary_statistic": "touched promotion - matched untouched-control promotion",
        "methods": method_summary,
        "checkpoints": checkpoints,
        "rows_csv": str(csv_path),
    }
    json_path = args.out / f"{stem}.json"
    json_path.write_text(json.dumps(payload, indent=2) + "\n")

    print(
        "W9_PUBLISHED_PLACEMENT_OK",
        args.dataset,
        args.request_seed,
        req_hash,
        "pairs",
        len(targets),
        "zero_support_touched",
        len(zero_support_touched),
        flush=True,
    )
    for method in METHODS:
        rec = method_summary[method]
        print(
            method,
            "target_promotion",
            f"{rec['target_promotion']['mean']:.10f}",
            "control_promotion",
            f"{rec['control_promotion']['mean']:.10f}",
            "DID",
            f"{rec['difference_in_differences']['mean']:.10f}",
            flush=True,
        )


if __name__ == "__main__":
    main()
