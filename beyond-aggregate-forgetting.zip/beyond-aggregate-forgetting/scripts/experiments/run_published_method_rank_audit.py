#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.graphdpo_shared import load_graphdpo_shared_checkpoint
from scripts.run_publication_families import select_forget
from scripts.experiments.evaluate_graphdpo_common import (
    graphdpo_vocab,
    parse_named,
    request_fingerprint,
    verify_exported_request,
)
from scripts.experiments.evaluate_graphdpo_common_support import (
    map_supported,
    supported_mask,
)


def filter_maps(*arrs: np.ndarray):
    tails: dict[tuple[int, int], set[int]] = {}
    heads: dict[tuple[int, int], set[int]] = {}
    for arr in arrs:
        for h, r, t in np.asarray(arr, dtype=np.int64):
            h, r, t = int(h), int(r), int(t)
            tails.setdefault((h, r), set()).add(t)
            heads.setdefault((r, t), set()).add(h)
    return tails, heads


@torch.no_grad()
def ranks_for_queries(model, queries: np.ndarray, ne: int, truth, device: str,
                      batch: int = 16, chunk: int = 4096) -> np.ndarray:
    tails, heads = filter_maps(*truth)
    model = model.to(device)
    model.eval()
    cand_full = torch.arange(ne, dtype=torch.long, device=device)
    tail_ranks: list[float] = []
    head_ranks: list[float] = []

    for st in range(0, len(queries), batch):
        b = np.asarray(queries[st:st + batch], dtype=np.int64)
        bt = torch.as_tensor(b, dtype=torch.long, device=device)
        true = model.score(bt).float()
        B = len(b)

        counts = torch.zeros(B, dtype=torch.long, device=device)
        for cs in range(0, ne, chunk):
            ce = min(ne, cs + chunk)
            cand = cand_full[cs:ce]
            sc = model.score_candidates('tail', bt[:, 0], bt[:, 1], cand).float()
            for j, (h, r, t) in enumerate(b):
                for x in tails.get((int(h), int(r)), ()):
                    if x != int(t) and cs <= x < ce:
                        sc[j, int(x) - cs] = -torch.inf
            counts += (sc > true[:, None]).sum(1)
        tail_ranks.extend((counts + 1).cpu().numpy().astype(float).tolist())

        counts = torch.zeros(B, dtype=torch.long, device=device)
        for cs in range(0, ne, chunk):
            ce = min(ne, cs + chunk)
            cand = cand_full[cs:ce]
            sc = model.score_candidates('head', bt[:, 1], bt[:, 2], cand).float()
            for j, (h, r, t) in enumerate(b):
                for x in heads.get((int(r), int(t)), ()):
                    if x != int(h) and cs <= x < ce:
                        sc[j, int(x) - cs] = -torch.inf
            counts += (sc > true[:, None]).sum(1)
        head_ranks.extend((counts + 1).cpu().numpy().astype(float).tolist())

    return np.r_[np.asarray(tail_ranks), np.asarray(head_ranks)]


def rank_pair(a: np.ndarray, b: np.ndarray) -> dict[str, float]:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    return {
        'mrr_a': float(np.mean(1.0 / a)),
        'mrr_b': float(np.mean(1.0 / b)),
        'mrr_gap': float(abs(np.mean(1.0 / a) - np.mean(1.0 / b))),
        'exact_rank_disagreement': float(np.mean(a != b)),
        'mean_abs_log10_rank_gap': float(np.mean(np.abs(np.log10(a) - np.log10(b)))),
        'top10_membership_disagreement': float(np.mean((a <= 10) != (b <= 10))),
        'top100_membership_disagreement': float(np.mean((a <= 100) != (b <= 100))),
    }


def main():
    p = argparse.ArgumentParser(
        description='Calibrated query-level rank audit for published KGE-unlearning methods.'
    )
    p.add_argument('--dataset', choices=['FB15K-237','CoDEx-M'], required=True)
    p.add_argument('--fraction', type=float, default=0.10)
    p.add_argument('--request-seed', type=int, choices=[17,29,43], required=True)
    p.add_argument('--data-root', type=Path, required=True)
    p.add_argument('--request-dir', type=Path, required=True)
    p.add_argument('--ref-a', type=Path, required=True)
    p.add_argument('--ref-b', type=Path, required=True)
    p.add_argument('--method', action='append', default=[], help='LABEL=checkpoint')
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--max-queries', type=int, default=1000)
    p.add_argument('--eval-batch', type=int, default=16)
    p.add_argument('--entity-chunk', type=int, default=4096)
    p.add_argument('--out', type=Path, required=True)
    args = p.parse_args()

    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    methods = parse_named(args.method)
    required = {'Finetune','GraphDPO','SGU'}
    if set(methods) != required:
        raise ValueError(f'Expected exactly {sorted(required)}, got {sorted(methods)}')

    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    fi, _ = select_forget(
        data.train,
        args.fraction,
        args.request_seed + int(args.fraction * 10000),
        'random',
    )
    forget = data.train[fi]
    keep = np.ones(len(data.train), dtype=bool)
    keep[fi] = False
    retain = data.train[keep]
    req_hash = request_fingerprint(data, forget)

    manifest, all_data_path = verify_exported_request(
        args.request_dir, data, forget, args.dataset, 'random',
        args.request_seed, args.fraction,
    )
    if manifest.get('request_hash') and manifest['request_hash'] != req_hash:
        raise RuntimeError('Request hash mismatch')

    entity2id, relation2id = graphdpo_vocab(all_data_path)
    retain_mask = supported_mask(retain, data, entity2id, relation2id)
    valid_mask = supported_mask(data.valid, data, entity2id, relation2id)
    test_mask = supported_mask(data.test, data, entity2id, relation2id)
    forget_mask = supported_mask(forget, data, entity2id, relation2id)
    if not forget_mask.all():
        raise RuntimeError('Forgotten queries are not fully covered by common vocabulary')

    retain_c = map_supported(retain[retain_mask], data, entity2id, relation2id)
    valid_c = map_supported(data.valid[valid_mask], data, entity2id, relation2id)
    test_c = map_supported(data.test[test_mask], data, entity2id, relation2id)
    forget_c = map_supported(forget, data, entity2id, relation2id)
    truth = (retain_c, valid_c, test_c, forget_c)

    rng = np.random.default_rng(19092026 + args.request_seed)
    if args.max_queries > 0 and len(forget_c) > args.max_queries:
        chosen = np.sort(rng.choice(len(forget_c), args.max_queries, replace=False))
        q = forget_c[chosen]
        q_idx = chosen
    else:
        q = forget_c
        q_idx = np.arange(len(forget_c), dtype=np.int64)

    checkpoints = {'RefA': str(args.ref_a), 'RefB': str(args.ref_b), **methods}
    ranks: dict[str, np.ndarray] = {}
    for label, path in checkpoints.items():
        model = load_graphdpo_shared_checkpoint(path)
        ranks[label] = ranks_for_queries(
            model, q, len(entity2id), truth, args.device,
            batch=args.eval_batch, chunk=args.entity_chunk,
        )
        del model
        if args.device.startswith('cuda'):
            torch.cuda.empty_cache()

    null = rank_pair(ranks['RefB'], ranks['RefA'])
    comparisons = {}
    for label in ('Finetune','GraphDPO','SGU'):
        m = rank_pair(ranks[label], ranks['RefA'])
        m['null_mean_abs_log10_rank_gap'] = null['mean_abs_log10_rank_gap']
        m['logrank_excess_over_null'] = (
            m['mean_abs_log10_rank_gap'] - null['mean_abs_log10_rank_gap']
        )
        m['null_mrr_gap'] = null['mrr_gap']
        m['mrr_gap_excess_over_null'] = m['mrr_gap'] - null['mrr_gap']
        m['null_top10_membership_disagreement'] = null['top10_membership_disagreement']
        m['top10_excess_over_null'] = (
            m['top10_membership_disagreement'] - null['top10_membership_disagreement']
        )
        m['null_top100_membership_disagreement'] = null['top100_membership_disagreement']
        m['top100_excess_over_null'] = (
            m['top100_membership_disagreement'] - null['top100_membership_disagreement']
        )
        comparisons[label] = m

    args.out.mkdir(parents=True, exist_ok=True)
    stem = f'{args.dataset}_seed{args.request_seed}_published_rank'
    payload = {
        'dataset': args.dataset,
        'fraction': args.fraction,
        'request_seed': args.request_seed,
        'request_hash': req_hash,
        'forget_n': int(len(forget)),
        'sampled_query_triples': int(len(q)),
        'rankings_per_model': int(len(ranks['RefA'])),
        'query_index_seed': int(19092026 + args.request_seed),
        'null': null,
        'comparisons': comparisons,
        'checkpoints': checkpoints,
    }
    (args.out / f'{stem}.json').write_text(json.dumps(payload, indent=2) + '\n')

    sides = np.array(['tail'] * len(q) + ['head'] * len(q), dtype=object)
    source_idx = np.r_[q_idx, q_idx]
    rows = []
    for i in range(len(sides)):
        row = {
            'dataset': args.dataset,
            'request_seed': args.request_seed,
            'request_hash': req_hash,
            'query_index': int(source_idx[i]),
            'side': str(sides[i]),
        }
        for label in ('RefA','RefB','Finetune','GraphDPO','SGU'):
            row[f'rank_{label}'] = float(ranks[label][i])
        rows.append(row)
    with (args.out / f'{stem}_rows.csv').open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    print(json.dumps({
        'dataset': args.dataset,
        'seed': args.request_seed,
        'null_logrank': null['mean_abs_log10_rank_gap'],
        'Finetune_logrank': comparisons['Finetune']['mean_abs_log10_rank_gap'],
        'GraphDPO_logrank': comparisons['GraphDPO']['mean_abs_log10_rank_gap'],
        'SGU_logrank': comparisons['SGU']['mean_abs_log10_rank_gap'],
        'ok': True,
    }, indent=2))
    print('PUBLISHED_METHOD_RANK_AUDIT_OK')


if __name__ == '__main__':
    main()
