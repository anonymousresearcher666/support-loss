#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
import time
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.family_models import make_model
from schemacert.train import corrupt_tail, loss_batch, train_model
from schemacert.unlearn import local_retrain
from scripts.run_publication_families import filtered_lp, param_dist, select_forget


def fresh(name, ne, nr, dim, seed, device):
    torch.manual_seed(seed)
    np.random.seed(seed)
    if device.startswith('cuda'):
        torch.cuda.manual_seed_all(seed)
    return make_model(name, ne, nr, dim).to(device)


def flat_named_params(model):
    names, params, shapes, sizes = [], [], [], []
    for name, p in model.named_parameters():
        if p.requires_grad:
            names.append(name); params.append(p); shapes.append(tuple(p.shape)); sizes.append(p.numel())
    return names, params, shapes, sizes


def flatten_tensors(xs):
    return torch.cat([x.reshape(-1) for x in xs])


def unflatten(v, params):
    out = []
    off = 0
    for p in params:
        n = p.numel(); out.append(v[off:off+n].view_as(p)); off += n
    return out


def affected_mask(model, affected_entities, affected_relations, device):
    masks = []
    ae = torch.as_tensor(affected_entities, dtype=torch.long, device=device)
    ar = torch.as_tensor(affected_relations, dtype=torch.long, device=device)
    for name, p in model.named_parameters():
        m = torch.zeros_like(p, dtype=torch.bool)
        if name.endswith('entity.weight'):
            m[ae] = True
        elif name.endswith('relation.weight'):
            m[ar] = True
        masks.append(m.reshape(-1))
    return torch.cat(masks)


def sample_curvature_triples(retain, ae, ar, n, seed):
    rng = np.random.default_rng(seed)
    aeh = np.isin(retain[:, 0], ae); aet = np.isin(retain[:, 2], ae); arr = np.isin(retain[:, 1], ar)
    cross = (aeh ^ aet) | (arr & ~(aeh & aet))
    cross_idx = np.flatnonzero(cross)
    other_idx = np.flatnonzero(~cross)
    take_cross = min(len(cross_idx), max(1, n // 2))
    ci = cross_idx if len(cross_idx) <= take_cross else rng.choice(cross_idx, take_cross, replace=False)
    left = max(0, n - len(ci))
    oi = other_idx if len(other_idx) <= left else rng.choice(other_idx, left, replace=False)
    idx = np.unique(np.r_[ci, oi]).astype(np.int64)
    if len(idx) < min(n, len(retain)):
        rest = np.setdiff1d(np.arange(len(retain)), idx, assume_unique=False)
        add_n = min(len(rest), min(n, len(retain)) - len(idx))
        if add_n:
            idx = np.r_[idx, rng.choice(rest, add_n, replace=False)]
    return retain[np.asarray(idx, dtype=np.int64)], float(cross.mean()), int(cross.sum())


def make_hvp(model, pos_np, n_entities, seed, l2, damping, device):
    names, params, _, _ = flat_named_params(model)
    rng = np.random.default_rng(seed)
    neg_np = corrupt_tail(pos_np.copy(), n_entities, rng)
    pos = torch.as_tensor(pos_np, dtype=torch.long, device=device)
    neg = torch.as_tensor(neg_np, dtype=torch.long, device=device)

    def hvp(v):
        model.zero_grad(set_to_none=True)
        loss = loss_batch(model, pos, neg, l2)
        g = torch.autograd.grad(loss, params, create_graph=True, retain_graph=True, allow_unused=False)
        vv = unflatten(v, params)
        dot = sum((gi * vi).sum() for gi, vi in zip(g, vv))
        h = torch.autograd.grad(dot, params, create_graph=False, retain_graph=False, allow_unused=False)
        return flatten_tensors(h).detach() + damping * v

    return hvp, names, params


def cg_solve(matvec, b, max_iter=32, tol=1e-4):
    x = torch.zeros_like(b)
    r = b.clone(); p = r.clone(); rr = torch.dot(r, r)
    rr0 = float(rr)
    if not math.isfinite(rr0):
        return x, 0, False, 'nonfinite_rhs'
    if rr0 == 0.0:
        return x, 0, True, 'zero_rhs'
    bnorm = math.sqrt(max(rr0, 0.0))
    it = 0
    min_rayleigh = float('inf')
    for it in range(1, max_iter + 1):
        Ap = matvec(p)
        den = torch.dot(p, Ap)
        pp = torch.dot(p, p)
        den_v = float(den); pp_v = float(pp)
        if not math.isfinite(den_v) or not math.isfinite(pp_v):
            return x, it, False, 'nonfinite_curvature'
        if pp_v <= 0.0:
            return x, it, True, 'zero_direction'
        rayleigh = den_v / pp_v
        min_rayleigh = min(min_rayleigh, rayleigh)
        # Do not threshold p^T A p absolutely: cross-block RHS vectors can be
        # tiny. The scale-invariant Rayleigh quotient is the curvature test.
        if rayleigh <= 0.0:
            return x, it, False, f'nonpositive_curvature(rayleigh={rayleigh:.3e})'
        alpha = rr / den
        x = x + alpha * p
        r = r - alpha * Ap
        rr_new = torch.dot(r, r)
        rr_new_v = float(rr_new)
        if not math.isfinite(rr_new_v):
            return x, it, False, 'nonfinite_residual'
        relres = math.sqrt(max(rr_new_v, 0.0)) / max(bnorm, 1e-30)
        if relres <= tol:
            return x, it, True, f'converged(relres={relres:.3e},min_rayleigh={min_rayleigh:.3e})'
        beta = rr_new / rr
        p = r + beta * p
        rr = rr_new
    relres = math.sqrt(max(float(rr), 0.0)) / max(bnorm, 1e-30)
    # A positive Rayleigh quotient is necessary but not sufficient: an
    # unconverged inverse solve biases the generalized power iteration.
    return x, it, False, f'max_iter_unconverged(relres={relres:.3e},min_rayleigh={min_rayleigh:.3e})'


def spectral_eta(hvp, mask_a, power_iters=4, cg_iters=32, seed=0):
    dtype = torch.float32
    ma = mask_a.to(dtype=dtype); mc = (~mask_a).to(dtype=dtype)
    P = len(ma)
    if int(ma.sum()) == 0 or int(mc.sum()) == 0:
        return 0.0, {'status': 'degenerate_partition', 'cg_iters': 0, 'eta2': 0.0}
    gen = torch.Generator(device=ma.device); gen.manual_seed(seed)
    v = torch.randn(P, generator=gen, device=ma.device, dtype=dtype) * mc

    def haa(x): return hvp(x * ma) * ma
    def hcc(x): return hvp(x * mc) * mc
    def hac(x): return hvp(x * mc) * ma
    def hca(x): return hvp(x * ma) * mc

    Hv = hcc(v)
    q = float(torch.dot(v, Hv))
    if not math.isfinite(q) or q <= 0:
        return float('nan'), {'status': 'nonpositive_Hcc_init', 'initial_Hcc_quadratic': q}
    v = v / math.sqrt(q)
    total_cg = 0
    lam = float('nan')
    cg_notes = []
    for pit in range(power_iters):
        y = hac(v)
        xa, ita, oka, notea = cg_solve(haa, y, max_iter=cg_iters)
        total_cg += ita; cg_notes.append(f'A{pit}:{notea}')
        if not oka:
            return float('nan'), {'status': 'cg_A_failed', 'cg_iters': total_cg, 'cg_notes': cg_notes}
        z = hca(xa)
        w, itc, okc, notec = cg_solve(hcc, z, max_iter=cg_iters)
        total_cg += itc; cg_notes.append(f'C{pit}:{notec}')
        if not okc:
            return float('nan'), {'status': 'cg_C_failed', 'cg_iters': total_cg, 'cg_notes': cg_notes}
        Hw = hcc(w)
        wn = float(torch.dot(w, Hw))
        if not math.isfinite(wn) or wn <= 1e-20:
            return 0.0, {'status': 'zero_cross', 'cg_iters': total_cg, 'cg_notes': cg_notes, 'eta2': 0.0}
        v = w / math.sqrt(wn)
        y = hac(v)
        xa, ita, oka, notea = cg_solve(haa, y, max_iter=cg_iters)
        total_cg += ita; cg_notes.append(f'AR{pit}:{notea}')
        if not oka:
            return float('nan'), {'status': 'cg_A_rayleigh_failed', 'cg_iters': total_cg, 'cg_notes': cg_notes}
        z = hca(xa)
        den = float(torch.dot(v, hcc(v)))
        num = float(torch.dot(v, z))
        lam = max(0.0, num / max(den, 1e-20))
    return math.sqrt(lam), {'status': 'ok', 'cg_iters': total_cg, 'cg_notes': cg_notes, 'eta2': lam}


def estimate_eta_with_damping(model, curv_np, ne, mask_a, args):
    attempts = []
    for damping in args.damping_grid:
        hvp, _, _ = make_hvp(model, curv_np, ne, args.seed + 12345, args.l2, damping, args.device)
        eta, meta = spectral_eta(hvp, mask_a, args.power_iters, args.cg_iters, args.seed + 77)
        attempts.append({'damping': float(damping), 'eta': eta if math.isfinite(eta) else None, **meta})
        if meta.get('status') in ('ok', 'zero_cross', 'degenerate_partition') and math.isfinite(eta):
            return eta, meta, float(damping), attempts
    return float('nan'), {'status': 'all_damping_attempts_failed'}, float('nan'), attempts


def run(args):
    t0 = time.time()
    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    ne, nr = len(data.entities), len(data.relations)
    base = fresh(args.model, ne, nr, args.dim, args.seed, args.device)
    base_stats = train_model(base, data.train, ne, args.epochs, args.batch_size, args.lr, args.l2, args.seed, args.device)
    fi, meta = select_forget(data.train, args.fraction, args.seed + int(args.fraction * 10000), args.policy)
    forget = data.train[fi]
    local, retain, _ = local_retrain(base, data.train, fi, ne, 1, args.local_epochs, args.batch_size, args.local_lr, args.l2, args.seed, args.device)
    ref = fresh(args.model, ne, nr, args.dim, args.seed, args.device)
    ref_stats = train_model(ref, retain, ne, args.ref_epochs, args.batch_size, args.lr, args.l2, args.seed, args.device)

    truth = (retain, data.valid, data.test)
    local_lp = filtered_lp(local.model, data.test, ne, truth, args.device, 8, args.entity_chunk, args.eval_queries, args.seed)
    ref_lp = filtered_lp(ref, data.test, ne, truth, args.device, 8, args.entity_chunk, args.eval_queries, args.seed)
    forget_truth = (retain, data.valid, data.test, forget)
    local_f = filtered_lp(local.model, forget, ne, forget_truth, args.device, 8, args.entity_chunk, args.forget_eval_queries, args.seed)
    ref_f = filtered_lp(ref, forget, ne, forget_truth, args.device, 8, args.entity_chunk, args.forget_eval_queries, args.seed)

    curv_np, boundary_ratio, boundary_n = sample_curvature_triples(retain, local.affected_entities, local.affected_relations, args.curvature_sample, args.seed + 991)
    mask_a = affected_mask(base, local.affected_entities, local.affected_relations, args.device)
    eta, eta_meta, damping_used, eta_attempts = estimate_eta_with_damping(base, curv_np, ne, mask_a, args)

    inc = (np.isin(retain[:,0], local.affected_entities) | np.isin(retain[:,2], local.affected_entities) | np.isin(retain[:,1], local.affected_relations))
    degree_mass_ratio = float(inc.mean())
    p_dist = param_dist(local.model, ref)
    row = {
        'dataset': args.dataset, 'model': args.model, 'policy': args.policy, 'seed': args.seed,
        'fraction': args.fraction, 'forget_n': int(len(fi)), 'request_meta': json.dumps(meta, separators=(',', ':')),
        'dim': args.dim, 'base_epochs': args.epochs, 'ref_epochs': args.ref_epochs, 'local_epochs': args.local_epochs,
        'eta_hvp': eta, 'eta_status': eta_meta.get('status'), 'eta_meta': json.dumps(eta_meta, separators=(',', ':')),
        'hessian_damping_used': damping_used,
        'hessian_damping_grid': json.dumps([float(x) for x in args.damping_grid], separators=(',', ':')),
        'eta_damping_attempts': json.dumps(eta_attempts, separators=(',', ':')),
        'curvature_sample_n': int(len(curv_np)),
        'boundary_ratio': boundary_ratio, 'boundary_n': boundary_n, 'boundary_proxy_sqrt': math.sqrt(max(boundary_ratio, 0.0)),
        'degree_mass_ratio': degree_mass_ratio,
        'parameter_distance_to_reference': p_dist,
        'global_mrr_gap': abs(local_lp['mrr'] - ref_lp['mrr']),
        'forgotten_mrr_gap': abs(local_f['mrr'] - ref_f['mrr']),
        'local_mrr': local_lp['mrr'], 'reference_mrr': ref_lp['mrr'],
        'local_forgotten_mrr': local_f['mrr'], 'reference_forgotten_mrr': ref_f['mrr'],
        'parameter_fraction': local.parameter_fraction,
        'unique_work_fraction': local.work_unique_triples / max(len(retain), 1),
        'speedup_vs_reference': ref_stats.seconds / max(local.seconds, 1e-12),
        'base_train_sec': base_stats.seconds, 'local_sec': local.seconds, 'reference_retrain_sec': ref_stats.seconds,
        'wall_sec': time.time() - t0,
    }
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    stem = f"{args.dataset}_{args.model}_{args.policy}_f{args.fraction:.2f}_s{args.seed}"
    with open(out / f'{stem}.json', 'w') as f: json.dump(row, f, indent=2)
    with open(out / f'{stem}.csv', 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=row.keys()); w.writeheader(); w.writerow(row)
    print(json.dumps(row, sort_keys=True), flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--dataset', required=True); p.add_argument('--model', choices=['transe','distmult','complex'], required=True)
    p.add_argument('--policy', choices=['entity','relation'], required=True); p.add_argument('--seed', type=int, required=True)
    p.add_argument('--fraction', type=float, required=True); p.add_argument('--data-root', default='data'); p.add_argument('--out', required=True)
    p.add_argument('--device', default='cuda'); p.add_argument('--dim', type=int, default=128)
    p.add_argument('--epochs', type=int, default=20); p.add_argument('--ref-epochs', type=int, default=20); p.add_argument('--local-epochs', type=int, default=5)
    p.add_argument('--batch-size', type=int, default=32768); p.add_argument('--lr', type=float, default=.002); p.add_argument('--local-lr', type=float, default=.001); p.add_argument('--l2', type=float, default=1e-6)
    p.add_argument('--eval-queries', type=int, default=1000); p.add_argument('--forget-eval-queries', type=int, default=1000); p.add_argument('--entity-chunk', type=int, default=8192)
    p.add_argument('--curvature-sample', type=int, default=1024)
    p.add_argument('--damping-grid', type=float, nargs='+', default=[0.0001, 0.001, 0.01, 0.1, 1.0])
    p.add_argument('--power-iters', type=int, default=4); p.add_argument('--cg-iters', type=int, default=32)
    run(p.parse_args())


if __name__ == '__main__': main()