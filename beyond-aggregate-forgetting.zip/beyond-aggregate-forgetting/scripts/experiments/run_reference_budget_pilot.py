#!/usr/bin/env python3
"""New full-split DistMult reference-budget and equal-update study.
Not the archived TransE/GraphDPO rescore. All settings fixed before outcomes.
100 epochs is a budget, not convergence. Preserve predictions and provenance.
"""
from __future__ import annotations
import argparse, copy, hashlib, json, platform, time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from schemacert.data import load_dataset
from schemacert.family_models import DistMult
from schemacert.unlearn import affected_region

PROTOCOL={'name':'full-split-distmult-reference-budget-v1','dim':128,'base_epochs':20,
 'reference_epochs':[20,50,100],'seeds':[17,29,43],
 'request':'complete highest-degree entity stars, ID tie-break','nominal_fraction':.10,
 'correction_presentations':'5*retained_triples','lr':.002,'batch':2048,'l2_mean':1e-6,
 'negative_ratio':1,'negative_rule':'uniform tail excluding positive tail; unfiltered',
 'query_seed':19072026,'queries_per_set':256,'optimizer':'Adam defaults',
 'training_dtype':'float32','evaluation_dtype':'float64','certified':False,
 'scope':'new DistMult study, not original TransE baseline rescore'}


def hash_array(a):return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()


def star_request(train,fraction=.1):
 ne=int(train[:,[0,2]].max())+1
 degree=np.bincount(train[:,[0,2]].reshape(-1),minlength=ne)
 order=np.lexsort((np.arange(ne),-degree));chosen=[];mask=np.zeros(len(train),bool)
 for e in order:
  chosen.append(int(e));mask|=(train[:,0]==e)|(train[:,2]==e)
  if mask.sum()>=max(1,round(fraction*len(train))):break
 if mask.all():raise ValueError('Complete data deletion is out of scope')
 return np.flatnonzero(mask),np.asarray(chosen,dtype=np.int64)


def corrupt_tail(pos,ne,rng):
 if ne<2:raise ValueError('Two entities required')
 out=pos.copy();z=rng.integers(0,ne-1,size=len(pos),dtype=np.int64)
 out[:,2]=z+(z>=pos[:,2]);return out


def fresh(ne,nr,seed,dim=128):
 with torch.random.fork_rng():
  torch.manual_seed(seed);return DistMult(ne,nr,dim)


def epoch(model,work,opt,rng,ne,budget=None,masks=None):
 budget=len(work) if budget is None else int(budget)
 if len(work)==0 or budget<=0:raise ValueError('Nonempty stream required')
 order=np.empty(0,dtype=int);cursor=0;consumed=0;loss_sum=0.;steps=0
 while consumed<budget:
  wanted=min(PROTOCOL['batch'],budget-consumed);pieces=[]
  while wanted:
   if cursor==len(order):order=rng.permutation(len(work));cursor=0
   n=min(wanted,len(order)-cursor);pieces.append(order[cursor:cursor+n]);cursor+=n;wanted-=n
  ix=np.concatenate(pieces);p=work[ix];n=corrupt_tail(p,ne,rng)
  opt.zero_grad(set_to_none=True)
  loss=F.softplus(-model.score(torch.from_numpy(p))).mean()+F.softplus(model.score(torch.from_numpy(n))).mean()
  loss=loss+PROTOCOL['l2_mean']*sum((q*q).mean() for q in model.parameters())
  if not torch.isfinite(loss):raise FloatingPointError('Nonfinite loss')
  loss.backward()
  if masks is not None:
   model.entity.weight.grad.mul_(masks[0]);model.relation.weight.grad.mul_(masks[1])
  opt.step();consumed+=len(ix);steps+=1;loss_sum+=float(loss.detach())*len(ix)
 return {'loss':loss_sum/consumed,'presentations':consumed,'steps':steps}


def train_trajectory(ne,nr,seed,train,max_epoch,label,out,callback):
 model=fresh(ne,nr,seed);opt=torch.optim.Adam(model.parameters(),lr=PROTOCOL['lr'])
 rng=np.random.default_rng(seed);trace=[];start=time.perf_counter()
 for e in range(1,max_epoch+1):
  stats=epoch(model,train,opt,rng,ne);trace.append({'epoch':e,**stats,'elapsed_sec':time.perf_counter()-start})
  if e in (20,50,100):
   callback(f'{label}{e}',model,trace[-1])
   torch.save({'state_dict':model.state_dict(),'epoch':e,'seed':seed,'protocol':PROTOCOL},out/f'{label}{e}.pt')
   print(label,e,stats['loss'],time.perf_counter()-start,flush=True)
 (out/f'{label}_training.json').write_text(json.dumps(trace,indent=2)+'\n')
 return model


def filters(*arrays):
 tails={};heads={}
 for rows in arrays:
  for h,r,t in rows:
   tails.setdefault((int(h),int(r)),set()).add(int(t));heads.setdefault((int(r),int(t)),set()).add(int(h))
 return tails,heads


@torch.no_grad()
def rank_queries(model,q,truth,batch=32):
 # Target from same score matrix: no separate-kernel rounding inconsistency.
 ent=model.entity.weight.detach().double().cpu();rel=model.relation.weight.detach().double().cpu()
 ranks=[];scores=[];top=[];ta,ha=truth
 for side in ('head','tail'):
  rs=[];ss=[];tt=[]
  for st in range(0,len(q),batch):
   b=q[st:st+batch];bt=torch.from_numpy(b)
   v=rel[bt[:,1]]*ent[bt[:,2] if side=='head' else bt[:,0]];sc=v@ent.T
   for j,(h,r,t) in enumerate(b):
    target=int(h if side=='head' else t);true=sc[j,target].item();ss.append(true)
    ex=ha.get((int(r),int(t)),()) if side=='head' else ta.get((int(h),int(r)),())
    bad=[int(z) for z in ex if z!=target]
    if bad:sc[j,bad]=-torch.inf
    tt.append(int(sc[j].argmax()));sc[j,target]=-torch.inf
    rs.append(1+int((sc[j]>true).sum())+.5*int((sc[j]==true).sum()))
  ranks.append(np.asarray(rs,dtype=float));scores.append(np.asarray(ss));top.append(np.asarray(tt))
 return {'ranks':np.stack(ranks),'scores':np.stack(scores),'top1':np.stack(top)}


def main():
 ap=argparse.ArgumentParser();ap.add_argument('--data-root',type=Path,required=True)
 ap.add_argument('--dataset',choices=['FB15K-237','CoDEx-M'],required=True)
 ap.add_argument('--seed',type=int,choices=[17,29,43],required=True);ap.add_argument('--out',type=Path,required=True)
 args=ap.parse_args();torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
 folder='FB15k-237' if args.dataset=='FB15K-237' else 'codex-m';path=args.data_root/folder
 data=load_dataset(path/'train.txt',path/'valid.txt',path/'test.txt');ne,nr=len(data.entities),len(data.relations)
 out=args.out/args.dataset/f'seed{args.seed}';out.mkdir(parents=True,exist_ok=True)
 if (out/'COMPLETE.json').exists():raise FileExistsError(f'Completed run exists: {out}')
 fi,selected=star_request(data.train);R=np.delete(data.train,fi,axis=0);U=data.train[fi]
 if np.isin(R[:,[0,2]],selected).any():raise AssertionError('Not complete stars')
 ae,ar,_,check_R=affected_region(data.train,fi,hops=1);np.testing.assert_array_equal(R,check_R)
 local_ids=np.flatnonzero(np.isin(R[:,0],ae)|np.isin(R[:,2],ae));rng_work=np.random.default_rng(17)
 extra_n=min(len(R),max(len(local_ids)//2,4096))
 extra=rng_work.choice(len(R),extra_n,replace=False) if len(R)>extra_n else np.arange(len(R))
 work_ids=np.r_[local_ids,extra];work=R[work_ids]
 em=torch.zeros(ne,1);em[ae]=1.;rm=torch.zeros(nr,1);rm[ar]=1.
 qgen=np.random.default_rng(PROTOCOL['query_seed'])
 qs={name:arr[np.sort(qgen.choice(len(arr),min(256,len(arr)),replace=False))]
     for name,arr in [('test',data.test),('forgotten',U),('retained',R)]}
 truth=filters(R,data.valid,data.test,U)
 np.savez_compressed(out/'queries.npz',**qs,forget_indices=fi,selected_entities=selected,
                     affected_entities=ae,affected_relations=ar,work_indices=work_ids)
 raw=[]
 def record(label,model,stats):
  metrics={};payload={}
  for name,q in qs.items():
   vals=rank_queries(model,q,truth)
   for k,v in vals.items():payload[f'{name}_{k}']=v
   metrics[f'{name}_mrr']=float((1/vals['ranks']).mean());metrics[f'{name}_hits10']=float((vals['ranks']<=10).mean())
  raw.append({'label':label,**metrics,**stats});np.savez_compressed(out/(label+'_predictions.npz'),**payload)
  (out/'raw.json').write_text(json.dumps(raw,indent=2)+'\n')
 start=time.perf_counter()
 # All interventions are constructed and scored BEFORE any retained reference.
 base=train_trajectory(ne,nr,args.seed,data.train,20,'Base',out,record)
 record('Unchanged',base,{'presentations':0,'steps':0,'elapsed_sec':0.})
 reset=copy.deepcopy(base);fresh_reset=fresh(ne,nr,args.seed+9001)
 with torch.no_grad():reset.entity.weight[selected]=fresh_reset.entity.weight[selected]
 record('ResetOnly',reset,{'presentations':0,'steps':0,'elapsed_sec':0.})
 for label,initial,stream,mask in [('Local',base,work,(em,rm)),('ResetLocal',reset,work,(em,rm)),
   ('FullRetain',base,R,None),('ResetFullRetain',reset,R,None),('ResetDenseSameWork',reset,work,None)]:
  model=copy.deepcopy(initial);opt=torch.optim.Adam(model.parameters(),lr=PROTOCOL['lr'])
  rng=np.random.default_rng(args.seed+18001);run_start=time.perf_counter()
  stats=epoch(model,stream,opt,rng,ne,budget=5*len(R),masks=mask);stats['elapsed_sec']=time.perf_counter()-run_start
  stats['parameter_fraction']=float((len(ae)+len(ar))/(ne+nr)) if mask is not None else 1.
  stats['work_unique_fraction']=len(np.unique(work_ids))/len(R) if stream is work else 1.
  if mask is not None:
   with torch.no_grad():
    assert torch.equal(model.entity.weight[em[:,0]==0],initial.entity.weight[em[:,0]==0])
    assert torch.equal(model.relation.weight[rm[:,0]==0],initial.relation.weight[rm[:,0]==0])
  record(label,model,stats);print(label,stats,flush=True)
  torch.save({'state_dict':model.state_dict(),'seed':args.seed,'protocol':PROTOCOL},out/(label+'.pt'))
 train_trajectory(ne,nr,args.seed,R,100,'Reference',out,record)
 manifest={'protocol':PROTOCOL,'dataset':args.dataset,'seed':args.seed,'entities':ne,'relations':nr,
  'train_triples':len(data.train),'retained_triples':len(R),'forgotten_triples':len(U),'selected_entities':len(selected),
  'realized_fraction':len(U)/len(data.train),'file_hashes':{s:hashlib.sha256((path/(s+'.txt')).read_bytes()).hexdigest() for s in ('train','valid','test')},
  'forget_hash':hash_array(fi),'test_query_hash':hash_array(qs['test']),'elapsed_sec':time.perf_counter()-start,
  'python':platform.python_version(),'numpy':np.__version__,'torch':torch.__version__,'cpu_threads':1,
  'reference_labels':['Reference20','Reference50','Reference100'],
  'iteration_control':'all five optimized interventions have equal positive presentations and steps',
  'query_shapes':{k:list(v.shape) for k,v in qs.items()}}
 (out/'COMPLETE.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print('REFERENCE_BUDGET_PILOT_COMPLETE',args.dataset,args.seed,flush=True)
if __name__=='__main__':main()
