#!/usr/bin/env python3
"""Targeted controls for the reference-budget review, specified before new outcomes.

No new candidate is chosen using a retraining checkpoint. Budget endpoints are
independent executions with equal presentations, not optimistic best-of curves.
The additional same-budget reference uses an independent seed (+1000). It is
not the same checkpoint given two labels. Results from the older cohort are
kept separately and their five-budget endpoints are reused without alteration.
"""
from __future__ import annotations
import argparse,copy,hashlib,json,time
from pathlib import Path
import numpy as np
import torch
from schemacert.data import load_dataset
from scripts.experiments.run_reference_budget_pilot import (
    PROTOCOL, fresh, epoch, filters, rank_queries, star_request, hash_array,
)

CONTROL_PROTOCOL={
    'name':'remaining-review-controls-v1','base_commit':'anonymous-source-snapshot',
    'seeds':[17,29,43],'datasets':['FB15K-237','CoDEx-M'],'dim':128,
    'positive_presentation_multipliers':[0,1,3,5,10],
    'trained_here':[1,3,10], 'five_budget':'reuse original cohort endpoint',
    'methods':['ResetLocal','ResetFullRetain','ResetDenseSameWork'],
    'null_reference_epochs':20,'null_reference_seed_offset':1000,
    'all_fresh_seed_offset':19001,'damaged_controls':['AllFresh','AllZero'],
    'reference_access_during_candidate_construction':False,
    'scope':'behavioral controls, not a certified release or original TransE rescore',
}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--data-root',type=Path,required=True)
    p.add_argument('--cohort',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--dataset',choices=CONTROL_PROTOCOL['datasets'],required=True)
    p.add_argument('--seed',type=int,choices=CONTROL_PROTOCOL['seeds'],required=True)
    args=p.parse_args()
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    ds=args.dataset;s=args.seed;out=args.out/ds/f'seed{s}'
    out.mkdir(parents=True,exist_ok=True)
    if (out/'COMPLETE.json').exists():raise FileExistsError(str(out))
    origin=args.cohort/ds/f'seed{s}'
    q=dict(np.load(origin/'queries.npz'))
    folder='FB15k-237' if ds=='FB15K-237' else 'codex-m'
    path=args.data_root/folder
    data=load_dataset(path/'train.txt',path/'valid.txt',path/'test.txt')
    ne,nr=len(data.entities),len(data.relations)
    U=data.train[q['forget_indices']];R=np.delete(data.train,q['forget_indices'],axis=0)
    fi,selected=star_request(data.train)
    np.testing.assert_array_equal(fi,q['forget_indices'])
    np.testing.assert_array_equal(selected,q['selected_entities'])
    work=R[q['work_indices']]
    em=torch.zeros(ne,1);em[q['affected_entities']]=1
    rm=torch.zeros(nr,1);rm[q['affected_relations']]=1
    base=fresh(ne,nr,s)
    original=torch.load(origin/'Base20.pt',map_location='cpu',weights_only=False)
    if original['protocol']!=PROTOCOL:raise ValueError('Source protocol differs')
    base.load_state_dict(original['state_dict'])
    reset=copy.deepcopy(base);reset_initializer=fresh(ne,nr,s+9001)
    with torch.no_grad():reset.entity.weight[selected]=reset_initializer.entity.weight[selected]
    truth=filters(R,data.valid,data.test,U)
    rows=[]
    def record(label,m,stats):
        payload={};metrics={}
        for name in ('test','forgotten','retained'):
            values=rank_queries(m,q[name],truth)
            for k,v in values.items():payload[f'{name}_{k}']=v
            metrics[name+'_mrr']=float((1/values['ranks']).mean())
        np.savez_compressed(out/f'{label}_predictions.npz',**payload)
        rows.append({'label':label,**metrics,**stats})
        (out/'raw.json').write_text(json.dumps(rows,indent=2)+'\n')
    # Explicitly destructive controls, not invented 'successful removals'.
    record('AllFresh',fresh(ne,nr,s+19001),{'steps':0,'presentations':0})
    zero=fresh(ne,nr,s+19001)
    with torch.no_grad():
        for v in zero.parameters():v.zero_()
    record('AllZero',zero,{'steps':0,'presentations':0})
    for budget in CONTROL_PROTOCOL['trained_here']:
        for name,stream,mask in [('ResetLocal',work,(em,rm)),
                                 ('ResetFullRetain',R,None),
                                 ('ResetDenseSameWork',work,None)]:
            m=copy.deepcopy(reset)
            opt=torch.optim.Adam(m.parameters(),lr=PROTOCOL['lr'])
            rng=np.random.default_rng(s+18001);start=time.perf_counter()
            stats=epoch(m,stream,opt,rng,ne,budget=budget*len(R),masks=mask)
            stats['elapsed_sec']=time.perf_counter()-start
            stats['budget']=budget
            if mask is not None:
                assert torch.equal(m.entity.weight[em[:,0]==0],reset.entity.weight[em[:,0]==0])
                assert torch.equal(m.relation.weight[rm[:,0]==0],reset.relation.weight[rm[:,0]==0])
            record(f'{name}_B{budget}',m,stats)
            print(ds,s,name,budget,stats,flush=True)
    # Independent reference group. Only retained data and public initialization.
    null=fresh(ne,nr,s+1000)
    opt=torch.optim.Adam(null.parameters(),lr=PROTOCOL['lr'])
    rng=np.random.default_rng(s+1000);trace=[]
    for e in range(1,21):
        trace.append({'epoch':e,**epoch(null,R,opt,rng,ne)})
    record('IndependentRef20',null,{'reference_seed':s+1000,'reference_epochs':20})
    (out/'null_training.json').write_text(json.dumps(trace,indent=2)+'\n')
    manifest={
        'protocol':CONTROL_PROTOCOL,'training_protocol':PROTOCOL,'dataset':ds,'seed':s,
        'forget_hash':hash_array(fi),'test_query_hash':hash_array(q['test']),
        'base_file_sha256':hashlib.sha256((origin/'Base20.pt').read_bytes()).hexdigest(),
        'predictions_sha256':{x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted(out.glob('*_predictions.npz'))},
        'retained_triples':len(R),'null_reference_seed':s+1000,
        'null_uses_original_checkpoint':False,
    }
    (out/'COMPLETE.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('REMAINING_CONTROLS_COMPLETE',ds,s,flush=True)
if __name__=='__main__':main()
