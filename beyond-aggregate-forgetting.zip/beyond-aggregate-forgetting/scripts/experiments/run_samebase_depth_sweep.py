#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.train import clone_model, train_model
from schemacert.unlearn import local_retrain
from scripts.run_publication_families import fresh, select_forget
from scripts.experiments.run_samebase_ng_pilot import (
    evaluate,
    negative_gradient,
    request_fingerprint,
    row,
)


def main():
    p = argparse.ArgumentParser(description='Controlled same-base depth sweep for SchemaCert, full finetune, and Negative Gradient.')
    p.add_argument('--dataset', default='FB15K-237')
    p.add_argument('--model', default='transe')
    p.add_argument('--policy', default='entity', choices=['entity', 'relation', 'random'])
    p.add_argument('--fraction', type=float, default=0.05)
    p.add_argument('--seed', type=int, default=17)
    p.add_argument('--depths', type=int, nargs='+', default=[5, 10, 20, 50])
    p.add_argument('--data-root', default='data')
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--threads', type=int, default=1)
    p.add_argument('--dim', type=int, default=128)
    p.add_argument('--epochs', type=int, default=20)
    p.add_argument('--ref-epochs', type=int, default=20)
    p.add_argument('--batch-size', type=int, default=4096)
    p.add_argument('--lr', type=float, default=0.002)
    p.add_argument('--local-lr', type=float, default=0.001)
    p.add_argument('--l2', type=float, default=1e-6)
    p.add_argument('--hops', type=int, default=1)
    p.add_argument('--ng-lr', type=float, default=0.001)
    p.add_argument('--eval-batch', type=int, default=16)
    p.add_argument('--entity-chunk', type=int, default=4096)
    p.add_argument('--eval-queries', type=int, default=1000)
    p.add_argument('--forget-eval-queries', type=int, default=1000)
    p.add_argument('--out', required=True)
    args = p.parse_args()

    depths = sorted(set(int(d) for d in args.depths))
    if not depths or min(depths) <= 0:
        raise ValueError('All depths must be positive integers')

    torch.set_num_threads(max(1, args.threads))
    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    ne, nr = len(data.entities), len(data.relations)
    fi, meta = select_forget(data.train, args.fraction, args.seed + int(args.fraction * 10000), args.policy)
    forget = data.train[fi]
    keep = np.ones(len(data.train), dtype=bool)
    keep[fi] = False
    retain = data.train[keep]
    req_hash = request_fingerprint(data, forget)

    base = fresh(args.model, ne, nr, args.dim, args.seed, args.device)
    base_stats = train_model(
        base, data.train, ne, args.epochs, args.batch_size, args.lr, args.l2, args.seed, args.device
    )

    exact = fresh(args.model, ne, nr, args.dim, args.seed, args.device)
    exact_stats = train_model(
        exact, retain, ne, args.ref_epochs, args.batch_size, args.lr, args.l2, args.seed, args.device
    )

    exact_global, exact_forget = evaluate(
        exact, data, retain, forget, args.device, args.eval_batch, args.entity_chunk,
        args.eval_queries, args.forget_eval_queries, args.seed,
    )
    base_global, base_forget = evaluate(
        base, data, retain, forget, args.device, args.eval_batch, args.entity_chunk,
        args.eval_queries, args.forget_eval_queries, args.seed,
    )

    rows = [
        row('ExactRetrain', exact_global, exact_forget, exact_stats.seconds, exact_global, exact_forget, req_hash),
        row('BaseBeforeUnlearning', base_global, base_forget, 0.0, exact_global, exact_forget, req_hash),
    ]
    ng_losses = {}

    for depth in depths:
        local, _, _ = local_retrain(
            base, data.train, fi, ne, args.hops, depth, args.batch_size,
            args.local_lr, args.l2, args.seed, args.device,
        )
        local_global, local_forget = evaluate(
            local.model, data, retain, forget, args.device, args.eval_batch, args.entity_chunk,
            args.eval_queries, args.forget_eval_queries, args.seed,
        )
        rows.append(row(
            f'SchemaCert-L{depth}', local_global, local_forget, local.seconds,
            exact_global, exact_forget, req_hash,
        ))

        finetune = clone_model(base)
        ft_stats = train_model(
            finetune, retain, ne, depth, args.batch_size, args.local_lr,
            args.l2, args.seed + 31, args.device,
        )
        ft_global, ft_forget = evaluate(
            finetune, data, retain, forget, args.device, args.eval_batch, args.entity_chunk,
            args.eval_queries, args.forget_eval_queries, args.seed,
        )
        rows.append(row(
            f'FullFinetune-L{depth}', ft_global, ft_forget, ft_stats.seconds,
            exact_global, exact_forget, req_hash,
        ))

        ng, ng_sec, losses = negative_gradient(
            base, forget, ne, depth, args.batch_size, args.ng_lr,
            args.l2, args.seed + 97, args.device,
        )
        ng_global, ng_forget = evaluate(
            ng, data, retain, forget, args.device, args.eval_batch, args.entity_chunk,
            args.eval_queries, args.forget_eval_queries, args.seed,
        )
        rows.append(row(
            f'NG-SameBase-L{depth}', ng_global, ng_forget, ng_sec,
            exact_global, exact_forget, req_hash,
        ))
        ng_losses[str(depth)] = losses

        del local, finetune, ng
        if args.device.startswith('cuda'):
            torch.cuda.empty_cache()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    stem = f'{args.dataset}_{args.model}_{args.policy}_f{args.fraction:g}_s{args.seed}_depth_sweep'
    csv_path = out / f'{stem}.csv'
    json_path = out / f'{stem}.json'

    with open(csv_path, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

    json_path.write_text(json.dumps({
        'config': vars(args),
        'depths': depths,
        'forget_n': len(forget),
        'request_hash': req_hash,
        'request_meta': meta,
        'base_train_sec': base_stats.seconds,
        'exact_retrain_sec': exact_stats.seconds,
        'ng_losses': ng_losses,
        'rows': rows,
    }, indent=2))

    print(f'REQUEST hash={req_hash} forget_n={len(forget)} depths={depths}')
    print(f'BASE_TRAIN_SEC={base_stats.seconds:.6f}')
    print('method\tglobal_mrr\tforget_mrr\tglobal_gap_exact\tforget_gap_exact\tupdate_sec')
    for r in rows:
        print(
            f"{r['method']}\t{r['global_mrr']:.6f}\t{r['forget_mrr']:.6f}\t"
            f"{r['global_mrr_gap_to_exact']:.6f}\t{r['forget_mrr_gap_to_exact']:.6f}\t{r['update_sec']:.6f}"
        )
    print(f'DEPTH_SWEEP_CSV={csv_path}')
    print(f'DEPTH_SWEEP_JSON={json_path}')
    print('SAMEBASE_DEPTH_SWEEP_OK')


if __name__ == '__main__':
    main()
