#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import time
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.train import batch_iter, clone_model, corrupt_tail, loss_batch, train_model
from schemacert.unlearn import local_retrain
from scripts.run_publication_families import filtered_lp, fresh, select_forget


def request_fingerprint(data, forget: np.ndarray) -> str:
    names = sorted(
        f"{data.entities[int(h)]}\t{data.relations[int(r)]}\t{data.entities[int(t)]}"
        for h, r, t in forget
    )
    return hashlib.sha256('\n'.join(names).encode('utf-8')).hexdigest()[:16]


def negative_gradient(model, forget: np.ndarray, n_entities: int, epochs: int, batch_size: int,
                      lr: float, l2: float, seed: int, device: str):
    """Raw gradient ascent on the SchemaCert training loss over the forget set.

    This is the same-base analogue of the standard Negative Gradient baseline:
    same pretrained model, score function, corruption rule, and normalization as
    SchemaCert; only the update direction is reversed on the forget request.
    """
    out = clone_model(model).to(device)
    rng = np.random.default_rng(seed)
    losses = []
    start = time.time()
    for _ in range(epochs):
        total = 0.0
        count = 0
        for ids in batch_iter(len(forget), batch_size, rng):
            pos = forget[ids]
            neg = corrupt_tail(pos, n_entities, rng)
            pt = torch.as_tensor(pos, dtype=torch.long, device=device)
            nt = torch.as_tensor(neg, dtype=torch.long, device=device)
            out.zero_grad(set_to_none=True)
            loss = loss_batch(out, pt, nt, l2)
            loss.backward()
            with torch.no_grad():
                for param in out.parameters():
                    if param.grad is not None:
                        param.add_(param.grad, alpha=lr)
                out.normalize_()
            total += float(loss.detach()) * len(ids)
            count += len(ids)
        losses.append(total / max(count, 1))
    return out, time.time() - start, losses


def evaluate(model, data, retain, forget, device, eval_batch, entity_chunk, eval_queries, forget_eval_queries, seed):
    truth = (retain, data.valid, data.test)
    forget_truth = (retain, data.valid, data.test, forget)
    global_metrics = filtered_lp(
        model, data.test, len(data.entities), truth, device,
        eval_batch, entity_chunk, eval_queries, seed,
    )
    forget_metrics = filtered_lp(
        model, forget, len(data.entities), forget_truth, device,
        eval_batch, entity_chunk, forget_eval_queries, seed,
    )
    return global_metrics, forget_metrics


def row(method, global_metrics, forget_metrics, seconds, ref_global, ref_forget, request_hash):
    return {
        'method': method,
        'global_mrr': global_metrics['mrr'],
        'global_h1': global_metrics['h1'],
        'global_h3': global_metrics['h3'],
        'global_h10': global_metrics['h10'],
        'forget_mrr': forget_metrics['mrr'],
        'forget_h1': forget_metrics['h1'],
        'forget_h3': forget_metrics['h3'],
        'forget_h10': forget_metrics['h10'],
        'global_mrr_gap_to_exact': abs(global_metrics['mrr'] - ref_global['mrr']),
        'forget_mrr_gap_to_exact': abs(forget_metrics['mrr'] - ref_forget['mrr']),
        'update_sec': seconds,
        'eval_rankings': global_metrics['n'],
        'forget_eval_rankings': forget_metrics['n'],
        'request_hash': request_hash,
    }


def main():
    p = argparse.ArgumentParser(description='Controlled same-base SchemaCert vs full finetune vs negative-gradient pilot.')
    p.add_argument('--dataset', default='FB15K-237')
    p.add_argument('--model', default='transe')
    p.add_argument('--policy', default='entity', choices=['entity', 'relation', 'random'])
    p.add_argument('--fraction', type=float, default=0.05)
    p.add_argument('--seed', type=int, default=17)
    p.add_argument('--data-root', default='data')
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--threads', type=int, default=1)
    p.add_argument('--dim', type=int, default=128)
    p.add_argument('--epochs', type=int, default=20)
    p.add_argument('--ref-epochs', type=int, default=20)
    p.add_argument('--local-epochs', type=int, default=5)
    p.add_argument('--batch-size', type=int, default=4096)
    p.add_argument('--lr', type=float, default=0.002)
    p.add_argument('--local-lr', type=float, default=0.001)
    p.add_argument('--l2', type=float, default=1e-6)
    p.add_argument('--hops', type=int, default=1)
    p.add_argument('--ng-epochs', type=int, default=5)
    p.add_argument('--ng-lr', type=float, default=0.001)
    p.add_argument('--eval-batch', type=int, default=16)
    p.add_argument('--entity-chunk', type=int, default=4096)
    p.add_argument('--eval-queries', type=int, default=1000)
    p.add_argument('--forget-eval-queries', type=int, default=1000)
    p.add_argument('--out', required=True)
    args = p.parse_args()

    torch.set_num_threads(max(1, args.threads))
    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    ne, nr = len(data.entities), len(data.relations)
    fi, meta = select_forget(data.train, args.fraction, args.seed + int(args.fraction * 10000), args.policy)
    forget = data.train[fi]
    keep = np.ones(len(data.train), dtype=bool)
    keep[fi] = False
    retain = data.train[keep]
    req_hash = request_fingerprint(data, forget)

    base = fresh(args.model, ne, nr, args.dim, args.seed, args.device)
    base_stats = train_model(
        base, data.train, ne, args.epochs, args.batch_size, args.lr, args.l2, args.seed, args.device
    )

    exact = fresh(args.model, ne, nr, args.dim, args.seed, args.device)
    exact_stats = train_model(
        exact, retain, ne, args.ref_epochs, args.batch_size, args.lr, args.l2, args.seed, args.device
    )

    local, _, _ = local_retrain(
        base, data.train, fi, ne, args.hops, args.local_epochs, args.batch_size,
        args.local_lr, args.l2, args.seed, args.device,
    )

    finetune = clone_model(base)
    finetune_stats = train_model(
        finetune, retain, ne, args.local_epochs, args.batch_size, args.local_lr,
        args.l2, args.seed + 31, args.device,
    )

    ng, ng_sec, ng_losses = negative_gradient(
        base, forget, ne, args.ng_epochs, args.batch_size, args.ng_lr,
        args.l2, args.seed + 97, args.device,
    )

    exact_global, exact_forget = evaluate(
        exact, data, retain, forget, args.device, args.eval_batch, args.entity_chunk,
        args.eval_queries, args.forget_eval_queries, args.seed,
    )
    base_global, base_forget = evaluate(
        base, data, retain, forget, args.device, args.eval_batch, args.entity_chunk,
        args.eval_queries, args.forget_eval_queries, args.seed,
    )
    local_global, local_forget = evaluate(
        local.model, data, retain, forget, args.device, args.eval_batch, args.entity_chunk,
        args.eval_queries, args.forget_eval_queries, args.seed,
    )
    ft_global, ft_forget = evaluate(
        finetune, data, retain, forget, args.device, args.eval_batch, args.entity_chunk,
        args.eval_queries, args.forget_eval_queries, args.seed,
    )
    ng_global, ng_forget = evaluate(
        ng, data, retain, forget, args.device, args.eval_batch, args.entity_chunk,
        args.eval_queries, args.forget_eval_queries, args.seed,
    )

    rows = [
        row('ExactRetrain', exact_global, exact_forget, exact_stats.seconds, exact_global, exact_forget, req_hash),
        row('BaseBeforeUnlearning', base_global, base_forget, 0.0, exact_global, exact_forget, req_hash),
        row('SchemaCert-L5', local_global, local_forget, local.seconds, exact_global, exact_forget, req_hash),
        row('FullFinetune-L5', ft_global, ft_forget, finetune_stats.seconds, exact_global, exact_forget, req_hash),
        row('NG-SameBase-L5', ng_global, ng_forget, ng_sec, exact_global, exact_forget, req_hash),
    ]

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    stem = f"{args.dataset}_{args.model}_{args.policy}_f{args.fraction:g}_s{args.seed}_samebase"
    csv_path = out / f'{stem}.csv'
    json_path = out / f'{stem}.json'
    with open(csv_path, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    json_path.write_text(json.dumps({
        'config': vars(args),
        'forget_n': len(forget),
        'request_hash': req_hash,
        'request_meta': meta,
        'base_train_sec': base_stats.seconds,
        'ng_losses': ng_losses,
        'rows': rows,
    }, indent=2))

    print(f"REQUEST hash={req_hash} forget_n={len(forget)}")
    print(f"BASE_TRAIN_SEC={base_stats.seconds:.6f}")
    print('method\tglobal_mrr\tforget_mrr\tglobal_gap_exact\tforget_gap_exact\tupdate_sec')
    for r in rows:
        print(
            f"{r['method']}\t{r['global_mrr']:.6f}\t{r['forget_mrr']:.6f}\t"
            f"{r['global_mrr_gap_to_exact']:.6f}\t{r['forget_mrr_gap_to_exact']:.6f}\t{r['update_sec']:.6f}"
        )
    print(f"SAMEBASE_CSV={csv_path}")
    print(f"SAMEBASE_JSON={json_path}")


if __name__ == '__main__':
    main()
