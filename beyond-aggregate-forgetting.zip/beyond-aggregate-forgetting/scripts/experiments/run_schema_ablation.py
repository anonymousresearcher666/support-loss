#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import time
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.train import clone_model, train_model
from schemacert.unlearn import local_retrain
from scripts.run_publication_families import filtered_lp, fresh, select_forget
from scripts.experiments.evaluate_family_restart import (
    _canonical_metrics,
    _canonical_row,
    _float,
    deterministic_family_restart,
)


def request_hash(forget: np.ndarray) -> str:
    x = np.ascontiguousarray(forget, dtype=np.int64)
    return hashlib.sha256(x.tobytes()).hexdigest()[:16]


def make_work(retain: np.ndarray, work_entities: np.ndarray, seed: int):
    inc = np.isin(retain[:, 0], work_entities) | np.isin(retain[:, 2], work_entities)
    local_idx = np.flatnonzero(inc)
    rng = np.random.default_rng(seed)
    extra_n = min(len(retain), max(len(local_idx) // 2, 4096))
    if len(retain) > extra_n:
        extra_idx = rng.choice(len(retain), extra_n, replace=False)
    else:
        extra_idx = np.arange(len(retain), dtype=np.int64)
    work_idx = np.concatenate([local_idx, extra_idx])
    return retain[work_idx], local_idx, work_idx


def masked_update(model, work, train_entities, train_relations, n_entities, args):
    m = clone_model(model)
    em = np.zeros_like(m.entity.weight.detach().cpu().numpy())
    rm = np.zeros_like(m.relation.weight.detach().cpu().numpy())
    if len(train_entities):
        em[np.asarray(train_entities, dtype=np.int64)] = 1
    if len(train_relations):
        rm[np.asarray(train_relations, dtype=np.int64)] = 1
    st = time.time()
    stats = train_model(
        m, work, n_entities, args.local_epochs, args.batch_size,
        args.local_lr, args.l2, args.seed, args.device,
        [(m.entity.weight, em), (m.relation.weight, rm)],
    )
    total = m.entity.weight.numel() + m.relation.weight.numel()
    affected = float(em.sum() + rm.sum())
    return m, time.time() - st, stats, affected / max(total, 1)


def eval_model(model, data, retain, forget, ne, args):
    truth = (retain, data.valid, data.test)
    forget_truth = (retain, data.valid, data.test, forget)
    g = filtered_lp(
        model, data.test, ne, truth, args.device,
        args.eval_batch, args.entity_chunk, args.eval_queries, args.seed,
    )
    f = filtered_lp(
        model, forget, ne, forget_truth, args.device,
        args.eval_batch, args.entity_chunk, args.forget_eval_queries, args.seed,
    )
    return g, f


def row(method, g, f, sec, ref_g, ref_f, *, parameter_fraction, work_unique_fraction,
        train_entities, train_relations, request, dataset, model, seed, fraction,
        work_mode, parameter_mode):
    return {
        'dataset': dataset,
        'model': model,
        'policy': 'entity',
        'seed': seed,
        'fraction': fraction,
        'request_hash': request,
        'method': method,
        'work_mode': work_mode,
        'parameter_mode': parameter_mode,
        'global_mrr': g['mrr'],
        'forget_mrr': f['mrr'],
        'global_mrr_gap_to_exact': abs(g['mrr'] - ref_g),
        'forget_mrr_gap_to_exact': abs(f['mrr'] - ref_f),
        'train_sec': sec,
        'parameter_fraction': parameter_fraction,
        'work_unique_fraction': work_unique_fraction,
        'train_entity_rows': int(len(train_entities)),
        'train_relation_rows': int(len(train_relations)),
    }


def main():
    p = argparse.ArgumentParser(description='Schema/boundary ablation with a matched random parameter-budget control.')
    p.add_argument('--dataset', required=True)
    p.add_argument('--model', required=True, choices=['distmult', 'complex'])
    p.add_argument('--seed', required=True, type=int)
    p.add_argument('--fractions', nargs='+', type=float, default=[0.10, 0.20])
    p.add_argument('--data-root', default='data')
    p.add_argument('--canonical-root', default='results_cluster/policy128_entitylocal_v2')
    p.add_argument('--out', required=True)
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--threads', type=int, default=1)
    p.add_argument('--dim', type=int, default=128)
    p.add_argument('--epochs', type=int, default=20)
    p.add_argument('--local-epochs', type=int, default=5)
    p.add_argument('--batch-size', type=int, default=4096)
    p.add_argument('--lr', type=float, default=0.002)
    p.add_argument('--local-lr', type=float, default=0.001)
    p.add_argument('--l2', type=float, default=1e-6)
    p.add_argument('--eval-batch', type=int, default=16)
    p.add_argument('--entity-chunk', type=int, default=4096)
    p.add_argument('--eval-queries', type=int, default=1000)
    p.add_argument('--forget-eval-queries', type=int, default=1000)
    p.add_argument('--base-mrr-tol', type=float, default=5e-4)
    args = p.parse_args()

    torch.set_num_threads(max(1, args.threads))
    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    ne, nr = len(data.entities), len(data.relations)
    canonical_path = Path(args.canonical_root) / f'{args.dataset}_{args.model}_entity_s{args.seed}.csv'
    if not canonical_path.is_file():
        raise FileNotFoundError(canonical_path)

    base = fresh(args.model, ne, nr, args.dim, args.seed, args.device)
    base_stats = train_model(
        base, data.train, ne, args.epochs, args.batch_size, args.lr, args.l2,
        args.seed, args.device,
    )
    base_lp = filtered_lp(
        base, data.test, ne, (data.train, data.valid, data.test), args.device,
        args.eval_batch, args.entity_chunk, args.eval_queries, args.seed,
    )

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    for frac in args.fractions:
        canonical = _canonical_row(canonical_path, args.dataset, args.model, args.seed, frac)
        canonical_base = _float(canonical, 'base_mrr')
        delta = abs(base_lp['mrr'] - canonical_base)
        if delta > args.base_mrr_tol:
            raise RuntimeError(f'base MRR drift {delta} > {args.base_mrr_tol}')

        fi, meta = select_forget(data.train, frac, args.seed + int(frac * 10000), policy='entity')
        forget = data.train[fi]
        keep = np.ones(len(data.train), dtype=bool); keep[fi] = False
        retain = data.train[keep]
        if json.loads(canonical.get('request_meta', '{}')) != meta:
            raise RuntimeError('canonical request mismatch')

        selected = np.asarray(meta.get('entities', []), dtype=np.int64)
        restart_seed = (args.seed * 1000003 + int(round(frac * 1000000)) + 17027) & 0x7FFFFFFF
        restarted, restart_sec, unsupported, _ = deterministic_family_restart(base, retain, selected, restart_seed)

        exact_g, exact_f = _canonical_metrics(canonical, 'reference')
        ref_g, ref_f = exact_g['mrr'], exact_f['mrr']
        req = request_hash(forget)

        # Core = exactly the current SchemaCert trainable rows for hops=1.
        core_e = np.unique(np.r_[forget[:, 0], forget[:, 2]]).astype(np.int64)
        core_r = np.unique(forget[:, 1]).astype(np.int64)

        # Boundary-expanded = all retained 1-hop endpoint rows and relation rows
        # actually appearing on retained triples incident to the core. This is
        # the structurally/schema-conditioned expansion being tested.
        inc = np.isin(retain[:, 0], core_e) | np.isin(retain[:, 2], core_e)
        local_retained = retain[inc]
        boundary_e = np.unique(np.r_[local_retained[:, 0], local_retained[:, 2]]).astype(np.int64) if len(local_retained) else core_e
        boundary_r = np.unique(local_retained[:, 1]).astype(np.int64) if len(local_retained) else core_r
        schema_e = np.union1d(core_e, boundary_e).astype(np.int64)
        schema_r = np.union1d(core_r, boundary_r).astype(np.int64)

        # Restart-only: isolates the support reconstruction intervention.
        g0, f0 = eval_model(restarted, data, retain, forget, ne, args)
        total = restarted.entity.weight.numel() + restarted.relation.weight.numel()
        restart_pf = float(len(unsupported) * restarted.entity.weight.shape[1] / max(total, 1))
        rows = [row(
            'RestartOnly', g0, f0, restart_sec, ref_g, ref_f,
            parameter_fraction=restart_pf, work_unique_fraction=0.0,
            train_entities=unsupported, train_relations=np.array([], dtype=np.int64),
            request=req, dataset=args.dataset, model=args.model, seed=args.seed,
            fraction=frac, work_mode='none', parameter_mode='unsupported selected rows only',
        )]

        # Current SchemaCert region, after the same restart.
        current, _, _ = local_retrain(
            restarted, data.train, fi, ne, 1, args.local_epochs, args.batch_size,
            args.local_lr, args.l2, args.seed, args.device,
        )
        gc, fc = eval_model(current.model, data, retain, forget, ne, args)
        rows.append(row(
            f'Restart+Current-L{args.local_epochs}', gc, fc, restart_sec + current.seconds, ref_g, ref_f,
            parameter_fraction=current.parameter_fraction,
            work_unique_fraction=current.work_unique_triples / max(len(retain), 1),
            train_entities=current.affected_entities, train_relations=current.affected_relations,
            request=req, dataset=args.dataset, model=args.model, seed=args.seed,
            fraction=frac, work_mode='current entity-incidence local work',
            parameter_mode='forgotten endpoints + forgotten relations',
        ))

        # Boundary-expanded region.
        schema_work, _, schema_work_idx = make_work(retain, schema_e, args.seed)
        sm, ss, _, spf = masked_update(restarted, schema_work, schema_e, schema_r, ne, args)
        gs, fs = eval_model(sm, data, retain, forget, ne, args)
        schema_unique = len(np.unique(schema_work_idx)) / max(len(retain), 1)
        rows.append(row(
            f'Restart+Boundary-L{args.local_epochs}', gs, fs, restart_sec + ss, ref_g, ref_f,
            parameter_fraction=spf, work_unique_fraction=schema_unique,
            train_entities=schema_e, train_relations=schema_r,
            request=req, dataset=args.dataset, model=args.model, seed=args.seed,
            fraction=frac, work_mode='boundary-expanded work',
            parameter_mode='actual retained 1-hop boundary entity/relation rows',
        ))

        # Matched-budget control: preserve the core rows, replace only the extra
        # boundary rows by deterministic random rows, and use the EXACT SAME work
        # triples as Boundary. Parameter count and data/work budget are matched.
        rng = np.random.default_rng(restart_seed + 991)
        extra_e_n = max(0, len(schema_e) - len(core_e))
        extra_r_n = max(0, len(schema_r) - len(core_r))
        e_pool = np.setdiff1d(np.arange(ne, dtype=np.int64), core_e)
        r_pool = np.setdiff1d(np.arange(nr, dtype=np.int64), core_r)
        rand_e = rng.choice(e_pool, extra_e_n, replace=False) if extra_e_n else np.array([], dtype=np.int64)
        rand_r = rng.choice(r_pool, extra_r_n, replace=False) if extra_r_n else np.array([], dtype=np.int64)
        matched_e = np.union1d(core_e, rand_e).astype(np.int64)
        matched_r = np.union1d(core_r, rand_r).astype(np.int64)
        mm, ms, _, mpf = masked_update(restarted, schema_work, matched_e, matched_r, ne, args)
        gm, fm = eval_model(mm, data, retain, forget, ne, args)
        rows.append(row(
            f'Restart+MatchedRandom-L{args.local_epochs}', gm, fm, restart_sec + ms, ref_g, ref_f,
            parameter_fraction=mpf, work_unique_fraction=schema_unique,
            train_entities=matched_e, train_relations=matched_r,
            request=req, dataset=args.dataset, model=args.model, seed=args.seed,
            fraction=frac, work_mode='same exact work triples as Boundary',
            parameter_mode='same core + equal random extra row budget',
        ))

        if abs(spf - mpf) > 1e-12:
            raise RuntimeError(f'matched parameter budget failed: {spf} vs {mpf}')

        stem = f'{args.dataset}_{args.model}_entity_f{frac:g}_s{args.seed}_schema_ablation'
        csv_path = out / f'{stem}.csv'
        json_path = out / f'{stem}.json'
        with csv_path.open('w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader(); w.writerows(rows)
        json_path.write_text(json.dumps({
            'dataset': args.dataset, 'model': args.model, 'seed': args.seed,
            'fraction': frac, 'request_hash': req, 'request_meta': meta,
            'canonical_csv': str(canonical_path), 'base_train_sec': base_stats.seconds,
            'base_mrr_delta_to_canonical': delta, 'restart_seed': restart_seed,
            'unsupported_selected_count': int(len(unsupported)),
            'core_entities': core_e.tolist(), 'core_relations': core_r.tolist(),
            'boundary_entities': schema_e.tolist(), 'boundary_relations': schema_r.tolist(),
            'rows': rows,
        }, indent=2))
        print(f'SCHEMA_ABLATION_OK {csv_path}', flush=True)


if __name__ == '__main__':
    main()
