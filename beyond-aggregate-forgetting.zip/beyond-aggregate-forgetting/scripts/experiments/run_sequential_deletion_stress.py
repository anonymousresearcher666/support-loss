#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,hashlib,json,time
from pathlib import Path
import numpy as np
import torch
from schemacert.data import deterministic_holdout,infer_paths,load_dataset
from schemacert.train import train_model
from schemacert.unlearn import local_retrain
from scripts.run_publication_families import filtered_lp,fresh

def hsh(x): return hashlib.sha256(np.ascontiguousarray(x,dtype=np.int64).tobytes()).hexdigest()[:16]
def evalm(model,data,retain,forget,ne,args):
    g=filtered_lp(model,data.test,ne,(retain,data.valid,data.test),args.device,args.eval_batch,args.entity_chunk,args.eval_queries,args.seed)
    f=filtered_lp(model,forget,ne,(retain,data.valid,data.test,forget),args.device,args.eval_batch,args.entity_chunk,args.forget_eval_queries,args.seed)
    return g,f

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--dataset',required=True);ap.add_argument('--seed',type=int,required=True);ap.add_argument('--data-root',default='data');ap.add_argument('--out',required=True);ap.add_argument('--device',default='cuda:0')
    ap.add_argument('--step-fraction',type=float,default=.02);ap.add_argument('--steps',type=int,default=5);ap.add_argument('--dim',type=int,default=128);ap.add_argument('--epochs',type=int,default=20);ap.add_argument('--local-epochs',type=int,default=5);ap.add_argument('--batch-size',type=int,default=4096);ap.add_argument('--lr',type=float,default=.002);ap.add_argument('--local-lr',type=float,default=.001);ap.add_argument('--l2',type=float,default=1e-6);ap.add_argument('--eval-batch',type=int,default=16);ap.add_argument('--entity-chunk',type=int,default=4096);ap.add_argument('--eval-queries',type=int,default=1000);ap.add_argument('--forget-eval-queries',type=int,default=1000);args=ap.parse_args();torch.set_num_threads(1)
    data=deterministic_holdout(load_dataset(*infer_paths(args.dataset,args.data_root)),seed=17);ne,nr=len(data.entities),len(data.relations); n0=len(data.train);k=max(1,int(round(args.step_fraction*n0)))
    rng=np.random.default_rng(args.seed+88001); perm=rng.permutation(n0); blocks=[np.sort(perm[i*k:(i+1)*k]) for i in range(args.steps)]
    if any(len(x)!=k for x in blocks): raise RuntimeError('not enough triples for sequential blocks')
    base=fresh('distmult',ne,nr,args.dim,args.seed,args.device);bs=train_model(base,data.train,ne,args.epochs,args.batch_size,args.lr,args.l2,args.seed,args.device);current_model=base; current_train=data.train.copy(); cumulative=[];rows=[]
    # Carry original row ids alongside the shrinking retained matrix so blocks remain disjoint and auditable.
    current_ids=np.arange(n0,dtype=np.int64)
    for step,orig_block in enumerate(blocks,1):
        pos={int(x):i for i,x in enumerate(current_ids.tolist())}; local_idx=np.asarray([pos[int(x)] for x in orig_block],dtype=np.int64)
        step_forget=current_train[local_idx]; cumulative.append(step_forget.copy()); all_forget=np.concatenate(cumulative,axis=0)
        keep=np.ones(len(current_train),dtype=bool);keep[local_idx]=False; next_train=current_train[keep]; next_ids=current_ids[keep]
        local,_,_=local_retrain(current_model,current_train,local_idx,ne,1,args.local_epochs,args.batch_size,args.local_lr,args.l2,args.seed+step,args.device)
        st=time.time();ref=fresh('distmult',ne,nr,args.dim,args.seed,args.device);rstats=train_model(ref,next_train,ne,args.epochs,args.batch_size,args.lr,args.l2,args.seed,args.device);refsec=time.time()-st
        lg,lf=evalm(local.model,data,next_train,all_forget,ne,args);rg,rf=evalm(ref,data,next_train,all_forget,ne,args)
        rows.append({'dataset':args.dataset,'model':'distmult','seed':args.seed,'step':step,'step_fraction':args.step_fraction,'cumulative_fraction':len(all_forget)/n0,'step_forget_n':len(step_forget),'cumulative_forget_n':len(all_forget),'request_hash':hsh(all_forget),'method':'SchemaCert-L5-sequential','global_mrr':lg['mrr'],'forget_mrr':lf['mrr'],'reference_global_mrr':rg['mrr'],'reference_forget_mrr':rf['mrr'],'global_gap_to_ref':abs(lg['mrr']-rg['mrr']),'forget_gap_to_ref':abs(lf['mrr']-rf['mrr']),'local_sec':local.seconds,'reference_sec':refsec,'parameter_fraction':local.parameter_fraction,'work_unique_triples':local.work_unique_triples})
        current_model=local.model;current_train=next_train;current_ids=next_ids
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True);p=out/f'{args.dataset}_distmult_s{args.seed}_sequential_2pct_x5.csv'
    with p.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0].keys()));w.writeheader();w.writerows(rows)
    (p.with_suffix('.json')).write_text(json.dumps({'dataset':args.dataset,'seed':args.seed,'base_train_sec':bs.seconds,'step_size':k,'rows':rows},indent=2)+'\n')
    print(f'SEQUENTIAL_DELETION_OK steps={len(rows)} final_fraction={rows[-1]["cumulative_fraction"]:.6f} out={p}')
if __name__=='__main__':main()
