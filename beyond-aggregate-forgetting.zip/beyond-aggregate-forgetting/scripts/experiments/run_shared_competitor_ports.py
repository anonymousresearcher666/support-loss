#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from schemacert.competitor_ports import (
    save_graphdpo_shared_checkpoint,
    sgu_schema_entity_shared,
    zero_fisher_shared,
)
from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.graphdpo_shared import load_graphdpo_shared_checkpoint
from scripts.experiments.evaluate_graphdpo_common import graphdpo_vocab, request_fingerprint, verify_exported_request
from scripts.experiments.evaluate_graphdpo_common_support import map_supported, supported_mask
from scripts.run_publication_families import select_forget


def main() -> None:
    p = argparse.ArgumentParser(description='Run matched SGU-Schema and ZeroFisher ports from the shared GraphDPO TransE base.')
    p.add_argument('--dataset', required=True)
    p.add_argument('--fraction', type=float, required=True)
    p.add_argument('--policy', choices=['entity','random'], default='entity')
    p.add_argument('--seed', type=int, required=True)
    p.add_argument('--data-root', default='data')
    p.add_argument('--request-dir', required=True)
    p.add_argument('--base-checkpoint', required=True)
    p.add_argument('--methods', nargs='+', default=['SGU', 'ZeroFisher'], choices=['SGU', 'ZeroFisher'])
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--out', required=True)
    p.add_argument('--sgu-clusters', type=int, default=3)
    p.add_argument('--sgu-lr', type=float, default=1e-5)
    p.add_argument('--zf-epsilon', type=float, default=1e-5)
    p.add_argument('--zf-gamma', type=float, default=1.0)
    p.add_argument('--zf-iterations', type=int, default=100)
    p.add_argument('--zf-damp', type=float, default=0.0)
    p.add_argument('--zf-scale', type=float, default=10.0)
    p.add_argument('--zf-batch-size', type=int, default=1024)
    p.add_argument('--neg-ratio', type=int, default=10)
    p.add_argument('--margin', type=float, default=8.0)
    args = p.parse_args()

    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    fi, meta = select_forget(data.train, args.fraction, args.seed + int(args.fraction * 10000), args.policy)
    forget = data.train[fi]
    request_dir = Path(args.request_dir)
    manifest, all_data_path = verify_exported_request(
        request_dir, data, forget, args.dataset, args.policy, args.seed, args.fraction
    )
    entity2id, relation2id = graphdpo_vocab(all_data_path)

    if not supported_mask(data.train, data, entity2id, relation2id).all():
        raise RuntimeError('GraphDPO vocabulary does not cover full train support')
    train_c = map_supported(data.train, data, entity2id, relation2id)
    forget_c = map_supported(forget, data, entity2id, relation2id)
    base = load_graphdpo_shared_checkpoint(args.base_checkpoint).to(args.device)
    if base.entity.num_embeddings != len(entity2id) or base.relation.num_embeddings != len(relation2id):
        raise RuntimeError('Shared base shape does not match request vocabulary')

    out = Path(args.out)
    stem = f'{args.dataset}_transe_{args.policy}_f{args.fraction:g}_s{args.seed}'
    run_dir = out / stem
    run_dir.mkdir(parents=True, exist_ok=True)
    meta_path = run_dir / 'metadata.json'
    if meta_path.exists():
        payload = json.loads(meta_path.read_text())
        payload.setdefault('methods', {})
    else:
        payload = {
            'dataset': args.dataset,
            'fraction': args.fraction,
            'policy': args.policy,
            'seed': args.seed,
            'request_hash': request_fingerprint(data, forget),
            'request_meta': meta,
            'graphdpo_manifest': manifest,
            'base_checkpoint': str(args.base_checkpoint),
            'methods': {},
        }

    timings = {}
    if 'SGU' in args.methods:
        res = sgu_schema_entity_shared(
            base, train_c, forget_c,
            seed=args.seed,
            device=args.device,
            n_clusters=args.sgu_clusters,
            lr=args.sgu_lr,
        )
        ckpt = run_dir / 'SGU_Schema_matched.tar'
        save_graphdpo_shared_checkpoint(res.model, ckpt)
        payload['methods']['SGU'] = {'checkpoint': str(ckpt), 'seconds': res.seconds, **res.metadata}
        timings['SGU'] = float(res.seconds)
        print(f'SGU_CHECKPOINT={ckpt}')
        print(f'SGU_TIME_SEC={res.seconds:.6f}')
        del res

    if 'ZeroFisher' in args.methods:
        res = zero_fisher_shared(
            base, train_c, fi, len(entity2id),
            seed=args.seed,
            device=args.device,
            epsilon=args.zf_epsilon,
            gamma=args.zf_gamma,
            iterations=args.zf_iterations,
            damp=args.zf_damp,
            scale=args.zf_scale,
            batch_size=args.zf_batch_size,
            neg_ratio=args.neg_ratio,
            margin=args.margin,
        )
        ckpt = run_dir / 'ZeroFisher_matched.tar'
        save_graphdpo_shared_checkpoint(res.model, ckpt)
        payload['methods']['ZeroFisher'] = {'checkpoint': str(ckpt), 'seconds': res.seconds, **res.metadata}
        timings['ZeroFisher'] = float(res.seconds)
        print(f'ZEROFISHER_CHECKPOINT={ckpt}')
        print(f'ZEROFISHER_TIME_SEC={res.seconds:.6f}')
        del res

    meta_path.write_text(json.dumps(payload, indent=2))
    print(f'COMPETITOR_PORT_METADATA={meta_path}')
    if len(timings) == 1:
        # parse_native_time() in the common evaluator understands this marker.
        print(f'Sum_Training_Time:{next(iter(timings.values())):.9f}')
    else:
        for name, sec in timings.items():
            print(f'{name}_Sum_Training_Time:{sec:.9f}')
    print('SHARED_COMPETITOR_PORTS_OK')


if __name__ == '__main__':
    main()
