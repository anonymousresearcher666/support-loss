#!/usr/bin/env python3
"""SupportLoss cross-family GPU rank and functional-output study.
Not the archived TransE/GraphDPO rescore. All settings fixed before outcomes.
100 epochs is a budget, not convergence. Preserve predictions and provenance.
"""
from __future__ import annotations
import argparse, copy, hashlib, json, platform, time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from schemacert.data import load_dataset
from schemacert.family_models import make_model, MODEL_NAMES
def affected_region(train, fi, hops=1):
 f=train[fi];ae=np.unique(f[:,[0,2]]);ar=np.unique(f[:,1]);R=np.delete(train,fi,axis=0)
 return ae,ar,None,R

DEVICE='cpu'
FAMILY='distmult'
NEGATIVE='tail'
BASE_EPOCHS=20
REFERENCE_EPOCHS=[20,50,100]
QUERIES=256
DIM=128
BUDGET=5


PROTOCOL={'name':'supportloss-cross-family-v1','dim':128,'base_epochs':20,
 'reference_epochs':[20,50,100],'seeds':[17,29,43],
 'request':'complete highest-degree entity stars, ID tie-break','nominal_fraction':.10,
 'correction_presentations':'5*retained_triples','lr':.002,'batch':2048,'l2_mean':1e-6,
 'negative_ratio':1,'negative_rule':'uniform tail excluding positive tail; unfiltered',
 'query_seed':19072026,'queries_per_set':256,'optimizer':'Adam defaults',
 'training_dtype':'float32','evaluation_dtype':'float64','certified':False,
 'scope':'new cross-family cohort; not pooled with historical CSVs'}


def hash_array(a):return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()


def star_request(train,fraction=.1):
 ne=int(train[:,[0,2]].max())+1
 degree=np.bincount(train[:,[0,2]].reshape(-1),minlength=ne)
 order=np.lexsort((np.arange(ne),-degree));chosen=[];mask=np.zeros(len(train),bool)
 for e in order:
  chosen.append(int(e));mask|=(train[:,0]==e)|(train[:,2]==e)
  if mask.sum()>=max(1,round(fraction*len(train))):break
 if mask.all():raise ValueError('Complete data deletion is out of scope')
 return np.flatnonzero(mask),np.asarray(chosen,dtype=np.int64)


def corrupt_tail(pos,ne,rng):
 if ne<2:raise ValueError('Two entities required')
 out=pos.copy()
 side=np.full(len(pos),2) if NEGATIVE=='tail' else rng.choice([0,2],len(pos))
 z=rng.integers(0,ne-1,size=len(pos),dtype=np.int64)
 original=pos[np.arange(len(pos)),side]
 out[np.arange(len(pos)),side]=z+(z>=original)
 return out


def fresh(ne,nr,seed,dim=None):
 # CPU initialization is reproducible independently of the CUDA RNG.
 with torch.random.fork_rng(devices=[]):
  torch.manual_seed(seed)
  return make_model(FAMILY,ne,nr,DIM if dim is None else dim).to(DEVICE)


def epoch(model,work,opt,rng,ne,budget=None,masks=None):
 budget=len(work) if budget is None else int(budget)
 if len(work)==0 or budget<=0:raise ValueError('Nonempty stream required')
 order=np.empty(0,dtype=int);cursor=0;consumed=0;loss_sum=0.;steps=0
 while consumed<budget:
  wanted=min(PROTOCOL['batch'],budget-consumed);pieces=[]
  while wanted:
   if cursor==len(order):order=rng.permutation(len(work));cursor=0
   n=min(wanted,len(order)-cursor);pieces.append(order[cursor:cursor+n]);cursor+=n;wanted-=n
  ix=np.concatenate(pieces);p=work[ix];n=corrupt_tail(p,ne,rng)
  opt.zero_grad(set_to_none=True)
  loss=F.softplus(-model.score(torch.from_numpy(p).to(DEVICE))).mean()+F.softplus(model.score(torch.from_numpy(n).to(DEVICE))).mean()
  loss=loss+PROTOCOL['l2_mean']*sum((q*q).mean() for q in model.parameters())
  if not torch.isfinite(loss):raise FloatingPointError('Nonfinite loss')
  loss.backward()
  if masks is not None:
   model.entity.weight.grad.mul_(masks[0]);model.relation.weight.grad.mul_(masks[1])
  opt.step();consumed+=len(ix);steps+=1;loss_sum+=float(loss.detach())*len(ix)
 return {'loss':loss_sum/consumed,'presentations':consumed,'steps':steps}


def train_trajectory(ne,nr,seed,train,max_epoch,label,out,callback):
 model=fresh(ne,nr,seed);opt=torch.optim.Adam(model.parameters(),lr=PROTOCOL['lr'])
 rng=np.random.default_rng(seed);trace=[];start=time.perf_counter()
 for e in range(1,max_epoch+1):
  stats=epoch(model,train,opt,rng,ne);trace.append({'epoch':e,**stats,'elapsed_sec':time.perf_counter()-start})
  if e in set(REFERENCE_EPOCHS+[BASE_EPOCHS]):
   callback(f'{label}{e}',model,trace[-1])
   torch.save({'state_dict':model.state_dict(),'epoch':e,'seed':seed,'protocol':PROTOCOL},out/f'{label}{e}.pt')
   print(label,e,stats['loss'],time.perf_counter()-start,flush=True)
 (out/f'{label}_training.json').write_text(json.dumps(trace,indent=2)+'\n')
 return model


def filters(*arrays):
 tails={};heads={}
 for rows in arrays:
  for h,r,t in rows:
   tails.setdefault((int(h),int(r)),set()).add(int(t));heads.setdefault((int(r),int(t)),set()).add(int(h))
 return tails,heads


@torch.no_grad()
def rank_queries(model,q,truth,batch=1):
 # Evaluate generic family scorers in float64, retaining only one query's
 # scores at a time. Target is read from the same candidate scoring pass.
 m=copy.deepcopy(model).double();device=next(m.parameters()).device
 ne=m.entity.num_embeddings;ta,ha=truth;ranks=[];scores=[];top=[]
 for side in ('head','tail'):
  rs=[];ss=[];tt=[]
  for h,r,t in q:
   a,b=(r,t) if side=='head' else (h,r)
   aa=torch.tensor([int(a)],device=device);bb=torch.tensor([int(b)],device=device)
   chunks=[m.score_candidates(side,aa,bb,torch.arange(st,min(st+2048,ne),device=device))[0]
           for st in range(0,ne,2048)]
   sc=torch.cat(chunks)
   if not torch.isfinite(sc).all():raise FloatingPointError('Nonfinite evaluation score')
   target=int(h if side=='head' else t);true=sc[target].item();ss.append(true)
   ex=ha.get((int(r),int(t)),()) if side=='head' else ta.get((int(h),int(r)),())
   bad=[int(z) for z in ex if z!=target]
   if bad:sc[bad]=-torch.inf
   tt.append(int(sc.argmax()));sc[target]=-torch.inf
   rs.append(1+int((sc>true).sum())+.5*int((sc==true).sum()))
  ranks.append(np.asarray(rs,dtype=float));scores.append(np.asarray(ss));top.append(np.asarray(tt))
 return {'ranks':np.stack(ranks),'scores':np.stack(scores),'top1':np.stack(top)}


def main():
 global DEVICE,FAMILY,NEGATIVE,BASE_EPOCHS,REFERENCE_EPOCHS,QUERIES,DIM,BUDGET
 ap=argparse.ArgumentParser();ap.add_argument('--data-root',type=Path,required=True)
 ap.add_argument('--dataset',choices=['FB15K-237','CoDEx-M'],required=True)
 ap.add_argument('--seed',type=int,choices=[17,29,43],required=True);ap.add_argument('--out',type=Path,required=True)
 ap.add_argument('--model',choices=MODEL_NAMES,required=True)
 ap.add_argument('--negative',choices=['tail','balanced'],default='tail')
 ap.add_argument('--device',default='cuda')
 ap.add_argument('--smoke',action='store_true',help='Synthetic data only; never paper evidence')
 args=ap.parse_args()
 DEVICE=args.device;FAMILY=args.model;NEGATIVE=args.negative
 if DEVICE.startswith('cuda') and not torch.cuda.is_available():raise RuntimeError('CUDA required; refusing CPU fallback')
 if args.smoke:BASE_EPOCHS=1;REFERENCE_EPOCHS=[1,2];QUERIES=8;DIM=8;BUDGET=1
 PROTOCOL.update(model=FAMILY,negative_rule=NEGATIVE+' uniform corruption excluding original entity; unfiltered',
   dim=DIM,base_epochs=BASE_EPOCHS,reference_epochs=REFERENCE_EPOCHS,queries_per_set=QUERIES,
   correction_presentations=f'{BUDGET}*retained_triples',smoke=args.smoke,
   normalization='initialization only; no post-update projection',device=DEVICE,
   independent_reference_seed=args.seed+70001)
 torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
 torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
 folder='FB15k-237' if args.dataset=='FB15K-237' else 'codex-m';path=args.data_root/folder
 if not path.exists() and args.dataset=='CoDEx-M':path=args.data_root/'codex/data/triples/codex-m'
 if args.smoke:
  from types import SimpleNamespace
  rng=np.random.default_rng(812);triples=np.unique(np.column_stack((rng.integers(0,24,150),rng.integers(0,3,150),rng.integers(0,24,150))),axis=0)
  data=SimpleNamespace(train=triples[:100],valid=triples[100:115],test=triples[115:],entities=list(range(24)),relations=list(range(3)))
 else:
  for split in ('train','valid','test'):
   if not (path/(split+'.txt')).is_file():raise FileNotFoundError(path/(split+'.txt'))
  data=load_dataset(path/'train.txt',path/'valid.txt',path/'test.txt')
 if any(len(a)==0 for a in (data.train,data.valid,data.test)):raise ValueError('All three splits must be nonempty')
 ne,nr=len(data.entities),len(data.relations)
 out=args.out/('smoke' if args.smoke else 'full')/args.negative/args.dataset/args.model/f'seed{args.seed}'
 # Exclusive directory creation prevents concurrent writes and accidental restart.
 out.mkdir(parents=True,exist_ok=False)
 (out/'STARTED.json').write_text(json.dumps({'protocol':PROTOCOL,'seed':args.seed},indent=2))
 fi,selected=star_request(data.train);R=np.delete(data.train,fi,axis=0);U=data.train[fi]
 if np.isin(R[:,[0,2]],selected).any():raise AssertionError('Not complete stars')
 ae,ar,_,check_R=affected_region(data.train,fi,hops=1);np.testing.assert_array_equal(R,check_R)
 local_ids=np.flatnonzero(np.isin(R[:,0],ae)|np.isin(R[:,2],ae));rng_work=np.random.default_rng(17)
 extra_n=min(len(R),max(len(local_ids)//2,4096))
 extra=rng_work.choice(len(R),extra_n,replace=False) if len(R)>extra_n else np.arange(len(R))
 work_ids=np.r_[local_ids,extra];work=R[work_ids]
 em=torch.zeros(ne,1,device=DEVICE);em[ae]=1.;rm=torch.zeros(nr,1,device=DEVICE);rm[ar]=1.
 qgen=np.random.default_rng(PROTOCOL['query_seed'])
 qs={name:arr[np.sort(qgen.choice(len(arr),min(QUERIES,len(arr)),replace=False))]
     for name,arr in [('test',data.test),('forgotten',U),('retained',R)]}
 truth=filters(R,data.valid,data.test,U)
 np.savez_compressed(out/'queries.npz',**qs,forget_indices=fi,selected_entities=selected,
                     affected_entities=ae,affected_relations=ar,work_indices=work_ids)
 raw=[]
 def record(label,model,stats):
  metrics={};payload={}
  for name,q in qs.items():
   vals=rank_queries(model,q,truth)
   for k,v in vals.items():payload[f'{name}_{k}']=v
   metrics[f'{name}_mrr']=float((1/vals['ranks']).mean());metrics[f'{name}_hits10']=float((vals['ranks']<=10).mean())
  raw.append({'label':label,**metrics,**stats});np.savez_compressed(out/(label+'_predictions.npz'),**payload)
  (out/'raw.json').write_text(json.dumps(raw,indent=2)+'\n')
 start=time.perf_counter()
 # All interventions are constructed and scored BEFORE any retained reference.
 base=train_trajectory(ne,nr,args.seed,data.train,BASE_EPOCHS,'Base',out,record)
 record('Unchanged',base,{'presentations':0,'steps':0,'elapsed_sec':0.})
 reset=copy.deepcopy(base);fresh_reset=fresh(ne,nr,args.seed+9001)
 with torch.no_grad():reset.entity.weight[selected]=fresh_reset.entity.weight[selected]
 record('ResetOnly',reset,{'presentations':0,'steps':0,'elapsed_sec':0.})
 for label,initial,stream,mask in [('Local',base,work,(em,rm)),('ResetLocal',reset,work,(em,rm)),
   ('FullRetain',base,R,None),('ResetFullRetain',reset,R,None),('ResetDenseSameWork',reset,work,None)]:
  model=copy.deepcopy(initial);opt=torch.optim.Adam(model.parameters(),lr=PROTOCOL['lr'])
  rng=np.random.default_rng(args.seed+18001);run_start=time.perf_counter()
  stats=epoch(model,stream,opt,rng,ne,budget=BUDGET*len(R),masks=mask);stats['elapsed_sec']=time.perf_counter()-run_start
  stats['parameter_fraction']=float((len(ae)*model.entity.embedding_dim+len(ar)*model.relation.embedding_dim)/(model.entity.weight.numel()+model.relation.weight.numel())) if mask is not None else 1.
  stats['work_unique_fraction']=len(np.unique(work_ids))/len(R) if stream is work else 1.
  if mask is not None:
   with torch.no_grad():
    assert torch.equal(model.entity.weight[em[:,0]==0],initial.entity.weight[em[:,0]==0])
    assert torch.equal(model.relation.weight[rm[:,0]==0],initial.relation.weight[rm[:,0]==0])
  record(label,model,stats);print(label,stats,flush=True)
  torch.save({'state_dict':model.state_dict(),'seed':args.seed,'protocol':PROTOCOL},out/(label+'.pt'))
 train_trajectory(ne,nr,args.seed,R,max(REFERENCE_EPOCHS),'Reference',out,record)
 train_trajectory(ne,nr,args.seed+70001,R,max(REFERENCE_EPOCHS),'IndependentReference',out,record)
 manifest={'protocol':PROTOCOL,'dataset':args.dataset,'seed':args.seed,'entities':ne,'relations':nr,
  'train_triples':len(data.train),'retained_triples':len(R),'forgotten_triples':len(U),'selected_entities':len(selected),
  'realized_fraction':len(U)/len(data.train),'file_hashes':{s:hashlib.sha256((path/(s+'.txt')).read_bytes()).hexdigest() for s in ('train','valid','test')} if not args.smoke else {'synthetic_train':hash_array(data.train)},
  'forget_hash':hash_array(fi),'test_query_hash':hash_array(qs['test']),'elapsed_sec':time.perf_counter()-start,
  'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'gpu':torch.cuda.get_device_name() if DEVICE.startswith('cuda') else None,'python':platform.python_version(),'numpy':np.__version__,'torch':torch.__version__,'cpu_threads':1,
  'reference_labels':[f'Reference{e}' for e in REFERENCE_EPOCHS],
  'iteration_control':'all five optimized interventions have equal positive presentations and steps',
  'query_shapes':{k:list(v.shape) for k,v in qs.items()}}
 (out/'COMPLETE.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print('SUPPORTLOSS_CROSS_FAMILY_COMPLETE',args.dataset,args.seed,flush=True)
if __name__=='__main__':main()

