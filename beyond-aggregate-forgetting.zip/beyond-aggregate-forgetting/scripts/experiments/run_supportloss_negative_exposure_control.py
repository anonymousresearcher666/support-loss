#!/usr/bin/env python3
from __future__ import annotations
import argparse, copy, json
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F

from schemacert.data import load_dataset
from schemacert.family_models import DistMult
from scripts.experiments.run_reference_budget_pilot import filters, rank_queries


def load_model(path: Path, ne: int, nr: int) -> DistMult:
    obj=torch.load(path,map_location="cpu",weights_only=False)
    state=obj["state_dict"] if isinstance(obj,dict) and "state_dict" in obj else obj
    dim=int(state["entity.weight"].shape[1])
    m=DistMult(ne,nr,dim);m.load_state_dict(state);m.eval()
    return m


def metric_pair(candidate: DistMult, reference: DistMult, q: np.ndarray, truth):
    a=rank_queries(candidate,q,truth)["ranks"]
    b=rank_queries(reference,q,truth)["ranks"]
    return {
        "mrr_candidate":float((1/a).mean()),
        "mrr_reference":float((1/b).mean()),
        "mrr_gap":float(abs((1/a).mean()-(1/b).mean())),
        "exact_rank_disagreement":float((a!=b).mean()),
        "mean_abs_log10_rank_gap":float(np.abs(np.log10(a)-np.log10(b)).mean()),
        "top10_membership_disagreement":float(((a<=10)!=(b<=10)).mean()),
        "top100_membership_disagreement":float(((a<=100)!=(b<=100)).mean()),
    }


def negative_exposure(model: DistMult, retained: np.ndarray, selected: np.ndarray, ne: int, epochs: int, seed: int, lr: float, l2: float):
    """Expose only zero-support entities as corrupted negatives.

    Original cohort uses one uniform tail corruption per retained positive.
    Under that process each entity receives about epochs*|R|/(|V|-1)
    negative-tail presentations. We deterministically match that expectation
    for each selected entity and update only its entity embedding.
    """
    m=copy.deepcopy(model);m.train()
    expected=max(1,round(epochs*len(retained)/(ne-1)))
    rng=np.random.default_rng(seed)
    negatives=[]
    for z in selected:
        z=int(z)
        made=0
        while made<expected:
            p=retained[int(rng.integers(0,len(retained)))].copy()
            if int(p[2])==z:
                continue
            p[2]=z
            negatives.append(p)
            made+=1
    neg=np.asarray(negatives,dtype=np.int64)
    rng.shuffle(neg)

    mask=torch.zeros_like(m.entity.weight)
    mask[selected]=1.0
    opt=torch.optim.Adam(m.parameters(),lr=lr)
    batch=2048
    for st in range(0,len(neg),batch):
        x=torch.from_numpy(neg[st:st+batch])
        opt.zero_grad(set_to_none=True)
        loss=F.softplus(m.score(x)).mean()+l2*(m.entity.weight[selected]**2).mean()
        loss.backward()
        if m.entity.weight.grad is not None:
            m.entity.weight.grad.mul_(mask)
        if m.relation.weight.grad is not None:
            m.relation.weight.grad.zero_()
        opt.step()
    m.eval()
    return m, expected, len(neg)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--data-root",type=Path,required=True)
    ap.add_argument("--cohort",type=Path,required=True)
    ap.add_argument("--out",type=Path,required=True)
    ap.add_argument("--dataset",choices=["FB15K-237","CoDEx-M"],required=True)
    ap.add_argument("--seed",type=int,choices=[17,29,43],required=True)
    args=ap.parse_args()
    torch.set_num_threads(1);torch.set_num_interop_threads(1)

    folder="FB15k-237" if args.dataset=="FB15K-237" else "codex-m"
    path=args.data_root/folder
    if args.dataset=="CoDEx-M" and not (path/"train.txt").is_file():
        alt=args.data_root/"codex"/"data"/"triples"/"codex-m"
        if (alt/"train.txt").is_file(): path=alt
    data=load_dataset(path/"train.txt",path/"valid.txt",path/"test.txt")
    ne,nr=len(data.entities),len(data.relations)

    direct=args.cohort/args.dataset/f"seed{args.seed}"
    nested=args.cohort/args.dataset/"distmult"/f"seed{args.seed}"
    run=direct if direct.is_dir() else nested
    if not run.is_dir(): raise FileNotFoundError(f"Missing cohort cell: {direct} or {nested}")

    q=dict(np.load(run/"queries.npz"))
    fi=q["forget_indices"];selected=q["selected_entities"].astype(np.int64)
    U=data.train[fi];R=np.delete(data.train,fi,axis=0)
    truth=filters(R,data.valid,data.test,U)

    rl=load_model(run/"ResetLocal.pt",ne,nr)
    ref=load_model(run/"Reference20.pt",ne,nr)

    neg,expected,nneg=negative_exposure(rl,R,selected,ne,20,args.seed+424242,0.002,1e-6)

    norm=copy.deepcopy(rl)
    with torch.no_grad():
        # IMPORTANT: Long/NumPy advanced indexing returns a temporary tensor.
        # The previous code used entity.weight[selected].mul_(...), which did
        # not write the rescaled rows back to entity.weight and made the oracle
        # a no-op.  Use explicit indexed write-back.
        idx=torch.as_tensor(selected,dtype=torch.long)
        before=norm.entity.weight.index_select(0,idx)
        rn=before.norm(dim=1,keepdim=True).clamp_min(1e-12)
        tn=ref.entity.weight.index_select(0,idx).norm(dim=1,keepdim=True)
        norm.entity.weight.index_copy_(0,idx,before*(tn/rn))
    norm.eval()

    def norms(m):
        x=m.entity.weight.detach()[selected].norm(dim=1).cpu().numpy()
        return {"mean":float(x.mean()),"median":float(np.median(x))}

    out={
      "dataset":args.dataset,"seed":args.seed,
      "selected_entities":int(len(selected)),
      "retained_triples":int(len(R)),
      "expected_negative_presentations_per_selected_entity":int(expected),
      "total_matched_negative_presentations":int(nneg),
      "diagnostic_scope":{
        "NegExposure20eq":"candidate-only mechanism control; no reference access",
        "NormMatchRefOracle":"diagnostic oracle using reference norms; not a deployable unlearning method"
      },
      "selected_norms":{
        "ResetLocal":norms(rl),"NegExposure20eq":norms(neg),
        "NormMatchRefOracle":norms(norm),"Reference20":norms(ref)
      },
      "forgotten":{
        "ResetLocal":metric_pair(rl,ref,q["forgotten"],truth),
        "NegExposure20eq":metric_pair(neg,ref,q["forgotten"],truth),
        "NormMatchRefOracle":metric_pair(norm,ref,q["forgotten"],truth)
      },
      "test":{
        "ResetLocal":metric_pair(rl,ref,q["test"],truth),
        "NegExposure20eq":metric_pair(neg,ref,q["test"],truth),
        "NormMatchRefOracle":metric_pair(norm,ref,q["test"],truth)
      }
    }
    args.out.mkdir(parents=True,exist_ok=True)
    p=args.out/f"{args.dataset}_seed{args.seed}_negative_exposure.json"
    p.write_text(json.dumps(out,indent=2)+"\n")
    print(json.dumps({
      "dataset":args.dataset,"seed":args.seed,
      "expected_per_entity":expected,
      "rl_loggap":out["forgotten"]["ResetLocal"]["mean_abs_log10_rank_gap"],
      "neg_loggap":out["forgotten"]["NegExposure20eq"]["mean_abs_log10_rank_gap"],
      "norm_loggap":out["forgotten"]["NormMatchRefOracle"]["mean_abs_log10_rank_gap"],
      "ok":True
    },indent=2))
    print("SUPPORTLOSS_NEGATIVE_EXPOSURE_CONTROL_OK")


if __name__=="__main__":
    main()
