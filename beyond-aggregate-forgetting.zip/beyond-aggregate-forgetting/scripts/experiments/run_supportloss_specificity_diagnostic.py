#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import torch

from schemacert.data import load_dataset
from schemacert.family_models import DistMult
from scripts.experiments.run_reference_budget_pilot import filters

MODELS = ("Base20", "ResetLocal", "Reference20")


def load_model(path: Path, ne: int, nr: int) -> DistMult:
    obj = torch.load(path, map_location="cpu", weights_only=False)
    state = obj["state_dict"] if isinstance(obj, dict) and "state_dict" in obj else obj
    dim = int(state["entity.weight"].shape[1])
    m = DistMult(ne, nr, dim)
    m.load_state_dict(state)
    m.eval()
    return m


def summarize(x: np.ndarray) -> dict[str, float]:
    x = np.asarray(x, dtype=float)
    return {
        "n": int(x.size),
        "mean": float(x.mean()),
        "median": float(np.median(x)),
        "q05": float(np.quantile(x, 0.05)),
        "q25": float(np.quantile(x, 0.25)),
        "q75": float(np.quantile(x, 0.75)),
        "q95": float(np.quantile(x, 0.95)),
    }


def roc_auc_binary(y: np.ndarray, s: np.ndarray) -> float:
    y = np.asarray(y, dtype=int)
    s = np.asarray(s, dtype=float)
    pos = s[y == 1]
    neg = s[y == 0]
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    order = np.argsort(s, kind="mergesort")
    ranks = np.empty(len(s), dtype=float)
    i = 0
    while i < len(order):
        j = i + 1
        while j < len(order) and s[order[j]] == s[order[i]]:
            j += 1
        avg_rank = 0.5 * ((i + 1) + j)
        ranks[order[i:j]] = avg_rank
        i = j
    rank_sum = ranks[y == 1].sum()
    return float((rank_sum - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg)))


def candidate_rank(
    model: DistMult,
    side: str,
    contexts: np.ndarray,
    targets: np.ndarray,
    truth,
    batch: int = 64,
) -> tuple[np.ndarray, np.ndarray]:
    ent = model.entity.weight.detach().double().cpu()
    rel = model.relation.weight.detach().double().cpu()
    tails, heads = truth
    ranks = []
    scores = []
    for st in range(0, len(contexts), batch):
        ctx = contexts[st:st + batch]
        tgt = targets[st:st + batch]
        if side == "tail":
            h = torch.from_numpy(ctx[:, 0]).long()
            r = torch.from_numpy(ctx[:, 1]).long()
            v = ent[h] * rel[r]
            sc = v @ ent.T
            for j in range(len(ctx)):
                target = int(tgt[j])
                true = float(sc[j, target])
                ex = tails.get((int(ctx[j, 0]), int(ctx[j, 1])), ())
                bad = [int(z) for z in ex if int(z) != target]
                if bad:
                    sc[j, bad] = -torch.inf
                rr = 1 + int((sc[j] > true).sum()) + 0.5 * int((sc[j] == true).sum())
                ranks.append(float(rr))
                scores.append(true)
        else:
            r = torch.from_numpy(ctx[:, 0]).long()
            t = torch.from_numpy(ctx[:, 1]).long()
            v = rel[r] * ent[t]
            sc = v @ ent.T
            for j in range(len(ctx)):
                target = int(tgt[j])
                true = float(sc[j, target])
                ex = heads.get((int(ctx[j, 0]), int(ctx[j, 1])), ())
                bad = [int(z) for z in ex if int(z) != target]
                if bad:
                    sc[j, bad] = -torch.inf
                rr = 1 + int((sc[j] > true).sum()) + 0.5 * int((sc[j] == true).sum())
                ranks.append(float(rr))
                scores.append(true)
    return np.asarray(ranks), np.asarray(scores)


def build_target_queries(forgotten: np.ndarray, selected: np.ndarray):
    selected_set = set(int(x) for x in selected)
    tail_ctx, tail_tgt, head_ctx, head_tgt = [], [], [], []
    for h, r, t in forgotten:
        h, r, t = int(h), int(r), int(t)
        if t in selected_set:
            tail_ctx.append((h, r))
            tail_tgt.append(t)
        if h in selected_set:
            head_ctx.append((r, t))
            head_tgt.append(h)
    return (
        np.asarray(tail_ctx, dtype=np.int64), np.asarray(tail_tgt, dtype=np.int64),
        np.asarray(head_ctx, dtype=np.int64), np.asarray(head_tgt, dtype=np.int64),
    )


def false_contexts(side: str, contexts: np.ndarray, targets: np.ndarray, all_true: set[tuple[int, int, int]], ne: int, seed: int) -> np.ndarray:
    """Build relation-matched false contexts over the full entity vocabulary.

    Tail prediction keeps (r, target-tail) fixed and replaces the head.
    Head prediction keeps (target-head, r) fixed and replaces the tail.
    The sampled triple must be absent from train/valid/test. This avoids a
    failure mode of within-forgotten-pool shuffling when a deleted entity is
    connected to every available context in that restricted pool.
    """
    rng = np.random.default_rng(seed)
    out = np.empty_like(contexts)
    for i, (c, target) in enumerate(zip(contexts, targets)):
        found = False
        relation = int(c[1] if side == "tail" else c[0])
        original_context_entity = int(c[0] if side == "tail" else c[1])
        for _ in range(20000):
            z = int(rng.integers(0, ne))
            if z == original_context_entity:
                continue
            if side == "tail":
                triple = (z, relation, int(target))
                candidate_context = (z, relation)
            else:
                triple = (int(target), relation, z)
                candidate_context = (relation, z)
            if triple not in all_true:
                out[i] = candidate_context
                found = True
                break
        if not found:
            raise RuntimeError(
                f"Could not build relation-matched false {side} query for target {int(target)} "
                f"and relation {relation}"
            )
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-root", type=Path, required=True)
    ap.add_argument("--cohort", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--dataset", choices=["FB15K-237", "CoDEx-M"], required=True)
    ap.add_argument("--seed", type=int, choices=[17, 29, 43], required=True)
    args = ap.parse_args()

    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)

    folder = "FB15k-237" if args.dataset == "FB15K-237" else "codex-m"
    path = args.data_root / folder
    if args.dataset == "CoDEx-M" and not (path / "train.txt").is_file():
        alt = args.data_root / "codex" / "data" / "triples" / "codex-m"
        if (alt / "train.txt").is_file():
            path = alt
    data = load_dataset(
        path / "train.txt",
        path / "valid.txt",
        path / "test.txt",
    )
    ne, nr = len(data.entities), len(data.relations)
    direct = args.cohort / args.dataset / f"seed{args.seed}"
    nested = args.cohort / args.dataset / "distmult" / f"seed{args.seed}"
    if direct.is_dir():
        run = direct
    elif nested.is_dir():
        run = nested
    else:
        raise FileNotFoundError(
            f"Could not locate cohort cell. Tried {direct} and {nested}"
        )
    q = dict(np.load(run / "queries.npz"))
    forgotten = data.train[q["forget_indices"]]
    selected = q["selected_entities"].astype(np.int64)

    all_true_arr = np.concatenate([data.train, data.valid, data.test], axis=0)
    all_true = {tuple(map(int, row)) for row in all_true_arr}
    retained = np.delete(data.train, q["forget_indices"], axis=0)
    truth = filters(retained, data.valid, data.test, forgotten)

    tail_ctx, tail_tgt, head_ctx, head_tgt = build_target_queries(forgotten, selected)
    cap = 4096
    rng = np.random.default_rng(19092026 + args.seed)

    def subsample(ctx, tgt):
        if len(ctx) <= cap:
            return ctx, tgt
        ix = np.sort(rng.choice(len(ctx), cap, replace=False))
        return ctx[ix], tgt[ix]

    tail_ctx, tail_tgt = subsample(tail_ctx, tail_tgt)
    head_ctx, head_tgt = subsample(head_ctx, head_tgt)

    tail_false = false_contexts("tail", tail_ctx, tail_tgt, all_true, ne, 991 + args.seed)
    head_false = false_contexts("head", head_ctx, head_tgt, all_true, ne, 1991 + args.seed)

    args.out.mkdir(parents=True, exist_ok=True)
    rows = []
    summary = {
        "dataset": args.dataset,
        "seed": args.seed,
        "selected_entities": int(len(selected)),
        "forgotten_triples": int(len(forgotten)),
        "target_queries": {"tail": int(len(tail_tgt)), "head": int(len(head_tgt))},
        "models": {},
    }

    for label in MODELS:
        model = load_model(run / f"{label}.pt", ne, nr)
        norms = model.entity.weight.detach().double().norm(dim=1).cpu().numpy()
        selected_norms = norms[selected]
        other_mask = np.ones(ne, dtype=bool)
        other_mask[selected] = False
        other_norms = norms[other_mask]

        per_model = {
            "selected_norm": summarize(selected_norms),
            "other_entity_norm": summarize(other_norms),
        }

        for side, ctx, tgt, fctx in (
            ("tail", tail_ctx, tail_tgt, tail_false),
            ("head", head_ctx, head_tgt, head_false),
        ):
            true_rank, true_score = candidate_rank(model, side, ctx, tgt, truth)
            false_rank, false_score = candidate_rank(model, side, fctx, tgt, truth)
            y = np.r_[np.ones(len(true_rank), dtype=int), np.zeros(len(false_rank), dtype=int)]
            rank_signal = -np.log10(np.r_[true_rank, false_rank])
            score_signal = np.r_[true_score, false_score]
            per_model[side] = {
                "true_rank": summarize(true_rank),
                "false_rank": summarize(false_rank),
                "true_score": summarize(true_score),
                "false_score": summarize(false_score),
                "specificity_auc_rank": roc_auc_binary(y, rank_signal),
                "specificity_auc_score": roc_auc_binary(y, score_signal),
                "median_log10_rank_advantage_true_over_false": float(np.median(np.log10(false_rank) - np.log10(true_rank))),
            }
            for kind, rr, ss in (("true", true_rank, true_score), ("false", false_rank, false_score)):
                for i in range(len(rr)):
                    rows.append({
                        "dataset": args.dataset,
                        "seed": args.seed,
                        "model": label,
                        "side": side,
                        "query_kind": kind,
                        "target_entity": int(tgt[i]),
                        "rank": float(rr[i]),
                        "score": float(ss[i]),
                    })
        summary["models"][label] = per_model

    out_json = args.out / f"{args.dataset}_seed{args.seed}_specificity.json"
    out_csv = args.out / f"{args.dataset}_seed{args.seed}_specificity_rows.csv"
    out_json.write_text(json.dumps(summary, indent=2) + "\n")
    with out_csv.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    print(json.dumps({
        "dataset": args.dataset,
        "seed": args.seed,
        "tail_queries": len(tail_tgt),
        "head_queries": len(head_tgt),
        "resetlocal_tail_true_median": summary["models"]["ResetLocal"]["tail"]["true_rank"]["median"],
        "resetlocal_tail_false_median": summary["models"]["ResetLocal"]["tail"]["false_rank"]["median"],
        "ref20_tail_true_median": summary["models"]["Reference20"]["tail"]["true_rank"]["median"],
        "ref20_tail_false_median": summary["models"]["Reference20"]["tail"]["false_rank"]["median"],
        "ok": True,
    }, indent=2))
    print("SUPPORTLOSS_SPECIFICITY_DIAGNOSTIC_OK")


if __name__ == "__main__":
    main()
