#!/usr/bin/env python3
"""Fresh end-to-end TransE rerun. No checkpoints or measurements are imported.
Prospective fixed-final-epoch pipeline: replaces headline values after collection;
it is not a bitwise reconstruction of validation-selected external checkpoints.
"""
import argparse, copy, hashlib, json, platform, time
from pathlib import Path
import numpy as np
import torch
from torch import nn
from schemacert.data import infer_paths, load_dataset
from scripts.experiments.supportloss_transe_core import (
    GraphDPOSharedTransE, _graphdpo_facts, _margin_batch, select_forget,
    deterministic_xavier_restart, local_retrain_graphdpo_shared,
    restart_rows_all, cost_aware_star_cover, repair_from_retained_star)

SEEDS=(17,29,43)
TASKS=[(d,'entity',f,s) for d in ('FB15K-237','WN18RR','CoDEx-L','YAGO3-10') for f in (.1,.2) for s in SEEDS]
TASKS += [(d,'random',f,s) for d in ('FB15K-237','CoDEx-M') for f in (.1,.2) for s in SEEDS]
PROTOCOL=dict(name='supportloss-unified-v1', dim=128, epochs=20, batch=1024,
    lr=1e-4, margin=8., negative_ratio=10, local_epochs=5, random_repair_epochs=3,
    dtype='float64', optimizer='Adam defaults', initializer='CPU Xavier normal',
    checkpoint='final epoch, no validation selection', query_seed=19072026, query_limit=1000,
    negatives='head/tail balanced; uniform IDs 0..N-2, matching pinned shared TransE implementation',
    candidates='entities present in original training split, unchanged after deletion',
    filtering='original train+valid+test truths for every model; remove target from filter',
    reference='fresh same-budget training on retained facts; second independent seed +70001',
    scope='fresh harmonized rerun; does not reuse validation-selected GraphDPO checkpoints')


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def ah(a):return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()

def sync(device):
    if str(device).startswith('cuda'):torch.cuda.synchronize()

def fresh(ne,nr,seed,dim,device):
    g=torch.Generator(device='cpu').manual_seed(seed)
    e=torch.empty(ne,dim,dtype=torch.float64);r=torch.empty(2*nr,dim,dtype=torch.float64)
    nn.init.xavier_normal_(e,generator=g);nn.init.xavier_normal_(r,generator=g)
    return GraphDPOSharedTransE(e,r).to(device)


def train(model,triples,seed,protocol,device):
    rng=np.random.default_rng(seed);opt=torch.optim.Adam(model.parameters(),lr=protocol['lr'])
    facts=_graphdpo_facts(triples);trace=[];sync(device);start=time.perf_counter()
    for epoch in range(protocol['epochs']):
        order=rng.permutation(len(facts));loss_sum=0.
        for j in range(0,len(order),protocol['batch']):
            pos=facts[order[j:j+protocol['batch']]];opt.zero_grad(set_to_none=True)
            loss=_margin_batch(model,pos,model.entity.num_embeddings,protocol['negative_ratio'],protocol['margin'],rng,device)
            if not torch.isfinite(loss):raise FloatingPointError('Nonfinite training loss')
            loss.backward();opt.step();loss_sum+=float(loss.detach())*len(pos)
        sync(device);trace.append(dict(epoch=epoch+1,loss=loss_sum/len(facts),seconds=time.perf_counter()-start))
        print('train',seed,trace[-1],flush=True)
    return trace


@torch.no_grad()
def ranks(model,q,truth,candidates):
    device=next(model.parameters()).device;result=[]
    for side in ('head','tail'):
        values=[]
        for h,r,t in q:
            args=(h,r) if side=='tail' else (r,t)
            a,b=[torch.tensor([int(x)],device=device) for x in args]
            scores=torch.cat([model.score_candidates(side,a,b,torch.as_tensor(candidates[j:j+2048],device=device))[0] for j in range(0,len(candidates),2048)])
            if not torch.isfinite(scores).all():raise FloatingPointError('Nonfinite ranking score')
            target=int(t if side=='tail' else h);ix=int(np.searchsorted(candidates,target));value=scores[ix].clone()
            excluded=truth[side].get(tuple(map(int,args)),set())-{target}
            mask=np.isin(candidates,list(excluded));scores[torch.as_tensor(mask,device=device)]=-torch.inf
            scores[ix]=-torch.inf
            values.append(1+int((scores>value).sum())+.5*int((scores==value).sum()))
        result.append(values)
    return np.asarray(result,dtype=float)


def run(args):
    dataset,policy,fraction,seed=TASKS[args.task]
    protocol=dict(PROTOCOL)
    if args.smoke:protocol.update(dim=8,epochs=1,batch=64,local_epochs=1,random_repair_epochs=1,query_limit=8)
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
    out=args.out/f'task{args.task:02d}'
    out.mkdir(parents=True,exist_ok=False)
    if args.smoke:
        rng=np.random.default_rng(813);arr=np.c_[rng.integers(0,40,240),rng.integers(0,3,240),rng.integers(0,40,240)]
        T,V,E=arr[:200],arr[200:220],arr[220:];ne,nr=40,3;files={'synthetic':ah(arr)}
    else:
        paths=infer_paths(dataset,args.data_root)
        if not Path(paths[0]).exists() and dataset.startswith('CoDEx'):
            paths=tuple(args.data_root/dataset.lower()/(s+'.txt') for s in ('train','valid','test'))
        data=load_dataset(*paths);T,V,E=data.train.copy(),data.valid.copy(),data.test.copy()
        ne,nr=len(data.entities),len(data.relations);files={s:sha(p) for s,p in zip(('train','valid','test'),paths)}
    for a in (T,V,E):a[:,1]*=2
    fi,meta=select_forget(T,fraction,seed+int(fraction*10000),policy)
    U=T[fi];R=np.delete(T,fi,axis=0)
    candidates=np.unique(T[:,[0,2]]);supported_rel=np.unique(T[:,1])
    truth={'head':{},'tail':{}}
    for h,r,t in np.concatenate((T,V,E)):
        truth['tail'].setdefault((int(h),int(r)),set()).add(int(t))
        truth['head'].setdefault((int(r),int(t)),set()).add(int(h))
    rng=np.random.default_rng(protocol['query_seed']);queries={}
    for name,arr in [('test',E),('forgotten',U),('retained',R)]:
        arr=arr[np.isin(arr[:,0],candidates)&np.isin(arr[:,2],candidates)&np.isin(arr[:,1],supported_rel)]
        if not len(arr):raise ValueError('Empty supported query split')
        queries[name]=arr[np.sort(rng.choice(len(arr),min(len(arr),protocol['query_limit']),replace=False))]
    np.savez_compressed(out/'queries.npz',**queries,forget_indices=fi,candidates=candidates)
    start=time.perf_counter();rows=[];timings={}
    def record(label,model,seconds):
        before=time.perf_counter();payload={k+'_ranks':ranks(model,q,truth,candidates) for k,q in queries.items()}
        row=dict(label=label,update_seconds=seconds,**{k+'_mrr':float(np.mean(1/payload[k+'_ranks'])) for k in queries})
        rows.append(row);np.savez_compressed(out/f'{label}_predictions.npz',**payload)
        torch.save(model.state_dict(),out/f'{label}.pt')
        timings[label+'_evaluation_and_save_seconds']=time.perf_counter()-before
        (out/'raw.json').write_text(json.dumps(rows,indent=2)+'\n')
    base=fresh(ne,nr,seed,protocol['dim'],args.device)
    trace=train(base,T,seed,protocol,args.device);timings['base_training_seconds']=trace[-1]['seconds']
    (out/'Base_training.json').write_text(json.dumps(trace,indent=2));record('Unchanged',base,0.)
    selected=np.asarray(meta.get('entities',[]),dtype=np.int64)
    restarted,reset_seconds,_,_=deterministic_xavier_restart(base,R,selected,seed+700001+int(fraction*10000))
    record('ResetOnly',restarted,reset_seconds)
    kwargs=dict(train_forward=T,forget_idx=fi,n_entities=ne,epochs=protocol['local_epochs'],batch_size=protocol['batch'],lr=protocol['lr'],seed=seed,device=args.device,neg_ratio=protocol['negative_ratio'],margin=protocol['margin'])
    local,_=local_retrain_graphdpo_shared(base,**kwargs);record('Local',local.model,local.seconds)
    if policy=='entity':
        repaired,_=local_retrain_graphdpo_shared(restarted,**kwargs);record('ResetLocal',repaired.model,repaired.seconds+reset_seconds)
    else:
        for label,chosen in [('Endpoint',np.unique(U[:,[0,2]])),('StarCover',cost_aware_star_cover(U,R,ne))]:
            reset,seconds=restart_rows_all(base,chosen,seed+700001+int(fraction*10000),args.device)
            record(label+'ResetOnly',reset,seconds)
            model,repair_seconds,_=repair_from_retained_star(reset,R,chosen,ne,protocol['random_repair_epochs'],protocol['batch'],protocol['lr'],seed,args.device,protocol['negative_ratio'],protocol['margin'])
            record(label+'E3',model,seconds+repair_seconds)
    # References are trained after interventions; their parameters cannot affect updates.
    for label,s in [('Reference20',seed),('IndependentReference20',seed+70001)]:
        model=fresh(ne,nr,s,protocol['dim'],args.device);trace=train(model,R,s,protocol,args.device)
        timings[label+'_training_seconds']=trace[-1]['seconds'];(out/(label+'_training.json')).write_text(json.dumps(trace,indent=2))
        record(label,model,trace[-1]['seconds'])
    manifest=dict(dataset=dataset,policy=policy,fraction=fraction,seed=seed,task=args.task,smoke=args.smoke,protocol=protocol,
        files=files,forget_sha256=ah(fi),actual_fraction=len(U)/len(T),request=meta,timings=timings,
        elapsed_seconds=time.perf_counter()-start,source_sha256=sha(__file__),core_sha256=sha(Path(__file__).with_name('supportloss_transe_core.py')),
        python=platform.python_version(),numpy=np.__version__,torch=torch.__version__,device=args.device,
        input_checkpoints=[],query_sha256={k:ah(v) for k,v in queries.items()})
    (out/'COMPLETE.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('UNIFIED_COMPLETE',out,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--task',type=int,required=True,choices=range(36));p.add_argument('--out',type=Path,required=True)
    p.add_argument('--data-root',type=Path,required=True);p.add_argument('--device',default='cuda:0');p.add_argument('--smoke',action='store_true')
    run(p.parse_args())
