#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.family_models import DistMult
from schemacert.unlearn import affected_region


MODEL_FILES = {
    "candidate": "SchemaCert_plus_Restart_L5.pt",
    "refA": "RefA_FiniteRetrain20.pt",
    "refB": "RefB_IndependentRetrain20.pt",
}


def load_model(path: Path, ne: int, nr: int, device: str) -> DistMult:
    obj = torch.load(path, map_location="cpu", weights_only=False)
    state = obj["state_dict"] if isinstance(obj, dict) and "state_dict" in obj else obj
    dim = int(state["entity.weight"].shape[1])
    model = DistMult(ne, nr, dim)
    model.load_state_dict(state)
    model.to(device)
    model.eval()
    return model


def degree(triples: np.ndarray, ne: int) -> np.ndarray:
    d = np.zeros(ne, dtype=np.int64)
    np.add.at(d, triples[:, 0], 1)
    np.add.at(d, triples[:, 2], 1)
    return d


def matched_controls(
    selected_targets: np.ndarray,
    affected_entities: np.ndarray,
    original_degree: np.ndarray,
    rng: np.random.Generator,
) -> np.ndarray:
    ne = len(original_degree)
    blocked = np.zeros(ne, dtype=bool)
    blocked[np.asarray(affected_entities, dtype=np.int64)] = True
    eligible = np.flatnonzero(~blocked)
    if len(eligible) == 0:
        raise RuntimeError("No unaffected entities available for matched controls")

    # Randomize ties once, then sort by degree. Matching is unique when possible.
    perm = rng.permutation(eligible)
    edeg = original_degree[perm]
    order = np.argsort(edeg, kind="stable")
    eligible = perm[order]
    edeg = edeg[order]
    used: set[int] = set()
    out = []

    for target in selected_targets:
        d = int(original_degree[int(target)])
        pos = int(np.searchsorted(edeg, d))
        lo = max(0, pos - 128)
        hi = min(len(eligible), pos + 128)
        cand = eligible[lo:hi]
        if len(cand) == 0:
            cand = eligible
        cdeg = original_degree[cand]
        dist = np.abs(cdeg - d)
        ord2 = np.argsort(dist, kind="stable")
        chosen = None
        for j in ord2:
            e = int(cand[int(j)])
            if e not in used:
                chosen = e
                break
        if chosen is None:
            chosen = int(cand[int(ord2[0])])
        used.add(chosen)
        out.append(chosen)
    return np.asarray(out, dtype=np.int64)


def build_probe_contexts(
    side: str,
    pool: np.ndarray,
    selected_targets: np.ndarray,
    control_targets: np.ndarray,
    all_true: set[tuple[int, int, int]],
    rng: np.random.Generator,
) -> np.ndarray:
    out = np.empty((len(selected_targets), 2), dtype=np.int64)
    for i, (sel, ctl) in enumerate(zip(selected_targets, control_targets)):
        found = False
        for _ in range(50000):
            h, r, t = map(int, pool[int(rng.integers(0, len(pool)))])
            if int(sel) in (h, t) or int(ctl) in (h, t):
                continue
            if side == "tail":
                ts = (h, r, int(sel))
                tc = (h, r, int(ctl))
                ctx = (h, r)
            else:
                ts = (int(sel), r, t)
                tc = (int(ctl), r, t)
                ctx = (r, t)
            if ts not in all_true and tc not in all_true:
                out[i] = ctx
                found = True
                break
        if not found:
            raise RuntimeError(
                f"Could not find unrelated false context for side={side}, "
                f"selected={int(sel)}, control={int(ctl)}"
            )
    return out


@torch.no_grad()
def rank_targets(
    model: DistMult,
    side: str,
    contexts: np.ndarray,
    targets: np.ndarray,
    ne: int,
    device: str,
    batch: int,
    chunk: int,
) -> tuple[np.ndarray, np.ndarray]:
    ranks = []
    zscores = []
    cand_all = torch.arange(ne, dtype=torch.long, device=device)

    for st in range(0, len(contexts), batch):
        ctx = contexts[st:st + batch]
        tgt = targets[st:st + batch]
        B = len(ctx)

        if side == "tail":
            triples = np.c_[ctx[:, 0], ctx[:, 1], tgt]
            a = torch.as_tensor(ctx[:, 0], dtype=torch.long, device=device)
            b = torch.as_tensor(ctx[:, 1], dtype=torch.long, device=device)
        else:
            triples = np.c_[tgt, ctx[:, 0], ctx[:, 1]]
            a = torch.as_tensor(ctx[:, 0], dtype=torch.long, device=device)
            b = torch.as_tensor(ctx[:, 1], dtype=torch.long, device=device)

        xt = torch.as_tensor(triples, dtype=torch.long, device=device)
        true = model.score(xt).float()
        gt = torch.zeros(B, dtype=torch.long, device=device)
        eq = torch.zeros(B, dtype=torch.long, device=device)
        s1 = torch.zeros(B, dtype=torch.float64, device=device)
        s2 = torch.zeros(B, dtype=torch.float64, device=device)

        for cs in range(0, ne, chunk):
            ce = min(ne, cs + chunk)
            cand = cand_all[cs:ce]
            sc = model.score_candidates(side, a, b, cand).float()
            gt += (sc > true[:, None]).sum(1)
            eq += (sc == true[:, None]).sum(1)
            sc64 = sc.double()
            s1 += sc64.sum(1)
            s2 += (sc64 * sc64).sum(1)

        # Target itself contributes one equality. Mean-tie competitors exclude it.
        eq_comp = (eq - 1).clamp_min(0)
        rank = 1.0 + gt.double() + 0.5 * eq_comp.double()
        mean = s1 / float(ne)
        var = (s2 / float(ne) - mean * mean).clamp_min(1e-20)
        z = (true.double() - mean) / torch.sqrt(var)
        ranks.append(rank.cpu().numpy())
        zscores.append(z.cpu().numpy())

    return np.concatenate(ranks), np.concatenate(zscores)


def summarize(x: np.ndarray) -> dict:
    x = np.asarray(x, dtype=float)
    return {
        "n": int(len(x)),
        "mean": float(np.mean(x)),
        "median": float(np.median(x)),
        "q05": float(np.quantile(x, .05)),
        "q95": float(np.quantile(x, .95)),
    }


def process_cell(
    dataset: str,
    seed: int,
    mode_dir: Path,
    data,
    out: Path,
    device: str,
    n_probes: int,
    batch: int,
    chunk: int,
):
    summary_path = mode_dir / "summary.json"
    meta = json.loads(summary_path.read_text())
    audit = np.load(mode_dir / "mean_tie_rank_audit.npz", allow_pickle=False)
    fi = np.asarray(audit["forget_indices"], dtype=np.int64)
    selected = np.asarray(audit["selected_entities"], dtype=np.int64)

    keep = np.ones(len(data.train), dtype=bool)
    keep[fi] = False
    retain = data.train[keep]
    ae, ar, _, check_retain = affected_region(data.train, fi, 1)
    if not np.array_equal(retain, check_retain):
        raise RuntimeError("affected_region retained graph mismatch")

    retained_deg = degree(retain, len(data.entities))
    unsupported = selected[retained_deg[selected] == 0]
    if len(unsupported) == 0:
        raise RuntimeError(f"{mode_dir}: no unsupported selected entities")

    seed_material = f"{dataset}|{seed}|{meta['mode']}|{meta['request_hash']}|placement-v2"
    probe_seed = int.from_bytes(
        hashlib.sha256(seed_material.encode()).digest()[:8], "little"
    ) & 0x7fffffff
    rng = np.random.default_rng(probe_seed)

    n = min(int(n_probes), len(unsupported))
    selected_targets = np.sort(rng.choice(unsupported, n, replace=False))
    original_deg = degree(data.train, len(data.entities))
    controls = matched_controls(selected_targets, ae, original_deg, rng)

    # Background contexts are sampled from the retained graph.  On CoDEx-M
    # and NELL-995 the selected/affected region can cover almost the whole KG,
    # so requiring the context endpoints (or relation) to lie outside that
    # region makes the probe undefined for exactly the broad deletion requests
    # we need to audit.
    #
    # Identification instead comes from a matched within-context contrast:
    # every restarted zero-support target and its degree-matched unaffected
    # control are scored in the *same* retained context.  We then subtract the
    # candidate-vs-reference promotion of the matched control from that of the
    # restarted target.  Query-side/context shifts shared by both candidates
    # are therefore controlled by the difference-in-differences statistic.
    #
    # The inserted selected/control probe triples are still required to be
    # absent from train/valid/test by build_probe_contexts().
    pool = retain
    if len(pool) < 32:
        raise RuntimeError(
            f"{mode_dir}: retained graph unexpectedly has only {len(pool)} triples"
        )

    all_true_arr = np.concatenate([data.train, data.valid, data.test], axis=0)
    all_true = {tuple(map(int, x)) for x in all_true_arr}
    tail_ctx = build_probe_contexts(
        "tail", pool, selected_targets, controls, all_true, rng
    )
    head_ctx = build_probe_contexts(
        "head", pool, selected_targets, controls, all_true, rng
    )

    model_values = {}
    ne, nr = len(data.entities), len(data.relations)
    for label, fn in MODEL_FILES.items():
        path = mode_dir / fn
        if not path.is_file():
            raise FileNotFoundError(path)
        model = load_model(path, ne, nr, device)
        vals = {}
        for side, ctx in (("head", head_ctx), ("tail", tail_ctx)):
            sr, sz = rank_targets(
                model, side, ctx, selected_targets, ne, device, batch, chunk
            )
            cr, cz = rank_targets(
                model, side, ctx, controls, ne, device, batch, chunk
            )
            vals[side] = {
                "selected_rank": sr,
                "selected_z": sz,
                "control_rank": cr,
                "control_z": cz,
            }
        model_values[label] = vals
        del model
        if device.startswith("cuda"):
            torch.cuda.empty_cache()

    rows = []
    for side, ctx in (("head", head_ctx), ("tail", tail_ctx)):
        for i in range(n):
            row = {
                "dataset": dataset,
                "seed": seed,
                "mode": meta["mode"],
                "request_hash": meta["request_hash"],
                "side": side,
                "probe_id": i,
                "selected_target": int(selected_targets[i]),
                "control_target": int(controls[i]),
                "selected_original_degree": int(original_deg[selected_targets[i]]),
                "control_original_degree": int(original_deg[controls[i]]),
                "context_a": int(ctx[i, 0]),
                "context_b": int(ctx[i, 1]),
            }
            for label in MODEL_FILES:
                v = model_values[label][side]
                row[f"{label}_selected_rank"] = float(v["selected_rank"][i])
                row[f"{label}_selected_z"] = float(v["selected_z"][i])
                row[f"{label}_control_rank"] = float(v["control_rank"][i])
                row[f"{label}_control_z"] = float(v["control_z"][i])
            rows.append(row)

    def metric_arrays(kind: str):
        outm = {}
        for side in ("head", "tail"):
            c = model_values["candidate"][side]
            a = model_values["refA"][side]
            b = model_values["refB"][side]
            if kind == "selected":
                rc, ra, rb = c["selected_rank"], a["selected_rank"], b["selected_rank"]
                zc, za, zb = c["selected_z"], a["selected_z"], b["selected_z"]
            else:
                rc, ra, rb = c["control_rank"], a["control_rank"], b["control_rank"]
                zc, za, zb = c["control_z"], a["control_z"], b["control_z"]
            promo = .5 * (np.log10(ra) + np.log10(rb)) - np.log10(rc)
            zpromo = zc - .5 * (za + zb)
            outm[side] = {
                "promotion_logrank": promo,
                "promotion_z": zpromo,
                "candidate_rank": rc,
                "refA_rank": ra,
                "refB_rank": rb,
            }
        return outm

    selm = metric_arrays("selected")
    ctlm = metric_arrays("control")
    report = {
        "dataset": dataset,
        "seed": seed,
        "mode": meta["mode"],
        "request_hash": meta["request_hash"],
        "probe_seed": probe_seed,
        "selected_n": int(len(selected)),
        "unsupported_n": int(len(unsupported)),
        "probed_unsupported_n": int(n),
        "affected_entities_n": int(len(ae)),
        "affected_relations_n": int(len(ar)),
        "background_context_pool_n": int(len(pool)),
        "context_definition": (
            "true triples sampled from the retained graph. Restarted and "
            "degree-matched unaffected control targets are inserted into the "
            "identical context; both resulting probe triples must be absent "
            "from train/valid/test."
        ),
        "identification_strategy": (
            "difference-in-differences between restarted and matched unaffected "
            "targets in the same context; this controls query-side/context shifts "
            "shared by both candidates but is not a causal isolation of every "
            "updated parameter."
        ),
        "rank_definition": "unfiltered mean-tie rank among the full entity vocabulary",
        "control_definition": "unaffected entity matched approximately on original training degree",
        "sides": {},
    }

    for side in ("head", "tail"):
        sp = selm[side]["promotion_logrank"]
        cp = ctlm[side]["promotion_logrank"]
        did = sp - cp
        sz = selm[side]["promotion_z"]
        cz = ctlm[side]["promotion_z"]
        report["sides"][side] = {
            "selected_promotion_logrank": summarize(sp),
            "control_promotion_logrank": summarize(cp),
            "difference_in_differences_logrank": summarize(did),
            "selected_promotion_z": summarize(sz),
            "control_promotion_z": summarize(cz),
            "difference_in_differences_z": summarize(sz - cz),
            "selected_fraction_candidate_beats_both_refs": float(np.mean(
                selm[side]["candidate_rank"] < np.minimum(
                    selm[side]["refA_rank"], selm[side]["refB_rank"]
                )
            )),
            "control_fraction_candidate_beats_both_refs": float(np.mean(
                ctlm[side]["candidate_rank"] < np.minimum(
                    ctlm[side]["refA_rank"], ctlm[side]["refB_rank"]
                )
            )),
            "selected_candidate_top100_rate": float(np.mean(selm[side]["candidate_rank"] <= 100)),
            "selected_ref_center_top100_rate": float(.5 * (
                np.mean(selm[side]["refA_rank"] <= 100)
                + np.mean(selm[side]["refB_rank"] <= 100)
            )),
            "control_candidate_top100_rate": float(np.mean(ctlm[side]["candidate_rank"] <= 100)),
            "control_ref_center_top100_rate": float(.5 * (
                np.mean(ctlm[side]["refA_rank"] <= 100)
                + np.mean(ctlm[side]["refB_rank"] <= 100)
            )),
        }

    out.mkdir(parents=True, exist_ok=True)
    stem = f"{dataset}_s{seed}_{meta['mode']}_{meta['request_hash']}_placement"
    csv_path = out / f"{stem}.csv"
    json_path = out / f"{stem}.json"
    with csv_path.open("w", newline="", encoding="utf8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    json_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf8")

    print(
        "PLACEMENT_CELL_OK",
        dataset, seed, meta["mode"], meta["request_hash"],
        "unsupported", len(unsupported),
        "probes_per_side", n,
        "head_DID", report["sides"]["head"]["difference_in_differences_logrank"]["mean"],
        "tail_DID", report["sides"]["tail"]["difference_in_differences_logrank"]["mean"],
        flush=True,
    )


def main():
    ap = argparse.ArgumentParser(
        description="Probe broad candidate promotion of restarted entities on retained background contexts."
    )
    ap.add_argument("--dataset", required=True, choices=["FB15K-237", "CoDEx-M", "NELL-995"])
    ap.add_argument("--seed", required=True, type=int, choices=[17, 29, 43])
    ap.add_argument("--root", action="append", type=Path, required=True)
    ap.add_argument("--data-root", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--n-probes", type=int, default=256)
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--entity-chunk", type=int, default=4096)
    args = ap.parse_args()

    torch.set_num_threads(1)
    data = deterministic_holdout(
        load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17
    )

    dirs = []
    for root in args.root:
        base = root / args.dataset / f"seed{args.seed}"
        if not base.is_dir():
            continue
        for d in sorted(base.iterdir()):
            if d.is_dir() and (d / "summary.json").is_file():
                dirs.append(d)

    # The complete 36-cell design has four constructions per dataset/seed.
    by_mode = {}
    for d in dirs:
        meta = json.loads((d / "summary.json").read_text())
        mode = meta["mode"]
        if mode in by_mode:
            raise RuntimeError(f"Duplicate mode {mode}: {by_mode[mode]} and {d}")
        by_mode[mode] = d
    expected = {"fullstar-low", "fullstar-mid", "fullstar-high", "exact-card-high"}
    if set(by_mode) != expected:
        raise RuntimeError(
            f"{args.dataset} s{args.seed}: expected modes {sorted(expected)}, got {sorted(by_mode)}"
        )

    for mode in sorted(by_mode):
        process_cell(
            args.dataset, args.seed, by_mode[mode], data, args.out,
            args.device, args.n_probes, args.batch, args.entity_chunk
        )

    print("PLACEMENT_DATASET_SEED_OK", args.dataset, args.seed, flush=True)


if __name__ == "__main__":
    main()
