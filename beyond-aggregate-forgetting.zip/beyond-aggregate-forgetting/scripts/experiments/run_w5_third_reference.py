
#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.train import train_model
from scripts.run_publication_families import fresh
from scripts.experiments.rerun_w5_mean_tie import rank_both_f32, save_checkpoint
from scripts.experiments.run_entity_request_robustness import hsh


DATASETS = ("FB15K-237", "CoDEx-M", "NELL-995")
SEEDS = (17, 43)
MODES = ("fullstar-high", "exact-card-high")


def pair_metrics(a: np.ndarray, b: np.ndarray) -> dict[str, float]:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    if a.shape != b.shape:
        raise RuntimeError(f"Rank shape mismatch: {a.shape} vs {b.shape}")
    return {
        "mean_abs_log10_rank_gap": float(
            np.mean(np.abs(np.log10(a) - np.log10(b)))
        ),
        "mrr_gap": float(abs(np.mean(1.0 / a) - np.mean(1.0 / b))),
        "top10_membership_disagreement": float(
            np.mean((a <= 10) != (b <= 10))
        ),
        "top100_membership_disagreement": float(
            np.mean((a <= 100) != (b <= 100))
        ),
        "exact_rank_disagreement": float(np.mean(a != b)),
    }


def cat(z, label: str) -> np.ndarray:
    return np.concatenate([
        np.asarray(z[f"{label}_head_mean_tie_rank"], dtype=float),
        np.asarray(z[f"{label}_tail_mean_tie_rank"], dtype=float),
    ])


def find_cell(root: Path, dataset: str, seed: int, mode: str) -> Path:
    base = root / dataset / f"seed{seed}"
    hits = sorted(
        d for d in base.glob(f"{mode}_*")
        if d.is_dir()
        and (d / "summary.json").is_file()
        and (d / "mean_tie_rank_audit.npz").is_file()
    )
    if len(hits) != 1:
        raise RuntimeError(
            f"Expected exactly one W5 cell for {dataset} seed={seed} mode={mode}; "
            f"found {hits}"
        )
    return hits[0]


def main():
    p = argparse.ArgumentParser(
        description="Train RefC for one frozen W5 high-degree mean-tie cell."
    )
    p.add_argument("--dataset", required=True, choices=DATASETS)
    p.add_argument("--seed", required=True, type=int, choices=SEEDS)
    p.add_argument("--mode", required=True, choices=MODES)
    p.add_argument("--source-root", type=Path, required=True)
    p.add_argument("--data-root", type=Path, required=True)
    p.add_argument("--out-root", type=Path, required=True)
    p.add_argument("--device", default="cuda:0")
    p.add_argument("--dim", type=int, default=128)
    p.add_argument("--epochs", type=int, default=20)
    p.add_argument("--batch-size", type=int, default=4096)
    p.add_argument("--lr", type=float, default=.002)
    p.add_argument("--l2", type=float, default=1e-6)
    p.add_argument("--eval-batch", type=int, default=16)
    p.add_argument("--entity-chunk", type=int, default=4096)
    args = p.parse_args()

    frozen = (args.dim, args.epochs, args.batch_size, args.lr, args.l2)
    if frozen != (128, 20, 4096, .002, 1e-6):
        raise RuntimeError(
            "W10 protocol is frozen: expected d=128, epochs=20, batch=4096, "
            "lr=.002, l2=1e-6"
        )

    torch.set_num_threads(1)
    source = find_cell(args.source_root, args.dataset, args.seed, args.mode)
    meta = json.loads((source / "summary.json").read_text())
    z = np.load(source / "mean_tie_rank_audit.npz", allow_pickle=False)

    required = {
        "queries", "forget_indices",
        "candidate_head_mean_tie_rank", "candidate_tail_mean_tie_rank",
        "refA_head_mean_tie_rank", "refA_tail_mean_tie_rank",
        "refB_head_mean_tie_rank", "refB_tail_mean_tie_rank",
    }
    missing = sorted(required - set(z.files))
    if missing:
        raise RuntimeError(f"{source}: missing arrays {missing}")

    if meta["dataset"] != args.dataset or int(meta["seed"]) != args.seed:
        raise RuntimeError("Source metadata dataset/seed mismatch")
    if meta["mode"] != args.mode:
        raise RuntimeError("Source metadata mode mismatch")

    data = deterministic_holdout(
        load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17
    )
    fi = np.asarray(z["forget_indices"], dtype=np.int64)
    q = np.asarray(z["queries"], dtype=np.int64)
    if np.any(fi < 0) or np.any(fi >= len(data.train)):
        raise RuntimeError("Invalid forget_indices in source artifact")
    forget = data.train[fi]
    request_hash = hsh(forget)
    if request_hash != meta["request_hash"]:
        raise RuntimeError(
            f"HARD REQUEST HASH GATE FAILED: reconstructed={request_hash} "
            f"source={meta['request_hash']}"
        )

    # Every saved query must be a forgotten triple. Duplicate triples are allowed,
    # therefore membership rather than one-to-one row identity is the relevant gate.
    forget_set = {tuple(map(int, x)) for x in forget}
    if any(tuple(map(int, x)) not in forget_set for x in q):
        raise RuntimeError("Saved query cohort contains a triple outside the deletion request")

    keep = np.ones(len(data.train), dtype=bool)
    keep[fi] = False
    retain = data.train[keep]
    ne, nr = len(data.entities), len(data.relations)

    refc_seed = args.seed + 900003
    refc = fresh("distmult", ne, nr, args.dim, refc_seed, args.device)
    stats = train_model(
        refc,
        retain,
        ne,
        args.epochs,
        args.batch_size,
        args.lr,
        args.l2,
        refc_seed,
        args.device,
    )

    truth = (retain, data.valid, data.test, forget)
    ranks = rank_both_f32(
        refc,
        q,
        ne,
        truth,
        args.device,
        args.eval_batch,
        args.entity_chunk,
    )
    refc_head = np.asarray(ranks["head"]["mean_tie_rank"], dtype=float)
    refc_tail = np.asarray(ranks["tail"]["mean_tie_rank"], dtype=float)
    refc_all = np.concatenate([refc_head, refc_tail])

    candidate = cat(z, "candidate")
    refa = cat(z, "refA")
    refb = cat(z, "refB")
    if not (len(candidate) == len(refa) == len(refb) == len(refc_all)):
        raise RuntimeError(
            f"Rank length mismatch: C={len(candidate)} A={len(refa)} "
            f"B={len(refb)} Cref={len(refc_all)}"
        )

    pairs = {
        "candidate_vs_RefA": pair_metrics(candidate, refa),
        "candidate_vs_RefB": pair_metrics(candidate, refb),
        "candidate_vs_RefC": pair_metrics(candidate, refc_all),
        "RefB_vs_RefA": pair_metrics(refb, refa),
        "RefC_vs_RefA": pair_metrics(refc_all, refa),
        "RefC_vs_RefB": pair_metrics(refc_all, refb),
    }

    null_vals = [
        pairs["RefB_vs_RefA"]["mean_abs_log10_rank_gap"],
        pairs["RefC_vs_RefA"]["mean_abs_log10_rank_gap"],
        pairs["RefC_vs_RefB"]["mean_abs_log10_rank_gap"],
    ]
    cand_vals = [
        pairs["candidate_vs_RefA"]["mean_abs_log10_rank_gap"],
        pairs["candidate_vs_RefB"]["mean_abs_log10_rank_gap"],
        pairs["candidate_vs_RefC"]["mean_abs_log10_rank_gap"],
    ]

    out = (
        args.out_root / args.dataset / f"seed{args.seed}"
        / f"{args.mode}_{request_hash}"
    )
    out.mkdir(parents=True, exist_ok=True)

    save_checkpoint(
        out / "RefC_IndependentRetrain20.pt",
        refc,
        {
            "dataset": args.dataset,
            "seed": args.seed,
            "mode": args.mode,
            "request_hash": request_hash,
            "role": "reference_c",
            "reference_seed": refc_seed,
            "epochs": args.epochs,
            "train_seconds": stats.seconds,
        },
    )

    np.savez_compressed(
        out / "W10_THREE_REFERENCE_RANKS.npz",
        queries=q,
        candidate_head=np.asarray(z["candidate_head_mean_tie_rank"], dtype=np.float32),
        candidate_tail=np.asarray(z["candidate_tail_mean_tie_rank"], dtype=np.float32),
        refA_head=np.asarray(z["refA_head_mean_tie_rank"], dtype=np.float32),
        refA_tail=np.asarray(z["refA_tail_mean_tie_rank"], dtype=np.float32),
        refB_head=np.asarray(z["refB_head_mean_tie_rank"], dtype=np.float32),
        refB_tail=np.asarray(z["refB_tail_mean_tie_rank"], dtype=np.float32),
        refC_head=refc_head.astype(np.float32),
        refC_tail=refc_tail.astype(np.float32),
    )

    result = {
        "protocol": "w5-three-reference-null-v1",
        "dataset": args.dataset,
        "seed": int(args.seed),
        "mode": args.mode,
        "request_hash": request_hash,
        "source_cell": str(source),
        "queries": int(len(q)),
        "reference_seeds": {
            "RefA": int(meta["reference_seed_a"]),
            "RefB": int(meta["reference_seed_b"]),
            "RefC": int(refc_seed),
        },
        "RefC_training": {
            "dim": args.dim,
            "epochs": args.epochs,
            "batch_size": args.batch_size,
            "lr": args.lr,
            "l2": args.l2,
            "train_seconds": stats.seconds,
        },
        "pairs": pairs,
        "primary": {
            "reference_pair_mean_logrank": float(np.mean(null_vals)),
            "reference_pair_sd_logrank": float(np.std(null_vals, ddof=1)),
            "reference_pair_min_logrank": float(np.min(null_vals)),
            "reference_pair_max_logrank": float(np.max(null_vals)),
            "candidate_mean_logrank_to_references": float(np.mean(cand_vals)),
            "candidate_min_logrank_to_references": float(np.min(cand_vals)),
            "candidate_max_logrank_to_references": float(np.max(cand_vals)),
            "symmetrized_excess_mean": float(np.mean(cand_vals) - np.mean(null_vals)),
            "original_excess_RefA_RefB": float(
                pairs["candidate_vs_RefA"]["mean_abs_log10_rank_gap"]
                - pairs["RefB_vs_RefA"]["mean_abs_log10_rank_gap"]
            ),
        },
    }

    out_json = out / "W10_THREE_REFERENCE_SUMMARY.json"
    out_json.write_text(json.dumps(result, indent=2) + "\n")

    out_csv = out / "W10_THREE_REFERENCE_PAIRS.csv"
    with out_csv.open("w", newline="") as f:
        fields = [
            "pair", "mean_abs_log10_rank_gap", "mrr_gap",
            "top10_membership_disagreement", "top100_membership_disagreement",
            "exact_rank_disagreement",
        ]
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for pair, rec in pairs.items():
            w.writerow({"pair": pair, **rec})

    print(
        "W10_THREE_REFERENCE_CELL_OK",
        args.dataset,
        args.seed,
        args.mode,
        request_hash,
        f"null_mean={result['primary']['reference_pair_mean_logrank']:.10f}",
        f"null_sd={result['primary']['reference_pair_sd_logrank']:.10f}",
        f"candidate_mean={result['primary']['candidate_mean_logrank_to_references']:.10f}",
        f"sym_excess={result['primary']['symmetrized_excess_mean']:.10f}",
        flush=True,
    )


if __name__ == "__main__":
    main()
