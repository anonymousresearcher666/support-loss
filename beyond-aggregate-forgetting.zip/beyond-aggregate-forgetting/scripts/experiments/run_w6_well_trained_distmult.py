#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import csv
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.unlearn import affected_region
from scripts.run_publication_families import filter_maps, select_forget


class ReciprocalDistMult(nn.Module):
    def __init__(self, ne: int, nr: int, dim: int):
        super().__init__()
        self.ne, self.nr, self.dim = int(ne), int(nr), int(dim)
        self.entity = nn.Embedding(ne, dim)
        self.relation = nn.Embedding(2 * nr, dim)
        nn.init.xavier_uniform_(self.entity.weight)
        nn.init.xavier_uniform_(self.relation.weight)

    def score(self, x: torch.Tensor) -> torch.Tensor:
        return (
            self.entity(x[:, 0])
            * self.relation(x[:, 1])
            * self.entity(x[:, 2])
        ).sum(-1)

    def score_tail(self, h: torch.Tensor, r: torch.Tensor) -> torch.Tensor:
        q = self.entity(h) * self.relation(r)
        return q @ self.entity.weight.T

    def score_candidates(self, kind: str, a: torch.Tensor, b: torch.Tensor, cand: torch.Tensor):
        e = self.entity(cand)
        if kind == 'tail':
            return (self.entity(a) * self.relation(b)) @ e.T
        # Head ranking uses the reciprocal relation r+nr: (t,r_inv)->h.
        return (self.entity(b) * self.relation(a + self.nr)) @ e.T


def fresh(ne: int, nr: int, dim: int, seed: int, device: str):
    torch.manual_seed(seed)
    np.random.seed(seed)
    if device.startswith('cuda'):
        torch.cuda.manual_seed_all(seed)
    return ReciprocalDistMult(ne, nr, dim).to(device)


def make_pairs(triples: np.ndarray, nr: int) -> np.ndarray:
    x = np.asarray(triples, dtype=np.int64)
    fwd = x.copy()
    inv = x[:, [2, 1, 0]].copy()
    inv[:, 1] += nr
    return np.concatenate([fwd, inv], axis=0)


def query_groups(pairs: np.ndarray):
    order = np.lexsort((pairs[:, 1], pairs[:, 0]))
    p = pairs[order]
    groups = []
    st = 0
    while st < len(p):
        en = st + 1
        h, r = int(p[st, 0]), int(p[st, 1])
        while en < len(p) and int(p[en, 0]) == h and int(p[en, 1]) == r:
            en += 1
        groups.append((h, r, np.unique(p[st:en, 2]).astype(np.int64)))
        st = en
    return groups


@dataclass
class TrainResult:
    model: ReciprocalDistMult
    best_epoch: int
    best_val_mrr: float
    seconds: float
    history: list[dict]
    score_std: float


@torch.no_grad()
def filtered_ranks(model, queries, ne, nr, truths, device, max_queries=1000, seed=17,
                   batch=32, chunk=4096):
    rng = np.random.default_rng(seed)
    q = np.asarray(queries, dtype=np.int64)
    if max_queries and len(q) > max_queries:
        ids = np.sort(rng.choice(len(q), max_queries, replace=False))
        q = q[ids]
    tails, heads = filter_maps(*truths)
    cand_all = torch.arange(ne, dtype=torch.long, device=device)
    tranks, hranks = [], []
    model.eval()
    for st in range(0, len(q), batch):
        b = q[st:st+batch]
        bt = torch.as_tensor(b, dtype=torch.long, device=device)

        # tail
        true = model.score(bt)
        count = torch.zeros(len(b), dtype=torch.long, device=device)
        for cs in range(0, ne, chunk):
            ce = min(ne, cs + chunk)
            cand = cand_all[cs:ce]
            sc = model.score_candidates('tail', bt[:,0], bt[:,1], cand)
            for j,(h,r,t) in enumerate(b):
                for x in tails.get((int(h),int(r)),()):
                    if int(x) != int(t) and cs <= int(x) < ce:
                        sc[j,int(x)-cs] = -torch.inf
            count += (sc > true[:,None]).sum(1)
        tranks.extend((count+1).cpu().numpy().astype(float).tolist())

        # head, reciprocal score for the true triple.
        true_h = (
            model.entity(bt[:,2])
            * model.relation(bt[:,1] + nr)
            * model.entity(bt[:,0])
        ).sum(-1)
        count = torch.zeros(len(b), dtype=torch.long, device=device)
        for cs in range(0, ne, chunk):
            ce = min(ne, cs + chunk)
            cand = cand_all[cs:ce]
            sc = model.score_candidates('head', bt[:,1], bt[:,2], cand)
            for j,(h,r,t) in enumerate(b):
                for x in heads.get((int(r),int(t)),()):
                    if int(x) != int(h) and cs <= int(x) < ce:
                        sc[j,int(x)-cs] = -torch.inf
            count += (sc > true_h[:,None]).sum(1)
        eq = torch.zeros(len(b), dtype=torch.long, device=device)
        for cs in range(0, ne, chunk):
            ce = min(ne, cs + chunk)
            cand = cand_all[cs:ce]
            sc = model.score_candidates('head', bt[:,1], bt[:,2], cand)
            for j,(h,r,t) in enumerate(b):
                for x in heads.get((int(r),int(t)),()):
                    if int(x) != int(h) and cs <= int(x) < ce:
                        sc[j,int(x)-cs] = -torch.inf
            eq += torch.isclose(sc, true_h[:,None], rtol=1e-5, atol=1e-7).sum(1)
        rank = 1.0 + count.float() + 0.5 * (eq.float().clamp_min(1.0) - 1.0)
        hranks.extend(rank.cpu().numpy().astype(float).tolist())
    return np.r_[np.asarray(tranks), np.asarray(hranks)]


def mrr_from_ranks(r):
    r=np.asarray(r,dtype=float)
    return float(np.mean(1.0/r))


def one_n_softmax_loss(logits: torch.Tensor, target_ids: torch.Tensor) -> torch.Tensor:
    """Standard reciprocal 1-N softmax objective for one positive target per query."""
    return F.cross_entropy(logits, target_ids)


def train_1vsall(train, valid, ne, nr, dim, seed, device, *,
                 max_epochs=300, eval_every=10, patience=6, batch_size=256,
                 lr=1e-3, weight_decay=1e-6, label_smoothing=0.1,
                 val_queries=1500, init_model=None, masks=None):
    model = fresh(ne,nr,dim,seed,device) if init_model is None else copy.deepcopy(init_model).to(device)
    pairs = make_pairs(train,nr)
    opt = torch.optim.Adagrad(model.parameters(), lr=lr, weight_decay=weight_decay)
    rng = np.random.default_rng(seed)
    hooks=[]
    if masks:
        em, rm = masks
        emt=torch.as_tensor(em,dtype=model.entity.weight.dtype,device=device)
        rmt=torch.as_tensor(rm,dtype=model.relation.weight.dtype,device=device)
        hooks=[
            model.entity.weight.register_hook(lambda g,m=emt:g*m),
            model.relation.weight.register_hook(lambda g,m=rmt:g*m),
        ]
    best_state=None
    best=-1.0
    best_epoch=0
    stale=0
    history=[]
    stime=time.time()
    try:
        for epoch in range(1,max_epochs+1):
            model.train()
            order=rng.permutation(len(pairs))
            total=0.0
            seen=0
            for bst in range(0,len(order),batch_size):
                ids=order[bst:bst+batch_size]
                batchp=pairs[ids]
                ht=torch.as_tensor(batchp[:,0],dtype=torch.long,device=device)
                rt=torch.as_tensor(batchp[:,1],dtype=torch.long,device=device)
                tt=torch.as_tensor(batchp[:,2],dtype=torch.long,device=device)
                opt.zero_grad(set_to_none=True)
                logits=model.score_tail(ht,rt)
                loss=one_n_softmax_loss(logits,tt)
                loss.backward()
                opt.step()
                total += float(loss.detach())*len(ids)
                seen += len(ids)

            if epoch % eval_every == 0 or epoch == max_epochs:
                ranks=filtered_ranks(
                    model,valid,ne,nr,(train,valid),device,
                    max_queries=val_queries,seed=19092026,batch=32,chunk=4096
                )
                vmrr=mrr_from_ranks(ranks)
                rec={'epoch':epoch,'train_loss':total/max(seen,1),'val_mrr':vmrr}
                history.append(rec)
                print('VAL',json.dumps(rec),flush=True)
                if vmrr > best + 1e-5:
                    best=vmrr; best_epoch=epoch
                    best_state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
                    stale=0
                else:
                    stale += 1
                if stale >= patience:
                    break
    finally:
        for h in hooks: h.remove()
    if best_state is None:
        raise RuntimeError('No validation checkpoint selected')
    model.load_state_dict(best_state)
    model.eval()
    with torch.no_grad():
        probe = torch.as_tensor(train[:min(len(train),4096)], dtype=torch.long, device=device)
        score_std = float(model.score(probe).float().std().cpu())
    if not math.isfinite(score_std) or score_std < 1e-5:
        raise RuntimeError(f'Degenerate training: score_std={score_std}')
    if len(history) >= 2 and abs(history[-1]['train_loss'] - history[0]['train_loss']) < 1e-4:
        raise RuntimeError(
            f'Degenerate training: loss did not move ({history[0]["train_loss"]} -> {history[-1]["train_loss"]})'
        )
    return TrainResult(model,best_epoch,best,time.time()-stime,history,score_std)


def restart_zero_support(base, retain, selected, seed):
    out=copy.deepcopy(base)
    deg=np.zeros(base.ne,dtype=np.int64)
    np.add.at(deg,retain[:,0],1); np.add.at(deg,retain[:,2],1)
    ids=np.asarray([int(e) for e in selected if deg[int(e)]==0],dtype=np.int64)
    if len(ids):
        g=torch.Generator(device='cpu'); g.manual_seed(seed)
        freshw=torch.empty(out.entity.weight.shape,dtype=out.entity.weight.dtype,device='cpu')
        nn.init.xavier_uniform_(freshw,generator=g)
        with torch.no_grad():
            idx=torch.as_tensor(ids,dtype=torch.long,device=out.entity.weight.device)
            out.entity.weight[idx]=freshw[torch.as_tensor(ids,dtype=torch.long)].to(out.entity.weight.device)
    return out,ids


def repair_rl(base_restarted, train, forget_idx, ne, nr, seed, device, *,
              epochs=30,batch_size=256,lr=1e-3,weight_decay=1e-6,label_smoothing=0.1):
    ae, ar, boundary, retain = affected_region(train,forget_idx,1)
    inc=np.isin(retain[:,0],ae)|np.isin(retain[:,2],ae)
    local_idx=np.flatnonzero(inc)
    rng=np.random.default_rng(seed)
    extra_n=min(len(retain),max(len(local_idx)//2,4096))
    extra_idx=(rng.choice(len(retain),extra_n,replace=False)
               if len(retain)>extra_n else np.arange(len(retain),dtype=np.int64))
    work=retain[np.concatenate([local_idx,extra_idx])]

    em=np.zeros(tuple(base_restarted.entity.weight.shape),dtype=np.float32); em[ae]=1
    rm=np.zeros(tuple(base_restarted.relation.weight.shape),dtype=np.float32)
    rm[ar]=1; rm[ar+nr]=1

    # Fixed repair budget, no validation on forgotten data.
    model=copy.deepcopy(base_restarted).to(device)
    pairs=make_pairs(work,nr)
    # Keep the update strictly masked: optimizer-level weight decay would move
    # frozen rows even when their backprop gradient is zero.
    opt=torch.optim.Adagrad(model.parameters(),lr=lr,weight_decay=0.0)
    emt=torch.as_tensor(em,dtype=model.entity.weight.dtype,device=device)
    rmt=torch.as_tensor(rm,dtype=model.relation.weight.dtype,device=device)
    hooks=[
        model.entity.weight.register_hook(lambda g,m=emt:g*m),
        model.relation.weight.register_hook(lambda g,m=rmt:g*m),
    ]
    rng=np.random.default_rng(seed)
    try:
        for epoch in range(epochs):
            order=rng.permutation(len(pairs))
            for bst in range(0,len(order),batch_size):
                ids=order[bst:bst+batch_size]
                batchp=pairs[ids]
                ht=torch.as_tensor(batchp[:,0],dtype=torch.long,device=device)
                rt=torch.as_tensor(batchp[:,1],dtype=torch.long,device=device)
                tt=torch.as_tensor(batchp[:,2],dtype=torch.long,device=device)
                opt.zero_grad(set_to_none=True)
                loss=one_n_softmax_loss(model.score_tail(ht,rt),tt)
                loss.backward(); opt.step()
    finally:
        for h in hooks:h.remove()
    return model,retain,{
        'affected_entities':int(len(ae)),
        'affected_relations_forward':int(len(ar)),
        'local_triples':int(len(local_idx)),
        'work_unique_triples':int(len(np.unique(np.r_[local_idx,extra_idx]))),
        'parameter_fraction':float((em.sum()+rm.sum())/(em.size+rm.size)),
    }


def pair_metrics(a,b):
    a=np.asarray(a,dtype=float); b=np.asarray(b,dtype=float)
    return {
      'mrr_gap':float(abs(np.mean(1/a)-np.mean(1/b))),
      'mean_abs_log10_rank_gap':float(np.mean(np.abs(np.log10(a)-np.log10(b)))),
      'top10_membership_disagreement':float(np.mean((a<=10)!=(b<=10))),
      'top100_membership_disagreement':float(np.mean((a<=100)!=(b<=100))),
      'exact_rank_disagreement':float(np.mean(a!=b)),
    }


def eval_model(model,data,retain,forget,ne,nr,device,seed,max_test=2000,max_forget=1000):
    test_r=filtered_ranks(model,data.test,ne,nr,(retain,data.valid,data.test),device,max_test,seed)
    forget_r=filtered_ranks(model,forget,ne,nr,(retain,data.valid,data.test,forget),device,max_forget,seed)
    return test_r,forget_r


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--dataset',default='FB15K-237')
    p.add_argument('--data-root',default='data')
    p.add_argument('--device',default='cuda:0')
    p.add_argument('--dim',type=int,default=256)
    p.add_argument('--fraction',type=float,default=.10)
    p.add_argument('--request-seed',type=int,default=17)
    p.add_argument('--base-seed',type=int,default=17)
    p.add_argument('--ref-a-seed',type=int,default=101)
    p.add_argument('--ref-b-seed',type=int,default=202)
    p.add_argument('--max-epochs',type=int,default=300)
    p.add_argument('--eval-every',type=int,default=10)
    p.add_argument('--patience',type=int,default=6)
    p.add_argument('--batch-size',type=int,default=256)
    p.add_argument('--lr',type=float,default=0.1)
    p.add_argument('--weight-decay',type=float,default=1e-6)
    p.add_argument('--label-smoothing',type=float,default=.1)
    p.add_argument('--repair-epochs',type=int,default=30)
    p.add_argument('--min-test-mrr',type=float,default=.20)
    p.add_argument('--out',type=Path,required=True)
    args=p.parse_args()

    if args.dataset!='FB15K-237':
        raise ValueError('W6 is intentionally a single-setting FB15K-237 sanity check')
    torch.set_num_threads(1)
    data=deterministic_holdout(load_dataset(*infer_paths(args.dataset,args.data_root)),seed=17)
    ne,nr=len(data.entities),len(data.relations)
    fi,meta=select_forget(data.train,args.fraction,args.request_seed+int(args.fraction*10000),'entity')
    forget=data.train[fi]
    keep=np.ones(len(data.train),dtype=bool); keep[fi]=False
    retain=data.train[keep]
    selected=np.asarray(meta['entities'],dtype=np.int64)

    common=dict(max_epochs=args.max_epochs,eval_every=args.eval_every,patience=args.patience,
                batch_size=args.batch_size,lr=args.lr,weight_decay=args.weight_decay,
                label_smoothing=args.label_smoothing,val_queries=1500)

    print('TRAIN_BASE',flush=True)
    base=train_1vsall(data.train,data.valid,ne,nr,args.dim,args.base_seed,args.device,**common)
    print('TRAIN_REFA',flush=True)
    refa=train_1vsall(retain,data.valid,ne,nr,args.dim,args.ref_a_seed,args.device,**common)
    print('TRAIN_REFB',flush=True)
    refb=train_1vsall(retain,data.valid,ne,nr,args.dim,args.ref_b_seed,args.device,**common)

    restarted,zero_ids=restart_zero_support(base.model,retain,selected,args.request_seed+700001)
    rl,retain2,foot=repair_rl(
        restarted,data.train,fi,ne,nr,args.request_seed,args.device,
        epochs=args.repair_epochs,batch_size=args.batch_size,lr=args.lr,
        weight_decay=args.weight_decay,label_smoothing=args.label_smoothing
    )
    if not np.array_equal(retain,retain2):
        raise RuntimeError('Retained graph mismatch')

    eval_seed=19092026
    base_test=filtered_ranks(
        base.model,data.test,ne,nr,(data.train,data.valid,data.test),args.device,
        max_queries=2000,seed=eval_seed,batch=32,chunk=4096
    )
    rl_test,rl_forget=eval_model(rl,data,retain,forget,ne,nr,args.device,eval_seed)
    a_test,a_forget=eval_model(refa.model,data,retain,forget,ne,nr,args.device,eval_seed)
    b_test,b_forget=eval_model(refb.model,data,retain,forget,ne,nr,args.device,eval_seed)

    payload={
      'dataset':args.dataset,'model':'DistMult-reciprocal-1N-softmax','dim':args.dim,
      'training':{
        'max_epochs':args.max_epochs,'eval_every':args.eval_every,'patience':args.patience,
        'batch_size':args.batch_size,'lr':args.lr,'weight_decay':args.weight_decay,
        'label_smoothing':0.0,
      },
      'deletion':{
        'policy':'entity-complete-star','target_fraction':args.fraction,
        'forget_n':int(len(forget)),'actual_fraction':float(len(forget)/len(data.train)),
        'selected_entities':int(len(selected)),'zero_support_restarted':int(len(zero_ids)),
      },
      'fit':{
        'base':{'seed':args.base_seed,'best_epoch':base.best_epoch,'best_val_mrr':base.best_val_mrr,
                'test_mrr':mrr_from_ranks(base_test),'score_std':base.score_std},
        'refA':{'seed':args.ref_a_seed,'best_epoch':refa.best_epoch,'best_val_mrr':refa.best_val_mrr,
                'test_mrr':mrr_from_ranks(a_test),'score_std':refa.score_std},
        'refB':{'seed':args.ref_b_seed,'best_epoch':refb.best_epoch,'best_val_mrr':refb.best_val_mrr,
                'test_mrr':mrr_from_ranks(b_test),'score_std':refb.score_std},
        'RL':{'repair_epochs':args.repair_epochs,'test_mrr':mrr_from_ranks(rl_test),**foot},
      },
      'forgotten_mrr':{
        'RL':mrr_from_ranks(rl_forget),'RefA':mrr_from_ranks(a_forget),'RefB':mrr_from_ranks(b_forget),
      },
      'candidate_vs_refA':pair_metrics(rl_forget,a_forget),
      'null_refB_vs_refA':pair_metrics(b_forget,a_forget),
    }
    payload['calibrated']={
      'logrank_excess':payload['candidate_vs_refA']['mean_abs_log10_rank_gap']-
                       payload['null_refB_vs_refA']['mean_abs_log10_rank_gap'],
      'mrr_gap_excess':payload['candidate_vs_refA']['mrr_gap']-
                       payload['null_refB_vs_refA']['mrr_gap'],
      'top10_excess':payload['candidate_vs_refA']['top10_membership_disagreement']-
                     payload['null_refB_vs_refA']['top10_membership_disagreement'],
      'top100_excess':payload['candidate_vs_refA']['top100_membership_disagreement']-
                      payload['null_refB_vs_refA']['top100_membership_disagreement'],
    }
    vals=[payload['fit']['base']['test_mrr'],payload['fit']['refA']['test_mrr'],payload['fit']['refB']['test_mrr']]
    payload['well_trained_gate']={
      'threshold':args.min_test_mrr,
      'pass':bool(min(vals)>=args.min_test_mrr),
      'min_reference_or_base_test_mrr':float(min(vals)),
    }

    args.out.mkdir(parents=True,exist_ok=True)
    (args.out/'W6_WELL_TRAINED_DISTMULT.json').write_text(json.dumps(payload,indent=2)+'\n')
    with (args.out/'W6_training_history.csv').open('w',newline='') as f:
        rows=[]
        for label,res in [('base',base),('RefA',refa),('RefB',refb)]:
            for x in res.history: rows.append({'run':label,**x})
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

    print('=== W6 WELL-TRAINED DISTMULT SANITY CHECK ===')
    print(json.dumps(payload,indent=2,sort_keys=True))
    if not payload['well_trained_gate']['pass']:
        raise RuntimeError(
          f"Well-trained gate failed: min test MRR={payload['well_trained_gate']['min_reference_or_base_test_mrr']:.4f} "
          f"< {args.min_test_mrr:.4f}; do not use this run to close W6."
        )
    print('W6_WELL_TRAINED_DISTMULT_OK')


if __name__=='__main__':
    main()
