#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from scripts.run_publication_families import select_forget
from scripts.experiments.run_w6_well_trained_distmult import (
    mrr_from_ranks,
    pair_metrics,
)
from scripts.experiments.run_w7_stronger_training_grid import (
    filtered_ranks_mean_tie,
    request_hash,
    train_or_resume,
)


def main():
    p = argparse.ArgumentParser(
        description="Train one additional retained-data reference (RefC) for a completed W7 cell."
    )
    p.add_argument("--dataset", default="NELL-995", choices=["FB15K-237", "CoDEx-M", "NELL-995"])
    p.add_argument("--data-root", required=True)
    p.add_argument("--device", default="cuda:0")
    p.add_argument("--threads", type=int, default=1)
    p.add_argument("--dim", type=int, default=256)
    p.add_argument("--fraction", type=float, default=.10)
    p.add_argument("--request-seed", type=int, required=True)
    p.add_argument("--expected-request-hash", required=True)
    p.add_argument("--ref-c-seed", type=int, required=True)
    p.add_argument("--existing-cell", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--max-epochs", type=int, default=300)
    p.add_argument("--eval-every", type=int, default=10)
    p.add_argument("--patience", type=int, default=6)
    p.add_argument("--batch-size", type=int, default=256)
    p.add_argument("--lr", type=float, default=.1)
    p.add_argument("--weight-decay", type=float, default=1e-6)
    p.add_argument("--val-queries", type=int, default=1500)
    p.add_argument("--test-queries", type=int, default=2000)
    p.add_argument("--forget-queries", type=int, default=1000)
    args = p.parse_args()

    torch.set_num_threads(max(1, args.threads))
    try:
        torch.set_num_interop_threads(max(1, min(args.threads, 4)))
    except RuntimeError:
        pass

    jsons = sorted(args.existing_cell.glob("W7_STRONGER_TRAINING_*.json"))
    npzs = sorted(args.existing_cell.glob("W7_STRONGER_TRAINING_*_ranks.npz"))
    if len(jsons) != 1 or len(npzs) != 1:
        raise RuntimeError(
            f"Expected exactly one W7 JSON and one W7 ranks NPZ in {args.existing_cell}; "
            f"found json={len(jsons)} npz={len(npzs)}"
        )

    old = json.loads(jsons[0].read_text())
    z = np.load(npzs[0])
    rl = np.asarray(z["rl_forget"], dtype=float)
    ra = np.asarray(z["refA_forget"], dtype=float)
    rb = np.asarray(z["refB_forget"], dtype=float)

    if old["dataset"] != args.dataset:
        raise RuntimeError(f"Dataset mismatch: old={old['dataset']} cli={args.dataset}")
    if int(old["request_seed"]) != int(args.request_seed):
        raise RuntimeError(
            f"Request-seed mismatch: old={old['request_seed']} cli={args.request_seed}"
        )
    if old["request_hash"] != args.expected_request_hash:
        raise RuntimeError(
            f"Existing-cell hash mismatch: old={old['request_hash']} "
            f"expected={args.expected_request_hash}"
        )

    data = deterministic_holdout(
        load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17
    )
    ne, nr = len(data.entities), len(data.relations)

    fi, meta = select_forget(
        data.train,
        args.fraction,
        args.request_seed + int(args.fraction * 10000),
        "entity",
    )
    forget = data.train[fi]
    keep = np.ones(len(data.train), dtype=bool)
    keep[fi] = False
    retain = data.train[keep]
    rh = request_hash(forget)
    if rh != args.expected_request_hash:
        raise RuntimeError(
            f"HARD REQUEST HASH GATE FAILED: reconstructed={rh} "
            f"expected={args.expected_request_hash}"
        )

    args.out.mkdir(parents=True, exist_ok=True)
    common = dict(
        max_epochs=args.max_epochs,
        eval_every=args.eval_every,
        patience=args.patience,
        batch_size=args.batch_size,
        lr=args.lr,
        weight_decay=args.weight_decay,
        label_smoothing=0.0,
        val_queries=args.val_queries,
    )
    refc = train_or_resume(
        args.out / "refC_stage.pt", "refC", retain, data.valid,
        ne, nr, args.dim, args.ref_c_seed, args.device, common,
    )

    eval_seed = 19092026
    c_test = filtered_ranks_mean_tie(
        refc.model, data.test, ne, nr, (retain, data.valid, data.test),
        args.device, args.test_queries, eval_seed, batch=32, chunk=4096,
    )
    c_forget = filtered_ranks_mean_tie(
        refc.model, forget, ne, nr, (retain, data.valid, data.test, forget),
        args.device, args.forget_queries, eval_seed, batch=32, chunk=4096,
    )

    if not (len(rl) == len(ra) == len(rb) == len(c_forget)):
        raise RuntimeError(
            f"Rank-array length mismatch: RL={len(rl)} A={len(ra)} B={len(rb)} C={len(c_forget)}"
        )

    metrics = {
        "RL_vs_RefA": pair_metrics(rl, ra),
        "RefB_vs_RefA": pair_metrics(rb, ra),
        "RefC_vs_RefA": pair_metrics(c_forget, ra),
        "RefC_vs_RefB": pair_metrics(c_forget, rb),
        "RL_vs_RefC": pair_metrics(rl, c_forget),
    }
    d_rl_a = metrics["RL_vs_RefA"]["mean_abs_log10_rank_gap"]
    d_b_a = metrics["RefB_vs_RefA"]["mean_abs_log10_rank_gap"]
    d_c_a = metrics["RefC_vs_RefA"]["mean_abs_log10_rank_gap"]
    d_c_b = metrics["RefC_vs_RefB"]["mean_abs_log10_rank_gap"]

    result = {
        "dataset": args.dataset,
        "request_seed": args.request_seed,
        "request_hash": rh,
        "request_metadata": meta,
        "refA_seed": int(old["ref_a_seed"]),
        "refB_seed": int(old["ref_b_seed"]),
        "refC_seed": args.ref_c_seed,
        "protocol": old["protocol"],
        "refC_fit": {
            "best_epoch": refc.best_epoch,
            "best_val_mrr": refc.best_val_mrr,
            "test_mrr": mrr_from_ranks(c_test),
            "score_std": refc.score_std,
        },
        "distances": metrics,
        "primary": {
            "candidate_RL_to_RefA": d_rl_a,
            "RefB_to_RefA": d_b_a,
            "RefC_to_RefA": d_c_a,
            "RefC_to_RefB": d_c_b,
            "excess_vs_RefB_null": d_rl_a - d_b_a,
            "excess_vs_RefC_null": d_rl_a - d_c_a,
            "reference_pair_mean": float(np.mean([d_b_a, d_c_a, d_c_b])),
            "reference_pair_min": float(np.min([d_b_a, d_c_a, d_c_b])),
            "reference_pair_max": float(np.max([d_b_a, d_c_a, d_c_b])),
        },
        "conditioning": (
            "One additional RefC draw for the fixed NELL-995 seed29 retained graph; "
            "same evaluator/query sample as the original W7 cell."
        ),
    }

    out_json = args.out / "W7_REFC_PROBE_SUMMARY.json"
    out_json.write_text(json.dumps(result, indent=2) + "\n")

    out_csv = args.out / "W7_REFC_PROBE_DISTANCES.csv"
    with out_csv.open("w", newline="") as f:
        fields = [
            "pair", "mean_abs_log10_rank_gap", "mrr_gap",
            "top10_membership_disagreement", "top100_membership_disagreement",
            "exact_rank_disagreement",
        ]
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for pair, rec in metrics.items():
            w.writerow({"pair": pair, **rec})

    np.savez_compressed(
        args.out / "W7_REFC_PROBE_RANKS.npz",
        refC_forget=np.asarray(c_forget, dtype=np.float32),
        refC_test=np.asarray(c_test, dtype=np.float32),
    )

    print("=== W7 NELL REFC PROBE ===")
    print(
        f"dataset={args.dataset} request_hash={rh} "
        f"RefA_seed={old['ref_a_seed']} RefB_seed={old['ref_b_seed']} "
        f"RefC_seed={args.ref_c_seed}"
    )
    print(
        f"RefC best_epoch={refc.best_epoch} "
        f"best_val_mrr={refc.best_val_mrr:.10f} "
        f"test_mrr={mrr_from_ranks(c_test):.10f}"
    )
    print(f"RL_vs_RefA={d_rl_a:.10f}")
    print(f"RefB_vs_RefA={d_b_a:.10f}")
    print(f"RefC_vs_RefA={d_c_a:.10f}")
    print(f"RefC_vs_RefB={d_c_b:.10f}")
    print(f"excess_vs_RefB_null={d_rl_a-d_b_a:.10f}")
    print(f"excess_vs_RefC_null={d_rl_a-d_c_a:.10f}")
    print(
        "reference_pair_range="
        f"[{result['primary']['reference_pair_min']:.10f},"
        f"{result['primary']['reference_pair_max']:.10f}] "
        f"mean={result['primary']['reference_pair_mean']:.10f}"
    )
    print(f"json={out_json}")
    print(f"csv={out_csv}")
    print("W7_REFC_PROBE_OK")


if __name__ == "__main__":
    main()
