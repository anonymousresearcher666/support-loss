#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from scripts.run_publication_families import select_forget
from scripts.experiments.run_entity_request_robustness import degrees, fullstar_stratum
from scripts.experiments.run_w6_well_trained_distmult import (
    ReciprocalDistMult,
    TrainResult,
    filtered_ranks,
    mrr_from_ranks,
    pair_metrics,
    repair_rl,
    restart_zero_support,
    train_1vsall,
)


@torch.no_grad()
def filtered_ranks_mean_tie(model, queries, ne, nr, truths, device,
                            max_queries=1000, seed=17, batch=32, chunk=4096):
    """Exact mean-tie filtered ranks for both completion directions.

    Training/early stopping remains the historical W6 validation routine, but
    every reported W7 test/forgotten statistic uses this evaluator so it matches
    the mean-tie convention of the 36-cell primary audit.
    """
    from scripts.run_publication_families import filter_maps

    rng = np.random.default_rng(seed)
    q = np.asarray(queries, dtype=np.int64)
    if max_queries and len(q) > max_queries:
        ids = np.sort(rng.choice(len(q), max_queries, replace=False))
        q = q[ids]
    tails, heads = filter_maps(*truths)
    cand_all = torch.arange(ne, dtype=torch.long, device=device)
    tranks, hranks = [], []
    model.eval()

    for st in range(0, len(q), batch):
        b = q[st:st + batch]
        bt = torch.as_tensor(b, dtype=torch.long, device=device)

        true_t = model.score(bt)
        gt = torch.zeros(len(b), dtype=torch.long, device=device)
        eq = torch.zeros(len(b), dtype=torch.long, device=device)
        for cs in range(0, ne, chunk):
            ce = min(ne, cs + chunk)
            cand = cand_all[cs:ce]
            sc = model.score_candidates("tail", bt[:, 0], bt[:, 1], cand)
            for j, (h, r, t) in enumerate(b):
                for x in tails.get((int(h), int(r)), ()):
                    if int(x) != int(t) and cs <= int(x) < ce:
                        sc[j, int(x) - cs] = -torch.inf
            gt += (sc > true_t[:, None]).sum(1)
            eq += (sc == true_t[:, None]).sum(1)
        trank = 1.0 + gt.double() + 0.5 * (eq.double().clamp_min(1.0) - 1.0)
        tranks.extend(trank.cpu().numpy().astype(float).tolist())

        true_h = (
            model.entity(bt[:, 2])
            * model.relation(bt[:, 1] + nr)
            * model.entity(bt[:, 0])
        ).sum(-1)
        gt = torch.zeros(len(b), dtype=torch.long, device=device)
        eq = torch.zeros(len(b), dtype=torch.long, device=device)
        for cs in range(0, ne, chunk):
            ce = min(ne, cs + chunk)
            cand = cand_all[cs:ce]
            sc = model.score_candidates("head", bt[:, 1], bt[:, 2], cand)
            for j, (h, r, t) in enumerate(b):
                for x in heads.get((int(r), int(t)), ()):
                    if int(x) != int(h) and cs <= int(x) < ce:
                        sc[j, int(x) - cs] = -torch.inf
            gt += (sc > true_h[:, None]).sum(1)
            eq += (sc == true_h[:, None]).sum(1)
        hrank = 1.0 + gt.double() + 0.5 * (eq.double().clamp_min(1.0) - 1.0)
        hranks.extend(hrank.cpu().numpy().astype(float).tolist())

    return np.r_[np.asarray(tranks), np.asarray(hranks)]


def eval_model_mean_tie(model, data, retain, forget, ne, nr, device, seed,
                        max_test=2000, max_forget=1000):
    test_r = filtered_ranks_mean_tie(
        model, data.test, ne, nr, (retain, data.valid, data.test), device,
        max_test, seed, batch=32, chunk=4096,
    )
    forget_r = filtered_ranks_mean_tie(
        model, forget, ne, nr, (retain, data.valid, data.test, forget), device,
        max_forget, seed, batch=32, chunk=4096,
    )
    return test_r, forget_r


def request_hash(forget: np.ndarray) -> str:
    x = np.ascontiguousarray(forget, dtype=np.int64)
    return hashlib.sha256(x.tobytes()).hexdigest()[:16]


def save_fit(path: Path, result: TrainResult, seed: int, role: str) -> None:
    obj = {
        "role": role,
        "seed": int(seed),
        "best_epoch": int(result.best_epoch),
        "best_val_mrr": float(result.best_val_mrr),
        "seconds": float(result.seconds),
        "history": result.history,
        "score_std": float(result.score_std),
        "state_dict": {k: v.detach().cpu() for k, v in result.model.state_dict().items()},
    }
    torch.save(obj, path)


def load_fit(path: Path, ne: int, nr: int, dim: int, device: str) -> TrainResult:
    obj = torch.load(path, map_location="cpu", weights_only=False)
    model = ReciprocalDistMult(ne, nr, dim)
    model.load_state_dict(obj["state_dict"])
    model.to(device)
    model.eval()
    return TrainResult(
        model=model,
        best_epoch=int(obj["best_epoch"]),
        best_val_mrr=float(obj["best_val_mrr"]),
        seconds=float(obj["seconds"]),
        history=list(obj["history"]),
        score_std=float(obj["score_std"]),
    )


def train_or_resume(path: Path, role: str, train: np.ndarray, valid: np.ndarray,
                    ne: int, nr: int, dim: int, seed: int, device: str, common: dict) -> TrainResult:
    if path.is_file():
        print(f"RESUME_{role.upper()} {path}", flush=True)
        return load_fit(path, ne, nr, dim, device)
    print(f"TRAIN_{role.upper()}", flush=True)
    result = train_1vsall(train, valid, ne, nr, dim, seed, device, **common)
    save_fit(path, result, seed, role)
    print(
        f"SAVED_{role.upper()} best_epoch={result.best_epoch} "
        f"best_val_mrr={result.best_val_mrr:.6f} score_std={result.score_std:.6g}",
        flush=True,
    )
    return result


def main():
    p = argparse.ArgumentParser(
        description="Expanded stronger-training DistMult audit beyond the original FB15K-237 W6 cohort."
    )
    p.add_argument("--dataset", required=True, choices=["FB15K-237", "CoDEx-M", "NELL-995"])
    p.add_argument("--data-root", default="data")
    p.add_argument("--device", default="cuda:0")
    p.add_argument("--threads", type=int, default=1)
    p.add_argument("--dim", type=int, default=256)
    p.add_argument("--fraction", type=float, default=.10)
    p.add_argument("--request-mode", choices=["entity-deterministic", "fullstar-low", "fullstar-mid"], default="entity-deterministic")
    p.add_argument("--expected-request-hash", default=None, help="Optional hard gate for an archived request hash.")
    p.add_argument("--request-seed", type=int, required=True)
    p.add_argument("--base-seed", type=int, required=True)
    p.add_argument("--ref-a-seed", type=int, required=True)
    p.add_argument("--ref-b-seed", type=int, required=True)
    p.add_argument("--max-epochs", type=int, default=300)
    p.add_argument("--eval-every", type=int, default=10)
    p.add_argument("--patience", type=int, default=6)
    p.add_argument("--batch-size", type=int, default=256)
    p.add_argument("--lr", type=float, default=.1)
    p.add_argument("--weight-decay", type=float, default=1e-6)
    p.add_argument("--repair-epochs", type=int, default=30)
    p.add_argument("--val-queries", type=int, default=1500)
    p.add_argument("--test-queries", type=int, default=2000)
    p.add_argument("--forget-queries", type=int, default=1000)
    p.add_argument(
        "--min-test-mrr", type=float, default=-1.0,
        help="Optional descriptive guard only; <=0 disables it. Model selection remains validation-only."
    )
    p.add_argument("--out-root", type=Path, required=True)
    p.add_argument("--base-stage-from", type=Path, default=None, help="Reuse an already trained W7 base_stage.pt with the same dataset/seed/protocol.")
    args = p.parse_args()

    torch.set_num_threads(max(1, args.threads))
    try:
        torch.set_num_interop_threads(max(1, min(args.threads, 4)))
    except RuntimeError:
        pass
    data = deterministic_holdout(
        load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17
    )
    ne, nr = len(data.entities), len(data.relations)

    request_meta = {}
    construction_seed = None
    if args.request_mode == "entity-deterministic":
        fi, meta = select_forget(
            data.train,
            args.fraction,
            args.request_seed + int(args.fraction * 10000),
            "entity",
        )
        selected = np.asarray(meta["entities"], dtype=np.int64)
        request_meta = dict(meta)
    else:
        target_n = max(1, int(round(args.fraction * len(data.train))))
        stratum = "low" if args.request_mode == "fullstar-low" else "mid"
        seed_offset = 9001 if stratum == "low" else 9002
        construction_seed = args.request_seed + seed_offset
        fi, selected, request_meta = fullstar_stratum(
            data.train, degrees(data.train, ne), stratum, target_n, construction_seed
        )
        selected = np.asarray(selected, dtype=np.int64)

    forget = data.train[fi]
    keep = np.ones(len(data.train), dtype=bool)
    keep[fi] = False
    retain = data.train[keep]
    rh = request_hash(forget)
    if args.expected_request_hash is not None and rh != args.expected_request_hash:
        raise RuntimeError(
            f"HARD REQUEST HASH GATE FAILED: mode={args.request_mode} "
            f"computed={rh} expected={args.expected_request_hash}"
        )

    leaf = (
        f"req{args.request_seed}_{rh}"
        if args.request_mode == "entity-deterministic"
        else f"{args.request_mode}_req{args.request_seed}_{rh}"
    )
    cell = args.out_root / args.dataset / f"seed{args.base_seed}" / leaf
    cell.mkdir(parents=True, exist_ok=True)

    manifest = {
        "dataset": args.dataset,
        "base_seed": args.base_seed,
        "request_seed": args.request_seed,
        "ref_a_seed": args.ref_a_seed,
        "ref_b_seed": args.ref_b_seed,
        "request_hash": rh,
        "request_mode": args.request_mode,
        "request_construction_seed": construction_seed,
        "request_metadata": request_meta,
        "expected_request_hash": args.expected_request_hash,
        "fraction": args.fraction,
        "forget_n": int(len(forget)),
        "actual_fraction": float(len(forget) / len(data.train)),
        "selected_entities": int(len(selected)),
        "protocol": "reciprocal DistMult, 1-N softmax, d=256, Adagrad, validation early stopping",
        "device": args.device,
        "threads": args.threads,
        "base_stage_from": str(args.base_stage_from) if args.base_stage_from is not None else None,
    }
    (cell / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")

    common = dict(
        max_epochs=args.max_epochs,
        eval_every=args.eval_every,
        patience=args.patience,
        batch_size=args.batch_size,
        lr=args.lr,
        weight_decay=args.weight_decay,
        label_smoothing=0.0,
        val_queries=args.val_queries,
    )

    if args.base_stage_from is not None:
        base_obj = torch.load(args.base_stage_from, map_location="cpu", weights_only=False)
        if base_obj.get("role") != "base" or int(base_obj.get("seed", -1)) != int(args.base_seed):
            raise RuntimeError(
                f"Base-stage provenance mismatch: role={base_obj.get('role')} "
                f"seed={base_obj.get('seed')} expected_seed={args.base_seed}"
            )
        print(f"REUSE_BASE_STAGE {args.base_stage_from}", flush=True)
        base = load_fit(args.base_stage_from, ne, nr, args.dim, args.device)
    else:
        base = train_or_resume(
            cell / "base_stage.pt", "base", data.train, data.valid,
            ne, nr, args.dim, args.base_seed, args.device, common,
        )
    refa = train_or_resume(
        cell / "refA_stage.pt", "refA", retain, data.valid,
        ne, nr, args.dim, args.ref_a_seed, args.device, common,
    )
    refb = train_or_resume(
        cell / "refB_stage.pt", "refB", retain, data.valid,
        ne, nr, args.dim, args.ref_b_seed, args.device, common,
    )

    restarted, zero_ids = restart_zero_support(
        base.model, retain, selected, args.request_seed + 700001
    )
    rl, retain2, foot = repair_rl(
        restarted, data.train, fi, ne, nr, args.request_seed, args.device,
        epochs=args.repair_epochs,
        batch_size=args.batch_size,
        lr=args.lr,
        weight_decay=args.weight_decay,
        label_smoothing=0.0,
    )
    if not np.array_equal(retain, retain2):
        raise RuntimeError("Retained graph mismatch")

    eval_seed = 19092026
    base_test = filtered_ranks_mean_tie(
        base.model, data.test, ne, nr, (data.train, data.valid, data.test), args.device,
        max_queries=args.test_queries, seed=eval_seed, batch=32, chunk=4096,
    )
    rl_test, rl_forget = eval_model_mean_tie(
        rl, data, retain, forget, ne, nr, args.device, eval_seed,
        max_test=args.test_queries, max_forget=args.forget_queries,
    )
    a_test, a_forget = eval_model_mean_tie(
        refa.model, data, retain, forget, ne, nr, args.device, eval_seed,
        max_test=args.test_queries, max_forget=args.forget_queries,
    )
    b_test, b_forget = eval_model_mean_tie(
        refb.model, data, retain, forget, ne, nr, args.device, eval_seed,
        max_test=args.test_queries, max_forget=args.forget_queries,
    )

    payload = {
        **manifest,
        "model": "DistMult-reciprocal-1N-softmax",
        "dim": args.dim,
        "training": {
            "max_epochs": args.max_epochs,
            "eval_every": args.eval_every,
            "patience": args.patience,
            "batch_size": args.batch_size,
            "lr": args.lr,
            "weight_decay": args.weight_decay,
            "label_smoothing": 0.0,
            "val_queries": args.val_queries,
            "selection": "validation MRR only",
            "device": args.device,
            "threads": args.threads,
            "reported_rank_rule": "exact mean-tie in both head and tail completion",
        },
        "deletion": {
            "policy": "entity-complete-star" if args.request_mode == "entity-deterministic" else args.request_mode,
            "target_fraction": args.fraction,
            "forget_n": int(len(forget)),
            "actual_fraction": float(len(forget) / len(data.train)),
            "selected_entities": int(len(selected)),
            "zero_support_restarted": int(len(zero_ids)),
        },
        "fit": {
            "base": {
                "seed": args.base_seed,
                "best_epoch": base.best_epoch,
                "best_val_mrr": base.best_val_mrr,
                "test_mrr": mrr_from_ranks(base_test),
                "score_std": base.score_std,
            },
            "refA": {
                "seed": args.ref_a_seed,
                "best_epoch": refa.best_epoch,
                "best_val_mrr": refa.best_val_mrr,
                "test_mrr": mrr_from_ranks(a_test),
                "score_std": refa.score_std,
            },
            "refB": {
                "seed": args.ref_b_seed,
                "best_epoch": refb.best_epoch,
                "best_val_mrr": refb.best_val_mrr,
                "test_mrr": mrr_from_ranks(b_test),
                "score_std": refb.score_std,
            },
            "RL": {
                "repair_epochs": args.repair_epochs,
                "test_mrr": mrr_from_ranks(rl_test),
                **foot,
            },
        },
        "forgotten_mrr": {
            "RL": mrr_from_ranks(rl_forget),
            "RefA": mrr_from_ranks(a_forget),
            "RefB": mrr_from_ranks(b_forget),
        },
        "candidate_vs_refA": pair_metrics(rl_forget, a_forget),
        "null_refB_vs_refA": pair_metrics(b_forget, a_forget),
    }
    payload["calibrated"] = {
        "logrank_excess":
            payload["candidate_vs_refA"]["mean_abs_log10_rank_gap"]
            - payload["null_refB_vs_refA"]["mean_abs_log10_rank_gap"],
        "mrr_gap_excess":
            payload["candidate_vs_refA"]["mrr_gap"]
            - payload["null_refB_vs_refA"]["mrr_gap"],
        "top10_excess":
            payload["candidate_vs_refA"]["top10_membership_disagreement"]
            - payload["null_refB_vs_refA"]["top10_membership_disagreement"],
        "top100_excess":
            payload["candidate_vs_refA"]["top100_membership_disagreement"]
            - payload["null_refB_vs_refA"]["top100_membership_disagreement"],
    }

    val_ok = all(
        math.isfinite(float(payload["fit"][k]["best_val_mrr"]))
        and float(payload["fit"][k]["best_val_mrr"]) > 0
        for k in ("base", "refA", "refB")
    )
    payload["training_gate"] = {
        "validation_selected_non_degenerate": bool(val_ok),
        "optional_min_test_mrr": float(args.min_test_mrr),
        "optional_test_guard_pass": bool(
            args.min_test_mrr <= 0
            or min(
                payload["fit"]["base"]["test_mrr"],
                payload["fit"]["refA"]["test_mrr"],
                payload["fit"]["refB"]["test_mrr"],
            ) >= args.min_test_mrr
        ),
    }

    mode_tag = "" if args.request_mode == "entity-deterministic" else f"_{args.request_mode}"
    stem = f"W7_STRONGER_TRAINING_{args.dataset}{mode_tag}_s{args.base_seed}_req{args.request_seed}_{rh}"
    (cell / f"{stem}.json").write_text(json.dumps(payload, indent=2) + "\n")
    np.savez_compressed(
        cell / f"{stem}_ranks.npz",
        rl_forget=np.asarray(rl_forget, dtype=np.float32),
        refA_forget=np.asarray(a_forget, dtype=np.float32),
        refB_forget=np.asarray(b_forget, dtype=np.float32),
        rl_test=np.asarray(rl_test, dtype=np.float32),
        refA_test=np.asarray(a_test, dtype=np.float32),
        refB_test=np.asarray(b_test, dtype=np.float32),
    )

    with (cell / f"{stem}_training_history.csv").open("w", newline="") as f:
        rows = []
        for label, res in (("base", base), ("RefA", refa), ("RefB", refb)):
            for x in res.history:
                rows.append({"run": label, **x})
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

    print("=== W7 STRONGER-TRAINING CELL ===")
    print(json.dumps(payload, indent=2, sort_keys=True))
    if not payload["training_gate"]["validation_selected_non_degenerate"]:
        raise RuntimeError("Validation-selected stronger-training gate failed")
    if not payload["training_gate"]["optional_test_guard_pass"]:
        raise RuntimeError(
            "Optional test-MRR guard failed; result is saved but must not be promoted as a stronger-training cell."
        )
    print(
        "W7_STRONGER_TRAINING_CELL_OK",
        args.dataset,
        args.request_mode,
        args.base_seed,
        args.request_seed,
        rh,
        "logrank_excess",
        f"{payload['calibrated']['logrank_excess']:.10f}",
        flush=True,
    )


if __name__ == "__main__":
    main()
