#!/usr/bin/env python3
"""Select learning rate on original-data validation queries before unlearning.
No test or forgotten-query metric enters selection. Fixed 20-epoch budget.
"""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
import torch
import run_supportloss_cross_family as core

def main():
 p=argparse.ArgumentParser();p.add_argument('--data-root',type=Path,required=True);p.add_argument('--dataset',choices=['FB15K-237','CoDEx-M'],required=True);p.add_argument('--model',choices=['distmult','complex'],required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--device',default='cuda:0');a=p.parse_args()
 torch.set_num_threads(1);torch.use_deterministic_algorithms(True);torch.backends.cuda.matmul.allow_tf32=False
 if a.device.startswith('cuda') and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable')
 path=a.data_root/('FB15k-237' if a.dataset=='FB15K-237' else 'codex-m')
 if not path.exists() and a.dataset=='CoDEx-M':path=a.data_root/'codex/data/triples/codex-m'
 for split in ['train','valid','test']:
  if not (path/(split+'.txt')).is_file():raise FileNotFoundError(path/(split+'.txt'))
 d=core.load_dataset(path/'train.txt',path/'valid.txt',path/'test.txt')
 # Test participates only in the shared entity-ID vocabulary, not filtering or model selection.
 if not len(d.valid):raise ValueError('Validation split required')
 queries=d.valid[np.sort(np.random.default_rng(29092026).choice(len(d.valid),min(256,len(d.valid)),replace=False))]
 truth=core.filters(d.train,d.valid);core.DEVICE=a.device;core.FAMILY=a.model;core.NEGATIVE='balanced'
 out=a.out/a.dataset/a.model;out.mkdir(parents=True,exist_ok=False)
 np.save(out/'validation_queries.npy',queries);rows=[]
 for lr in [.0005,.001,.002]:
  for seed in [17,29,43]:
   m=core.fresh(len(d.entities),len(d.relations),seed);opt=torch.optim.Adam(m.parameters(),lr=lr);rng=np.random.default_rng(seed)
   for epoch in range(20):core.epoch(m,d.train,opt,rng,len(d.entities))
   vals=core.rank_queries(m,queries,truth)
   np.savez_compressed(out/f'lr{lr}_seed{seed}.npz',**vals)
   rows.append(dict(lr=lr,seed=seed,validation_mrr=float(np.mean(1/vals['ranks']))))
   (out/'selection_rows.json').write_text(json.dumps(rows,indent=2));print(rows[-1],flush=True)
 averages={lr:float(np.mean([r['validation_mrr'] for r in rows if r['lr']==lr])) for lr in [.0005,.001,.002]}
 # Smaller learning rate breaks exact ties, declared before unlearning outcomes.
 chosen=min(averages,key=lambda lr:(-averages[lr],lr))
 result=dict(dataset=a.dataset,model=a.model,selected_lr=chosen,epochs=20,seeds=[17,29,43],negative='balanced',grid_mean_validation_mrr=averages,query_hash=core.hash_array(queries),files={s:hashlib.sha256((path/(s+'.txt')).read_bytes()).hexdigest() for s in ['train','valid','test']},selection='mean original-data validation MRR; no test or deletion metrics; tie -> smaller lr')
 (out/'SELECTED.json').write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':main()
