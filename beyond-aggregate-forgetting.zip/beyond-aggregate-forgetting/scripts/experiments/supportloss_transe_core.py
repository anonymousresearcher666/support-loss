"""Pinned shared TransE operators used by the support-loss experiments.
Only dependency imports were reduced. Corruption retains the original exclusive upper bound.
The fresh end-to-end runner declares its training/checkpoint policy separately.
"""
from __future__ import annotations
from dataclasses import dataclass
import copy
import time
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F

@dataclass
class SharedLocalResult:
    model: nn.Module
    seconds: float
    affected_entities: np.ndarray
    affected_relations: np.ndarray
    boundary_entities: np.ndarray
    parameter_fraction: float
    local_triples: int
    work_triples: int
    work_unique_triples: int

class GraphDPOSharedTransE(nn.Module):
    """Trainable SchemaCert view of an official GraphDPO TransE checkpoint.

    The parameter tensors are copied exactly from GraphDPO. GraphDPO stores
    forward and inverse relations as adjacent rows. Scores use the same
    normalized L1 TransE geometry. The class exposes ``entity`` and ``relation``
    embeddings so SchemaCert can mask local updates without converting the
    checkpoint to another model family.
    """

    def __init__(self, entity_weight: torch.Tensor, relation_weight: torch.Tensor):
        super().__init__()
        if entity_weight.ndim != 2 or relation_weight.ndim != 2:
            raise ValueError('GraphDPO embedding tensors must be matrices')
        if entity_weight.shape[1] != relation_weight.shape[1]:
            raise ValueError('Entity/relation embedding dimensions differ')
        if relation_weight.shape[0] % 2:
            raise ValueError('GraphDPO relation table must contain forward/inverse pairs')
        self.entity = nn.Embedding(entity_weight.shape[0], entity_weight.shape[1]).double()
        self.relation = nn.Embedding(relation_weight.shape[0], relation_weight.shape[1]).double()
        with torch.no_grad():
            self.entity.weight.copy_(entity_weight.detach().to(dtype=torch.float64, device='cpu'))
            self.relation.weight.copy_(relation_weight.detach().to(dtype=torch.float64, device='cpu'))

    @staticmethod
    def _norm(x: torch.Tensor) -> torch.Tensor:
        return F.normalize(x, p=2, dim=-1)

    def normalize_(self) -> None:
        # Official GraphDPO normalizes inside score_fun/predict rather than
        # projecting the stored parameters after each optimizer step.
        return None

    def distance(self, x: torch.Tensor) -> torch.Tensor:
        h = self._norm(self.entity(x[:, 0]))
        r = self._norm(self.relation(x[:, 1]))
        t = self._norm(self.entity(x[:, 2]))
        return torch.linalg.vector_norm(h + r - t, ord=1, dim=-1)

    def score(self, x: torch.Tensor) -> torch.Tensor:
        return -self.distance(x)

    def score_candidates(
        self, kind: str, a: torch.Tensor, b: torch.Tensor, cand: torch.Tensor
    ) -> torch.Tensor:
        e = self._norm(self.entity(cand))
        if kind == 'tail':
            h = self._norm(self.entity(a))
            r = self._norm(self.relation(b))
            return -torch.linalg.vector_norm(
                (h + r)[:, None, :] - e[None, :, :], ord=1, dim=-1
            )
        if kind == 'head':
            # The common evaluator ranks the same forward triple score s(h,r,t)
            # for both head and tail prediction, so the true-score threshold and
            # candidate scores are exactly comparable for every method.
            r = self._norm(self.relation(a))
            t = self._norm(self.entity(b))
            return -torch.linalg.vector_norm(
                e[None, :, :] + r[:, None, :] - t[:, None, :], ord=1, dim=-1
            )
        raise KeyError(kind)

def clone_shared(model: GraphDPOSharedTransE) -> GraphDPOSharedTransE:
    return copy.deepcopy(model)

def retained_positive_degrees(retain: np.ndarray, entity_ids: np.ndarray) -> dict[int, int]:
    out: dict[int, int] = {}
    for e in entity_ids:
        e = int(e)
        out[e] = int(((retain[:, 0] == e) | (retain[:, 2] == e)).sum())
    return out

def deterministic_xavier_restart(
    model: GraphDPOSharedTransE,
    retain: np.ndarray,
    selected_entities: np.ndarray,
    seed: int,
) -> tuple[GraphDPOSharedTransE, float, np.ndarray, dict[int, int]]:
    """Restart zero-positive-support selected rows before the local update.

    The restart is deterministic and request/seed controlled. It is deliberately
    a pre-update warm start, matching the theory ordering; it does not use the
    deleted triples or the retrain reference.
    """
    deg = retained_positive_degrees(retain, selected_entities)
    unsupported = np.asarray(
        [int(e) for e in selected_entities if deg[int(e)] == 0], dtype=np.int64
    )
    out = clone_shared(model)
    st = time.time()
    if len(unsupported):
        g = torch.Generator(device='cpu')
        g.manual_seed(int(seed))
        fresh = torch.empty(
            out.entity.weight.shape,
            dtype=out.entity.weight.dtype,
            device='cpu',
        )
        nn.init.xavier_normal_(fresh, generator=g)
        idx_cpu = torch.as_tensor(unsupported, dtype=torch.long)
        idx_dev = idx_cpu.to(out.entity.weight.device)
        with torch.no_grad():
            out.entity.weight[idx_dev] = fresh[idx_cpu].to(out.entity.weight.device)
        if out.entity.weight.is_cuda:
            torch.cuda.synchronize()
    return out, time.time() - st, unsupported, deg

def _graphdpo_facts(forward: np.ndarray) -> np.ndarray:
    if len(forward) == 0:
        return np.empty((0, 3), dtype=np.int64)
    if np.any(forward[:, 1] % 2 != 0):
        raise ValueError('Expected forward GraphDPO relation IDs (even rows)')
    inv = forward.copy()
    inv[:, 0] = forward[:, 2]
    inv[:, 1] = forward[:, 1] + 1
    inv[:, 2] = forward[:, 0]
    return np.concatenate([forward, inv], axis=0)

def _margin_batch(
    model: GraphDPOSharedTransE,
    positives: np.ndarray,
    n_entities: int,
    neg_ratio: int,
    margin: float,
    rng: np.random.Generator,
    device: str,
) -> torch.Tensor:
    b = len(positives)
    if b == 0:
        raise ValueError('Empty positive batch')
    # Match the public GraphDPO corruption rule, including its high bound
    # ``ent_num - 1`` (the final entity id is therefore not sampled as noise).
    high = max(1, n_entities - 1)
    neg_h = rng.integers(0, high, size=(b, neg_ratio), dtype=np.int64)
    neg_t = rng.integers(0, high, size=(b, neg_ratio), dtype=np.int64)
    choose_tail = rng.random((b, neg_ratio)) > 0.5

    h = np.where(choose_tail, positives[:, 0, None], neg_h)
    t = np.where(choose_tail, neg_t, positives[:, 2, None])
    r = np.broadcast_to(positives[:, 1, None], (b, neg_ratio))
    negatives = np.stack([h, r, t], axis=-1).reshape(-1, 3)

    p = torch.as_tensor(positives, dtype=torch.long, device=device)
    n = torch.as_tensor(negatives, dtype=torch.long, device=device)
    p_dist = model.distance(p)
    n_dist = model.distance(n).reshape(b, neg_ratio).mean(dim=1)

    # Official TransE uses MarginRankingLoss(pos_dist, mean_neg_dist, y=-1,
    # reduction='sum') and then divides by the concatenated sample count.
    loss = torch.relu(p_dist - n_dist + float(margin)).sum()
    return loss / float(b * (1 + neg_ratio))

def local_retrain_graphdpo_shared(
    model: GraphDPOSharedTransE,
    train_forward: np.ndarray,
    forget_idx: np.ndarray,
    n_entities: int,
    hops: int = 1,
    epochs: int = 5,
    batch_size: int = 1024,
    lr: float = 1e-4,
    seed: int = 17,
    device: str = 'cpu',
    neg_ratio: int = 10,
    margin: float = 8.0,
) -> tuple[SharedLocalResult, np.ndarray]:
    """SchemaCert local update on the exact GraphDPO TransE parameterization.

    Locality/work-set selection is SchemaCert's. The optimization objective is
    GraphDPO-compatible TransE: forward+inverse facts, 10-way head/tail negative
    corruption, normalized L1 distance, margin loss, and Adam. Thus the base
    checkpoint and scoring family are shared; only the unlearning update rule
    differs across methods.
    """
    ae, ar_forward, boundary, retain = affected_region(train_forward, forget_idx, hops)
    m = clone_shared(model).to(device)
    st = time.time()

    inc = np.isin(retain[:, 0], ae) | np.isin(retain[:, 2], ae)
    local_idx = np.flatnonzero(inc)
    rng_work = np.random.default_rng(seed)
    extra_n = min(len(retain), max(len(local_idx) // 2, 4096))
    if len(retain) > extra_n:
        extra_idx = rng_work.choice(len(retain), extra_n, replace=False)
    else:
        extra_idx = np.arange(len(retain), dtype=np.int64)
    work_idx = np.concatenate([local_idx, extra_idx])
    work_forward = retain[work_idx]
    facts = _graphdpo_facts(work_forward)

    em = np.zeros(tuple(m.entity.weight.shape), dtype=np.float64)
    rm = np.zeros(tuple(m.relation.weight.shape), dtype=np.float64)
    em[ae] = 1.0
    ar_all = np.unique(np.concatenate([ar_forward, ar_forward + 1])).astype(np.int64)
    rm[ar_all] = 1.0

    hooks = [
        m.entity.weight.register_hook(
            lambda g, mask=torch.as_tensor(em, dtype=m.entity.weight.dtype, device=device): g * mask
        ),
        m.relation.weight.register_hook(
            lambda g, mask=torch.as_tensor(rm, dtype=m.relation.weight.dtype, device=device): g * mask
        ),
    ]
    opt = torch.optim.Adam(m.parameters(), lr=float(lr))
    rng = np.random.default_rng(seed)
    try:
        for _ in range(int(epochs)):
            order = rng.permutation(len(facts))
            for start in range(0, len(order), int(batch_size)):
                pos = facts[order[start:start + int(batch_size)]]
                opt.zero_grad(set_to_none=True)
                loss = _margin_batch(
                    m, pos, n_entities, int(neg_ratio), float(margin), rng, device
                )
                loss.backward()
                opt.step()
    finally:
        for hook in hooks:
            hook.remove()

    if m.entity.weight.is_cuda:
        torch.cuda.synchronize()
    total = m.entity.weight.numel() + m.relation.weight.numel()
    affected = float(em.sum() + rm.sum())
    result = SharedLocalResult(
        model=m,
        seconds=time.time() - st,
        affected_entities=ae,
        affected_relations=ar_all,
        boundary_entities=boundary,
        parameter_fraction=affected / float(total),
        local_triples=int(len(local_idx)),
        work_triples=int(len(work_idx)),
        work_unique_triples=int(len(np.union1d(local_idx, extra_idx))),
    )
    return result, retain

def affected_region(train, forget_idx, hops=1):
    f = train[forget_idx]
    ae = set(f[:, 0]) | set(f[:, 2])
    ar = set(f[:, 1])
    for _ in range(max(0, hops - 1)):
        # Topological expansion is entity-adjacency only.  A retained triple
        # enters the next hop when it shares a head/tail entity with the
        # current affected entity set; sharing only a relation is not enough.
        mask = np.isin(train[:, 0], list(ae)) | np.isin(train[:, 2], list(ae))
        x = train[mask]
        ae |= set(x[:, 0]) | set(x[:, 2])
        ar |= set(x[:, 1])
    retain = np.delete(train, forget_idx, axis=0)
    bm = np.isin(retain[:, 0], list(ae)) | np.isin(retain[:, 2], list(ae))
    b = retain[bm]
    boundary = np.unique(np.r_[b[:, 0], b[:, 2]]) if len(b) else np.array([], dtype=np.int64)
    return (
        np.array(sorted(ae), dtype=np.int64),
        np.array(sorted(ar), dtype=np.int64),
        boundary,
        retain,
    )

def select_forget(train, fraction, seed, policy='relation'):
    rng = np.random.default_rng(seed)
    if policy == 'relation':
        u, c = np.unique(train[:, 1], return_counts=True)
        rid = int(u[np.argmax(c)])
        cand = np.flatnonzero(train[:, 1] == rid)
        k = max(1, int(round(fraction * len(cand))))
        tails, counts = np.unique(train[cand, 2], return_counts=True)
        order = tails[np.argsort(-counts)]
        picked = []
        for t in order:
            x = cand[train[cand, 2] == t]
            if len(x) > 1:
                picked.extend(x.tolist())
            if len(picked) >= max(2, k // 3):
                break
        picked = list(dict.fromkeys(picked))[:min(k, max(2, k // 3))]
        s = set(picked)
        rem = np.asarray([int(i) for i in cand if int(i) not in s], dtype=np.int64)
        if len(picked) < k:
            picked += rng.choice(rem, k - len(picked), replace=False).tolist()
        return np.asarray(picked[:k], dtype=np.int64), {
            'policy': 'relation',
            'relation_id': rid,
            'candidates': len(cand),
        }
    if policy == 'random':
        k = max(1, int(round(fraction * len(train))))
        return np.sort(rng.choice(len(train), k, replace=False)), {
            'policy': 'random',
            'candidates': len(train),
        }
    if policy == 'entity':
        target = max(1, int(round(fraction * len(train))))
        ents = np.r_[train[:, 0], train[:, 2]]
        u, c = np.unique(ents, return_counts=True)
        order = u[np.argsort(-c)]
        chosen = []
        mask = np.zeros(len(train), bool)
        for e in order:
            chosen.append(int(e))
            mask |= (train[:, 0] == e) | (train[:, 2] == e)
            if int(mask.sum()) >= target:
                break
        return np.flatnonzero(mask), {
            'policy': 'entity',
            'entities': chosen,
            'candidates': len(train),
        }
    raise KeyError(policy)

def restart_rows_all(model, entity_ids: np.ndarray, seed: int, device: str):
    ids = np.asarray(sorted(set(map(int, entity_ids))), dtype=np.int64)
    out = clone_shared(model).to(device)
    st = time.time()
    if len(ids):
        g = torch.Generator(device="cpu")
        g.manual_seed(int(seed))
        fresh = torch.empty(
            out.entity.weight.shape,
            dtype=out.entity.weight.dtype,
            device="cpu",
        )
        nn.init.xavier_normal_(fresh, generator=g)
        idx_cpu = torch.as_tensor(ids, dtype=torch.long)
        idx_dev = idx_cpu.to(out.entity.weight.device)
        with torch.no_grad():
            out.entity.weight[idx_dev] = fresh[idx_cpu].to(out.entity.weight.device)
        if out.entity.weight.is_cuda:
            torch.cuda.synchronize()
    return out, time.time() - st

def retained_degrees(retain: np.ndarray, n_entities: int) -> np.ndarray:
    deg = np.zeros(int(n_entities), dtype=np.int64)
    if len(retain):
        np.add.at(deg, retain[:, 0], 1)
        np.add.at(deg, retain[:, 2], 1)
    return deg

def cost_aware_star_cover(forget: np.ndarray, retain: np.ndarray, n_entities: int) -> np.ndarray:
    """Deterministic low-cost vertex-cover heuristic for the forgotten edge set.

    Each forgotten triple is represented by its head/tail entity edge. For each
    edge we initially select the endpoint with lower retained degree, then prune
    redundant selected vertices from highest to lowest retained-degree cost.
    The result is guaranteed to cover every forgotten triple but is not claimed
    to be a minimum vertex cover.
    """
    if len(forget) == 0:
        return np.empty(0, dtype=np.int64)
    deg = retained_degrees(retain, n_entities)
    selected: set[int] = set()
    incident: dict[int, list[int]] = {}
    edges: list[tuple[int, int]] = []
    for i, (h, _, t) in enumerate(forget):
        h, t = int(h), int(t)
        edges.append((h, t))
        incident.setdefault(h, []).append(i)
        if t != h:
            incident.setdefault(t, []).append(i)
        if h == t:
            selected.add(h)
        elif deg[h] < deg[t]:
            selected.add(h)
        elif deg[t] < deg[h]:
            selected.add(t)
        else:
            selected.add(min(h, t))

    cover_count = np.zeros(len(edges), dtype=np.int16)
    for i, (h, t) in enumerate(edges):
        cover_count[i] = int(h in selected) + (int(t in selected) if t != h else 0)
        if cover_count[i] == 0:
            raise RuntimeError("Internal cover construction failure")

    for v in sorted(selected, key=lambda x: (int(deg[x]), x), reverse=True):
        inc = incident.get(v, [])
        if inc and all(int(cover_count[i]) >= 2 for i in inc):
            selected.remove(v)
            for i in inc:
                cover_count[i] -= 1

    if np.any(cover_count <= 0):
        raise RuntimeError("Pruned star cover does not cover all forgotten facts")
    return np.asarray(sorted(selected), dtype=np.int64)

def repair_from_retained_star(
    model,
    retain: np.ndarray,
    anchors: np.ndarray,
    n_entities: int,
    epochs: int,
    batch_size: int,
    lr: float,
    seed: int,
    device: str,
    neg_ratio: int,
    margin: float,
):
    anchors = np.asarray(sorted(set(map(int, anchors))), dtype=np.int64)
    m = clone_shared(model).to(device)
    mask = np.isin(retain[:, 0], anchors) | np.isin(retain[:, 2], anchors)
    repair_forward = retain[mask]
    facts = _graphdpo_facts(repair_forward)
    st = time.time()
    if len(facts) and len(anchors) and int(epochs) > 0:
        entity_mask = torch.zeros_like(m.entity.weight)
        entity_mask[torch.as_tensor(anchors, dtype=torch.long, device=device)] = 1.0
        hook = m.entity.weight.register_hook(lambda g, mk=entity_mask: g * mk)
        m.relation.weight.requires_grad_(False)
        opt = torch.optim.Adam([m.entity.weight], lr=float(lr))
        rng = np.random.default_rng(int(seed))
        try:
            for _ in range(int(epochs)):
                order = rng.permutation(len(facts))
                for start in range(0, len(order), int(batch_size)):
                    pos = facts[order[start:start + int(batch_size)]]
                    opt.zero_grad(set_to_none=True)
                    loss = _margin_batch(
                        m, pos, int(n_entities), int(neg_ratio), float(margin), rng, device
                    )
                    loss.backward()
                    opt.step()
        finally:
            hook.remove()
            m.relation.weight.requires_grad_(True)
    if m.entity.weight.is_cuda:
        torch.cuda.synchronize()
    return m, time.time() - st, int(len(repair_forward))

