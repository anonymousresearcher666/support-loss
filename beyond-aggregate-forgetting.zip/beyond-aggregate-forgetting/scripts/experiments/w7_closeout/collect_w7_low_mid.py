#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def main():
    p = argparse.ArgumentParser(
        description="Collect completed CoDEx-M stronger-training low/mid request cells into one CSV."
    )
    p.add_argument("--root", type=Path, required=True, help="w7_degree_request_followup_v1 root")
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()

    wanted = {
        "fullstar-low": "61623266c70e6d94",
        "fullstar-mid": "1e6ace2c11a8a0e8",
    }
    rows = []

    for mode, request_hash in wanted.items():
        matches = []
        for fp in args.root.rglob("W7_STRONGER_TRAINING_*.json"):
            try:
                d = json.loads(fp.read_text())
            except Exception:
                continue
            if (
                d.get("dataset") == "CoDEx-M"
                and d.get("request_mode") == mode
                and d.get("request_hash") == request_hash
            ):
                matches.append((fp, d))

        if len(matches) != 1:
            raise RuntimeError(
                f"Expected one {mode}/{request_hash} cell, found {len(matches)}"
            )

        fp, d = matches[0]
        row = {
            "dataset": d["dataset"],
            "request_mode": mode,
            "request_hash": request_hash,
            "base_seed": d["base_seed"],
            "request_seed": d["request_seed"],
            "target_fraction": d["deletion"]["target_fraction"],
            "forget_n": d["deletion"]["forget_n"],
            "actual_fraction": d["deletion"]["actual_fraction"],
            "selected_entities": d["deletion"]["selected_entities"],
            "zero_support_restarted": d["deletion"]["zero_support_restarted"],
            "candidate_logrank": d["candidate_vs_refA"]["mean_abs_log10_rank_gap"],
            "null_logrank": d["null_refB_vs_refA"]["mean_abs_log10_rank_gap"],
            "logrank_excess": d["calibrated"]["logrank_excess"],
            "candidate_mrr_gap": d["candidate_vs_refA"]["mrr_gap"],
            "null_mrr_gap": d["null_refB_vs_refA"]["mrr_gap"],
            "mrr_gap_excess": d["calibrated"]["mrr_gap_excess"],
            "candidate_top10": d["candidate_vs_refA"]["top10_membership_disagreement"],
            "null_top10": d["null_refB_vs_refA"]["top10_membership_disagreement"],
            "top10_excess": d["calibrated"]["top10_excess"],
            "candidate_top100": d["candidate_vs_refA"]["top100_membership_disagreement"],
            "null_top100": d["null_refB_vs_refA"]["top100_membership_disagreement"],
            "top100_excess": d["calibrated"]["top100_excess"],
            "base_test_mrr": d["fit"]["base"]["test_mrr"],
            "refA_test_mrr": d["fit"]["refA"]["test_mrr"],
            "refB_test_mrr": d["fit"]["refB"]["test_mrr"],
            "RL_test_mrr": d["fit"]["RL"]["test_mrr"],
            "affected_entities": d["fit"]["RL"]["affected_entities"],
            "affected_relations_forward": d["fit"]["RL"]["affected_relations_forward"],
            "local_triples": d["fit"]["RL"]["local_triples"],
            "work_unique_triples": d["fit"]["RL"]["work_unique_triples"],
            "parameter_fraction": d["fit"]["RL"]["parameter_fraction"],
            "source_json": str(fp),
        }
        rows.append(row)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

    print(args.out)
    print("W7_LOW_MID_COLLECT_OK")


if __name__ == "__main__":
    main()
