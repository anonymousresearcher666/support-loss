#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import numpy as np


def pair_metrics(a, b):
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    if a.shape != b.shape:
        raise RuntimeError(f"shape mismatch: {a.shape} vs {b.shape}")
    return {
        "mrr_gap": float(abs(np.mean(1 / a) - np.mean(1 / b))),
        "mean_abs_log10_rank_gap": float(np.mean(np.abs(np.log10(a) - np.log10(b)))),
        "top10_membership_disagreement": float(np.mean((a <= 10) != (b <= 10))),
        "top100_membership_disagreement": float(np.mean((a <= 100) != (b <= 100))),
        "exact_rank_disagreement": float(np.mean(a != b)),
    }


def one(paths, pattern):
    xs = sorted(paths.glob(pattern))
    if len(xs) != 1:
        raise RuntimeError(f"Expected exactly one {pattern} in {paths}; found {len(xs)}: {xs}")
    return xs[0]


def main():
    p = argparse.ArgumentParser(
        description=(
            "Extract the missing RL-vs-RefB metric for W7 NELL-995 seed29 "
            "and average candidate distances over RefA/B/C without retraining or forward passes."
        )
    )
    p.add_argument(
        "--existing-cell",
        type=Path,
        required=True,
        help="Original W7 NELL seed29 cell containing W7_STRONGER_TRAINING_*_ranks.npz and JSON",
    )
    p.add_argument(
        "--refc-dir",
        type=Path,
        required=True,
        help="Completed RefC probe directory containing W7_REFC_PROBE_RANKS.npz and summary JSON",
    )
    p.add_argument("--out-dir", type=Path, required=True)
    args = p.parse_args()

    w7_npz = one(args.existing_cell, "W7_STRONGER_TRAINING_*_ranks.npz")
    w7_json = one(args.existing_cell, "W7_STRONGER_TRAINING_*.json")
    refc_npz = args.refc_dir / "W7_REFC_PROBE_RANKS.npz"
    refc_json = args.refc_dir / "W7_REFC_PROBE_SUMMARY.json"
    if not refc_npz.is_file() or not refc_json.is_file():
        raise RuntimeError(f"Missing RefC files under {args.refc_dir}")

    old = json.loads(w7_json.read_text())
    rcj = json.loads(refc_json.read_text())

    if old["dataset"] != "NELL-995" or int(old["request_seed"]) != 29:
        raise RuntimeError(
            f"Expected NELL-995 request_seed=29, got {old['dataset']} seed={old['request_seed']}"
        )
    if old["request_hash"] != "895b0893f4dbd3f1":
        raise RuntimeError(f"Unexpected request hash: {old['request_hash']}")
    if rcj["request_hash"] != old["request_hash"]:
        raise RuntimeError("RefC request hash does not match original W7 cell")

    z = np.load(w7_npz)
    zc = np.load(refc_npz)
    rl = np.asarray(z["rl_forget"], dtype=float)
    a = np.asarray(z["refA_forget"], dtype=float)
    b = np.asarray(z["refB_forget"], dtype=float)
    c = np.asarray(zc["refC_forget"], dtype=float)

    if not (len(rl) == len(a) == len(b) == len(c)):
        raise RuntimeError(
            f"rank-array length mismatch RL={len(rl)} A={len(a)} B={len(b)} C={len(c)}"
        )

    metrics = {
        "RL_vs_RefA": pair_metrics(rl, a),
        "RL_vs_RefB": pair_metrics(rl, b),
        "RL_vs_RefC": pair_metrics(rl, c),
        "RefB_vs_RefA": pair_metrics(b, a),
        "RefC_vs_RefA": pair_metrics(c, a),
        "RefC_vs_RefB": pair_metrics(c, b),
    }

    cand = [
        metrics[x]["mean_abs_log10_rank_gap"]
        for x in ("RL_vs_RefA", "RL_vs_RefB", "RL_vs_RefC")
    ]
    refs = [
        metrics[x]["mean_abs_log10_rank_gap"]
        for x in ("RefB_vs_RefA", "RefC_vs_RefA", "RefC_vs_RefB")
    ]

    summary = {
        "dataset": "NELL-995",
        "request_seed": 29,
        "request_hash": old["request_hash"],
        "refA_seed": int(old["ref_a_seed"]),
        "refB_seed": int(old["ref_b_seed"]),
        "refC_seed": int(rcj["refC_seed"]),
        "n_rank_entries": int(len(rl)),
        "candidate_mean_logrank_over_A_B_C": float(np.mean(cand)),
        "candidate_min_logrank_over_A_B_C": float(np.min(cand)),
        "candidate_max_logrank_over_A_B_C": float(np.max(cand)),
        "reference_pair_mean_logrank": float(np.mean(refs)),
        "reference_pair_min_logrank": float(np.min(refs)),
        "reference_pair_max_logrank": float(np.max(refs)),
        "symmetrized_excess_mean": float(np.mean(cand) - np.mean(refs)),
        "note": (
            "Computed from saved rank arrays only; no retraining and no model forward pass required."
        ),
    }

    args.out_dir.mkdir(parents=True, exist_ok=True)

    out_csv = args.out_dir / "nell995_seed29_three_reference_distances.csv"
    fields = [
        "pair",
        "mean_abs_log10_rank_gap",
        "mrr_gap",
        "top10_membership_disagreement",
        "top100_membership_disagreement",
        "exact_rank_disagreement",
    ]
    with out_csv.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for pair, rec in metrics.items():
            w.writerow({"pair": pair, **rec})

    out_summary_csv = args.out_dir / "nell995_seed29_three_reference_summary.csv"
    with out_summary_csv.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(summary))
        w.writeheader()
        w.writerow(summary)

    out_json = args.out_dir / "nell995_seed29_three_reference_summary.json"
    out_json.write_text(json.dumps({"summary": summary, "distances": metrics}, indent=2) + "\n")

    print("RL_vs_RefB", json.dumps(metrics["RL_vs_RefB"], sort_keys=True))
    print(
        "candidate_mean_logrank_over_A_B_C",
        f"{summary['candidate_mean_logrank_over_A_B_C']:.10f}",
    )
    print(
        "reference_pair_mean_logrank",
        f"{summary['reference_pair_mean_logrank']:.10f}",
    )
    print(
        "symmetrized_excess_mean",
        f"{summary['symmetrized_excess_mean']:.10f}",
    )
    print("csv", out_csv)
    print("summary_csv", out_summary_csv)
    print("json", out_json)
    print("W7_NELL29_THREE_REFERENCE_OK")


if __name__ == "__main__":
    main()
