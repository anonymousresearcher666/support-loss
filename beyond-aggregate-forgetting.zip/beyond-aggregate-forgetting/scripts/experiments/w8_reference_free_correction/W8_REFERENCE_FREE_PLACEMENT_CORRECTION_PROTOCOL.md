# W8 pre-registered protocol: reference-free placement correction

Status: FROZEN BEFORE ANY W8 RESULT IS INSPECTED.

## Scientific question

Does the broad candidate-placement shift identified by the 36-cell matched probe account for a substantial part of the calibrated rank-fidelity gap?

The intervention must be deployable without retraining access. RefA, RefB, any other retained-data retrain, validation/test triples, forgotten evaluation queries, and placement-probe evaluation contexts are forbidden when estimating the correction.

References are used only after the correction has been frozen, for evaluation with the existing W5 protocol.

## Variant A only

We run exactly two pre-declared post-hoc candidate-score corrections:

- A-median
- A-mean

No hyperparameter search is performed.

### Allowed information

The correction may use:

- the updated R+L DistMult model;
- the retained training graph;
- the deletion request (equivalently retained graph + deleted request metadata);
- a deterministic random seed.

It may not use:

- RefA, RefB, RefC, or any retraining model/output;
- validation or test triples for estimating the correction;
- W5 forgotten evaluation queries;
- placement-probe evaluation contexts;
- evaluation metrics for tuning.

### Fixed constants

- B = 200 retained-training background triples per cell.
- K = 20 supported, unaffected controls per restarted entity.
- background seed = SHA256(dataset, seed, request_mode, request_hash, "placement-cal-v1").
- control tie seed = SHA256(dataset, seed, request_mode, request_hash, "placement-controls-v1").
- delta rules = median and mean only.

Because a restarted zero-support entity has retained degree zero, every retained training triple is automatically non-incident to that entity. The same fixed set of B retained background triples is therefore used for all restarted entities within a cell.

Controls are supported, unaffected entities matched approximately on PRE-DELETION degree, using the same degree concept as the existing placement probe. This degree is reconstructible from retained training triples plus the deletion request and therefore does not require a retraining oracle.

### Correction

For each restarted entity v and each retained background tail context q=(h,r), compute the candidate score s(q,v). Let C_v be K matched controls and let center_q(C_v) be the median or mean of their scores in the same context.

Median rule:

delta_v = median_q [ s(q,v) - median_{c in C_v} s(q,c) ].

Mean rule:

delta_v = mean_q [ s(q,v) - mean_{c in C_v} s(q,c) ].

At evaluation time the correction is candidate-side only:

s_corr(q,v) = s(q,v) - delta_v

for restarted entities v, and s_corr(q,e)=s(q,e) for every other candidate e.

The same entity delta is applied when the entity is a head or tail candidate. Context embeddings are never changed.

### Bitwise invariance gate

Before evaluation, the implementation must verify that scores for non-restarted candidate entities are bitwise identical before and after the correction on a deterministic sample of calibration contexts. A failed gate aborts the cell.

## Evaluation

Use the same 36 W5 cells, exact 1,000 forgotten queries, saved RefA/RefB ranks, float32 scoring, full candidate vocabulary, filtering semantics, and mean-tie rule.

For each corrected model report:

- candidate log-rank gap;
- null log-rank gap;
- signed calibrated log-rank excess;
- signed MRR excess;
- signed Top-10 excess;
- signed Top-100 excess;
- forgotten MRR gap to RefA;
- corrected test MRR;
- change in test MRR from the uncorrected R+L model on the same fixed test-query sample;
- placement DID using the exact pre-existing placement-probe contexts;
- number of restarted entities.

Test utility is evaluated on a deterministic sample of up to 1,000 TEST queries, seed 19092026, for both uncorrected and corrected R+L. This test set is not read until AFTER delta is fixed.

The placement DID is evaluated only after delta is fixed, by reusing the already-frozen probe contexts and reference ranks. Those contexts are never used to estimate delta.

## Aggregation

- 36 cells, equal cell weight.
- 10,000 bootstrap replicates.
- forgotten-query head/tail directions stay paired within query.
- fixed-cell conditional intervals, as in the W5 audit.
- report signed excess values. NEVER report |excess|.
- placement DID bootstrap resamples matched probe rows within cell.
- test-MRR bootstrap resamples the fixed test queries within cell.
- aggregate point estimates are equal-weight means over cells.

## Success criteria fixed before results

Baseline values motivating the thresholds:

- W5 log-rank excess = +0.2561088.
- placement DID = +0.6182.
- W5 forgotten-MRR gap for R+L = approximately 0.0070.

FULL SUCCESS for a rule requires ALL:

1. signed aggregate log-rank excess <= +0.1280544 (at least 50% reduction);
2. |aggregate placement DID| <= 0.3091 (at least 50% reduction in placement-shift magnitude);
3. aggregate corrected-minus-baseline test MRR >= -0.005;
4. aggregate forgotten-MRR gap <= 0.010.

PARTIAL SUCCESS:

- placement DID decreases materially but log-rank excess remains > +0.1280544, while utility constraints remain acceptable.

FAILURE:

- test-MRR change < -0.005, or no material movement in the targeted mechanism/rank gap.

Negative calibrated log-rank excess is reported with its sign and is not converted to an absolute value.

## Variant B

Variant B is NOT run initially. It may be considered only after Variant A results are fully recorded. If run later, lambda values must be pre-declared and all reported; no best-lambda selection is allowed.
