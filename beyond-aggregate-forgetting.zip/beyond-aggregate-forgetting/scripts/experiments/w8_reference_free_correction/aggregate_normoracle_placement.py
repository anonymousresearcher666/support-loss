#!/usr/bin/env python3
"""Aggregate NormOracle placement contrast over the exact 36-cell probe cohort."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import numpy as np

DATASETS=("FB15K-237","CoDEx-M","NELL-995")
MODES=("fullstar-low","fullstar-mid","fullstar-high","exact-card-high")


def summarize(cells):
    b=float(np.mean([c["baseline_placement_did"] for c in cells]))
    o=float(np.mean([c["oracle_placement_did"] for c in cells]))
    return {
        "cells":len(cells),
        "baseline_placement_did":b,
        "oracle_placement_did":o,
        "absolute_reduction_to_zero":float(1-abs(o)/abs(b)) if b!=0 else None,
        "positive_oracle_cells":int(sum(c["oracle_placement_did"]>0 for c in cells)),
        "negative_oracle_cells":int(sum(c["oracle_placement_did"]<0 for c in cells)),
    }


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",type=Path,required=True)
    ap.add_argument("--out",type=Path,required=True)
    ap.add_argument("--n-boot",type=int,default=10000)
    ap.add_argument("--seed",type=int,default=25092026)
    args=ap.parse_args()

    files=sorted(args.root.glob("*_NORMORACLE_PLACEMENT.json"))
    if len(files)!=36:
        raise RuntimeError(f"Expected 36 NormOracle placement JSONs, found {len(files)}")
    cells=[json.loads(p.read_text()) for p in files]

    result={
        "overall":summarize(cells),
        "by_dataset":{},
        "by_construction":{},
        "bootstrap":{},
    }
    for ds in DATASETS:
        cc=[c for c in cells if c["dataset"]==ds]
        result["by_dataset"][ds]=summarize(cc)
    for m in MODES:
        cc=[c for c in cells if c["request_mode"]==m]
        result["by_construction"][m]=summarize(cc)

    vals=[]
    for p in files:
        z=np.load(p.with_suffix(".npz"),allow_pickle=False)
        vals.append(np.asarray(z["placement_did_values"],dtype=float))

    rng=np.random.default_rng(args.seed)
    odist=np.empty(args.n_boot,float)
    for i in range(args.n_boot):
        acc=0.0
        for v in vals:
            ids=rng.integers(0,len(v),size=len(v))
            acc+=float(np.mean(v[ids]))
        odist[i]=acc/len(vals)

    result["bootstrap"]={
        "oracle_placement_did_ci95":[
            float(np.quantile(odist,.025)),
            float(np.quantile(odist,.975)),
        ],
        "n_boot":args.n_boot,
        "seed":args.seed,
    }

    args.out.mkdir(parents=True,exist_ok=True)
    outp=args.out/"NORMORACLE_PLACEMENT_SUMMARY.json"
    outp.write_text(json.dumps(result,indent=2)+"\n")

    x=result["overall"]
    print("=== NORMORACLE PLACEMENT CONTRAST ===")
    print(f"baseline={x['baseline_placement_did']:.10f}")
    print(f"oracle={x['oracle_placement_did']:.10f}")
    print(f"absolute reduction to zero={100*x['absolute_reduction_to_zero']:.2f}%")
    print(f"oracle positive/negative cells={x['positive_oracle_cells']}/{x['negative_oracle_cells']}")
    lo,hi=result["bootstrap"]["oracle_placement_did_ci95"]
    print(f"oracle CI95=[{lo:.10f},{hi:.10f}]")
    print("[BY_DATASET]")
    for ds,q in result["by_dataset"].items():
        print(ds,f"baseline={q['baseline_placement_did']:.10f}",f"oracle={q['oracle_placement_did']:.10f}")
    print("[BY_CONSTRUCTION]")
    for m,q in result["by_construction"].items():
        print(m,f"baseline={q['baseline_placement_did']:.10f}",f"oracle={q['oracle_placement_did']:.10f}")
    print(outp)
    print("NORMORACLE_PLACEMENT_AGGREGATE_OK")


if __name__=="__main__":
    main()
