#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,json
from pathlib import Path
import numpy as np

RULES=("median","mean")
MODES=("fullstar-low","fullstar-mid","fullstar-high","exact-card-high")
DATASETS=("FB15K-237","CoDEx-M","NELL-995")

def mean(xs): return float(np.mean(np.asarray(xs,float)))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",type=Path,required=True)
    ap.add_argument("--out",type=Path,required=True)
    args=ap.parse_args()
    files=sorted(args.root.glob("*_W12.json"))
    if len(files)!=36:
        raise RuntimeError(f"Expected 36 W12 cell JSONs, found {len(files)}")
    cells=[json.loads(p.read_text()) for p in files]

    def E(c,label,rule=None):
        if label=="R+L": return c["R+L"]["logrank_excess"]
        if label=="NormOracle": return c["NormOracle"]["logrank_excess"]
        if label=="RFPC":
            return c["RFPC_historical"][rule]["logrank_excess"]
        if label=="Both":
            return c["NormOracle_plus_RFPC_refit"][rule]["logrank_excess"]
        raise KeyError(label)

    out={"cells":36,"overall":{},"by_dataset":{},"by_construction":{}}
    e0=mean([E(c,"R+L") for c in cells])
    en=mean([E(c,"NormOracle") for c in cells])
    out["overall"]["baseline_excess"]=e0
    out["overall"]["norm_excess"]=en
    out["overall"]["scale_reduction"]=float(1-en/e0)
    out["overall"]["rules"]={}
    for r in RULES:
        er=mean([E(c,"RFPC",r) for c in cells])
        eb=mean([E(c,"Both",r) for c in cells])
        out["overall"]["rules"][r]={
            "rfpc_excess":er,
            "both_excess":eb,
            "rfpc_reduction":float(1-er/e0),
            "additional_rfpc_after_scale":float((en-eb)/en),
            "both_total_reduction":float(1-eb/e0),
            "cells_additional_positive":int(sum(E(c,"Both",r)<E(c,"NormOracle") for c in cells)),
        }

    for ds in DATASETS:
        cc=[c for c in cells if c["dataset"]==ds]
        b=mean([E(c,"R+L") for c in cc]);n=mean([E(c,"NormOracle") for c in cc])
        rec={"cells":len(cc),"baseline_excess":b,"norm_excess":n,"scale_reduction":float(1-n/b),"rules":{}}
        for r in RULES:
            rr=mean([E(c,"RFPC",r) for c in cc]);bb=mean([E(c,"Both",r) for c in cc])
            rec["rules"][r]={
                "rfpc_excess":rr,"both_excess":bb,
                "rfpc_reduction":float(1-rr/b),
                "additional_rfpc_after_scale":float((n-bb)/n) if n!=0 else None,
                "both_total_reduction":float(1-bb/b),
            }
        out["by_dataset"][ds]=rec

    for m in MODES:
        cc=[c for c in cells if c["request_mode"]==m]
        b=mean([E(c,"R+L") for c in cc]);n=mean([E(c,"NormOracle") for c in cc])
        rec={"cells":len(cc),"baseline_excess":b,"norm_excess":n,"scale_reduction":float(1-n/b),"rules":{}}
        for r in RULES:
            rr=mean([E(c,"RFPC",r) for c in cc]);bb=mean([E(c,"Both",r) for c in cc])
            rec["rules"][r]={
                "rfpc_excess":rr,"both_excess":bb,
                "rfpc_reduction":float(1-rr/b),
                "additional_rfpc_after_scale":float((n-bb)/n) if n!=0 else None,
                "both_total_reduction":float(1-bb/b),
            }
        out["by_construction"][m]=rec

    args.out.mkdir(parents=True,exist_ok=True)
    (args.out/"W12_SCALE_RFPC_SUMMARY.json").write_text(json.dumps(out,indent=2)+"\n")

    rows=[]
    for c in cells:
        for r in RULES:
            rows.append({
                "dataset":c["dataset"],"seed":c["seed"],"request_mode":c["request_mode"],
                "request_hash":c["request_hash"],"rule":r,
                "baseline_excess":E(c,"R+L"),"norm_excess":E(c,"NormOracle"),
                "rfpc_excess":E(c,"RFPC",r),"both_excess":E(c,"Both",r),
                "scale_reduction":c["decomposition"]["R_scale"],
                "rfpc_reduction":c["decomposition"][f"{r}_R_rfpc"],
                "additional_rfpc_after_scale":c["decomposition"][f"{r}_R_rfpc_given_scale"],
            })
    with (args.out/"W12_SCALE_RFPC_CELLS.csv").open("w",newline="",encoding="utf8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()));w.writeheader();w.writerows(rows)

    print("=== W12 SCALE vs RFPC ===")
    print(f"R+L excess={e0:.10f}")
    print(f"NormOracle excess={en:.10f} scale reduction={100*out['overall']['scale_reduction']:.2f}%")
    for r in RULES:
        x=out["overall"]["rules"][r]
        print(
            r,
            f"RFPC={x['rfpc_excess']:.10f} ({100*x['rfpc_reduction']:.2f}% reduction)",
            f"Norm+RFPC={x['both_excess']:.10f}",
            f"additional-after-scale={100*x['additional_rfpc_after_scale']:.2f}%",
            f"total={100*x['both_total_reduction']:.2f}%",
            f"additional-positive={x['cells_additional_positive']}/36",
        )
    print(args.out/"W12_SCALE_RFPC_SUMMARY.json")
    print("W12_AGGREGATE_OK")

if __name__=="__main__":
    main()
