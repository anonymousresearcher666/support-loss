#!/usr/bin/env python3
"""Aggregate W13 placement contrast over the exact 36-cell probe cohort."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import numpy as np

DATASETS=("FB15K-237","CoDEx-M","NELL-995")
MODES=("fullstar-low","fullstar-mid","fullstar-high","exact-card-high")


def summarize(cells):
    b=float(np.mean([c["baseline_placement_did"] for c in cells]))
    w=float(np.mean([c["w13_placement_did"] for c in cells]))
    return {
        "cells":len(cells),
        "baseline_placement_did":b,
        "w13_placement_did":w,
        "absolute_reduction_to_zero":float(1-abs(w)/abs(b)) if b!=0 else None,
        "positive_w13_cells":int(sum(c["w13_placement_did"]>0 for c in cells)),
        "negative_w13_cells":int(sum(c["w13_placement_did"]<0 for c in cells)),
    }


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",type=Path,required=True)
    ap.add_argument("--out",type=Path,required=True)
    ap.add_argument("--n-boot",type=int,default=10000)
    ap.add_argument("--seed",type=int,default=25092026)
    args=ap.parse_args()

    files=sorted(args.root.glob("*_W13_PLACEMENT.json"))
    if len(files)!=36:
        raise RuntimeError(f"Expected 36 W13 placement JSONs, found {len(files)}")
    cells=[json.loads(p.read_text()) for p in files]

    result={
        "overall":summarize(cells),
        "by_dataset":{},
        "by_construction":{},
        "bootstrap":{},
    }
    for ds in DATASETS:
        cc=[c for c in cells if c["dataset"]==ds]
        result["by_dataset"][ds]=summarize(cc)
    for m in MODES:
        cc=[c for c in cells if c["request_mode"]==m]
        result["by_construction"][m]=summarize(cc)

    vals=[]
    for p in files:
        z=np.load(p.with_suffix(".npz"),allow_pickle=False)
        vals.append(np.asarray(z["placement_did_values"],dtype=float))

    rng=np.random.default_rng(args.seed)
    bdist=np.empty(args.n_boot,float)
    wdist=np.empty(args.n_boot,float)
    for i in range(args.n_boot):
        bacc=0.0;wacc=0.0
        for c,v in zip(cells,vals):
            ids=rng.integers(0,len(v),size=len(v))
            # baseline per-cell mean is fixed from canonical probe rows; bootstrap
            # the W13 per-probe values and use the saved canonical baseline mean.
            wacc+=float(np.mean(v[ids]))
            bacc+=float(c["baseline_placement_did"])
        wdist[i]=wacc/len(cells)
        bdist[i]=bacc/len(cells)

    result["bootstrap"]={
        "w13_placement_did_ci95":[float(np.quantile(wdist,.025)),float(np.quantile(wdist,.975))],
        "baseline_placement_did":float(np.mean(bdist)),
        "n_boot":args.n_boot,
        "seed":args.seed,
    }

    args.out.mkdir(parents=True,exist_ok=True)
    outp=args.out/"W13_PLACEMENT_SUMMARY.json"
    outp.write_text(json.dumps(result,indent=2)+"\n")

    x=result["overall"]
    print("=== W13 PLACEMENT CONTRAST ===")
    print(f"baseline={x['baseline_placement_did']:.10f}")
    print(f"W13={x['w13_placement_did']:.10f}")
    print(f"absolute reduction to zero={100*x['absolute_reduction_to_zero']:.2f}%")
    print(f"W13 positive/negative cells={x['positive_w13_cells']}/{x['negative_w13_cells']}")
    lo,hi=result["bootstrap"]["w13_placement_did_ci95"]
    print(f"W13 CI95=[{lo:.10f},{hi:.10f}]")
    print("[BY_DATASET]")
    for ds,q in result["by_dataset"].items():
        print(ds,f"baseline={q['baseline_placement_did']:.10f}",f"W13={q['w13_placement_did']:.10f}")
    print("[BY_CONSTRUCTION]")
    for m,q in result["by_construction"].items():
        print(m,f"baseline={q['baseline_placement_did']:.10f}",f"W13={q['w13_placement_did']:.10f}")
    print(outp)
    print("W13_PLACEMENT_AGGREGATE_OK")


if __name__=="__main__":
    main()
