#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import numpy as np

DATASETS=("FB15K-237","CoDEx-M","NELL-995")
MODES=("fullstar-low","fullstar-mid","fullstar-high","exact-card-high")

def mean(xs):
    return float(np.mean(np.asarray(xs,float)))

def summarize(cells):
    e0=mean([c["R+L"]["logrank_excess"] for c in cells])
    eo=mean([c["NormOracle_evaluation_only"]["logrank_excess"] for c in cells])
    er=mean([c["RetainedNormMedian"]["logrank_excess"] for c in cells])
    oracle_gain=e0-eo
    rf_gain=e0-er
    return {
        "cells":len(cells),
        "baseline_excess":e0,
        "reference_free_excess":er,
        "oracle_excess":eo,
        "reference_free_reduction":float(1-er/e0) if e0!=0 else None,
        "oracle_reduction":float(1-eo/e0) if e0!=0 else None,
        "fraction_oracle_gain_recovered":float(rf_gain/oracle_gain) if oracle_gain!=0 else None,
        "absolute_gap_to_oracle":float(er-eo),
        "positive_reference_free_excess_cells":int(sum(c["RetainedNormMedian"]["logrank_excess"]>0 for c in cells)),
        "mean_forgotten_mrr_gap":mean([c["RetainedNormMedian"]["candidate_mrr_gap"] for c in cells]),
        "mean_null_mrr_gap":mean([c["RetainedNormMedian"]["null_mrr_gap"] for c in cells]),
        "mean_mrr_excess":mean([c["RetainedNormMedian"]["mrr_excess"] for c in cells]),
        "mean_top10_excess":mean([c["RetainedNormMedian"]["top10_excess"] for c in cells]),
        "mean_top100_excess":mean([c["RetainedNormMedian"]["top100_excess"] for c in cells]),
        "cells_better_than_baseline":int(sum(c["RetainedNormMedian"]["logrank_excess"]<c["R+L"]["logrank_excess"] for c in cells)),
        "cells_better_or_equal_oracle":int(sum(c["RetainedNormMedian"]["logrank_excess"]<=c["NormOracle_evaluation_only"]["logrank_excess"] for c in cells)),
        "mean_test_mrr_change":mean([c["test_utility"]["test_mrr_change"] for c in cells]),
        "min_test_mrr_change":float(np.min([c["test_utility"]["test_mrr_change"] for c in cells])),
        "max_test_mrr_change":float(np.max([c["test_utility"]["test_mrr_change"] for c in cells])),
        "median_target_norm":float(np.median([c["fit_diagnostic"]["target_retained_median_norm"] for c in cells])),
        "median_restarted_norm_before":float(np.median([c["fit_diagnostic"]["median_restarted_norm_before"] for c in cells])),
        "median_refa_restarted_norm_evaluation_only":float(np.median([c["fit_diagnostic"]["median_refa_restarted_norm_evaluation_only"] for c in cells])),
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",type=Path,required=True)
    ap.add_argument("--out",type=Path,required=True)
    args=ap.parse_args()

    files=sorted(args.root.glob("*_W13.json"))
    if len(files)!=36:
        raise RuntimeError(f"Expected 36 W13 cell JSONs, found {len(files)}")
    cells=[json.loads(p.read_text()) for p in files]

    if not all(bool(c.get("fitting_reference_free")) for c in cells):
        raise RuntimeError("At least one W13 cell is not marked fitting_reference_free")

    out={
        "protocol":"W13-reference-free-retained-norm-median-v1",
        "method":"RetainedNormMedian",
        "overall":summarize(cells),
        "by_dataset":{},
        "by_construction":{},
    }
    for ds in DATASETS:
        cc=[c for c in cells if c["dataset"]==ds]
        if len(cc)!=12: raise RuntimeError(f"{ds}: expected 12 cells, found {len(cc)}")
        out["by_dataset"][ds]=summarize(cc)
    for mode in MODES:
        cc=[c for c in cells if c["request_mode"]==mode]
        if len(cc)!=9: raise RuntimeError(f"{mode}: expected 9 cells, found {len(cc)}")
        out["by_construction"][mode]=summarize(cc)

    args.out.mkdir(parents=True,exist_ok=True)
    (args.out/"W13_REFERENCE_FREE_NORM_SUMMARY.json").write_text(json.dumps(out,indent=2)+"\n")

    rows=[]
    for c in cells:
        rows.append({
            "dataset":c["dataset"],
            "seed":c["seed"],
            "request_mode":c["request_mode"],
            "request_hash":c["request_hash"],
            "baseline_excess":c["R+L"]["logrank_excess"],
            "reference_free_excess":c["RetainedNormMedian"]["logrank_excess"],
            "oracle_excess":c["NormOracle_evaluation_only"]["logrank_excess"],
            "reference_free_reduction":c["comparison"]["reference_free_reduction"],
            "oracle_reduction":c["comparison"]["oracle_reduction"],
            "fraction_oracle_gain_recovered":c["comparison"]["fraction_oracle_gain_recovered"],
            "test_mrr_change":c["test_utility"]["test_mrr_change"],
            "target_retained_median_norm":c["fit_diagnostic"]["target_retained_median_norm"],
            "median_restarted_norm_before":c["fit_diagnostic"]["median_restarted_norm_before"],
            "median_refa_restarted_norm_evaluation_only":c["fit_diagnostic"]["median_refa_restarted_norm_evaluation_only"],
        })
    with (args.out/"W13_REFERENCE_FREE_NORM_CELLS.csv").open("w",newline="",encoding="utf8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()))
        w.writeheader();w.writerows(rows)

    x=out["overall"]
    print("=== W13 REFERENCE-FREE RETAINED NORM ===")
    print(f"R+L excess={x['baseline_excess']:.10f}")
    print(f"RetainedNormMedian excess={x['reference_free_excess']:.10f} reduction={100*x['reference_free_reduction']:.2f}%")
    print(f"NormOracle excess={x['oracle_excess']:.10f} reduction={100*x['oracle_reduction']:.2f}%")
    print(f"oracle gain recovered={100*x['fraction_oracle_gain_recovered']:.2f}%")
    print(f"better-than-baseline={x['cells_better_than_baseline']}/36 positive-residual={x['positive_reference_free_excess_cells']}/36")
    print(f"forgotten-MRR gap={x['mean_forgotten_mrr_gap']:.10f} null={x['mean_null_mrr_gap']:.10f} excess={x['mean_mrr_excess']:.10f}")
    print(f"top10_excess={x['mean_top10_excess']:.10f} top100_excess={x['mean_top100_excess']:.10f}")
    print(f"mean test-MRR change={x['mean_test_mrr_change']:.8f} range=[{x['min_test_mrr_change']:.8f},{x['max_test_mrr_change']:.8f}]")
    print("=== BY CONSTRUCTION ===")
    for m in MODES:
        q=out["by_construction"][m]
        print(
            m,
            f"E0={q['baseline_excess']:.6f}",
            f"ERF={q['reference_free_excess']:.6f}",
            f"EO={q['oracle_excess']:.6f}",
            f"RF reduction={100*q['reference_free_reduction']:.2f}%",
            f"oracle gain recovered={100*q['fraction_oracle_gain_recovered']:.2f}%",
        )
    print("=== BY DATASET ===")
    for ds in DATASETS:
        q=out["by_dataset"][ds]
        print(
            ds,
            f"E0={q['baseline_excess']:.6f}",
            f"ERF={q['reference_free_excess']:.6f}",
            f"EO={q['oracle_excess']:.6f}",
            f"RF reduction={100*q['reference_free_reduction']:.2f}%",
            f"oracle gain recovered={100*q['fraction_oracle_gain_recovered']:.2f}%",
        )
    print(args.out/"W13_REFERENCE_FREE_NORM_SUMMARY.json")
    print("W13_AGGREGATE_OK")

if __name__=="__main__":
    main()
