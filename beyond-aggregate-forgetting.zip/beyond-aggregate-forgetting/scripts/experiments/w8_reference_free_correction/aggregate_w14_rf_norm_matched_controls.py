#!/usr/bin/env python3
"""Aggregate W14 RF-NORM over the exact 36-cell primary grid."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

DATASETS = ("FB15K-237", "CoDEx-M", "NELL-995")
MODES = ("fullstar-low", "fullstar-mid", "fullstar-high", "exact-card-high")


def mean(xs):
    return float(np.mean(np.asarray(xs, dtype=float)))


def summarize(cells):
    e0 = mean([c["R+L"]["logrank_excess"] for c in cells])
    er = mean([c["ControlNormMedian"]["logrank_excess"] for c in cells])
    eo = mean([c["NormOracle_evaluation_only"]["logrank_excess"] for c in cells])
    em = mean([c["RFPC_historical"]["median_logrank_excess"] for c in cells])
    ea = mean([c["RFPC_historical"]["mean_logrank_excess"] for c in cells])
    oracle_gain = e0 - eo
    rfn_gain = e0 - er
    return {
        "cells": len(cells),
        "baseline_excess": e0,
        "rf_norm_excess": er,
        "oracle_excess": eo,
        "rfpc_median_excess": em,
        "rfpc_mean_excess": ea,
        "rf_norm_reduction": float(1 - er / e0) if e0 != 0 else None,
        "oracle_reduction": float(1 - eo / e0) if e0 != 0 else None,
        "fraction_oracle_gain_recovered": float(rfn_gain / oracle_gain) if oracle_gain != 0 else None,
        "absolute_improvement_vs_rfpc_median": float(em - er),
        "absolute_improvement_vs_rfpc_mean": float(ea - er),
        "better_than_baseline_cells": int(sum(
            c["ControlNormMedian"]["logrank_excess"] < c["R+L"]["logrank_excess"]
            for c in cells
        )),
        "better_than_rfpc_median_cells": int(sum(
            c["ControlNormMedian"]["logrank_excess"] <
            c["RFPC_historical"]["median_logrank_excess"]
            for c in cells
        )),
        "better_than_rfpc_mean_cells": int(sum(
            c["ControlNormMedian"]["logrank_excess"] <
            c["RFPC_historical"]["mean_logrank_excess"]
            for c in cells
        )),
        "positive_rf_norm_excess_cells": int(sum(
            c["ControlNormMedian"]["logrank_excess"] > 0 for c in cells
        )),
        "top10_excess": mean([c["ControlNormMedian"]["top10_excess"] for c in cells]),
        "top100_excess": mean([c["ControlNormMedian"]["top100_excess"] for c in cells]),
        "mrr_excess": mean([c["ControlNormMedian"]["mrr_excess"] for c in cells]),
        "mean_test_mrr_change": mean([c["test_utility"]["test_mrr_change"] for c in cells]),
        "min_test_mrr_change": float(np.min([c["test_utility"]["test_mrr_change"] for c in cells])),
        "max_test_mrr_change": float(np.max([c["test_utility"]["test_mrr_change"] for c in cells])),
        "median_control_target_norm": float(np.median([
            c["fit_diagnostic"]["median_control_target_norm"] for c in cells
        ])),
        "median_restarted_norm_before": float(np.median([
            c["fit_diagnostic"]["median_restarted_norm_before"] for c in cells
        ])),
        "median_refa_norm_evaluation_only": float(np.median([
            c["fit_diagnostic"]["median_refa_restarted_norm_evaluation_only"] for c in cells
        ])),
        "median_target_to_refa_ratio_evaluation_only": float(np.median([
            c["fit_diagnostic"]["median_target_to_refa_ratio_evaluation_only"] for c in cells
        ])),
        "median_degree_mismatch": float(np.median([
            c["fit_diagnostic"]["median_abs_predelete_degree_mismatch"] for c in cells
        ])),
    }


def load_rank_cell(npz_path: Path):
    z = np.load(npz_path, allow_pickle=False)
    keys = (
        "rl_head_rank", "rl_tail_rank",
        "corrected_head_rank", "corrected_tail_rank",
        "refA_head_rank", "refA_tail_rank",
        "refB_head_rank", "refB_tail_rank",
    )
    missing = [k for k in keys if k not in z.files]
    if missing:
        raise RuntimeError(f"{npz_path}: missing rank arrays {missing}")
    out = {k: np.asarray(z[k], dtype=float) for k in keys}
    n = len(out["refA_head_rank"])
    if any(len(v) != n for v in out.values()):
        raise RuntimeError(f"{npz_path}: rank-array length mismatch")
    return out


def pair_metrics_from_arrays(candidate_h, candidate_t, refa_h, refa_t):
    c = np.concatenate([candidate_h, candidate_t])
    a = np.concatenate([refa_h, refa_t])
    loggap = float(np.mean(np.abs(np.log10(c) - np.log10(a))))
    t10 = float(np.mean((c <= 10) != (a <= 10)))
    t100 = float(np.mean((c <= 100) != (a <= 100)))
    mrrgap = float(abs(np.mean(1.0 / c) - np.mean(1.0 / a)))
    return loggap, t10, t100, mrrgap


def boot_metrics(rank_cells, n_boot: int, seed: int):
    rng = np.random.default_rng(seed)
    names = (
        "baseline_excess", "rf_norm_excess", "rf_norm_reduction",
        "top10_excess", "top100_excess", "mrr_excess",
    )
    dist = {k: np.empty(n_boot, dtype=float) for k in names}
    chunk = 200

    for st in range(0, n_boot, chunk):
        en = min(n_boot, st + chunk)
        b = en - st
        acc = {k: np.zeros(b, dtype=float) for k in names}
        for rc in rank_cells:
            n = len(rc["refA_head_rank"])
            ids = rng.integers(0, n, size=(b, n))
            for j in range(b):
                q = ids[j]
                refa_h = rc["refA_head_rank"][q]
                refa_t = rc["refA_tail_rank"][q]
                refb_h = rc["refB_head_rank"][q]
                refb_t = rc["refB_tail_rank"][q]

                rl = pair_metrics_from_arrays(
                    rc["rl_head_rank"][q], rc["rl_tail_rank"][q],
                    refa_h, refa_t
                )
                rfn = pair_metrics_from_arrays(
                    rc["corrected_head_rank"][q], rc["corrected_tail_rank"][q],
                    refa_h, refa_t
                )
                null = pair_metrics_from_arrays(refb_h, refb_t, refa_h, refa_t)

                e0 = rl[0] - null[0]
                er = rfn[0] - null[0]
                acc["baseline_excess"][j] += e0
                acc["rf_norm_excess"][j] += er
                acc["top10_excess"][j] += rfn[1] - null[1]
                acc["top100_excess"][j] += rfn[2] - null[2]
                acc["mrr_excess"][j] += rfn[3] - null[3]

        for k in ("baseline_excess", "rf_norm_excess", "top10_excess", "top100_excess", "mrr_excess"):
            dist[k][st:en] = acc[k] / len(rank_cells)
        dist["rf_norm_reduction"][st:en] = (
            1.0 - dist["rf_norm_excess"][st:en] / dist["baseline_excess"][st:en]
        )

    return {
        k: {
            "mean": float(np.nanmean(v)),
            "ci95": [
                float(np.nanquantile(v, 0.025)),
                float(np.nanquantile(v, 0.975)),
            ],
        }
        for k, v in dist.items()
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--n-boot", type=int, default=10000)
    ap.add_argument("--seed", type=int, default=25092026)
    args = ap.parse_args()

    files = sorted(args.root.glob("*_W14.json"))
    if len(files) != 36:
        raise RuntimeError(f"Expected 36 W14 cell JSONs, found {len(files)}")

    cells = [json.loads(p.read_text()) for p in files]
    if not all(c.get("method") == "ControlNormMedian" for c in cells):
        raise RuntimeError("Unexpected W14 method label")
    if not all(bool(c.get("fitting_reference_free")) for c in cells):
        raise RuntimeError("At least one W14 cell is not reference-free")

    rank_cells = []
    for jp in files:
        npz = jp.with_suffix(".npz")
        if not npz.is_file():
            raise FileNotFoundError(npz)
        rank_cells.append(load_rank_cell(npz))

    result = {
        "protocol": "W14-rf-norm-matched-controls-v1",
        "method": "ControlNormMedian",
        "overall": summarize(cells),
        "by_dataset": {},
        "by_construction": {},
        "bootstrap": boot_metrics(rank_cells, args.n_boot, args.seed),
        "bootstrap_design": {
            "n_boot": args.n_boot,
            "seed": args.seed,
            "within_cell": "forgotten-query resampling with head/tail paired",
            "across_cells": "equal 1/36 weight",
        },
    }

    for ds in DATASETS:
        cc = [c for c in cells if c["dataset"] == ds]
        if len(cc) != 12:
            raise RuntimeError(f"{ds}: expected 12 cells, found {len(cc)}")
        result["by_dataset"][ds] = summarize(cc)

    for mode in MODES:
        cc = [c for c in cells if c["request_mode"] == mode]
        if len(cc) != 9:
            raise RuntimeError(f"{mode}: expected 9 cells, found {len(cc)}")
        result["by_construction"][mode] = summarize(cc)

    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "W14_RF_NORM_SUMMARY.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )

    rows = []
    for c in cells:
        rows.append({
            "dataset": c["dataset"],
            "seed": c["seed"],
            "request_mode": c["request_mode"],
            "request_hash": c["request_hash"],
            "baseline_excess": c["R+L"]["logrank_excess"],
            "rf_norm_excess": c["ControlNormMedian"]["logrank_excess"],
            "oracle_excess": c["NormOracle_evaluation_only"]["logrank_excess"],
            "rfpc_median_excess": c["RFPC_historical"]["median_logrank_excess"],
            "rfpc_mean_excess": c["RFPC_historical"]["mean_logrank_excess"],
            "rf_norm_reduction": c["comparison"]["rf_norm_reduction"],
            "oracle_gain_recovered": c["comparison"]["fraction_oracle_gain_recovered"],
            "top10_excess": c["ControlNormMedian"]["top10_excess"],
            "top100_excess": c["ControlNormMedian"]["top100_excess"],
            "mrr_excess": c["ControlNormMedian"]["mrr_excess"],
            "test_mrr_change": c["test_utility"]["test_mrr_change"],
            "control_seed": c["control_seed"],
            "controls_sha256": c["controls_sha256"],
            "median_control_target_norm": c["fit_diagnostic"]["median_control_target_norm"],
            "median_restarted_norm_before": c["fit_diagnostic"]["median_restarted_norm_before"],
            "median_refa_norm_evaluation_only": c["fit_diagnostic"]["median_refa_restarted_norm_evaluation_only"],
            "median_degree_mismatch": c["fit_diagnostic"]["median_abs_predelete_degree_mismatch"],
        })
    with (args.out / "W14_RF_NORM_CELLS.csv").open("w", newline="", encoding="utf8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    x = result["overall"]
    print("=== W14 RF-NORM MATCHED CONTROLS ===")
    print(f"R+L excess={x['baseline_excess']:.10f}")
    print(
        f"RF-NORM excess={x['rf_norm_excess']:.10f} "
        f"reduction={100*x['rf_norm_reduction']:.2f}%"
    )
    print(
        f"NormOracle excess={x['oracle_excess']:.10f} "
        f"reduction={100*x['oracle_reduction']:.2f}%"
    )
    print(f"oracle gain recovered={100*x['fraction_oracle_gain_recovered']:.2f}%")
    print(
        f"RFPC median={x['rfpc_median_excess']:.10f} "
        f"RF-NORM improvement={x['absolute_improvement_vs_rfpc_median']:.10f}"
    )
    print(
        f"RFPC mean={x['rfpc_mean_excess']:.10f} "
        f"RF-NORM improvement={x['absolute_improvement_vs_rfpc_mean']:.10f}"
    )
    print(
        f"better-than-baseline={x['better_than_baseline_cells']}/36 "
        f"better-than-RFPCmedian={x['better_than_rfpc_median_cells']}/36 "
        f"better-than-RFPCmean={x['better_than_rfpc_mean_cells']}/36"
    )
    print(
        f"top10_excess={x['top10_excess']:.10f} "
        f"top100_excess={x['top100_excess']:.10f} "
        f"mrr_excess={x['mrr_excess']:.10f}"
    )
    print(
        f"mean test-MRR change={x['mean_test_mrr_change']:.8f} "
        f"range=[{x['min_test_mrr_change']:.8f},{x['max_test_mrr_change']:.8f}]"
    )
    print("=== BY CONSTRUCTION ===")
    for mode in MODES:
        q = result["by_construction"][mode]
        print(
            mode,
            f"E0={q['baseline_excess']:.6f}",
            f"ERFN={q['rf_norm_excess']:.6f}",
            f"EO={q['oracle_excess']:.6f}",
            f"RFPCmed={q['rfpc_median_excess']:.6f}",
            f"reduction={100*q['rf_norm_reduction']:.2f}%",
            f"oracle-gain={100*q['fraction_oracle_gain_recovered']:.2f}%",
        )
    print("=== BY DATASET ===")
    for ds in DATASETS:
        q = result["by_dataset"][ds]
        print(
            ds,
            f"E0={q['baseline_excess']:.6f}",
            f"ERFN={q['rf_norm_excess']:.6f}",
            f"EO={q['oracle_excess']:.6f}",
            f"RFPCmed={q['rfpc_median_excess']:.6f}",
            f"reduction={100*q['rf_norm_reduction']:.2f}%",
            f"oracle-gain={100*q['fraction_oracle_gain_recovered']:.2f}%",
        )
    print("=== BOOTSTRAP ===")
    for k, v in result["bootstrap"].items():
        print(k, f"mean={v['mean']:.10f}", f"CI95=[{v['ci95'][0]:.10f},{v['ci95'][1]:.10f}]")
    print(args.out / "W14_RF_NORM_SUMMARY.json")
    print("W14_AGGREGATE_OK")


if __name__ == "__main__":
    main()
