#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np


RULES = ("median", "mean")
REQ_COLS = [
    "dataset", "request_mode", "request_hash", "seed", "variant", "delta_rule",
    "lambda", "candidate_logrank", "null_logrank", "logrank_excess",
    "mrr_excess", "top10_excess", "top100_excess", "forgotten_mrr_gap",
    "test_mrr", "placement_did", "n_restarted",
]


def stable_seed(*parts: object) -> int:
    s = "|".join(str(x) for x in parts)
    return int.from_bytes(hashlib.sha256(s.encode("utf8")).digest()[:8], "little") & 0x7FFFFFFF


def ci(x):
    return float(np.quantile(x, .025)), float(np.quantile(x, .975))


def bootstrap_mean(v: np.ndarray, n_boot: int, rng: np.random.Generator) -> np.ndarray:
    v = np.asarray(v, dtype=float)
    out = np.empty(n_boot, dtype=float)
    chunk = 250
    for st in range(0, n_boot, chunk):
        en = min(n_boot, st + chunk)
        ids = rng.integers(0, len(v), size=(en - st, len(v)))
        out[st:en] = v[ids].mean(axis=1)
    return out


def forgotten_arrays(z):
    ch = np.asarray(z["candidate_head_rank"], float)
    ct = np.asarray(z["candidate_tail_rank"], float)
    ah = np.asarray(z["refA_head_rank"], float)
    at = np.asarray(z["refA_tail_rank"], float)
    bh = np.asarray(z["refB_head_rank"], float)
    bt = np.asarray(z["refB_tail_rank"], float)

    cand_log = .5 * (np.abs(np.log10(ch) - np.log10(ah)) + np.abs(np.log10(ct) - np.log10(at)))
    null_log = .5 * (np.abs(np.log10(bh) - np.log10(ah)) + np.abs(np.log10(bt) - np.log10(at)))

    def topk(xh, xt, yh, yt, k):
        return .5 * (((xh <= k) != (yh <= k)).astype(float) + ((xt <= k) != (yt <= k)).astype(float))

    cand_t10 = topk(ch, ct, ah, at, 10)
    null_t10 = topk(bh, bt, ah, at, 10)
    cand_t100 = topk(ch, ct, ah, at, 100)
    null_t100 = topk(bh, bt, ah, at, 100)

    cand_rr = .5 * (1.0 / ch + 1.0 / ct)
    refa_rr = .5 * (1.0 / ah + 1.0 / at)
    refb_rr = .5 * (1.0 / bh + 1.0 / bt)

    return {
        "candidate_logrank": cand_log,
        "null_logrank": null_log,
        "logrank_excess": cand_log - null_log,
        "candidate_top10": cand_t10,
        "null_top10": null_t10,
        "top10_excess": cand_t10 - null_t10,
        "candidate_top100": cand_t100,
        "null_top100": null_t100,
        "top100_excess": cand_t100 - null_t100,
        "candidate_mrr_signed": cand_rr - refa_rr,
        "null_mrr_signed": refb_rr - refa_rr,
    }


def test_arrays(z):
    bh = np.asarray(z["baseline_test_head_rank"], float)
    bt = np.asarray(z["baseline_test_tail_rank"], float)
    ch = np.asarray(z["corrected_test_head_rank"], float)
    ct = np.asarray(z["corrected_test_tail_rank"], float)
    return {
        "baseline_test_rr": .5 * (1.0 / bh + 1.0 / bt),
        "corrected_test_rr": .5 * (1.0 / ch + 1.0 / ct),
    }


def baseline_point_from_w5(source_cell: Path, w8_npz: Path):
    """Uncorrected R+L baseline on the exact same W5 cell/query set."""
    w5_path = source_cell / "mean_tie_rank_audit.npz"
    if not w5_path.is_file():
        raise FileNotFoundError(w5_path)

    w5 = np.load(w5_path, allow_pickle=False)
    w8 = np.load(w8_npz, allow_pickle=False)

    needed = {
        "queries",
        "candidate_head_mean_tie_rank", "candidate_tail_mean_tie_rank",
        "refA_head_mean_tie_rank", "refA_tail_mean_tie_rank",
        "refB_head_mean_tie_rank", "refB_tail_mean_tie_rank",
    }
    missing = sorted(needed - set(w5.files))
    if missing:
        raise RuntimeError(f"{w5_path}: missing baseline arrays {missing}")

    # Hard alignment gates: same forgotten queries and identical reference ranks.
    if not np.array_equal(
        np.asarray(w5["queries"], dtype=np.int64),
        np.asarray(w8["forgotten_queries"], dtype=np.int64),
    ):
        raise RuntimeError(f"{source_cell}: W5/W8 forgotten query mismatch")

    for w5_key, w8_key in (
        ("refA_head_mean_tie_rank", "refA_head_rank"),
        ("refA_tail_mean_tie_rank", "refA_tail_rank"),
        ("refB_head_mean_tie_rank", "refB_head_rank"),
        ("refB_tail_mean_tie_rank", "refB_tail_rank"),
    ):
        if not np.array_equal(
            np.asarray(w5[w5_key], dtype=np.float32),
            np.asarray(w8[w8_key], dtype=np.float32),
        ):
            raise RuntimeError(
                f"{source_cell}: reference rank mismatch {w5_key} vs {w8_key}"
            )

    ch = np.asarray(w5["candidate_head_mean_tie_rank"], float)
    ct = np.asarray(w5["candidate_tail_mean_tie_rank"], float)
    ah = np.asarray(w5["refA_head_mean_tie_rank"], float)
    at = np.asarray(w5["refA_tail_mean_tie_rank"], float)
    bh = np.asarray(w5["refB_head_mean_tie_rank"], float)
    bt = np.asarray(w5["refB_tail_mean_tie_rank"], float)

    cand_log = .5 * (
        np.abs(np.log10(ch) - np.log10(ah))
        + np.abs(np.log10(ct) - np.log10(at))
    )
    null_log = .5 * (
        np.abs(np.log10(bh) - np.log10(ah))
        + np.abs(np.log10(bt) - np.log10(at))
    )

    return {
        "baseline_candidate_logrank": float(np.mean(cand_log)),
        "baseline_null_logrank": float(np.mean(null_log)),
        "baseline_logrank_excess": float(np.mean(cand_log - null_log)),
    }


def bootstrap_baseline_logrank(source_cell: Path, w8_npz: Path, n_boot: int, seed: int):
    """Paired-query bootstrap for the uncorrected R+L log-rank excess."""
    w5 = np.load(source_cell / "mean_tie_rank_audit.npz", allow_pickle=False)
    w8 = np.load(w8_npz, allow_pickle=False)

    # Reuse the same hard gates as the point estimator.
    _ = baseline_point_from_w5(source_cell, w8_npz)

    ch = np.asarray(w5["candidate_head_mean_tie_rank"], float)
    ct = np.asarray(w5["candidate_tail_mean_tie_rank"], float)
    ah = np.asarray(w5["refA_head_mean_tie_rank"], float)
    at = np.asarray(w5["refA_tail_mean_tie_rank"], float)
    bh = np.asarray(w5["refB_head_mean_tie_rank"], float)
    bt = np.asarray(w5["refB_tail_mean_tie_rank"], float)

    contrib = .5 * (
        np.abs(np.log10(ch) - np.log10(ah))
        + np.abs(np.log10(ct) - np.log10(at))
        - np.abs(np.log10(bh) - np.log10(ah))
        - np.abs(np.log10(bt) - np.log10(at))
    )

    rng = np.random.default_rng(seed)
    return bootstrap_mean(contrib, n_boot, rng)


def bootstrap_cell(npz_path: Path, n_boot: int, seed: int):
    z = np.load(npz_path, allow_pickle=False)
    f = forgotten_arrays(z)
    t = test_arrays(z)
    p = np.asarray(z["placement_did_values"], float)

    # Same fixed resample stream for median/mean because seed excludes rule.
    rng_q = np.random.default_rng(seed)
    rng_t = np.random.default_rng(seed ^ 0x13579BDF)
    rng_p = np.random.default_rng(seed ^ 0x2468ACE)

    n = len(f["candidate_logrank"])
    qids_chunks = []
    # Build all query bootstrap metrics in chunks without storing index matrices globally.
    keys_linear = [
        "candidate_logrank", "null_logrank", "logrank_excess",
        "candidate_top10", "null_top10", "top10_excess",
        "candidate_top100", "null_top100", "top100_excess",
    ]
    dist = {k: np.empty(n_boot, dtype=float) for k in keys_linear}
    dist["forgotten_mrr_gap"] = np.empty(n_boot, dtype=float)
    dist["null_mrr_gap"] = np.empty(n_boot, dtype=float)
    dist["mrr_excess"] = np.empty(n_boot, dtype=float)

    chunk = 250
    for st in range(0, n_boot, chunk):
        en = min(n_boot, st + chunk)
        ids = rng_q.integers(0, n, size=(en - st, n))
        for k in keys_linear:
            dist[k][st:en] = f[k][ids].mean(axis=1)
        cs = f["candidate_mrr_signed"][ids].mean(axis=1)
        ns = f["null_mrr_signed"][ids].mean(axis=1)
        dist["forgotten_mrr_gap"][st:en] = np.abs(cs)
        dist["null_mrr_gap"][st:en] = np.abs(ns)
        dist["mrr_excess"][st:en] = np.abs(cs) - np.abs(ns)

    base_test = bootstrap_mean(t["baseline_test_rr"], n_boot, rng_t)
    # Reset a paired stream for corrected test so both use the SAME query indices.
    rng_t2 = np.random.default_rng(seed ^ 0x13579BDF)
    corr_test = bootstrap_mean(t["corrected_test_rr"], n_boot, rng_t2)
    dist["baseline_test_mrr"] = base_test
    dist["test_mrr"] = corr_test
    dist["test_mrr_change"] = corr_test - base_test
    dist["placement_did"] = bootstrap_mean(p, n_boot, rng_p)
    return dist


def point_from_npz(npz_path: Path):
    z = np.load(npz_path, allow_pickle=False)
    f = forgotten_arrays(z)
    t = test_arrays(z)
    p = np.asarray(z["placement_did_values"], float)

    cand_signed = float(np.mean(f["candidate_mrr_signed"]))
    null_signed = float(np.mean(f["null_mrr_signed"]))
    cand_gap = abs(cand_signed)
    null_gap = abs(null_signed)

    return {
        "candidate_logrank": float(np.mean(f["candidate_logrank"])),
        "null_logrank": float(np.mean(f["null_logrank"])),
        "logrank_excess": float(np.mean(f["logrank_excess"])),
        "candidate_top10": float(np.mean(f["candidate_top10"])),
        "null_top10": float(np.mean(f["null_top10"])),
        "top10_excess": float(np.mean(f["top10_excess"])),
        "candidate_top100": float(np.mean(f["candidate_top100"])),
        "null_top100": float(np.mean(f["null_top100"])),
        "top100_excess": float(np.mean(f["top100_excess"])),
        "forgotten_mrr_gap": float(cand_gap),
        "null_mrr_gap": float(null_gap),
        "mrr_excess": float(cand_gap - null_gap),
        "baseline_test_mrr": float(np.mean(t["baseline_test_rr"])),
        "test_mrr": float(np.mean(t["corrected_test_rr"])),
        "test_mrr_change": float(np.mean(t["corrected_test_rr"]) - np.mean(t["baseline_test_rr"])),
        "placement_did": float(np.mean(p)),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--n-boot", type=int, default=10000)
    ap.add_argument("--seed", type=int, default=19092026)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    jsons = sorted(args.root.glob("*/*/*/W8_REFERENCE_FREE_A_*.json"))
    if len(jsons) != 72:
        raise RuntimeError(f"Expected 72 W8 JSON files (36 cells x 2 rules), found {len(jsons)}")

    entries = {r: [] for r in RULES}
    for js in jsons:
        rec = json.loads(js.read_text())
        rule = rec["delta_rule"]
        if rule not in entries:
            raise RuntimeError(f"Unexpected delta_rule={rule}")
        npz = js.with_suffix(".npz")
        if not npz.is_file():
            raise FileNotFoundError(npz)
        point = point_from_npz(npz)

        # Strong consistency gate against the cell JSON.
        for k in (
            "candidate_logrank", "null_logrank", "logrank_excess",
            "mrr_excess", "top10_excess", "top100_excess",
            "forgotten_mrr_gap", "test_mrr", "test_mrr_change", "placement_did",
        ):
            if abs(float(rec[k]) - float(point[k])) > 2e-6:
                raise RuntimeError(
                    f"{js}: point mismatch {k}: json={rec[k]} recomputed={point[k]}"
                )

        key = (
            rec["dataset"], int(rec["seed"]), rec["request_mode"], rec["request_hash"]
        )
        entries[rule].append((key, rec, npz))

    records = {r: [] for r in RULES}
    npzs = {r: [] for r in RULES}
    for rule in RULES:
        entries[rule].sort(key=lambda x: x[0])
        records[rule] = [x[1] for x in entries[rule]]
        npzs[rule] = [x[2] for x in entries[rule]]
        if len(records[rule]) != 36:
            raise RuntimeError(f"{rule}: expected 36 cells, found {len(records[rule])}")

        # Per-variant cell CSV. Required user columns come first.
        out_csv = args.out / f"W8_VARIANT_A_{rule.upper()}_PER_CELL.csv"
        extra = [
            "baseline_test_mrr", "test_mrr_change", "baseline_placement_did",
            "candidate_top10", "null_top10", "candidate_top100", "null_top100",
            "candidate_mrr_gap", "null_mrr_gap", "B", "K", "context_seed",
            "control_seed", "n_test_queries", "source_cell", "placement_csv",
            "bitwise_nonrestarted_gate", "delta_mean", "delta_median", "delta_q05", "delta_q95",
        ]
        fields = REQ_COLS + [x for x in extra if x not in REQ_COLS]
        with out_csv.open("w", newline="", encoding="utf8") as f:
            w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
            w.writeheader()
            w.writerows(records[rule])

    # ------------------------------------------------------------------
    # Exact uncorrected R+L baseline, one row per W5 cell.
    # Use the median entries only to enumerate the 36 unique cells; the
    # baseline itself is independent of the correction rule.
    # ------------------------------------------------------------------
    baseline_rows = []
    baseline_dists = []
    for rec, npz in zip(records["median"], npzs["median"]):
        source_cell = Path(rec["source_cell"])
        p = baseline_point_from_w5(source_cell, npz)
        key_seed = stable_seed(
            rec["dataset"], rec["seed"], rec["request_mode"], rec["request_hash"],
            args.seed, "w8-baseline-bootstrap"
        )
        d = bootstrap_baseline_logrank(source_cell, npz, args.n_boot, key_seed)
        lo, hi = ci(d)
        baseline_rows.append({
            "dataset": rec["dataset"],
            "seed": int(rec["seed"]),
            "request_mode": rec["request_mode"],
            "request_hash": rec["request_hash"],
            **p,
            "baseline_logrank_excess_ci95_low": lo,
            "baseline_logrank_excess_ci95_high": hi,
            "n_queries": int(np.load(npz, allow_pickle=False)["forgotten_queries"].shape[0]),
            "source_cell": str(source_cell),
        })
        baseline_dists.append(d)

    if len(baseline_rows) != 36:
        raise RuntimeError(f"Expected 36 baseline rows, got {len(baseline_rows)}")

    baseline_csv = args.out / "W8_BASELINE_RL_LOGRANK_PER_CELL.csv"
    with baseline_csv.open("w", newline="", encoding="utf8") as f:
        fields = [
            "dataset", "seed", "request_mode", "request_hash",
            "baseline_candidate_logrank", "baseline_null_logrank",
            "baseline_logrank_excess",
            "baseline_logrank_excess_ci95_low",
            "baseline_logrank_excess_ci95_high",
            "n_queries", "source_cell",
        ]
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(baseline_rows)

    baseline_aggregate_point = float(np.mean([
        r["baseline_logrank_excess"] for r in baseline_rows
    ]))
    baseline_aggregate_dist = np.mean(np.vstack(baseline_dists), axis=0)
    baseline_aggregate_ci = ci(baseline_aggregate_dist)

    baseline_summary = {
        "metric": "baseline_logrank_excess",
        "point": baseline_aggregate_point,
        "ci95_low": baseline_aggregate_ci[0],
        "ci95_high": baseline_aggregate_ci[1],
        "positive_cells": int(sum(
            r["baseline_logrank_excess"] > 0 for r in baseline_rows
        )),
        "cells": 36,
    }
    (args.out / "W8_BASELINE_RL_LOGRANK_SUMMARY.json").write_text(
        json.dumps({
            "bootstrap": {
                "unit": "forgotten query triple; head/tail paired within query",
                "n_boot": args.n_boot,
                "seed": args.seed,
                "aggregation": "equal-weight mean across 36 fixed W5 cells",
            },
            "aggregate": baseline_summary,
            "cells": baseline_rows,
        }, indent=2) + "\n"
    )

    metrics = [
        "candidate_logrank", "null_logrank", "logrank_excess",
        "forgotten_mrr_gap", "null_mrr_gap", "mrr_excess",
        "candidate_top10", "null_top10", "top10_excess",
        "candidate_top100", "null_top100", "top100_excess",
        "baseline_test_mrr", "test_mrr", "test_mrr_change", "placement_did",
    ]

    aggregate_rows = []
    success_payload = {}

    for rule in RULES:
        cell_dists = []
        cell_points = []
        for rec, npz in zip(records[rule], npzs[rule]):
            key_seed = stable_seed(
                rec["dataset"], rec["seed"], rec["request_mode"], rec["request_hash"],
                args.seed, "w8-bootstrap"
            )
            cell_dists.append(bootstrap_cell(npz, args.n_boot, key_seed))
            cell_points.append(point_from_npz(npz))

        agg_point = {k: float(np.mean([p[k] for p in cell_points])) for k in metrics}
        agg_dist = {
            k: np.mean(np.vstack([d[k] for d in cell_dists]), axis=0)
            for k in metrics
        }

        positive = {
            k: int(sum(float(p[k]) > 0 for p in cell_points))
            for k in metrics
        }

        full_success = bool(
            agg_point["logrank_excess"] <= 0.1280544
            and abs(agg_point["placement_did"]) <= 0.3091
            and agg_point["test_mrr_change"] >= -0.005
            and agg_point["forgotten_mrr_gap"] <= 0.010
        )
        success_payload[rule] = {
            "full_success": full_success,
            "criteria": {
                "signed_logrank_excess_le_0.1280544": bool(agg_point["logrank_excess"] <= 0.1280544),
                "abs_placement_did_le_0.3091": bool(abs(agg_point["placement_did"]) <= 0.3091),
                "test_mrr_change_ge_minus_0.005": bool(agg_point["test_mrr_change"] >= -0.005),
                "forgotten_mrr_gap_le_0.010": bool(agg_point["forgotten_mrr_gap"] <= 0.010),
            },
            "point": agg_point,
        }

        for k in metrics:
            lo, hi = ci(agg_dist[k])
            threshold = ""
            passed = ""
            if k == "logrank_excess":
                threshold, passed = "<= +0.1280544 (SIGNED)", str(agg_point[k] <= 0.1280544)
            elif k == "placement_did":
                threshold, passed = "|DID| <= 0.3091", str(abs(agg_point[k]) <= 0.3091)
            elif k == "test_mrr_change":
                threshold, passed = ">= -0.005", str(agg_point[k] >= -0.005)
            elif k == "forgotten_mrr_gap":
                threshold, passed = "<= 0.010", str(agg_point[k] <= 0.010)

            aggregate_rows.append({
                "variant": "A",
                "delta_rule": rule,
                "metric": k,
                "point": agg_point[k],
                "ci95_low": lo,
                "ci95_high": hi,
                "positive_cells": positive[k],
                "cells": 36,
                "success_threshold": threshold,
                "success_pass": passed,
            })

        print(f"=== W8 VARIANT A {rule.upper()} ===")
        for k in metrics:
            lo, hi = ci(agg_dist[k])
            print(
                f"{k}={agg_point[k]:.10f} CI95=[{lo:.10f},{hi:.10f}] "
                f"positive={positive[k]}/36"
            )
        print("FULL_SUCCESS", full_success)

    agg_csv = args.out / "W8_VARIANT_A_AGGREGATE_BOOTSTRAP.csv"
    with agg_csv.open("w", newline="", encoding="utf8") as f:
        fields = [
            "variant", "delta_rule", "metric", "point", "ci95_low", "ci95_high",
            "positive_cells", "cells", "success_threshold", "success_pass",
        ]
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(aggregate_rows)

    # Compact paper-facing corrected-excess table requested for W8.
    corrected_excess_metrics = {"mrr_excess", "top10_excess", "top100_excess"}
    corrected_excess_rows = [
        r for r in aggregate_rows if r["metric"] in corrected_excess_metrics
    ]
    corrected_csv = args.out / "W8_CORRECTED_EXCESS_AGGREGATE_BOOTSTRAP.csv"
    with corrected_csv.open("w", newline="", encoding="utf8") as f:
        fields = [
            "variant", "delta_rule", "metric", "point",
            "ci95_low", "ci95_high", "positive_cells", "cells",
        ]
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(corrected_excess_rows)

    (args.out / "W8_CORRECTED_EXCESS_AGGREGATE_BOOTSTRAP.json").write_text(
        json.dumps({
            "bootstrap": {
                "unit": "forgotten query triple; head/tail paired within query",
                "n_boot": args.n_boot,
                "seed": args.seed,
                "aggregation": "equal-weight mean across 36 fixed W5 cells",
                "signed_excess": True,
            },
            "rows": corrected_excess_rows,
        }, indent=2) + "\n"
    )

    payload = {
        "protocol": {
            "n_cells": 36,
            "n_boot": args.n_boot,
            "bootstrap_seed": args.seed,
            "equal_cell_weight": True,
            "forgotten_unit": "query triple; head/tail kept paired",
            "placement_unit": "matched placement-probe row",
            "test_unit": "fixed test query triple; head/tail kept paired",
            "signed_excess": True,
        },
        "success": success_payload,
        "aggregate_rows": aggregate_rows,
    }
    (args.out / "W8_VARIANT_A_AGGREGATE_BOOTSTRAP.json").write_text(
        json.dumps(payload, indent=2) + "\n"
    )
    print("baseline_per_cell_csv", baseline_csv)
    print(
        "baseline_logrank_excess="
        f"{baseline_aggregate_point:.10f} "
        f"CI95=[{baseline_aggregate_ci[0]:.10f},{baseline_aggregate_ci[1]:.10f}]"
    )
    print("corrected_excess_csv", corrected_csv)
    print("aggregate_csv", agg_csv)
    print("W8_AGGREGATE_OK")


if __name__ == "__main__":
    main()
