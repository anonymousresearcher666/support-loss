#!/usr/bin/env python3
"""Exact B3 reanalysis from the W8 aggregate artifacts.

Inputs are the files produced by
scripts/experiments/w8_reference_free_correction/aggregate_w8_reference_free_placement.py:
  W8_BASELINE_RL_LOGRANK_PER_CELL.csv
  W8_VARIANT_A_MEDIAN_PER_CELL.csv
  W8_VARIANT_A_MEAN_PER_CELL.csv

No discovery, no heuristic field matching, no recomputation of ranks.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import numpy as np

RULES=("median","mean")
MODES=("fullstar-low","fullstar-mid","fullstar-high","exact-card-high")
DATASETS=("FB15K-237","CoDEx-M","NELL-995")
KEY=("dataset","seed","request_mode","request_hash")

def read_csv(path:Path):
    with path.open(newline="",encoding="utf8") as f:
        return list(csv.DictReader(f))

def key(r):
    return (r["dataset"],int(r["seed"]),r["request_mode"],r["request_hash"])

def f(r,k):
    return float(r[k])

def stats(x):
    a=np.asarray(x,float)
    return {
        "mean":float(np.mean(a)),
        "median":float(np.median(a)),
        "min":float(np.min(a)),
        "max":float(np.max(a)),
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--aggregate-dir",type=Path,required=True)
    ap.add_argument("--out",type=Path,required=True)
    args=ap.parse_args()

    d=args.aggregate_dir
    bpath=d/"W8_BASELINE_RL_LOGRANK_PER_CELL.csv"
    paths={
        "median":d/"W8_VARIANT_A_MEDIAN_PER_CELL.csv",
        "mean":d/"W8_VARIANT_A_MEAN_PER_CELL.csv",
    }
    for p in [bpath,*paths.values()]:
        if not p.is_file(): raise FileNotFoundError(p)

    base=read_csv(bpath)
    if len(base)!=36: raise RuntimeError(f"baseline expected 36 rows, got {len(base)}")
    bm={key(r):r for r in base}
    if len(bm)!=36: raise RuntimeError("baseline cell keys are not unique")

    out_rows=[]
    summary={
        "estimand_note":(
            "Primary/equal-setting quantities are arithmetic means across the 36 fixed cells. "
            "Per-cell reductions are descriptive ratios computed only after the signed excess "
            "has been formed within each cell."
        ),
        "baseline_equal_setting":{
            "candidate_logrank":float(np.mean([f(r,"baseline_candidate_logrank") for r in base])),
            "null_logrank":float(np.mean([f(r,"baseline_null_logrank") for r in base])),
            "logrank_excess":float(np.mean([f(r,"baseline_logrank_excess") for r in base])),
        },
        "rules":{}
    }

    for rule,p in paths.items():
        rr=read_csv(p)
        if len(rr)!=36: raise RuntimeError(f"{rule}: expected 36 rows, got {len(rr)}")
        rm={key(r):r for r in rr}
        if set(rm)!=set(bm):
            missing=sorted(set(bm)-set(rm)); extra=sorted(set(rm)-set(bm))
            raise RuntimeError(f"{rule}: key mismatch missing={missing[:3]} extra={extra[:3]}")

        cells=[]
        for k in sorted(bm):
            b=bm[k]; r=rm[k]
            before=f(b,"baseline_logrank_excess")
            after=f(r,"logrank_excess")
            reduction=(before-after)/before if before!=0 else float("nan")
            row={
                "dataset":k[0],"seed":k[1],"request_mode":k[2],"request_hash":k[3],
                "rule":rule,
                "baseline_candidate_logrank":f(b,"baseline_candidate_logrank"),
                "baseline_null_logrank":f(b,"baseline_null_logrank"),
                "baseline_logrank_excess":before,
                "corrected_candidate_logrank":f(r,"candidate_logrank"),
                "corrected_null_logrank":f(r,"null_logrank"),
                "corrected_logrank_excess":after,
                "per_cell_reduction":reduction,
                "passes_25pct":bool(reduction>=.25),
                "passes_50pct":bool(reduction>=.50),
            }
            cells.append(row);out_rows.append(row)

        red=np.asarray([x["per_cell_reduction"] for x in cells],float)
        before=np.asarray([x["baseline_logrank_excess"] for x in cells],float)
        after=np.asarray([x["corrected_logrank_excess"] for x in cells],float)

        rec={
            "equal_setting":{
                "baseline_excess":float(np.mean(before)),
                "corrected_candidate_logrank":float(np.mean([x["corrected_candidate_logrank"] for x in cells])),
                "null_logrank":float(np.mean([x["corrected_null_logrank"] for x in cells])),
                "corrected_excess":float(np.mean(after)),
                "reduction_ratio_of_equal_setting_means":float(1-np.mean(after)/np.mean(before)),
            },
            "per_cell_reduction":{
                **stats(red),
                "ge_25_count":int(np.sum(red>=.25)),
                "gt_25_count":int(np.sum(red>.25)),
                "ge_50_count":int(np.sum(red>=.50)),
                "gt_50_count":int(np.sum(red>.50)),
                "negative_count":int(np.sum(red<0)),
                "cells":36,
            },
            "by_construction":{},
            "by_dataset":{},
        }

        for mode in MODES:
            x=[z for z in cells if z["request_mode"]==mode]
            if len(x)!=9: raise RuntimeError(f"{rule}/{mode}: expected 9 cells, got {len(x)}")
            b=np.asarray([z["baseline_logrank_excess"] for z in x],float)
            a=np.asarray([z["corrected_logrank_excess"] for z in x],float)
            c=np.asarray([z["corrected_candidate_logrank"] for z in x],float)
            n=np.asarray([z["corrected_null_logrank"] for z in x],float)
            q=np.asarray([z["per_cell_reduction"] for z in x],float)
            rec["by_construction"][mode]={
                "baseline_candidate_logrank_mean":float(np.mean([z["baseline_candidate_logrank"] for z in x])),
                "baseline_null_logrank_mean":float(np.mean([z["baseline_null_logrank"] for z in x])),
                "baseline_excess_mean":float(np.mean(b)),
                "baseline_excess_median":float(np.median(b)),
                "corrected_candidate_logrank_mean":float(np.mean(c)),
                "corrected_null_logrank_mean":float(np.mean(n)),
                "corrected_excess_mean":float(np.mean(a)),
                "corrected_excess_median":float(np.median(a)),
                "reduction_of_means":float(1-np.mean(a)/np.mean(b)),
                "per_cell_reduction_mean":float(np.mean(q)),
                "per_cell_reduction_median":float(np.median(q)),
                "per_cell_reduction_min":float(np.min(q)),
                "per_cell_reduction_max":float(np.max(q)),
                "ge_25_count":int(np.sum(q>=.25)),
                "ge_50_count":int(np.sum(q>=.50)),
                "cells":9,
            }

        for ds in DATASETS:
            x=[z for z in cells if z["dataset"]==ds]
            if len(x)!=12: raise RuntimeError(f"{rule}/{ds}: expected 12 cells, got {len(x)}")
            b=np.asarray([z["baseline_logrank_excess"] for z in x],float)
            a=np.asarray([z["corrected_logrank_excess"] for z in x],float)
            q=np.asarray([z["per_cell_reduction"] for z in x],float)
            rec["by_dataset"][ds]={
                "baseline_excess_mean":float(np.mean(b)),
                "corrected_excess_mean":float(np.mean(a)),
                "corrected_excess_median":float(np.median(a)),
                "reduction_of_means":float(1-np.mean(a)/np.mean(b)),
                "per_cell_reduction_mean":float(np.mean(q)),
                "per_cell_reduction_median":float(np.median(q)),
                "ge_25_count":int(np.sum(q>=.25)),
                "ge_50_count":int(np.sum(q>=.50)),
                "cells":12,
            }

        # Diagnose the historical manuscript construction-median summary.
        construction_corrected_medians=[
            rec["by_construction"][m]["corrected_excess_median"] for m in MODES
        ]
        construction_baseline_means=[
            rec["by_construction"][m]["baseline_excess_mean"] for m in MODES
        ]
        rec["historical_summary_diagnostic"]={
            "mean_of_four_corrected_construction_medians":float(np.mean(construction_corrected_medians)),
            "mean_of_four_baseline_construction_means":float(np.mean(construction_baseline_means)),
            "mixed_summary_reduction":float(
                1-np.mean(construction_corrected_medians)/np.mean(construction_baseline_means)
            ),
            "warning":(
                "This mixes corrected construction medians with baseline construction means "
                "and is NOT the primary equal-setting estimand."
            ),
        }
        summary["rules"][rule]=rec

    args.out.mkdir(parents=True,exist_ok=True)
    (args.out/"B3_RFPC_OFFICIAL_SUMMARY.json").write_text(json.dumps(summary,indent=2)+"\n")
    with (args.out/"B3_RFPC_OFFICIAL_CELLS.csv").open("w",newline="",encoding="utf8") as fobj:
        fields=list(out_rows[0].keys())
        w=csv.DictWriter(fobj,fieldnames=fields);w.writeheader();w.writerows(out_rows)

    print("=== B3 OFFICIAL W8 REANALYSIS ===")
    print("baseline equal-setting excess",f"{summary['baseline_equal_setting']['logrank_excess']:.10f}")
    for rule in RULES:
        r=summary["rules"][rule]
        e=r["equal_setting"]; pr=r["per_cell_reduction"]; h=r["historical_summary_diagnostic"]
        print(
            rule,
            f"equal-setting residual={e['corrected_excess']:.10f}",
            f"equal-setting reduction={100*e['reduction_ratio_of_equal_setting_means']:.2f}%",
            f"mean cell reduction={100*pr['mean']:.2f}%",
            f"median cell reduction={100*pr['median']:.2f}%",
            f"min={100*pr['min']:.2f}%",
            f"max={100*pr['max']:.2f}%",
            f">=25={pr['ge_25_count']}/36",
            f">=50={pr['ge_50_count']}/36",
        )
        print(
            rule,
            "historical mixed construction summary:",
            f"residual={h['mean_of_four_corrected_construction_medians']:.10f}",
            f"reduction={100*h['mixed_summary_reduction']:.2f}%"
        )
    print(args.out/"B3_RFPC_OFFICIAL_SUMMARY.json")
    print("B3_RFPC_OFFICIAL_OK")

if __name__=="__main__":
    main()
