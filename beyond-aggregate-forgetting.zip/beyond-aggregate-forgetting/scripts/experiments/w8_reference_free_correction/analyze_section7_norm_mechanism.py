#!/usr/bin/env python3
"""Explanatory audit for Section 6/7: degree↔RefA norm and W13 target overshoot.

No model fitting, no new method. Uses the frozen W5/W13 cohort and RefA only
for post-hoc explanation.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[3]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from scripts.experiments.w8_reference_free_correction.run_w8_reference_free_placement import (
    EXPECTED_MODES,
    degree,
    load_model,
)
from scripts.experiments.w8_reference_free_correction.run_w13_reference_free_norm import (
    discover_source_cells,
)

DATASETS=("FB15K-237","CoDEx-M","NELL-995")
SEEDS=(17,29,43)


def rankdata_average(x: np.ndarray) -> np.ndarray:
    x=np.asarray(x,float)
    order=np.argsort(x,kind="mergesort")
    ranks=np.empty(len(x),float)
    i=0
    while i<len(x):
        j=i+1
        while j<len(x) and x[order[j]]==x[order[i]]:
            j+=1
        r=0.5*((i+1)+j)
        ranks[order[i:j]]=r
        i=j
    return ranks


def corr(x,y):
    x=np.asarray(x,float); y=np.asarray(y,float)
    if len(x)<2 or np.std(x)==0 or np.std(y)==0:
        return {"n":int(len(x)),"pearson":None,"spearman":None}
    return {
        "n":int(len(x)),
        "pearson":float(np.corrcoef(x,y)[0,1]),
        "spearman":float(np.corrcoef(rankdata_average(x),rankdata_average(y))[0,1]),
    }


def zscore(x):
    x=np.asarray(x,float)
    s=float(np.std(x))
    return (x-float(np.mean(x)))/s if s>0 else np.zeros_like(x)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--w8-root",type=Path,required=True)
    ap.add_argument("--w13-root",type=Path,required=True)
    ap.add_argument("--data-root",type=Path,required=True)
    ap.add_argument("--out",type=Path,required=True)
    args=ap.parse_args()

    rows=[]
    by_ds=defaultdict(list)

    for ds in DATASETS:
        data=deterministic_holdout(
            load_dataset(*infer_paths(ds,args.data_root)),seed=17
        )
        ne,nr=len(data.entities),len(data.relations)
        predeg=degree(data.train,ne)

        for seed in SEEDS:
            cells=discover_source_cells(args.w8_root,ds,seed)
            for mode in sorted(EXPECTED_MODES):
                cell=cells[mode]
                meta=json.loads((cell/"summary.json").read_text())
                rh=meta["request_hash"]

                w13p=args.w13_root/f"{ds}_s{seed}_{mode}_{rh}_W13.json"
                if not w13p.is_file():
                    raise FileNotFoundError(w13p)
                w13=json.loads(w13p.read_text())
                target=float(w13["fit_diagnostic"]["target_retained_median_norm"])

                z=np.load(cell/"mean_tie_rank_audit.npz",allow_pickle=False)
                fi=np.asarray(z["forget_indices"],dtype=np.int64)
                selected=np.asarray(z["selected_entities"],dtype=np.int64)
                keep=np.ones(len(data.train),dtype=bool)
                keep[fi]=False
                retain=data.train[keep]
                rdeg=degree(retain,ne)
                restarted=np.asarray(selected[rdeg[selected]==0],dtype=np.int64)

                refa=load_model(cell/"RefA_FiniteRetrain20.pt",ne,nr,"cpu")
                ids=torch.as_tensor(restarted,dtype=torch.long)
                refa_norm=(
                    refa.entity.weight.index_select(0,ids)
                    .norm(dim=1).detach().cpu().numpy().astype(float)
                )

                for ent,norm in zip(restarted,refa_norm):
                    rec={
                        "dataset":ds,
                        "seed":int(seed),
                        "request_mode":mode,
                        "request_hash":rh,
                        "entity":int(ent),
                        "predelete_degree":int(predeg[int(ent)]),
                        "log1p_predelete_degree":float(np.log1p(predeg[int(ent)])),
                        "refa_norm":float(norm),
                        "w13_target_norm":target,
                        "target_to_refa_ratio":float(target/norm),
                    }
                    rows.append(rec)
                    by_ds[ds].append(rec)
                del refa

    if not rows:
        raise RuntimeError("no observations")

    result={"observations":len(rows),"by_dataset":{}}
    zdeg=[]; znorm=[]
    for ds in DATASETS:
        rr=by_ds[ds]
        deg=np.asarray([r["log1p_predelete_degree"] for r in rr],float)
        norm=np.asarray([r["refa_norm"] for r in rr],float)
        ratio=np.asarray([r["target_to_refa_ratio"] for r in rr],float)
        result["by_dataset"][ds]={
            "observations":len(rr),
            "degree_refa_norm_correlation_log1p_degree":corr(deg,norm),
            "target_to_refa_ratio":{
                "mean":float(np.mean(ratio)),
                "median":float(np.median(ratio)),
                "q25":float(np.quantile(ratio,.25)),
                "q75":float(np.quantile(ratio,.75)),
                "min":float(np.min(ratio)),
                "max":float(np.max(ratio)),
                "fraction_above_1":float(np.mean(ratio>1.0)),
            },
        }
        zdeg.extend(zscore(deg))
        znorm.extend(zscore(norm))

    allratio=np.asarray([r["target_to_refa_ratio"] for r in rows],float)
    result["overall"]={
        "within_dataset_standardized_degree_refa_norm_correlation":corr(
            np.asarray(zdeg,float),np.asarray(znorm,float)
        ),
        "target_to_refa_ratio":{
            "mean":float(np.mean(allratio)),
            "median":float(np.median(allratio)),
            "q25":float(np.quantile(allratio,.25)),
            "q75":float(np.quantile(allratio,.75)),
            "min":float(np.min(allratio)),
            "max":float(np.max(allratio)),
            "fraction_above_1":float(np.mean(allratio>1.0)),
        },
    }

    args.out.mkdir(parents=True,exist_ok=True)
    (args.out/"SECTION7_NORM_MECHANISM_AUDIT.json").write_text(
        json.dumps(result,indent=2)+"\n"
    )

    import csv
    with (args.out/"SECTION7_NORM_MECHANISM_OBSERVATIONS.csv").open(
        "w",newline="",encoding="utf8"
    ) as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)

    print("=== DEGREE <-> RefA NORM ON Z_U ===")
    for ds in DATASETS:
        q=result["by_dataset"][ds]["degree_refa_norm_correlation_log1p_degree"]
        print(ds,f"n={q['n']}",f"Pearson={q['pearson']:.6f}",f"Spearman={q['spearman']:.6f}")
    q=result["overall"]["within_dataset_standardized_degree_refa_norm_correlation"]
    print("pooled-within-dataset-standardized",f"n={q['n']}",f"Pearson={q['pearson']:.6f}",f"Spearman={q['spearman']:.6f}")

    print("=== W13 TARGET / RefA ENTITY NORM ===")
    q=result["overall"]["target_to_refa_ratio"]
    print(
        f"mean={q['mean']:.6f}",
        f"median={q['median']:.6f}",
        f"IQR=[{q['q25']:.6f},{q['q75']:.6f}]",
        f"range=[{q['min']:.6f},{q['max']:.6f}]",
        f"above1={100*q['fraction_above_1']:.2f}%"
    )
    for ds in DATASETS:
        q=result["by_dataset"][ds]["target_to_refa_ratio"]
        print(ds,f"mean={q['mean']:.6f}",f"median={q['median']:.6f}",f"above1={100*q['fraction_above_1']:.2f}%")
    print(args.out/"SECTION7_NORM_MECHANISM_AUDIT.json")
    print("SECTION7_NORM_MECHANISM_AUDIT_OK")


if __name__=="__main__":
    main()
