#!/usr/bin/env python3
"""Evaluate frozen W13 RetainedNormMedian on the canonical W5 placement probe."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[3]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.unlearn import affected_region
from scripts.experiments.w8_reference_free_correction.run_w8_reference_free_placement import (
    EXPECTED_MODES,
    degree,
    load_model,
    find_placement_csv,
    load_placement_rows,
    evaluate_placement,
)
from scripts.experiments.w8_reference_free_correction.run_w13_reference_free_norm import (
    discover_source_cells,
    apply_retained_norm_median,
)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True, choices=["FB15K-237","CoDEx-M","NELL-995"])
    ap.add_argument("--seed", required=True, type=int, choices=[17,29,43])
    ap.add_argument("--w8-root", type=Path, required=True)
    ap.add_argument("--placement-root", type=Path, required=True)
    ap.add_argument("--data-root", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--entity-chunk", type=int, default=4096)
    args = ap.parse_args()

    torch.set_num_threads(1)
    data = deterministic_holdout(
        load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17
    )
    ne, nr = len(data.entities), len(data.relations)
    cells = discover_source_cells(args.w8_root, args.dataset, args.seed)
    args.out.mkdir(parents=True, exist_ok=True)

    done = []
    for mode in sorted(EXPECTED_MODES):
        source_cell = cells[mode]
        meta = json.loads((source_cell / "summary.json").read_text())
        rh = meta["request_hash"]

        z = np.load(source_cell / "mean_tie_rank_audit.npz", allow_pickle=False)
        fi = np.asarray(z["forget_indices"], dtype=np.int64)
        selected = np.asarray(z["selected_entities"], dtype=np.int64)

        keep = np.ones(len(data.train), dtype=bool)
        keep[fi] = False
        retain = data.train[keep]
        rdeg = degree(retain, ne)
        restarted = np.asarray(selected[rdeg[selected] == 0], dtype=np.int64)
        if len(restarted) == 0:
            raise RuntimeError(f"{mode}: no restarted zero-support entities")

        ae, _, _, check_retain = affected_region(data.train, fi, 1)
        if not np.array_equal(retain, check_retain):
            raise RuntimeError(f"{mode}: retained graph mismatch")

        model = load_model(
            source_cell / "SchemaCert_plus_Restart_L5.pt", ne, nr, args.device
        )
        fit_diag = apply_retained_norm_median(model, restarted, ae, rdeg)

        placement_csv = find_placement_csv(
            args.placement_root, args.dataset, args.seed, mode, rh
        )
        rows = load_placement_rows(placement_csv)
        zero = np.zeros(ne, dtype=np.float32)
        did, baseline_did, did_values = evaluate_placement(
            model, rows, zero, restarted, ne,
            args.device, args.batch, args.entity_chunk
        )

        rec = {
            "protocol": "W13-placement-on-canonical-W5-probe-v1",
            "dataset": args.dataset,
            "seed": args.seed,
            "request_mode": mode,
            "request_hash": rh,
            "source_cell": str(source_cell),
            "placement_csv": str(placement_csv),
            "n_restarted": int(len(restarted)),
            "baseline_placement_did": float(baseline_did),
            "w13_placement_did": float(did),
            "absolute_baseline_did": float(abs(baseline_did)),
            "absolute_w13_did": float(abs(did)),
            "absolute_reduction_to_zero": (
                float(1.0 - abs(did) / abs(baseline_did))
                if baseline_did != 0 else None
            ),
            "fit_diagnostic": fit_diag,
            "n_probe_values": int(len(did_values)),
        }

        stem = f"{args.dataset}_s{args.seed}_{mode}_{rh}_W13_PLACEMENT"
        (args.out / f"{stem}.json").write_text(json.dumps(rec, indent=2) + "\n")
        np.savez_compressed(
            args.out / f"{stem}.npz",
            placement_did_values=np.asarray(did_values, dtype=np.float64),
        )
        done.append(rec)

        print(
            "W13_PLACEMENT_CELL_OK", args.dataset, args.seed, mode, rh,
            "baseline", f"{baseline_did:.10f}",
            "W13", f"{did:.10f}",
            "abs_reduction", f"{rec['absolute_reduction_to_zero']:.6f}",
            flush=True,
        )

        del model
        if args.device.startswith("cuda"):
            torch.cuda.empty_cache()

    (args.out / f"{args.dataset}_s{args.seed}_W13_PLACEMENT_COMPLETE.json").write_text(
        json.dumps({"dataset":args.dataset,"seed":args.seed,"cells":done}, indent=2) + "\n"
    )
    print("W13_PLACEMENT_DATASET_SEED_OK", args.dataset, args.seed, flush=True)


if __name__ == "__main__":
    main()
