#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

# Make the repository root importable when this file is executed directly by path.
REPO_ROOT = Path(__file__).resolve().parents[3]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scripts.experiments.w8_reference_free_correction.run_w8_reference_free_placement import (
    EXPECTED_MODES,
    discover_cells,
    find_placement_csv,
)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results-root", type=Path, required=True)
    ap.add_argument("--placement-root", type=Path, required=True)
    args = ap.parse_args()

    total = 0
    for dataset in ("FB15K-237", "CoDEx-M", "NELL-995"):
        for seed in (17, 29, 43):
            cells = discover_cells(args.results_root, dataset, seed)
            for mode in sorted(EXPECTED_MODES):
                cell = cells[mode]
                meta = json.loads((cell / "summary.json").read_text())
                rh = meta["request_hash"]
                p = find_placement_csv(args.placement_root, dataset, seed, mode, rh)
                print(
                    "W8_PREFLIGHT_CELL_OK",
                    dataset, seed, mode, rh,
                    "cell", cell,
                    "placement", p,
                )
                total += 1

    if total != 36:
        raise RuntimeError(f"Expected 36 cells, got {total}")
    print("W8_PREFLIGHT_ALL_OK cells=36")


if __name__ == "__main__":
    main()
