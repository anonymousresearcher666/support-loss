#!/usr/bin/env python3
"""W12: decompose restart-scale mismatch and RFPC on the primary 36-cell grid.

For one dataset/seed task this script evaluates all four W5 request modes:
  - R+L baseline (from frozen W5 ranks)
  - NormOracle: only restarted Z_U entity rows are rescaled to RefA row norms
  - historical RFPC median/mean (read from frozen W8 artifacts)
  - NormOracle + refitted RFPC median/mean

No retraining is performed. RefA is used only by NormOracle and final evaluation.
RFPC refitting uses only the norm-corrected candidate, retained graph, deletion
metadata, original degrees, and the exact frozen W8 seeds/protocol.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import sys
from pathlib import Path

REPO_ROOT=Path(__file__).resolve().parents[3]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0,str(REPO_ROOT))

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.unlearn import affected_region
from scripts.experiments.w8_reference_free_correction.run_w8_reference_free_placement import (
    EXPECTED_MODES,
    degree,
    load_model,
    matched_controls_k,
    estimate_deltas,
    rank_both_corrected,
    pair_metrics,
    sha_seed,
)

RULES=("median","mean")


def sha256_file(path:Path)->str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()


def discover_w8(w8_root:Path,dataset:str,seed:int):
    out={}
    base=w8_root/dataset/f"seed{seed}"
    if not base.is_dir():
        raise FileNotFoundError(base)
    for d in sorted(base.iterdir()):
        if not d.is_dir(): continue
        js=d/"W8_REFERENCE_FREE_A_median.json"
        if not js.is_file(): continue
        rec=json.loads(js.read_text())
        mode=rec["request_mode"]
        if mode in out:
            raise RuntimeError(f"duplicate W8 mode {mode}: {out[mode]} and {d}")
        out[mode]=d
    if set(out)!=set(EXPECTED_MODES):
        raise RuntimeError(f"{dataset} s{seed}: W8 modes={sorted(out)} expected={sorted(EXPECTED_MODES)}")
    return out


@torch.no_grad()
def apply_norm_oracle(model, refa_model, restarted:np.ndarray):
    before=model.entity.weight.detach().clone()
    ids=torch.as_tensor(restarted,dtype=torch.long,device=model.entity.weight.device)
    rows=model.entity.weight.index_select(0,ids)
    target=refa_model.entity.weight.index_select(0,ids)
    rn=rows.norm(dim=1,keepdim=True)
    tn=target.norm(dim=1,keepdim=True)
    if torch.any(rn<=0):
        raise RuntimeError("zero candidate norm in NormOracle")
    scaled=rows*(tn/rn)
    model.entity.weight.index_copy_(0,ids,scaled)

    after=model.entity.weight.detach()
    mask=torch.ones(after.shape[0],dtype=torch.bool,device=after.device)
    mask[ids]=False
    if not torch.equal(before[mask],after[mask]):
        raise RuntimeError("NormOracle modified non-restarted rows")
    if len(restarted) and torch.equal(before[ids],after[ids]):
        raise RuntimeError("NormOracle changed no restarted row")

    got=after.index_select(0,ids).norm(dim=1)
    want=target.norm(dim=1)
    max_abs=float(torch.max(torch.abs(got-want)).detach().cpu()) if len(restarted) else 0.0
    return {
        "median_norm_before":float(torch.median(before.index_select(0,ids).norm(dim=1)).cpu()),
        "median_norm_after":float(torch.median(got).cpu()),
        "median_norm_refa":float(torch.median(want).cpu()),
        "max_abs_norm_error":max_abs,
        "nonrestarted_bit_identical":True,
    }


def rank_dict_from_npz(z,prefix):
    return {
        "head":np.asarray(z[f"{prefix}_head_rank"],dtype=float),
        "tail":np.asarray(z[f"{prefix}_tail_rank"],dtype=float),
    }


def w5_rank_dict(z,prefix):
    return {
        "head":np.asarray(z[f"{prefix}_head_mean_tie_rank"],dtype=float),
        "tail":np.asarray(z[f"{prefix}_tail_mean_tie_rank"],dtype=float),
    }


def metrics(candidate,refa,refb):
    c=pair_metrics(candidate,refa)
    n=pair_metrics(refb,refa)
    return {
        "candidate_logrank":c["mean_abs_log10_rank_gap"],
        "null_logrank":n["mean_abs_log10_rank_gap"],
        "logrank_excess":c["mean_abs_log10_rank_gap"]-n["mean_abs_log10_rank_gap"],
        "candidate_mrr_gap":c["mrr_gap"],
        "null_mrr_gap":n["mrr_gap"],
        "mrr_excess":c["mrr_gap"]-n["mrr_gap"],
        "candidate_top10":c["top10_membership_disagreement"],
        "null_top10":n["top10_membership_disagreement"],
        "top10_excess":c["top10_membership_disagreement"]-n["top10_membership_disagreement"],
        "candidate_top100":c["top100_membership_disagreement"],
        "null_top100":n["top100_membership_disagreement"],
        "top100_excess":c["top100_membership_disagreement"]-n["top100_membership_disagreement"],
    }


def changed_fraction(a,b):
    ah=np.asarray(a["head"]);at=np.asarray(a["tail"])
    bh=np.asarray(b["head"]);bt=np.asarray(b["tail"])
    return {
        "rank_changed":int(np.sum(ah!=bh)+np.sum(at!=bt)),
        "rank_total":int(ah.size+at.size),
        "rank_changed_fraction":float((np.sum(ah!=bh)+np.sum(at!=bt))/(ah.size+at.size)),
    }


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--dataset",required=True,choices=["FB15K-237","CoDEx-M","NELL-995"])
    ap.add_argument("--seed",required=True,type=int,choices=[17,29,43])
    ap.add_argument("--w8-root",type=Path,required=True)
    ap.add_argument("--data-root",type=Path,required=True)
    ap.add_argument("--out",type=Path,required=True)
    ap.add_argument("--device",default="cuda:0")
    ap.add_argument("--batch",type=int,default=16)
    ap.add_argument("--entity-chunk",type=int,default=4096)
    args=ap.parse_args()

    torch.set_num_threads(1)
    data=deterministic_holdout(load_dataset(*infer_paths(args.dataset,args.data_root)),seed=17)
    ne,nr=len(data.entities),len(data.relations)
    cells=discover_w8(args.w8_root,args.dataset,args.seed)
    args.out.mkdir(parents=True,exist_ok=True)

    summaries=[]
    for mode in sorted(EXPECTED_MODES):
        w8dir=cells[mode]
        med_js=w8dir/"W8_REFERENCE_FREE_A_median.json"
        mean_js=w8dir/"W8_REFERENCE_FREE_A_mean.json"
        med_rec=json.loads(med_js.read_text())
        mean_rec=json.loads(mean_js.read_text())
        if med_rec["request_hash"]!=mean_rec["request_hash"]:
            raise RuntimeError("median/mean request hash mismatch")
        rh=med_rec["request_hash"]
        source_cell=Path(med_rec["source_cell"])
        if Path(mean_rec["source_cell"])!=source_cell:
            raise RuntimeError("median/mean source_cell mismatch")

        required=[
            source_cell/"SchemaCert_plus_Restart_L5.pt",
            source_cell/"RefA_FiniteRetrain20.pt",
            source_cell/"RefB_IndependentRetrain20.pt",
            source_cell/"mean_tie_rank_audit.npz",
            med_js.with_suffix(".npz"),
            mean_js.with_suffix(".npz"),
        ]
        for p in required:
            if not p.is_file(): raise FileNotFoundError(p)

        w5=np.load(source_cell/"mean_tie_rank_audit.npz",allow_pickle=False)
        fi=np.asarray(w5["forget_indices"],dtype=np.int64)
        selected=np.asarray(w5["selected_entities"],dtype=np.int64)
        queries=np.asarray(w5["queries"],dtype=np.int64)
        keep=np.ones(len(data.train),dtype=bool);keep[fi]=False
        retain=data.train[keep]
        rdeg=degree(retain,ne)
        predeg=degree(data.train,ne)
        restarted=np.asarray(selected[rdeg[selected]==0],dtype=np.int64)

        med_npz=np.load(med_js.with_suffix(".npz"),allow_pickle=False)
        mean_npz=np.load(mean_js.with_suffix(".npz"),allow_pickle=False)
        saved_restarted=np.asarray(med_npz["restarted_entities"],dtype=np.int64)
        if not np.array_equal(restarted,saved_restarted):
            raise RuntimeError(f"{mode}: restarted entity mismatch W5/W8")
        if not np.array_equal(saved_restarted,np.asarray(mean_npz["restarted_entities"],dtype=np.int64)):
            raise RuntimeError(f"{mode}: median/mean restarted mismatch")
        if not np.array_equal(queries,np.asarray(med_npz["forgotten_queries"],dtype=np.int64)):
            raise RuntimeError(f"{mode}: W5/W8 query mismatch")

        refa_ranks=w5_rank_dict(w5,"refA")
        refb_ranks=w5_rank_dict(w5,"refB")
        rl_ranks=w5_rank_dict(w5,"candidate")
        base_metrics=metrics(rl_ranks,refa_ranks,refb_ranks)

        hist={}
        for rule,z in (("median",med_npz),("mean",mean_npz)):
            rr=rank_dict_from_npz(z,"candidate")
            hist[rule]={**metrics(rr,refa_ranks,refb_ranks),**changed_fraction(rl_ranks,rr)}

        candidate=load_model(source_cell/"SchemaCert_plus_Restart_L5.pt",ne,nr,args.device)
        refa_model=load_model(source_cell/"RefA_FiniteRetrain20.pt",ne,nr,args.device)
        norm_model=copy.deepcopy(candidate)
        norm_diag=apply_norm_oracle(norm_model,refa_model,restarted)

        zero=np.zeros(ne,dtype=np.float32)
        truth=(retain,data.valid,data.test,data.train[fi])
        norm_ranks=rank_both_corrected(
            norm_model,queries,zero,ne,truth,args.device,args.batch,args.entity_chunk
        )
        norm_metrics={**metrics(norm_ranks,refa_ranks,refb_ranks),**changed_fraction(rl_ranks,norm_ranks)}

        ae,_,_,check_retain=affected_region(data.train,fi,1)
        if not np.array_equal(retain,check_retain):
            raise RuntimeError("retained graph mismatch")
        controls_seed=sha_seed(args.dataset,args.seed,mode,rh,"placement-controls-v1")
        controls,eligible=matched_controls_k(
            restarted,ae,rdeg,predeg,20,controls_seed
        )
        context_seed=sha_seed(args.dataset,args.seed,mode,rh,"placement-cal-v1")
        biases,bg=estimate_deltas(
            norm_model,retain,restarted,controls,eligible,ne,args.device,
            200,context_seed
        )
        saved_bg=np.asarray(med_npz["background_triples"],dtype=np.int64)
        if not np.array_equal(bg,saved_bg):
            raise RuntimeError(f"{mode}: refit background triples differ from frozen W8")
        if not np.array_equal(saved_bg,np.asarray(mean_npz["background_triples"],dtype=np.int64)):
            raise RuntimeError(f"{mode}: historical median/mean background mismatch")

        both={}
        for rule in RULES:
            rr=rank_both_corrected(
                norm_model,queries,biases[rule],ne,truth,
                args.device,args.batch,args.entity_chunk
            )
            both[rule]={
                **metrics(rr,refa_ranks,refb_ranks),
                **changed_fraction(rl_ranks,rr),
                "delta_mean":float(np.mean(biases[rule][restarted])),
                "delta_median":float(np.median(biases[rule][restarted])),
            }

        e0=base_metrics["logrank_excess"]
        en=norm_metrics["logrank_excess"]
        summary={
            "dataset":args.dataset,"seed":args.seed,"request_mode":mode,"request_hash":rh,
            "source_cell":str(source_cell),
            "source_hashes":{
                "candidate":sha256_file(source_cell/"SchemaCert_plus_Restart_L5.pt"),
                "refA":sha256_file(source_cell/"RefA_FiniteRetrain20.pt"),
                "refB":sha256_file(source_cell/"RefB_IndependentRetrain20.pt"),
                "w8_median_json":sha256_file(med_js),
                "w8_median_npz":sha256_file(med_js.with_suffix(".npz")),
                "w8_mean_json":sha256_file(mean_js),
                "w8_mean_npz":sha256_file(mean_js.with_suffix(".npz")),
            },
            "n_restarted":int(len(restarted)),
            "norm_diagnostic":norm_diag,
            "R+L":base_metrics,
            "NormOracle":norm_metrics,
            "RFPC_historical":hist,
            "NormOracle_plus_RFPC_refit":both,
            "decomposition":{
                "R_scale":float(1-en/e0) if e0!=0 else None,
                "median_R_rfpc":float(1-hist["median"]["logrank_excess"]/e0) if e0!=0 else None,
                "mean_R_rfpc":float(1-hist["mean"]["logrank_excess"]/e0) if e0!=0 else None,
                "median_R_rfpc_given_scale":float((en-both["median"]["logrank_excess"])/en) if en!=0 else None,
                "mean_R_rfpc_given_scale":float((en-both["mean"]["logrank_excess"])/en) if en!=0 else None,
            },
        }
        outp=args.out/f"{args.dataset}_s{args.seed}_{mode}_{rh}_W12.json"
        outp.write_text(json.dumps(summary,indent=2)+"\n")
        summaries.append(summary)
        print(
            "W12_CELL_OK",args.dataset,args.seed,mode,rh,
            "E0",f"{e0:.10f}",
            "ENorm",f"{en:.10f}",
            "ENormMed",f"{both['median']['logrank_excess']:.10f}",
            "ENormMean",f"{both['mean']['logrank_excess']:.10f}",
            "Rscale",f"{summary['decomposition']['R_scale']:.6f}",
            "Rmed|scale",f"{summary['decomposition']['median_R_rfpc_given_scale']:.6f}",
            "Rmean|scale",f"{summary['decomposition']['mean_R_rfpc_given_scale']:.6f}",
            flush=True,
        )

        del candidate,refa_model,norm_model
        if args.device.startswith("cuda"):
            torch.cuda.empty_cache()

    (args.out/f"{args.dataset}_s{args.seed}_W12_COMPLETE.json").write_text(
        json.dumps({"dataset":args.dataset,"seed":args.seed,"cells":summaries},indent=2)+"\n"
    )
    print("W12_DATASET_SEED_OK",args.dataset,args.seed,flush=True)


if __name__=="__main__":
    main()
