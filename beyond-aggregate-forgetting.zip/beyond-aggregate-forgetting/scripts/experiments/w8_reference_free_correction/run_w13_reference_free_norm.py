#!/usr/bin/env python3
"""W13: reference-free retained-norm matching on the primary 36-cell grid."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[3]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.unlearn import affected_region
from scripts.experiments.w8_reference_free_correction.run_w8_reference_free_placement import (
    EXPECTED_MODES,
    degree,
    load_model,
    rank_both_corrected,
    pair_metrics,
    sample_fixed,
    mrr,
)

EVAL_SEED = 19092026
TEST_QUERIES = 1000


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def discover_source_cells(w8_root: Path, dataset: str, seed: int) -> dict[str, Path]:
    out = {}
    base = w8_root / dataset / f"seed{seed}"
    if not base.is_dir():
        raise FileNotFoundError(base)
    for d in sorted(base.iterdir()):
        if not d.is_dir():
            continue
        js = d / "W8_REFERENCE_FREE_A_median.json"
        if not js.is_file():
            continue
        rec = json.loads(js.read_text())
        mode = rec["request_mode"]
        cell = Path(rec["source_cell"])
        if mode in out and out[mode] != cell:
            raise RuntimeError(f"duplicate W5 source for {mode}: {out[mode]} vs {cell}")
        out[mode] = cell
    if set(out) != set(EXPECTED_MODES):
        raise RuntimeError(
            f"{dataset} s{seed}: modes={sorted(out)} expected={sorted(EXPECTED_MODES)}"
        )
    return out


def w5_rank_dict(z, prefix: str):
    return {
        "head": np.asarray(z[f"{prefix}_head_mean_tie_rank"], dtype=float),
        "tail": np.asarray(z[f"{prefix}_tail_mean_tie_rank"], dtype=float),
    }


def metrics(candidate, refa, refb):
    c = pair_metrics(candidate, refa)
    n = pair_metrics(refb, refa)
    return {
        "candidate_logrank": c["mean_abs_log10_rank_gap"],
        "null_logrank": n["mean_abs_log10_rank_gap"],
        "logrank_excess": c["mean_abs_log10_rank_gap"] - n["mean_abs_log10_rank_gap"],
        "candidate_mrr_gap": c["mrr_gap"],
        "null_mrr_gap": n["mrr_gap"],
        "mrr_excess": c["mrr_gap"] - n["mrr_gap"],
        "candidate_top10": c["top10_membership_disagreement"],
        "null_top10": n["top10_membership_disagreement"],
        "top10_excess": c["top10_membership_disagreement"] - n["top10_membership_disagreement"],
        "candidate_top100": c["top100_membership_disagreement"],
        "null_top100": n["top100_membership_disagreement"],
        "top100_excess": c["top100_membership_disagreement"] - n["top100_membership_disagreement"],
    }


def changed_fraction(a, b):
    ah, at = np.asarray(a["head"]), np.asarray(a["tail"])
    bh, bt = np.asarray(b["head"]), np.asarray(b["tail"])
    changed = int(np.sum(ah != bh) + np.sum(at != bt))
    total = int(ah.size + at.size)
    return {
        "rank_changed": changed,
        "rank_total": total,
        "rank_changed_fraction": float(changed / total),
    }


@torch.no_grad()
def apply_retained_norm_median(
    model,
    restarted: np.ndarray,
    affected_entities: np.ndarray,
    retained_degree: np.ndarray,
):
    """Scale Z_U rows to the median norm of supported unaffected candidate rows."""
    entity_before = model.entity.weight.detach().clone()
    relation_before = model.relation.weight.detach().clone()

    ne = entity_before.shape[0]
    restarted = np.asarray(restarted, dtype=np.int64)
    affected_entities = np.asarray(affected_entities, dtype=np.int64)

    blocked = np.zeros(ne, dtype=bool)
    blocked[affected_entities] = True
    pool = np.flatnonzero((retained_degree > 0) & (~blocked))
    if len(pool) == 0:
        raise RuntimeError("empty RetainedNormMedian calibration pool")

    all_norms = entity_before.norm(dim=1).detach().cpu().numpy().astype(np.float64)
    target_norm = float(np.median(all_norms[pool]))
    if not np.isfinite(target_norm) or target_norm <= 0:
        raise RuntimeError(f"invalid target norm {target_norm}")

    ids = torch.as_tensor(restarted, dtype=torch.long, device=model.entity.weight.device)
    rows = model.entity.weight.index_select(0, ids)
    row_norms = rows.norm(dim=1, keepdim=True)
    if torch.any(row_norms <= 0):
        raise RuntimeError("zero restarted-row norm")

    target = torch.full_like(row_norms, target_norm)
    scaled = rows * (target / row_norms)
    model.entity.weight.index_copy_(0, ids, scaled)

    after = model.entity.weight.detach()
    mask = torch.ones(ne, dtype=torch.bool, device=after.device)
    mask[ids] = False
    if not torch.equal(entity_before[mask], after[mask]):
        raise RuntimeError("RetainedNormMedian modified non-Z_U entity rows")
    if not torch.equal(relation_before, model.relation.weight.detach()):
        raise RuntimeError("RetainedNormMedian modified relation parameters")

    got = after.index_select(0, ids).norm(dim=1)
    max_abs = float(torch.max(torch.abs(got - target.squeeze(1))).cpu()) if len(restarted) else 0.0

    restart_before = entity_before.index_select(0, ids).norm(dim=1).cpu().numpy()
    scale_factors = target_norm / restart_before

    return {
        "pool_size": int(len(pool)),
        "target_retained_median_norm": target_norm,
        "median_restarted_norm_before": float(np.median(restart_before)),
        "median_restarted_norm_after": float(np.median(got.cpu().numpy())),
        "median_scale_factor": float(np.median(scale_factors)),
        "min_scale_factor": float(np.min(scale_factors)),
        "max_scale_factor": float(np.max(scale_factors)),
        "max_abs_target_norm_error": max_abs,
        "non_restarted_entity_rows_bit_identical": True,
        "relation_parameters_bit_identical": True,
        "pool_definition": "retained_degree>0 AND entity not in affected_region",
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True, choices=["FB15K-237", "CoDEx-M", "NELL-995"])
    ap.add_argument("--seed", required=True, type=int, choices=[17, 29, 43])
    ap.add_argument("--w8-root", type=Path, required=True)
    ap.add_argument("--data-root", type=Path, required=True)
    ap.add_argument("--w12-root", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--entity-chunk", type=int, default=4096)
    args = ap.parse_args()

    torch.set_num_threads(1)
    data = deterministic_holdout(
        load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17
    )
    ne, nr = len(data.entities), len(data.relations)
    cells = discover_source_cells(args.w8_root, args.dataset, args.seed)
    args.out.mkdir(parents=True, exist_ok=True)

    summaries = []
    for mode in sorted(EXPECTED_MODES):
        source_cell = cells[mode]
        meta = json.loads((source_cell / "summary.json").read_text())
        rh = meta["request_hash"]

        required = [
            source_cell / "SchemaCert_plus_Restart_L5.pt",
            source_cell / "RefA_FiniteRetrain20.pt",
            source_cell / "RefB_IndependentRetrain20.pt",
            source_cell / "mean_tie_rank_audit.npz",
        ]
        for p in required:
            if not p.is_file():
                raise FileNotFoundError(p)

        w12_path = args.w12_root / f"{args.dataset}_s{args.seed}_{mode}_{rh}_W12.json"
        if not w12_path.is_file():
            raise FileNotFoundError(w12_path)
        w12 = json.loads(w12_path.read_text())

        z = np.load(source_cell / "mean_tie_rank_audit.npz", allow_pickle=False)
        fi = np.asarray(z["forget_indices"], dtype=np.int64)
        selected = np.asarray(z["selected_entities"], dtype=np.int64)
        queries = np.asarray(z["queries"], dtype=np.int64)

        keep = np.ones(len(data.train), dtype=bool)
        keep[fi] = False
        retain = data.train[keep]
        rdeg = degree(retain, ne)
        restarted = np.asarray(selected[rdeg[selected] == 0], dtype=np.int64)
        if len(restarted) == 0:
            raise RuntimeError(f"{mode}: no restarted zero-support entities")

        affected_entities, _, _, check_retain = affected_region(data.train, fi, 1)
        if not np.array_equal(retain, check_retain):
            raise RuntimeError(f"{mode}: retained graph mismatch")

        refa_ranks = w5_rank_dict(z, "refA")
        refb_ranks = w5_rank_dict(z, "refB")
        rl_ranks = w5_rank_dict(z, "candidate")

        candidate = load_model(
            source_cell / "SchemaCert_plus_Restart_L5.pt", ne, nr, args.device
        )

        # FITTING: candidate + retained graph + deletion metadata only.
        fit_diag = apply_retained_norm_median(
            candidate, restarted, affected_entities, rdeg
        )

        # EVALUATION begins only after the correction is frozen.
        refa_model = load_model(
            source_cell / "RefA_FiniteRetrain20.pt", ne, nr, args.device
        )
        ids = torch.as_tensor(restarted, dtype=torch.long, device=args.device)
        refa_restart_norms = (
            refa_model.entity.weight.index_select(0, ids).norm(dim=1).detach().cpu().numpy()
        )
        fit_diag["median_refa_restarted_norm_evaluation_only"] = float(
            np.median(refa_restart_norms)
        )
        fit_diag["target_to_refa_median_ratio_evaluation_only"] = float(
            fit_diag["target_retained_median_norm"] / np.median(refa_restart_norms)
        )

        zero = np.zeros(ne, dtype=np.float32)
        truth_forgotten = (retain, data.valid, data.test, data.train[fi])
        corrected_ranks = rank_both_corrected(
            candidate, queries, zero, ne, truth_forgotten,
            args.device, args.batch, args.entity_chunk
        )
        corrected_metrics = {
            **metrics(corrected_ranks, refa_ranks, refb_ranks),
            **changed_fraction(rl_ranks, corrected_ranks),
        }

        test_q = sample_fixed(data.test, TEST_QUERIES, EVAL_SEED)
        truth_test = (retain, data.valid, data.test)
        rl_model = load_model(
            source_cell / "SchemaCert_plus_Restart_L5.pt", ne, nr, args.device
        )
        base_test_ranks = rank_both_corrected(
            rl_model, test_q, zero, ne, truth_test,
            args.device, args.batch, args.entity_chunk
        )
        corr_test_ranks = rank_both_corrected(
            candidate, test_q, zero, ne, truth_test,
            args.device, args.batch, args.entity_chunk
        )
        base_test_mrr = mrr(base_test_ranks)
        corr_test_mrr = mrr(corr_test_ranks)

        e0 = float(w12["R+L"]["logrank_excess"])
        eo = float(w12["NormOracle"]["logrank_excess"])
        er = float(corrected_metrics["logrank_excess"])
        oracle_gain = e0 - eo
        rf_gain = e0 - er

        summary = {
            "protocol": "W13-reference-free-retained-norm-median-v1",
            "fitting_reference_free": True,
            "dataset": args.dataset,
            "seed": args.seed,
            "request_mode": mode,
            "request_hash": rh,
            "source_cell": str(source_cell),
            "n_restarted": int(len(restarted)),
            "fit_diagnostic": fit_diag,
            "R+L": w12["R+L"],
            "NormOracle_evaluation_only": w12["NormOracle"],
            "RetainedNormMedian": corrected_metrics,
            "test_utility": {
                "n_queries": int(len(test_q)),
                "eval_seed": EVAL_SEED,
                "baseline_test_mrr": float(base_test_mrr),
                "corrected_test_mrr": float(corr_test_mrr),
                "test_mrr_change": float(corr_test_mrr - base_test_mrr),
            },
            "comparison": {
                "reference_free_reduction": float(1.0 - er / e0) if e0 != 0 else None,
                "oracle_reduction": float(1.0 - eo / e0) if e0 != 0 else None,
                "oracle_gain": float(oracle_gain),
                "reference_free_gain": float(rf_gain),
                "fraction_oracle_gain_recovered": (
                    float(rf_gain / oracle_gain) if oracle_gain != 0 else None
                ),
                "absolute_gap_to_oracle_excess": float(er - eo),
            },
            "provenance": {
                "candidate_sha256": sha256_file(source_cell / "SchemaCert_plus_Restart_L5.pt"),
                "refA_sha256_evaluation_only": sha256_file(source_cell / "RefA_FiniteRetrain20.pt"),
                "refB_sha256_evaluation_only": sha256_file(source_cell / "RefB_IndependentRetrain20.pt"),
                "w5_rank_artifact_sha256": sha256_file(source_cell / "mean_tie_rank_audit.npz"),
                "w12_json_sha256": sha256_file(w12_path),
            },
        }

        outp = args.out / f"{args.dataset}_s{args.seed}_{mode}_{rh}_W13.json"
        outp.write_text(json.dumps(summary, indent=2) + "\n")
        summaries.append(summary)

        print(
            "W13_CELL_OK", args.dataset, args.seed, mode, rh,
            "E0", f"{e0:.10f}",
            "ERF", f"{er:.10f}",
            "EOracle", f"{eo:.10f}",
            "RRF", f"{summary['comparison']['reference_free_reduction']:.6f}",
            "OracleGainRecovered", f"{summary['comparison']['fraction_oracle_gain_recovered']:.6f}",
            "TargetNorm", f"{fit_diag['target_retained_median_norm']:.6f}",
            "RestartBefore", f"{fit_diag['median_restarted_norm_before']:.6f}",
            "RefAMedian", f"{fit_diag['median_refa_restarted_norm_evaluation_only']:.6f}",
            "TestDelta", f"{summary['test_utility']['test_mrr_change']:.8f}",
            flush=True,
        )

        del candidate, refa_model, rl_model
        if args.device.startswith("cuda"):
            torch.cuda.empty_cache()

    (args.out / f"{args.dataset}_s{args.seed}_W13_COMPLETE.json").write_text(
        json.dumps(
            {"dataset": args.dataset, "seed": args.seed, "cells": summaries},
            indent=2,
        ) + "\n"
    )
    print("W13_DATASET_SEED_OK", args.dataset, args.seed, flush=True)


if __name__ == "__main__":
    main()
