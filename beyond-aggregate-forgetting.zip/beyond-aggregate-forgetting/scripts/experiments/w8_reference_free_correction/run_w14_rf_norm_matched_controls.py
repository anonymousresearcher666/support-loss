#!/usr/bin/env python3
"""W14: matched-control reference-free norm calibration (RF-NORM)."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[3]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.unlearn import affected_region
from scripts.experiments.w8_reference_free_correction.run_w8_reference_free_placement import (
    EXPECTED_MODES,
    degree,
    load_model,
    matched_controls_k,
    rank_both_corrected,
    pair_metrics,
    sample_fixed,
    mrr,
    sha_seed,
)

EVAL_SEED = 19092026
TEST_QUERIES = 1000
K_CONTROLS = 20


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def sha256_array(x: np.ndarray) -> str:
    y = np.ascontiguousarray(x)
    return hashlib.sha256(y.tobytes()).hexdigest()


def discover_w8(w8_root: Path, dataset: str, seed: int) -> dict[str, Path]:
    out = {}
    base = w8_root / dataset / f"seed{seed}"
    if not base.is_dir():
        raise FileNotFoundError(base)
    for d in sorted(base.iterdir()):
        if not d.is_dir():
            continue
        js = d / "W8_REFERENCE_FREE_A_median.json"
        if not js.is_file():
            continue
        rec = json.loads(js.read_text())
        mode = rec["request_mode"]
        if mode in out:
            raise RuntimeError(f"duplicate W8 mode {mode}: {out[mode]} and {d}")
        out[mode] = d
    if set(out) != set(EXPECTED_MODES):
        raise RuntimeError(
            f"{dataset} s{seed}: W8 modes={sorted(out)} expected={sorted(EXPECTED_MODES)}"
        )
    return out


def w5_rank_dict(z, prefix: str):
    return {
        "head": np.asarray(z[f"{prefix}_head_mean_tie_rank"], dtype=float),
        "tail": np.asarray(z[f"{prefix}_tail_mean_tie_rank"], dtype=float),
    }


def metrics(candidate, refa, refb):
    c = pair_metrics(candidate, refa)
    n = pair_metrics(refb, refa)
    return {
        "candidate_logrank": c["mean_abs_log10_rank_gap"],
        "null_logrank": n["mean_abs_log10_rank_gap"],
        "logrank_excess": c["mean_abs_log10_rank_gap"] - n["mean_abs_log10_rank_gap"],
        "candidate_mrr_gap": c["mrr_gap"],
        "null_mrr_gap": n["mrr_gap"],
        "mrr_excess": c["mrr_gap"] - n["mrr_gap"],
        "candidate_top10": c["top10_membership_disagreement"],
        "null_top10": n["top10_membership_disagreement"],
        "top10_excess": c["top10_membership_disagreement"] - n["top10_membership_disagreement"],
        "candidate_top100": c["top100_membership_disagreement"],
        "null_top100": n["top100_membership_disagreement"],
        "top100_excess": c["top100_membership_disagreement"] - n["top100_membership_disagreement"],
    }


def changed_fraction(a, b):
    ah, at = np.asarray(a["head"]), np.asarray(a["tail"])
    bh, bt = np.asarray(b["head"]), np.asarray(b["tail"])
    changed = int(np.sum(ah != bh) + np.sum(at != bt))
    total = int(ah.size + at.size)
    return {
        "rank_changed": changed,
        "rank_total": total,
        "rank_changed_fraction": float(changed / total),
    }


@torch.no_grad()
def apply_control_norm_median(
    model,
    restarted: np.ndarray,
    controls: np.ndarray,
    predelete_degree: np.ndarray,
):
    """Scale each restarted row to median norm of its matched controls C_v."""
    restarted = np.asarray(restarted, dtype=np.int64)
    controls = np.asarray(controls, dtype=np.int64)
    if controls.shape != (len(restarted), K_CONTROLS):
        raise RuntimeError(
            f"control matrix shape {controls.shape}, expected {(len(restarted), K_CONTROLS)}"
        )

    entity_before = model.entity.weight.detach().clone()
    relation_before = model.relation.weight.detach().clone()
    ne = entity_before.shape[0]

    ids = torch.as_tensor(restarted, dtype=torch.long, device=model.entity.weight.device)
    ctrl_ids = torch.as_tensor(controls, dtype=torch.long, device=model.entity.weight.device)

    rows = model.entity.weight.index_select(0, ids)
    row_norms = rows.norm(dim=1)
    if torch.any(row_norms <= 0):
        raise RuntimeError("zero restarted-row norm")

    control_rows = model.entity.weight[ctrl_ids]  # [T,K,d]
    control_norms = control_rows.norm(dim=2).detach().cpu().numpy().astype(np.float64)
    target_norms = np.median(control_norms, axis=1)
    if not np.all(np.isfinite(target_norms)) or np.any(target_norms <= 0):
        raise RuntimeError("invalid per-target control median norm")

    target_t = torch.as_tensor(
        target_norms, dtype=rows.dtype, device=rows.device
    )
    scaled = rows * (target_t / row_norms)[:, None]
    model.entity.weight.index_copy_(0, ids, scaled)

    after = model.entity.weight.detach()
    mask = torch.ones(ne, dtype=torch.bool, device=after.device)
    mask[ids] = False
    if not torch.equal(entity_before[mask], after[mask]):
        raise RuntimeError("RF-NORM modified non-Z_U entity rows")
    if not torch.equal(relation_before, model.relation.weight.detach()):
        raise RuntimeError("RF-NORM modified relation parameters")

    got = after.index_select(0, ids).norm(dim=1).detach().cpu().numpy()
    max_abs = float(np.max(np.abs(got - target_norms))) if len(got) else 0.0

    restart_before = row_norms.detach().cpu().numpy().astype(np.float64)
    scale_factors = target_norms / restart_before

    target_deg = predelete_degree[restarted][:, None]
    control_deg = predelete_degree[controls]
    degree_mismatch = np.abs(control_deg - target_deg).astype(np.float64)

    return {
        "target_norms": target_norms,
        "control_norms": control_norms,
        "median_restarted_norm_before": float(np.median(restart_before)),
        "median_control_target_norm": float(np.median(target_norms)),
        "min_control_target_norm": float(np.min(target_norms)),
        "max_control_target_norm": float(np.max(target_norms)),
        "median_scale_factor": float(np.median(scale_factors)),
        "min_scale_factor": float(np.min(scale_factors)),
        "max_scale_factor": float(np.max(scale_factors)),
        "median_abs_predelete_degree_mismatch": float(np.median(degree_mismatch)),
        "mean_abs_predelete_degree_mismatch": float(np.mean(degree_mismatch)),
        "max_abs_predelete_degree_mismatch": float(np.max(degree_mismatch)),
        "max_abs_target_norm_error": max_abs,
        "non_restarted_entity_rows_bit_identical": True,
        "relation_parameters_bit_identical": True,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True, choices=["FB15K-237", "CoDEx-M", "NELL-995"])
    ap.add_argument("--seed", required=True, type=int, choices=[17, 29, 43])
    ap.add_argument("--w8-root", type=Path, required=True)
    ap.add_argument("--w12-root", type=Path, required=True)
    ap.add_argument("--data-root", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--entity-chunk", type=int, default=4096)
    args = ap.parse_args()

    torch.set_num_threads(1)
    data = deterministic_holdout(
        load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17
    )
    ne, nr = len(data.entities), len(data.relations)
    w8dirs = discover_w8(args.w8_root, args.dataset, args.seed)
    args.out.mkdir(parents=True, exist_ok=True)

    summaries = []
    for mode in sorted(EXPECTED_MODES):
        w8dir = w8dirs[mode]
        w8_json = w8dir / "W8_REFERENCE_FREE_A_median.json"
        w8rec = json.loads(w8_json.read_text())
        rh = w8rec["request_hash"]
        source_cell = Path(w8rec["source_cell"])

        if int(w8rec["K"]) != K_CONTROLS:
            raise RuntimeError(f"{mode}: W8 K={w8rec['K']} expected {K_CONTROLS}")

        expected_control_seed = sha_seed(
            args.dataset, args.seed, mode, rh, "placement-controls-v1"
        )
        if int(w8rec["control_seed"]) != int(expected_control_seed):
            raise RuntimeError(
                f"{mode}: W8 control_seed={w8rec['control_seed']} expected={expected_control_seed}"
            )

        required = [
            source_cell / "SchemaCert_plus_Restart_L5.pt",
            source_cell / "RefA_FiniteRetrain20.pt",
            source_cell / "RefB_IndependentRetrain20.pt",
            source_cell / "mean_tie_rank_audit.npz",
        ]
        for p in required:
            if not p.is_file():
                raise FileNotFoundError(p)

        w12_path = args.w12_root / f"{args.dataset}_s{args.seed}_{mode}_{rh}_W12.json"
        if not w12_path.is_file():
            raise FileNotFoundError(w12_path)
        w12 = json.loads(w12_path.read_text())
        if Path(w12["source_cell"]) != source_cell:
            raise RuntimeError(f"{mode}: W12/W8 source_cell mismatch")

        z = np.load(source_cell / "mean_tie_rank_audit.npz", allow_pickle=False)
        fi = np.asarray(z["forget_indices"], dtype=np.int64)
        selected = np.asarray(z["selected_entities"], dtype=np.int64)
        queries = np.asarray(z["queries"], dtype=np.int64)

        keep = np.ones(len(data.train), dtype=bool)
        keep[fi] = False
        retain = data.train[keep]
        rdeg = degree(retain, ne)
        predeg = degree(data.train, ne)
        restarted = np.asarray(selected[rdeg[selected] == 0], dtype=np.int64)
        if len(restarted) == 0:
            raise RuntimeError(f"{mode}: no restarted zero-support entities")

        ae, _, _, check_retain = affected_region(data.train, fi, 1)
        if not np.array_equal(retain, check_retain):
            raise RuntimeError(f"{mode}: retained graph mismatch")

        controls, eligible = matched_controls_k(
            restarted, ae, rdeg, predeg, K_CONTROLS, expected_control_seed
        )
        if np.any(rdeg[controls] <= 0):
            raise RuntimeError(f"{mode}: control with zero retained support")
        blocked = np.zeros(ne, dtype=bool)
        blocked[np.asarray(ae, dtype=np.int64)] = True
        if np.any(blocked[controls]):
            raise RuntimeError(f"{mode}: affected entity leaked into controls")

        refa_ranks = w5_rank_dict(z, "refA")
        refb_ranks = w5_rank_dict(z, "refB")
        rl_ranks = w5_rank_dict(z, "candidate")

        candidate = load_model(
            source_cell / "SchemaCert_plus_Restart_L5.pt", ne, nr, args.device
        )

        # FITTING ENDS HERE: candidate + graph + frozen W8 control construction only.
        fit = apply_control_norm_median(
            candidate, restarted, controls, predeg
        )

        # Evaluation-only reference information is loaded only after RF-NORM is frozen.
        refa_model = load_model(
            source_cell / "RefA_FiniteRetrain20.pt", ne, nr, args.device
        )
        ids = torch.as_tensor(restarted, dtype=torch.long, device=args.device)
        refa_norms = (
            refa_model.entity.weight.index_select(0, ids)
            .norm(dim=1).detach().cpu().numpy()
        )
        fit["median_refa_restarted_norm_evaluation_only"] = float(np.median(refa_norms))
        fit["median_target_to_refa_ratio_evaluation_only"] = float(
            np.median(fit["target_norms"] / refa_norms)
        )

        zero = np.zeros(ne, dtype=np.float32)
        truth_forgotten = (retain, data.valid, data.test, data.train[fi])
        corrected_ranks = rank_both_corrected(
            candidate, queries, zero, ne, truth_forgotten,
            args.device, args.batch, args.entity_chunk
        )
        corrected_metrics = {
            **metrics(corrected_ranks, refa_ranks, refb_ranks),
            **changed_fraction(rl_ranks, corrected_ranks),
        }

        test_q = sample_fixed(data.test, TEST_QUERIES, EVAL_SEED)
        truth_test = (retain, data.valid, data.test)
        baseline_model = load_model(
            source_cell / "SchemaCert_plus_Restart_L5.pt", ne, nr, args.device
        )
        base_test_ranks = rank_both_corrected(
            baseline_model, test_q, zero, ne, truth_test,
            args.device, args.batch, args.entity_chunk
        )
        corr_test_ranks = rank_both_corrected(
            candidate, test_q, zero, ne, truth_test,
            args.device, args.batch, args.entity_chunk
        )
        base_test_mrr = mrr(base_test_ranks)
        corr_test_mrr = mrr(corr_test_ranks)

        e0 = float(w12["R+L"]["logrank_excess"])
        eo = float(w12["NormOracle"]["logrank_excess"])
        er = float(corrected_metrics["logrank_excess"])
        oracle_gain = e0 - eo
        rf_gain = e0 - er

        rfpc_median = float(w12["RFPC_historical"]["median"]["logrank_excess"])
        rfpc_mean = float(w12["RFPC_historical"]["mean"]["logrank_excess"])

        record = {
            "protocol": "W14-rf-norm-matched-controls-v1",
            "method": "ControlNormMedian",
            "fitting_reference_free": True,
            "dataset": args.dataset,
            "seed": args.seed,
            "request_mode": mode,
            "request_hash": rh,
            "source_cell": str(source_cell),
            "n_restarted": int(len(restarted)),
            "K": K_CONTROLS,
            "control_seed": int(expected_control_seed),
            "controls_sha256": sha256_array(controls.astype(np.int64, copy=False)),
            "fit_diagnostic": {
                k: v for k, v in fit.items()
                if k not in ("target_norms", "control_norms")
            },
            "R+L": w12["R+L"],
            "NormOracle_evaluation_only": w12["NormOracle"],
            "RFPC_historical": {
                "median_logrank_excess": rfpc_median,
                "mean_logrank_excess": rfpc_mean,
            },
            "ControlNormMedian": corrected_metrics,
            "test_utility": {
                "n_queries": int(len(test_q)),
                "eval_seed": EVAL_SEED,
                "baseline_test_mrr": float(base_test_mrr),
                "corrected_test_mrr": float(corr_test_mrr),
                "test_mrr_change": float(corr_test_mrr - base_test_mrr),
            },
            "comparison": {
                "rf_norm_reduction": float(1.0 - er / e0) if e0 != 0 else None,
                "oracle_reduction": float(1.0 - eo / e0) if e0 != 0 else None,
                "oracle_gain": float(oracle_gain),
                "rf_norm_gain": float(rf_gain),
                "fraction_oracle_gain_recovered": (
                    float(rf_gain / oracle_gain) if oracle_gain != 0 else None
                ),
                "absolute_gap_to_oracle_excess": float(er - eo),
                "absolute_improvement_vs_rfpc_median": float(rfpc_median - er),
                "absolute_improvement_vs_rfpc_mean": float(rfpc_mean - er),
            },
            "provenance": {
                "w8_json": str(w8_json),
                "w8_json_sha256": sha256_file(w8_json),
                "candidate_sha256": sha256_file(source_cell / "SchemaCert_plus_Restart_L5.pt"),
                "refA_sha256_evaluation_only": sha256_file(source_cell / "RefA_FiniteRetrain20.pt"),
                "refB_sha256_evaluation_only": sha256_file(source_cell / "RefB_IndependentRetrain20.pt"),
                "w5_rank_artifact_sha256": sha256_file(source_cell / "mean_tie_rank_audit.npz"),
                "w12_json_sha256": sha256_file(w12_path),
            },
        }

        stem = f"{args.dataset}_s{args.seed}_{mode}_{rh}_W14"
        (args.out / f"{stem}.json").write_text(json.dumps(record, indent=2) + "\n")
        np.savez_compressed(
            args.out / f"{stem}.npz",
            restarted_entities=restarted.astype(np.int64, copy=False),
            controls=controls.astype(np.int64, copy=False),
            target_norms=np.asarray(fit["target_norms"], dtype=np.float64),
            control_norms=np.asarray(fit["control_norms"], dtype=np.float64),
            rl_head_rank=np.asarray(rl_ranks["head"], dtype=np.float32),
            rl_tail_rank=np.asarray(rl_ranks["tail"], dtype=np.float32),
            corrected_head_rank=np.asarray(corrected_ranks["head"], dtype=np.float32),
            corrected_tail_rank=np.asarray(corrected_ranks["tail"], dtype=np.float32),
            refA_head_rank=np.asarray(refa_ranks["head"], dtype=np.float32),
            refA_tail_rank=np.asarray(refa_ranks["tail"], dtype=np.float32),
            refB_head_rank=np.asarray(refb_ranks["head"], dtype=np.float32),
            refB_tail_rank=np.asarray(refb_ranks["tail"], dtype=np.float32),
            test_queries=np.asarray(test_q, dtype=np.int64),
            baseline_test_head_rank=np.asarray(base_test_ranks["head"], dtype=np.float32),
            baseline_test_tail_rank=np.asarray(base_test_ranks["tail"], dtype=np.float32),
            corrected_test_head_rank=np.asarray(corr_test_ranks["head"], dtype=np.float32),
            corrected_test_tail_rank=np.asarray(corr_test_ranks["tail"], dtype=np.float32),
        )
        summaries.append(record)

        print(
            "W14_CELL_OK", args.dataset, args.seed, mode, rh,
            "E0", f"{e0:.10f}",
            "ERFN", f"{er:.10f}",
            "EOracle", f"{eo:.10f}",
            "RRFN", f"{record['comparison']['rf_norm_reduction']:.6f}",
            "OracleGainRecovered", f"{record['comparison']['fraction_oracle_gain_recovered']:.6f}",
            "TargetNorm", f"{fit['median_control_target_norm']:.6f}",
            "RestartBefore", f"{fit['median_restarted_norm_before']:.6f}",
            "RefAMedian", f"{fit['median_refa_restarted_norm_evaluation_only']:.6f}",
            "VsRFPCmed", f"{record['comparison']['absolute_improvement_vs_rfpc_median']:.10f}",
            "TestDelta", f"{record['test_utility']['test_mrr_change']:.8f}",
            flush=True,
        )

        del candidate, refa_model, baseline_model
        if args.device.startswith("cuda"):
            torch.cuda.empty_cache()

    (args.out / f"{args.dataset}_s{args.seed}_W14_COMPLETE.json").write_text(
        json.dumps({"dataset": args.dataset, "seed": args.seed, "cells": summaries}, indent=2) + "\n"
    )
    print("W14_DATASET_SEED_OK", args.dataset, args.seed, flush=True)


if __name__ == "__main__":
    main()
