#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from pathlib import Path

# Make the repository root importable when this file is executed directly by path.
REPO_ROOT = Path(__file__).resolve().parents[3]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.family_models import DistMult
from schemacert.unlearn import affected_region
from scripts.run_publication_families import filter_maps


EXPECTED_MODES = {
    "fullstar-low",
    "fullstar-mid",
    "fullstar-high",
    "exact-card-high",
}


def sha_seed(*parts: object) -> int:
    s = "|".join(str(x) for x in parts)
    return int.from_bytes(hashlib.sha256(s.encode("utf8")).digest()[:8], "little") & 0x7FFFFFFF


def degree(triples: np.ndarray, ne: int) -> np.ndarray:
    d = np.zeros(ne, dtype=np.int64)
    np.add.at(d, triples[:, 0], 1)
    np.add.at(d, triples[:, 2], 1)
    return d


def load_model(path: Path, ne: int, nr: int, device: str) -> DistMult:
    obj = torch.load(path, map_location="cpu", weights_only=False)
    state = obj["state_dict"] if isinstance(obj, dict) and "state_dict" in obj else obj
    dim = int(state["entity.weight"].shape[1])
    model = DistMult(ne, nr, dim)
    model.load_state_dict(state)
    model.to(device)
    model.eval()
    return model


def discover_cells(results_root: Path, dataset: str, seed: int) -> dict[str, Path]:
    hits: dict[str, list[Path]] = {m: [] for m in EXPECTED_MODES}
    for summary_path in results_root.rglob("summary.json"):
        d = summary_path.parent
        if not (d / "mean_tie_rank_audit.npz").is_file():
            continue
        if not (d / "SchemaCert_plus_Restart_L5.pt").is_file():
            continue
        try:
            meta = json.loads(summary_path.read_text())
        except Exception:
            continue
        if meta.get("dataset") != dataset or int(meta.get("seed", -1)) != int(seed):
            continue
        mode = meta.get("mode")
        if mode in hits:
            hits[mode].append(d)

    out = {}
    for mode in sorted(EXPECTED_MODES):
        xs = sorted(set(hits[mode]))
        if len(xs) != 1:
            raise RuntimeError(
                f"{dataset} seed={seed} mode={mode}: expected exactly one W5 cell under "
                f"{results_root}, found {len(xs)}: {xs}"
            )
        out[mode] = xs[0]
    return out


def find_placement_csv(root: Path, dataset: str, seed: int, mode: str, request_hash: str) -> Path:
    name = f"{dataset}_s{seed}_{mode}_{request_hash}_placement.csv"
    hits = sorted(set(root.rglob(name)))
    if not hits:
        raise RuntimeError(f"Placement CSV not found: {name} under {root}")

    # Canonical paper artifact: the finalized CPU rerun used for the reported
    # 36/36 placement DID analysis. Older v1 copies may coexist in the review root.
    canonical = [
        p for p in hits
        if "w5_unrelated_placement_probe_v2_cpu" in p.parts
    ]
    if len(canonical) == 1:
        return canonical[0]
    if len(canonical) > 1:
        raise RuntimeError(
            f"Multiple canonical v2_cpu placement CSVs for {name}: {canonical}"
        )

    # Fail closed rather than silently choosing an older/unknown copy.
    raise RuntimeError(
        f"No canonical w5_unrelated_placement_probe_v2_cpu copy for {name}. "
        f"Found non-canonical copies only: {hits}"
    )


def matched_controls_k(
    targets: np.ndarray,
    affected_entities: np.ndarray,
    retained_degree: np.ndarray,
    predelete_degree: np.ndarray,
    k: int,
    seed: int,
) -> tuple[np.ndarray, np.ndarray]:
    ne = len(predelete_degree)
    blocked = np.zeros(ne, dtype=bool)
    blocked[np.asarray(affected_entities, dtype=np.int64)] = True
    supported = retained_degree > 0
    eligible = np.flatnonzero((~blocked) & supported)
    if len(eligible) < k:
        raise RuntimeError(f"Only {len(eligible)} supported unaffected controls, need K={k}")

    rng = np.random.default_rng(seed)
    perm = rng.permutation(eligible)
    edeg = predelete_degree[perm]
    order = np.argsort(edeg, kind="stable")
    eligible_sorted = perm[order]
    edeg_sorted = edeg[order]

    controls = np.empty((len(targets), k), dtype=np.int64)
    window = max(256, 8 * k)
    for i, target in enumerate(targets):
        d = int(predelete_degree[int(target)])
        pos = int(np.searchsorted(edeg_sorted, d))
        lo = max(0, pos - window)
        hi = min(len(eligible_sorted), pos + window)
        cand = eligible_sorted[lo:hi]
        if len(cand) < k:
            cand = eligible_sorted
        dist = np.abs(predelete_degree[cand] - d)
        ord2 = np.argsort(dist, kind="stable")
        controls[i] = cand[ord2[:k]]

    return controls, eligible


@torch.no_grad()
def estimate_deltas(
    model: DistMult,
    retain: np.ndarray,
    restarted: np.ndarray,
    controls: np.ndarray,
    eligible: np.ndarray,
    ne: int,
    device: str,
    b_contexts: int,
    context_seed: int,
    target_chunk: int = 512,
) -> tuple[dict[str, np.ndarray], np.ndarray]:
    if len(retain) < b_contexts:
        raise RuntimeError(f"Retained graph has {len(retain)} triples, smaller than B={b_contexts}")

    rng = np.random.default_rng(context_seed)
    ids = rng.choice(len(retain), b_contexts, replace=False)
    bg = np.asarray(retain[ids], dtype=np.int64)

    # Restarted entities have retained degree zero, hence every retained triple
    # is automatically non-incident to every restarted target.
    ctx = torch.as_tensor(bg[:, :2], dtype=torch.long, device=device)
    qvec = model.entity(ctx[:, 0]) * model.relation(ctx[:, 1])  # [B,d]

    eligible_t = torch.as_tensor(eligible, dtype=torch.long, device=device)
    eligible_scores = qvec @ model.entity(eligible_t).T  # [B,Eeligible]

    pos = np.full(ne, -1, dtype=np.int64)
    pos[eligible] = np.arange(len(eligible), dtype=np.int64)
    control_cols = pos[controls]
    if np.any(control_cols < 0):
        raise RuntimeError("Control-to-eligible index mapping failed")

    delta_med = np.zeros(ne, dtype=np.float32)
    delta_mean = np.zeros(ne, dtype=np.float32)

    for st in range(0, len(restarted), target_chunk):
        en = min(len(restarted), st + target_chunk)
        tgt = restarted[st:en]
        tgt_t = torch.as_tensor(tgt, dtype=torch.long, device=device)
        target_scores = qvec @ model.entity(tgt_t).T  # [B,C]

        cc = torch.as_tensor(control_cols[st:en], dtype=torch.long, device=device)
        # Advanced indexing gives [B,C,K].
        cs = eligible_scores[:, cc]

        # Conventional median for even K/B: midpoint of the two central values.
        cs_sorted = torch.sort(cs, dim=2).values
        kk = cs_sorted.shape[2]
        if kk % 2 == 0:
            ctrl_med = 0.5 * (cs_sorted[:, :, kk // 2 - 1] + cs_sorted[:, :, kk // 2])
        else:
            ctrl_med = cs_sorted[:, :, kk // 2]
        diff_med = target_scores - ctrl_med
        dm_sorted = torch.sort(diff_med, dim=0).values
        bb = dm_sorted.shape[0]
        if bb % 2 == 0:
            dmed = 0.5 * (dm_sorted[bb // 2 - 1] + dm_sorted[bb // 2])
        else:
            dmed = dm_sorted[bb // 2]

        ctrl_mean = cs.mean(dim=2)
        diff_mean = target_scores - ctrl_mean
        dmean = diff_mean.mean(dim=0)

        delta_med[tgt] = dmed.detach().cpu().numpy().astype(np.float32, copy=False)
        delta_mean[tgt] = dmean.detach().cpu().numpy().astype(np.float32, copy=False)

    return {"median": delta_med, "mean": delta_mean}, bg


@torch.no_grad()
def bitwise_invariance_gate(
    model: DistMult,
    bg: np.ndarray,
    bias: np.ndarray,
    restarted: np.ndarray,
    ne: int,
    device: str,
    seed: int,
) -> None:
    mask = np.ones(ne, dtype=bool)
    mask[np.asarray(restarted, dtype=np.int64)] = False
    unaffected = np.flatnonzero(mask)
    rng = np.random.default_rng(seed)
    nc = min(1024, len(unaffected))
    nb = min(32, len(bg))
    cand_np = np.sort(rng.choice(unaffected, nc, replace=False))
    bg_np = bg[np.sort(rng.choice(len(bg), nb, replace=False))]

    cand = torch.as_tensor(cand_np, dtype=torch.long, device=device)
    h = torch.as_tensor(bg_np[:, 0], dtype=torch.long, device=device)
    r = torch.as_tensor(bg_np[:, 1], dtype=torch.long, device=device)
    raw = model.score_candidates("tail", h, r, cand).float()
    b = torch.as_tensor(bias[cand_np], dtype=torch.float32, device=device)
    corrected = raw - b[None, :]
    if not torch.equal(raw, corrected):
        raise RuntimeError("BITWISE INVARIANCE GATE FAILED for non-restarted candidates")


@torch.no_grad()
def rank_both_corrected(
    model: DistMult,
    q: np.ndarray,
    bias_np: np.ndarray,
    ne: int,
    truth,
    device: str,
    batch: int,
    chunk: int,
) -> dict[str, np.ndarray]:
    tails, heads = filter_maps(*truth)
    cand_full = torch.arange(ne, dtype=torch.long, device=device)
    bias = torch.as_tensor(bias_np, dtype=torch.float32, device=device)
    model.eval()

    out = {}
    for side in ("head", "tail"):
        ranks = []
        for st in range(0, len(q), batch):
            b = np.asarray(q[st:st + batch], dtype=np.int64)
            bt = torch.as_tensor(b, dtype=torch.long, device=device)
            target = bt[:, 2] if side == "tail" else bt[:, 0]
            true = model.score(bt).float() - bias[target]
            gt = torch.zeros(len(b), dtype=torch.long, device=device)
            eq = torch.zeros(len(b), dtype=torch.long, device=device)

            for cs in range(0, ne, chunk):
                ce = min(ne, cs + chunk)
                cand = cand_full[cs:ce]
                if side == "tail":
                    sc = model.score_candidates("tail", bt[:, 0], bt[:, 1], cand).float()
                else:
                    sc = model.score_candidates("head", bt[:, 1], bt[:, 2], cand).float()
                sc = sc - bias[cand][None, :]

                for j, (h, r, t) in enumerate(b):
                    tgt = int(t) if side == "tail" else int(h)
                    filt = tails.get((int(h), int(r)), ()) if side == "tail" else heads.get((int(r), int(t)), ())
                    for x in filt:
                        x = int(x)
                        if x != tgt and cs <= x < ce:
                            sc[j, x - cs] = -torch.inf
                    if cs <= tgt < ce:
                        sc[j, tgt - cs] = -torch.inf

                gt += (sc > true[:, None]).sum(1)
                eq += (sc == true[:, None]).sum(1)

            rank = 1.0 + gt.double() + 0.5 * eq.double()
            ranks.append(rank.cpu().numpy())
        out[side] = np.concatenate(ranks).astype(np.float64, copy=False)
    return out


def pair_metrics(a: dict[str, np.ndarray], b: dict[str, np.ndarray]) -> dict[str, float]:
    aa = np.concatenate([np.asarray(a["head"], float), np.asarray(a["tail"], float)])
    bb = np.concatenate([np.asarray(b["head"], float), np.asarray(b["tail"], float)])
    if aa.shape != bb.shape:
        raise RuntimeError(f"rank shape mismatch: {aa.shape} vs {bb.shape}")
    return {
        "mrr_gap": float(abs(np.mean(1.0 / aa) - np.mean(1.0 / bb))),
        "mean_abs_log10_rank_gap": float(np.mean(np.abs(np.log10(aa) - np.log10(bb)))),
        "top10_membership_disagreement": float(np.mean((aa <= 10) != (bb <= 10))),
        "top100_membership_disagreement": float(np.mean((aa <= 100) != (bb <= 100))),
    }


def mrr(ranks: dict[str, np.ndarray]) -> float:
    x = np.concatenate([np.asarray(ranks["head"], float), np.asarray(ranks["tail"], float)])
    return float(np.mean(1.0 / x))


def sample_fixed(q: np.ndarray, max_queries: int, seed: int) -> np.ndarray:
    q = np.asarray(q, dtype=np.int64)
    if max_queries <= 0 or len(q) <= max_queries:
        return q.copy()
    rng = np.random.default_rng(seed)
    ids = rng.choice(len(q), max_queries, replace=False)
    return q[ids]


def load_placement_rows(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf8") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        raise RuntimeError(f"Empty placement CSV: {path}")
    return rows


@torch.no_grad()
def rank_probe_targets(
    model: DistMult,
    side: str,
    contexts: np.ndarray,
    targets: np.ndarray,
    bias_np: np.ndarray,
    ne: int,
    device: str,
    batch: int,
    chunk: int,
) -> np.ndarray:
    bias = torch.as_tensor(bias_np, dtype=torch.float32, device=device)
    cand_full = torch.arange(ne, dtype=torch.long, device=device)
    ranks = []
    for st in range(0, len(contexts), batch):
        ctx = np.asarray(contexts[st:st + batch], dtype=np.int64)
        tgt = np.asarray(targets[st:st + batch], dtype=np.int64)
        if side == "tail":
            triples = np.c_[ctx[:, 0], ctx[:, 1], tgt]
            a = torch.as_tensor(ctx[:, 0], dtype=torch.long, device=device)
            b = torch.as_tensor(ctx[:, 1], dtype=torch.long, device=device)
        else:
            triples = np.c_[tgt, ctx[:, 0], ctx[:, 1]]
            a = torch.as_tensor(ctx[:, 0], dtype=torch.long, device=device)
            b = torch.as_tensor(ctx[:, 1], dtype=torch.long, device=device)

        xt = torch.as_tensor(triples, dtype=torch.long, device=device)
        tgt_t = torch.as_tensor(tgt, dtype=torch.long, device=device)
        true = model.score(xt).float() - bias[tgt_t]
        gt = torch.zeros(len(ctx), dtype=torch.long, device=device)
        eq = torch.zeros(len(ctx), dtype=torch.long, device=device)

        for cs in range(0, ne, chunk):
            ce = min(ne, cs + chunk)
            cand = cand_full[cs:ce]
            sc = model.score_candidates(side, a, b, cand).float()
            sc = sc - bias[cand][None, :]
            for j, target in enumerate(tgt):
                target = int(target)
                if cs <= target < ce:
                    sc[j, target - cs] = -torch.inf
            gt += (sc > true[:, None]).sum(1)
            eq += (sc == true[:, None]).sum(1)

        rank = 1.0 + gt.double() + 0.5 * eq.double()
        ranks.append(rank.cpu().numpy())
    return np.concatenate(ranks).astype(np.float64, copy=False)


def evaluate_placement(
    model: DistMult,
    rows: list[dict],
    bias: np.ndarray,
    restarted: np.ndarray,
    ne: int,
    device: str,
    batch: int,
    chunk: int,
) -> tuple[float, float, np.ndarray]:
    restarted_set = set(int(x) for x in restarted)
    all_did = []
    baseline_did = []

    for side in ("head", "tail"):
        sr = [r for r in rows if r["side"] == side]
        if not sr:
            raise RuntimeError(f"No placement rows for side={side}")
        ctx = np.asarray([[int(r["context_a"]), int(r["context_b"])] for r in sr], dtype=np.int64)
        sel = np.asarray([int(r["selected_target"]) for r in sr], dtype=np.int64)
        ctl = np.asarray([int(r["control_target"]) for r in sr], dtype=np.int64)
        if any(int(x) not in restarted_set for x in sel):
            raise RuntimeError("Placement selected target is not in restarted set")
        if any(int(x) in restarted_set for x in ctl):
            raise RuntimeError("Placement control unexpectedly belongs to restarted set")

        corr_sel = rank_probe_targets(model, side, ctx, sel, bias, ne, device, batch, chunk)
        corr_ctl = rank_probe_targets(model, side, ctx, ctl, bias, ne, device, batch, chunk)

        ra_s = np.asarray([float(r["refA_selected_rank"]) for r in sr])
        rb_s = np.asarray([float(r["refB_selected_rank"]) for r in sr])
        ra_c = np.asarray([float(r["refA_control_rank"]) for r in sr])
        rb_c = np.asarray([float(r["refB_control_rank"]) for r in sr])
        old_s = np.asarray([float(r["candidate_selected_rank"]) for r in sr])
        old_c = np.asarray([float(r["candidate_control_rank"]) for r in sr])

        corr_sel_promo = 0.5 * (np.log10(ra_s) + np.log10(rb_s)) - np.log10(corr_sel)
        corr_ctl_promo = 0.5 * (np.log10(ra_c) + np.log10(rb_c)) - np.log10(corr_ctl)
        all_did.append(corr_sel_promo - corr_ctl_promo)

        old_sel_promo = 0.5 * (np.log10(ra_s) + np.log10(rb_s)) - np.log10(old_s)
        old_ctl_promo = 0.5 * (np.log10(ra_c) + np.log10(rb_c)) - np.log10(old_c)
        baseline_did.append(old_sel_promo - old_ctl_promo)

    did = np.concatenate(all_did)
    old = np.concatenate(baseline_did)
    return float(np.mean(did)), float(np.mean(old)), did


def process_cell(
    dataset: str,
    seed: int,
    mode: str,
    cell: Path,
    data,
    placement_root: Path,
    out_root: Path,
    device: str,
    b_contexts: int,
    k_controls: int,
    test_queries: int,
    eval_seed: int,
    batch: int,
    chunk: int,
):
    meta = json.loads((cell / "summary.json").read_text())
    request_hash = meta["request_hash"]
    z = np.load(cell / "mean_tie_rank_audit.npz", allow_pickle=False)

    needed = {
        "queries", "forget_indices", "selected_entities",
        "refA_head_mean_tie_rank", "refA_tail_mean_tie_rank",
        "refB_head_mean_tie_rank", "refB_tail_mean_tie_rank",
    }
    missing = sorted(needed - set(z.files))
    if missing:
        raise RuntimeError(f"{cell}: missing arrays {missing}")

    fi = np.asarray(z["forget_indices"], dtype=np.int64)
    selected = np.asarray(z["selected_entities"], dtype=np.int64)
    forgotten_q = np.asarray(z["queries"], dtype=np.int64)

    keep = np.ones(len(data.train), dtype=bool)
    keep[fi] = False
    retain = data.train[keep]
    ne, nr = len(data.entities), len(data.relations)

    rdeg = degree(retain, ne)
    predeg = degree(data.train, ne)
    restarted = np.asarray(selected[rdeg[selected] == 0], dtype=np.int64)
    if len(restarted) == 0:
        raise RuntimeError(f"{cell}: no restarted zero-support entities")

    ae, _, _, check_retain = affected_region(data.train, fi, 1)
    if not np.array_equal(retain, check_retain):
        raise RuntimeError("affected_region retained graph mismatch")

    controls_seed = sha_seed(dataset, seed, mode, request_hash, "placement-controls-v1")
    controls, eligible = matched_controls_k(
        restarted, ae, rdeg, predeg, k_controls, controls_seed
    )

    model = load_model(cell / "SchemaCert_plus_Restart_L5.pt", ne, nr, device)
    context_seed = sha_seed(dataset, seed, mode, request_hash, "placement-cal-v1")
    biases, bg = estimate_deltas(
        model, retain, restarted, controls, eligible, ne, device,
        b_contexts, context_seed
    )

    placement_csv = find_placement_csv(
        placement_root, dataset, seed, mode, request_hash
    )
    placement_rows = load_placement_rows(placement_csv)

    refa = {
        "head": np.asarray(z["refA_head_mean_tie_rank"], dtype=float),
        "tail": np.asarray(z["refA_tail_mean_tie_rank"], dtype=float),
    }
    refb = {
        "head": np.asarray(z["refB_head_mean_tie_rank"], dtype=float),
        "tail": np.asarray(z["refB_tail_mean_tie_rank"], dtype=float),
    }
    null = pair_metrics(refb, refa)

    test_q = sample_fixed(data.test, test_queries, eval_seed)
    zero_bias = np.zeros(ne, dtype=np.float32)
    baseline_test_ranks = rank_both_corrected(
        model, test_q, zero_bias, ne, (retain, data.valid, data.test),
        device, batch, chunk
    )
    baseline_test_mrr = mrr(baseline_test_ranks)

    mode_out = out_root / dataset / f"seed{seed}" / f"{mode}_{request_hash}"
    mode_out.mkdir(parents=True, exist_ok=True)

    for rule in ("median", "mean"):
        bias = biases[rule]
        bitwise_invariance_gate(
            model, bg, bias, restarted, ne, device,
            sha_seed(dataset, seed, mode, request_hash, rule, "bitwise-gate")
        )

        corr_forgotten = rank_both_corrected(
            model, forgotten_q, bias, ne,
            (retain, data.valid, data.test, data.train[fi]),
            device, batch, chunk
        )
        cand = pair_metrics(corr_forgotten, refa)

        corr_test = rank_both_corrected(
            model, test_q, bias, ne, (retain, data.valid, data.test),
            device, batch, chunk
        )
        test_mrr = mrr(corr_test)

        placement_did, baseline_placement_did, placement_values = evaluate_placement(
            model, placement_rows, bias, restarted, ne, device, batch, chunk
        )

        record = {
            "dataset": dataset,
            "request_mode": mode,
            "request_hash": request_hash,
            "seed": int(seed),
            "variant": "A",
            "delta_rule": rule,
            "lambda": None,
            "candidate_logrank": cand["mean_abs_log10_rank_gap"],
            "null_logrank": null["mean_abs_log10_rank_gap"],
            "logrank_excess": cand["mean_abs_log10_rank_gap"] - null["mean_abs_log10_rank_gap"],
            "mrr_excess": cand["mrr_gap"] - null["mrr_gap"],
            "top10_excess": (
                cand["top10_membership_disagreement"] - null["top10_membership_disagreement"]
            ),
            "top100_excess": (
                cand["top100_membership_disagreement"] - null["top100_membership_disagreement"]
            ),
            "forgotten_mrr_gap": cand["mrr_gap"],
            "test_mrr": test_mrr,
            "placement_did": placement_did,
            "n_restarted": int(len(restarted)),
            "baseline_test_mrr": baseline_test_mrr,
            "test_mrr_change": test_mrr - baseline_test_mrr,
            "baseline_placement_did": baseline_placement_did,
            "candidate_top10": cand["top10_membership_disagreement"],
            "null_top10": null["top10_membership_disagreement"],
            "candidate_top100": cand["top100_membership_disagreement"],
            "null_top100": null["top100_membership_disagreement"],
            "candidate_mrr_gap": cand["mrr_gap"],
            "null_mrr_gap": null["mrr_gap"],
            "B": int(b_contexts),
            "K": int(k_controls),
            "context_seed": int(context_seed),
            "control_seed": int(controls_seed),
            "test_query_seed": int(eval_seed),
            "n_test_queries": int(len(test_q)),
            "placement_csv": str(placement_csv),
            "source_cell": str(cell),
            "bitwise_nonrestarted_gate": True,
            "delta_mean": float(np.mean(bias[restarted])),
            "delta_median": float(np.median(bias[restarted])),
            "delta_q05": float(np.quantile(bias[restarted], 0.05)),
            "delta_q95": float(np.quantile(bias[restarted], 0.95)),
        }

        js = mode_out / f"W8_REFERENCE_FREE_A_{rule}.json"
        js.write_text(json.dumps(record, indent=2) + "\n")

        np.savez_compressed(
            mode_out / f"W8_REFERENCE_FREE_A_{rule}.npz",
            forgotten_queries=forgotten_q,
            candidate_head_rank=np.asarray(corr_forgotten["head"], dtype=np.float32),
            candidate_tail_rank=np.asarray(corr_forgotten["tail"], dtype=np.float32),
            refA_head_rank=np.asarray(refa["head"], dtype=np.float32),
            refA_tail_rank=np.asarray(refa["tail"], dtype=np.float32),
            refB_head_rank=np.asarray(refb["head"], dtype=np.float32),
            refB_tail_rank=np.asarray(refb["tail"], dtype=np.float32),
            test_queries=np.asarray(test_q, dtype=np.int64),
            baseline_test_head_rank=np.asarray(baseline_test_ranks["head"], dtype=np.float32),
            baseline_test_tail_rank=np.asarray(baseline_test_ranks["tail"], dtype=np.float32),
            corrected_test_head_rank=np.asarray(corr_test["head"], dtype=np.float32),
            corrected_test_tail_rank=np.asarray(corr_test["tail"], dtype=np.float32),
            placement_did_values=np.asarray(placement_values, dtype=np.float32),
            restarted_entities=np.asarray(restarted, dtype=np.int64),
            delta=np.asarray(bias[restarted], dtype=np.float32),
            background_triples=np.asarray(bg, dtype=np.int64),
        )

        print(
            "W8_CELL_OK",
            dataset, seed, mode, request_hash, rule,
            "logrank_excess", f"{record['logrank_excess']:.10f}",
            "forgotten_mrr_gap", f"{record['forgotten_mrr_gap']:.10f}",
            "test_mrr_change", f"{record['test_mrr_change']:.10f}",
            "placement_did", f"{record['placement_did']:.10f}",
            flush=True,
        )

    del model
    if device.startswith("cuda"):
        torch.cuda.empty_cache()


def main():
    ap = argparse.ArgumentParser(
        description="W8 Variant A: reference-free candidate-placement correction."
    )
    ap.add_argument("--dataset", required=True, choices=["FB15K-237", "CoDEx-M", "NELL-995"])
    ap.add_argument("--seed", required=True, type=int, choices=[17, 29, 43])
    ap.add_argument("--results-root", type=Path, required=True)
    ap.add_argument("--placement-root", type=Path, required=True)
    ap.add_argument("--data-root", type=Path, required=True)
    ap.add_argument("--out-root", type=Path, required=True)
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--background-contexts", type=int, default=200)
    ap.add_argument("--controls", type=int, default=20)
    ap.add_argument("--test-queries", type=int, default=1000)
    ap.add_argument("--eval-seed", type=int, default=19092026)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--entity-chunk", type=int, default=4096)
    args = ap.parse_args()

    if args.background_contexts != 200 or args.controls != 20:
        raise RuntimeError(
            "W8 protocol is frozen: background-contexts must be 200 and controls must be 20"
        )

    torch.set_num_threads(1)
    data = deterministic_holdout(
        load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17
    )
    cells = discover_cells(args.results_root, args.dataset, args.seed)

    for mode in sorted(EXPECTED_MODES):
        process_cell(
            args.dataset, args.seed, mode, cells[mode], data,
            args.placement_root, args.out_root, args.device,
            args.background_contexts, args.controls,
            args.test_queries, args.eval_seed, args.batch, args.entity_chunk,
        )

    print("W8_DATASET_SEED_OK", args.dataset, args.seed, flush=True)


if __name__ == "__main__":
    main()
