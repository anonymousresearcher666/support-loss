# W8 transfer to the W7 stronger-training regime

Status: **FROZEN BEFORE RESULTS**

This is a direct transfer of the W8 reference-free placement correction to the
W7 stronger-training DistMult regime. It is not a new correction family.

## Frozen cells

Use exactly the completed W7 stronger-training grid cells for:

- CoDEx-M, seeds 17/29/43;
- NELL-995, seeds 17/29/43.

The request is the W7 complete-star entity request in each cell.

## Frozen correction

Use the original W8 definition:

- B = 200 retained-training background contexts;
- K = 20 supported unaffected controls;
- controls matched on pre-deletion degree because the corrected targets have
  retained degree zero;
- correction target set = the restarted zero-support entities;
- delta rules = median and mean, exactly as W8;
- score correction = s'(q,v) = s(q,v) - delta_v;
- no rho weighting, no lambda sweep, no tuning.

The conventional median for even B/K is the midpoint of the two central values,
matching W8.

## Candidate reconstruction gate

W7 stored base, RefA, and RefB stages, but the R+L candidate is reconstructed
from the stored base stage using the exact frozen W7 restart and repair code and
the hyperparameters recorded in the W7 result JSON.

Before any corrected result is accepted, the reconstructed uncorrected R+L
forgotten ranks must reproduce the saved W7 rank artifact within numerical
tolerance. A failed gate aborts the cell.

## Reference-free fitting

Delta is estimated from:

- the reconstructed candidate checkpoint;
- retained training triples;
- the deletion request.

Forbidden during delta fitting:

- RefA/RefB scores or ranks;
- validation/test triples;
- forgotten evaluation ranks;
- placement evaluation contexts.

## Evaluation after delta is frozen

After both median and mean bias vectors are frozen:

- evaluate the same saved forgotten-query population with exact mean-tie ranks;
- use the saved RefA/RefB W7 ranks as the calibrated reference/null;
- evaluate the same W7 test-query sample for utility;
- evaluate a separate placement DID probe with up to P=256 restarted targets,
  degree-matched unaffected controls, and retained background contexts disjoint
  from calibration contexts.

Report signed log-rank, Top-10, Top-100 and MRR excesses before/after, placement
DID before/after, and test-MRR change.

## Statistical analysis

Use 10,000 paired bootstrap replicates, keeping head/tail together within each
forgotten query and weighting the six W7 cells equally. Report paired reductions
and percentile 95% confidence intervals. No arbitrary success percentage is
frozen; the primary direction is positive reduction in calibrated excess.
