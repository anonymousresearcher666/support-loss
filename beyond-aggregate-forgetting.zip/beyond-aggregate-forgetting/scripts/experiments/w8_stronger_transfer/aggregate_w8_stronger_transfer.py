#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

DATASETS = ("CoDEx-M", "NELL-995")
SEEDS = (17, 29, 43)
RULES = ("median", "mean")


def split(x):
    x = np.asarray(x, float)
    if len(x) % 2:
        raise RuntimeError("rank vector must contain paired tail/head blocks")
    n = len(x)//2
    return x[:n], x[n:]


def contrib(z):
    b = np.asarray(z["baseline_rank"], float)
    c = np.asarray(z["corrected_rank"], float)
    a = np.asarray(z["refA_rank"], float)
    r = np.asarray(z["refB_rank"], float)
    bt,bh=split(b); ct,ch=split(c); at,ah=split(a); rt,rh=split(r)
    avg=lambda x,y:.5*(x+y)
    blog=avg(np.abs(np.log10(bt)-np.log10(at)),np.abs(np.log10(bh)-np.log10(ah)))
    clog=avg(np.abs(np.log10(ct)-np.log10(at)),np.abs(np.log10(ch)-np.log10(ah)))
    nlog=avg(np.abs(np.log10(rt)-np.log10(at)),np.abs(np.log10(rh)-np.log10(ah)))
    b10=avg(((bt<=10)!=(at<=10)).astype(float),((bh<=10)!=(ah<=10)).astype(float))
    c10=avg(((ct<=10)!=(at<=10)).astype(float),((ch<=10)!=(ah<=10)).astype(float))
    n10=avg(((rt<=10)!=(at<=10)).astype(float),((rh<=10)!=(ah<=10)).astype(float))
    b100=avg(((bt<=100)!=(at<=100)).astype(float),((bh<=100)!=(ah<=100)).astype(float))
    c100=avg(((ct<=100)!=(at<=100)).astype(float),((ch<=100)!=(ah<=100)).astype(float))
    n100=avg(((rt<=100)!=(at<=100)).astype(float),((rh<=100)!=(ah<=100)).astype(float))
    tb=np.asarray(z["baseline_test_rank"],float); tc=np.asarray(z["corrected_test_rank"],float)
    tbt,tbh=split(tb); tct,tch=split(tc)
    test=avg(1/tct-1/tbt,1/tch-1/tbh)
    pb=np.asarray(z["placement_did_before"],float)
    pa=np.asarray(z["placement_did_after"],float)
    place=np.mean(pb-pa,axis=0)
    return {
        "baseline_logrank_excess":blog-nlog,
        "corrected_logrank_excess":clog-nlog,
        "logrank_excess_reduction":blog-clog,
        "baseline_top10_excess":b10-n10,
        "corrected_top10_excess":c10-n10,
        "top10_excess_reduction":b10-c10,
        "baseline_top100_excess":b100-n100,
        "corrected_top100_excess":c100-n100,
        "top100_excess_reduction":b100-c100,
        "test_mrr_change":test,
        "placement_did_reduction":place,
    }


def boot(cells,key,n_boot,rng):
    out=np.empty(n_boot,float)
    for b in range(n_boot):
        vals=[]
        for c in cells:
            x=c[key]
            ids=rng.integers(0,len(x),len(x))
            vals.append(float(np.mean(x[ids])))
        out[b]=float(np.mean(vals))
    return out


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",type=Path,required=True)
    ap.add_argument("--out",type=Path,required=True)
    ap.add_argument("--n-boot",type=int,default=10000)
    ap.add_argument("--seed",type=int,default=19092026)
    args=ap.parse_args()
    if args.n_boot!=10000:
        raise RuntimeError("protocol frozen at 10000 bootstraps")
    args.out.mkdir(parents=True,exist_ok=True)
    rows=[]
    for rule in RULES:
        cells=[]
        for ds in DATASETS:
            for seed in SEEDS:
                p=args.root/f"{ds}_seed{seed}_{rule}.npz"
                if not p.is_file(): raise FileNotFoundError(p)
                with np.load(p,allow_pickle=False) as z:
                    cells.append(contrib(z))
        keys=list(cells[0])
        rec={"delta_rule":rule}
        for key in keys:
            rec[key]=float(np.mean([np.mean(c[key]) for c in cells]))
            rng=np.random.default_rng(args.seed+sum(map(ord,f"{rule}|{key}")))
            d=boot(cells,key,args.n_boot,rng)
            rec[key+"_ci95_low"]=float(np.quantile(d,.025))
            rec[key+"_ci95_high"]=float(np.quantile(d,.975))
        rows.append(rec)
    with (args.out/"W8_STRONGER_TRANSFER_AGGREGATE.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)
    (args.out/"W8_STRONGER_TRANSFER_AGGREGATE.json").write_text(
        json.dumps({"cells":6,"bootstrap":10000,"results":rows},indent=2)+"\n"
    )
    for r in rows:
        print("W8_STRONGER_AGG",r["delta_rule"],
              "before",f"{r['baseline_logrank_excess']:.10f}",
              "after",f"{r['corrected_logrank_excess']:.10f}",
              "reduction",f"{r['logrank_excess_reduction']:.10f}",
              "CI",f"[{r['logrank_excess_reduction_ci95_low']:.10f},{r['logrank_excess_reduction_ci95_high']:.10f}]",
              flush=True)
    print("W8_STRONGER_AGGREGATE_OK")


if __name__=="__main__":
    main()
