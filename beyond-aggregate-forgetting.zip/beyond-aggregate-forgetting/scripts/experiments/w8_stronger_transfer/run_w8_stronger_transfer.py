#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.unlearn import affected_region
from scripts.experiments.run_entity_request_robustness import degrees, fullstar_stratum
from scripts.experiments.run_w6_well_trained_distmult import (
    ReciprocalDistMult,
    repair_rl,
    restart_zero_support,
)
from scripts.experiments.run_w7_stronger_training_grid import (
    filtered_ranks_mean_tie,
    load_fit,
    request_hash,
)
from scripts.experiments.w9_method_transfer.run_w9_method_transfer import (
    build_probe_contexts,
    choose_probe_targets,
    conventional_median,
    degree,
    matched_controls_k,
    sha_seed,
)
from scripts.run_publication_families import filter_maps, select_forget

B = 200
K = 20
P = 256
EVAL_SEED = 19092026


def sample_same(q: np.ndarray, max_queries: int, seed: int) -> np.ndarray:
    q = np.asarray(q, dtype=np.int64)
    if max_queries and len(q) > max_queries:
        rng = np.random.default_rng(seed)
        ids = np.sort(rng.choice(len(q), max_queries, replace=False))
        return q[ids]
    return q.copy()


@torch.no_grad()
def estimate_deltas(model, background, targets, controls, device, batch=32):
    model = model.to(device)
    model.eval()
    med_parts, mean_parts = [], []
    for st in range(0, len(background), batch):
        bg = np.asarray(background[st:st+batch], dtype=np.int64)
        h = torch.as_tensor(bg[:, 0], dtype=torch.long, device=device)
        r = torch.as_tensor(bg[:, 1], dtype=torch.long, device=device)
        tt = torch.as_tensor(targets, dtype=torch.long, device=device)
        cc = torch.as_tensor(controls.reshape(-1), dtype=torch.long, device=device)
        ts = model.score_candidates("tail", h, r, tt).float()
        cs = model.score_candidates("tail", h, r, cc).float()
        cs = cs.reshape(len(bg), len(targets), controls.shape[1])
        med_parts.append((ts - conventional_median(cs, 2)).cpu())
        mean_parts.append((ts - cs.mean(2)).cpu())
    med_d = conventional_median(torch.cat(med_parts, 0), 0).numpy().astype(np.float32)
    mean_d = torch.cat(mean_parts, 0).mean(0).numpy().astype(np.float32)
    return {"median": med_d, "mean": mean_d}


@torch.no_grad()
def corrected_ranks(model, queries, bias_np, ne, nr, truths, device, batch=32, chunk=4096):
    tails, heads = filter_maps(*truths)
    cand_all = torch.arange(ne, dtype=torch.long, device=device)
    bias = torch.as_tensor(bias_np, dtype=torch.float32, device=device)
    tranks, hranks = [], []
    model = model.to(device)
    model.eval()

    for st in range(0, len(queries), batch):
        b = np.asarray(queries[st:st+batch], dtype=np.int64)
        bt = torch.as_tensor(b, dtype=torch.long, device=device)

        target_t = bt[:, 2]
        true_t = model.score(bt).float() - bias[target_t]
        gt = torch.zeros(len(b), dtype=torch.long, device=device)
        eq = torch.zeros(len(b), dtype=torch.long, device=device)
        for cs in range(0, ne, chunk):
            ce = min(ne, cs + chunk)
            cand = cand_all[cs:ce]
            sc = model.score_candidates("tail", bt[:, 0], bt[:, 1], cand).float()
            sc = sc - bias[cand][None, :]
            for j, (h, r, t) in enumerate(b):
                for x in tails.get((int(h), int(r)), ()):
                    if int(x) != int(t) and cs <= int(x) < ce:
                        sc[j, int(x)-cs] = -torch.inf
            gt += (sc > true_t[:, None]).sum(1)
            eq += (sc == true_t[:, None]).sum(1)
        trank = 1.0 + gt.double() + 0.5 * (eq.double().clamp_min(1.0) - 1.0)
        tranks.extend(trank.cpu().numpy().tolist())

        target_h = bt[:, 0]
        true_h = (
            model.entity(bt[:, 2]) *
            model.relation(bt[:, 1] + nr) *
            model.entity(bt[:, 0])
        ).sum(-1).float() - bias[target_h]
        gt = torch.zeros(len(b), dtype=torch.long, device=device)
        eq = torch.zeros(len(b), dtype=torch.long, device=device)
        for cs in range(0, ne, chunk):
            ce = min(ne, cs + chunk)
            cand = cand_all[cs:ce]
            sc = model.score_candidates("head", bt[:, 1], bt[:, 2], cand).float()
            sc = sc - bias[cand][None, :]
            for j, (h, r, t) in enumerate(b):
                for x in heads.get((int(r), int(t)), ()):
                    if int(x) != int(h) and cs <= int(x) < ce:
                        sc[j, int(x)-cs] = -torch.inf
            gt += (sc > true_h[:, None]).sum(1)
            eq += (sc == true_h[:, None]).sum(1)
        hrank = 1.0 + gt.double() + 0.5 * (eq.double().clamp_min(1.0) - 1.0)
        hranks.extend(hrank.cpu().numpy().tolist())

    return np.r_[np.asarray(tranks), np.asarray(hranks)]


def pair_metrics(a, b):
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    return {
        "logrank": float(np.mean(np.abs(np.log10(a)-np.log10(b)))),
        "mrr_gap": float(abs(np.mean(1.0/a)-np.mean(1.0/b))),
        "top10": float(np.mean((a <= 10) != (b <= 10))),
        "top100": float(np.mean((a <= 100) != (b <= 100))),
    }


@torch.no_grad()
def rank_targets(model, side, contexts, targets, bias_np, ne, nr, device, batch=32, chunk=4096):
    cand_all = torch.arange(ne, dtype=torch.long, device=device)
    bias = torch.as_tensor(bias_np, dtype=torch.float32, device=device)
    out = []
    model = model.to(device)
    model.eval()
    for st in range(0, len(contexts), batch):
        ctx = np.asarray(contexts[st:st+batch], dtype=np.int64)
        tgt = np.asarray(targets[st:st+batch], dtype=np.int64)
        if side == "tail":
            triples = np.c_[ctx[:, 0], ctx[:, 1], tgt]
            a = torch.as_tensor(ctx[:, 0], dtype=torch.long, device=device)
            b = torch.as_tensor(ctx[:, 1], dtype=torch.long, device=device)
            tt = torch.as_tensor(tgt, dtype=torch.long, device=device)
            true = model.score(torch.as_tensor(triples, dtype=torch.long, device=device)).float() - bias[tt]
        else:
            triples = np.c_[tgt, ctx[:, 0], ctx[:, 1]]
            r = torch.as_tensor(ctx[:, 0], dtype=torch.long, device=device)
            t = torch.as_tensor(ctx[:, 1], dtype=torch.long, device=device)
            tt = torch.as_tensor(tgt, dtype=torch.long, device=device)
            true = (model.entity(t) * model.relation(r + nr) * model.entity(tt)).sum(-1).float() - bias[tt]
            a, b = r, t
        gt = torch.zeros(len(ctx), dtype=torch.long, device=device)
        eq = torch.zeros(len(ctx), dtype=torch.long, device=device)
        for cs in range(0, ne, chunk):
            ce = min(ne, cs + chunk)
            cand = cand_all[cs:ce]
            sc = model.score_candidates(side, a, b, cand).float() - bias[cand][None, :]
            for j, x in enumerate(tgt):
                if cs <= int(x) < ce:
                    sc[j, int(x)-cs] = -torch.inf
            gt += (sc > true[:, None]).sum(1)
            eq += (sc == true[:, None]).sum(1)
        out.append((1.0 + gt.double() + 0.5 * eq.double()).cpu().numpy())
    return np.concatenate(out)


def placement_did(candidate, refa, refb, selected, controls, contexts, bias, ne, nr, device):
    zero = np.zeros(ne, dtype=np.float32)
    vals = []
    for side in ("tail", "head"):
        ctx = contexts[side]
        cs = rank_targets(candidate, side, ctx, selected, bias, ne, nr, device)
        cc = rank_targets(candidate, side, ctx, controls, bias, ne, nr, device)
        ars = rank_targets(refa, side, ctx, selected, zero, ne, nr, device)
        arc = rank_targets(refa, side, ctx, controls, zero, ne, nr, device)
        brs = rank_targets(refb, side, ctx, selected, zero, ne, nr, device)
        brc = rank_targets(refb, side, ctx, controls, zero, ne, nr, device)
        ps = 0.5 * (np.log10(ars)+np.log10(brs)) - np.log10(cs)
        pc = 0.5 * (np.log10(arc)+np.log10(brc)) - np.log10(cc)
        vals.append(ps-pc)
    return np.stack(vals, axis=0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cell", type=Path, required=True)
    ap.add_argument("--data-root", type=Path, required=True)
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()

    result_jsons = sorted(args.cell.glob("W7_STRONGER_TRAINING_*.json"))
    if len(result_jsons) != 1:
        raise RuntimeError(f"Expected one W7 result JSON in {args.cell}, found {len(result_jsons)}")
    result_path = result_jsons[0]
    d = json.loads(result_path.read_text())
    manifest_path = args.cell / "manifest.json"
    if not manifest_path.is_file():
        raise FileNotFoundError(manifest_path)
    manifest = json.loads(manifest_path.read_text())

    # Older W7 result JSONs do not duplicate every request-construction field
    # stored in manifest.json. Merge only missing keys so the result payload
    # remains authoritative while preserving backward compatibility.
    for key, value in manifest.items():
        d.setdefault(key, value)

    # Replaying R+L must use the same numerical environment that produced W7.
    # In particular, the archived six-cell stronger-training campaign was run
    # on CPU with four PyTorch threads; replaying it on CUDA can change rank
    # orderings even with identical seeds and code.
    source_device = str(d.get("device", args.device))
    source_threads = int(d.get("threads", 1))
    if source_device not in ("cpu", "cuda:0"):
        raise RuntimeError(f"Unsupported archived W7 device={source_device!r}")
    torch.set_num_threads(max(1, source_threads))
    try:
        torch.set_num_interop_threads(max(1, min(source_threads, 4)))
    except RuntimeError:
        pass
    device = source_device
    print(
        "W8_REPLAY_ENV",
        f"device={device}",
        f"threads={source_threads}",
        flush=True,
    )

    ranks_path = result_path.with_name(result_path.stem + "_ranks.npz")
    z = np.load(ranks_path, allow_pickle=False)

    dataset = d["dataset"]
    base_seed = int(d["base_seed"])
    req_seed = int(d["request_seed"])
    request_mode = d.get("request_mode")
    if request_mode is None:
        # submit_w8_stronger_transfer.slurm selects only legacy req<seed>_*
        # W7 cells, which are the entity-deterministic construction.
        if args.cell.name.startswith(f"req{req_seed}_"):
            request_mode = "entity-deterministic"
        else:
            raise RuntimeError(
                f"Missing request_mode in both result JSON and manifest for {args.cell}"
            )
    data = deterministic_holdout(load_dataset(*infer_paths(dataset, args.data_root)), seed=17)
    ne, nr = len(data.entities), len(data.relations)

    if request_mode == "entity-deterministic":
        fi, meta = select_forget(data.train, d["fraction"], req_seed + int(d["fraction"]*10000), "entity")
        selected = np.asarray(meta["entities"], dtype=np.int64)
    elif request_mode in ("fullstar-low", "fullstar-mid"):
        target_n = max(1, int(round(d["fraction"] * len(data.train))))
        stratum = "low" if request_mode == "fullstar-low" else "mid"
        seed_offset = 9001 if stratum == "low" else 9002
        fi, selected, _ = fullstar_stratum(
            data.train, degrees(data.train, ne), stratum, target_n, req_seed + seed_offset
        )
        selected = np.asarray(selected, dtype=np.int64)
    else:
        raise RuntimeError(f"Unsupported W7 request_mode={request_mode}")

    forget = data.train[fi]
    if request_hash(forget) != d["request_hash"]:
        raise RuntimeError("W7 request hash reconstruction failed")
    keep = np.ones(len(data.train), dtype=bool)
    keep[fi] = False
    retain = data.train[keep]

    dim = int(d["dim"])
    base = load_fit(args.cell / "base_stage.pt", ne, nr, dim, device)
    refa = load_fit(args.cell / "refA_stage.pt", ne, nr, dim, device)
    refb = load_fit(args.cell / "refB_stage.pt", ne, nr, dim, device)

    restarted_model, zero_ids = restart_zero_support(
        base.model, retain, selected, req_seed + 700001
    )
    tr = d["training"]
    candidate, retain2, _ = repair_rl(
        restarted_model, data.train, fi, ne, nr, req_seed, device,
        epochs=int(d["fit"]["RL"]["repair_epochs"]),
        batch_size=int(tr["batch_size"]),
        lr=float(tr["lr"]),
        weight_decay=float(tr["weight_decay"]),
        label_smoothing=float(tr["label_smoothing"]),
    )
    if not np.array_equal(retain, retain2):
        raise RuntimeError("Retained graph mismatch")

    q = sample_same(forget, 1000, EVAL_SEED)
    zero = np.zeros(ne, dtype=np.float32)
    reconstructed = corrected_ranks(
        candidate, q, zero, ne, nr, (retain, data.valid, data.test, forget), device
    )
    saved = np.asarray(z["rl_forget"], float)
    if reconstructed.shape != saved.shape or not np.allclose(reconstructed, saved, rtol=0.0, atol=1e-6):
        raise RuntimeError("Reconstructed R+L does not reproduce saved W7 forgotten ranks")

    ae, _, _, check_retain = affected_region(data.train, fi, 1)
    if not np.array_equal(check_retain, retain):
        raise RuntimeError("affected_region mismatch")
    rdeg = degree(retain, ne)
    predeg = degree(data.train, ne)
    restarted = np.asarray(zero_ids, dtype=np.int64)
    if len(restarted) == 0 or np.any(rdeg[restarted] != 0):
        raise RuntimeError("W8 stronger transfer requires zero-support restarted entities")

    controls, _ = matched_controls_k(
        restarted, ae, rdeg, predeg, K,
        sha_seed(dataset, base_seed, req_seed, d["request_hash"], "w8-strong-controls-v1")
    )
    bg_rng = np.random.default_rng(
        sha_seed(dataset, base_seed, req_seed, d["request_hash"], "w8-strong-cal-v1")
    )
    bg_idx = np.sort(bg_rng.choice(len(retain), B, replace=False))
    background = retain[bg_idx]
    deltas = estimate_deltas(candidate, background, restarted, controls, device)

    biases = {}
    for rule in ("median", "mean"):
        b = np.zeros(ne, dtype=np.float32)
        b[restarted] = deltas[rule]
        biases[rule] = b

    # Evaluation only after both offsets are frozen.
    refa_forget = np.asarray(z["refA_forget"], float)
    refb_forget = np.asarray(z["refB_forget"], float)
    null = pair_metrics(refb_forget, refa_forget)
    baseline = pair_metrics(reconstructed, refa_forget)

    test_q = sample_same(data.test, 2000, EVAL_SEED)
    baseline_test = corrected_ranks(
        candidate, test_q, zero, ne, nr, (retain, data.valid, data.test), device
    )

    psel = choose_probe_targets(
        restarted, P,
        sha_seed(dataset, base_seed, req_seed, d["request_hash"], "w8-strong-placement-targets-v1")
    )
    pctrl, _ = matched_controls_k(
        psel, ae, rdeg, predeg, 1,
        sha_seed(dataset, base_seed, req_seed, d["request_hash"], "w8-strong-placement-controls-v1")
    )
    pctrl = pctrl[:, 0]
    all_true = {tuple(map(int, x)) for x in np.concatenate([data.train, data.valid, data.test], axis=0)}
    forbidden = {tuple(map(int, x)) for x in background}
    contexts = {
        "tail": build_probe_contexts(
            "tail", retain, psel, pctrl, all_true, forbidden,
            sha_seed(dataset, base_seed, req_seed, d["request_hash"], "w8-strong-placement-v1", "tail")
        ),
        "head": build_probe_contexts(
            "head", retain, psel, pctrl, all_true, forbidden,
            sha_seed(dataset, base_seed, req_seed, d["request_hash"], "w8-strong-placement-v1", "head")
        ),
    }
    placement_before = placement_did(
        candidate, refa.model, refb.model, psel, pctrl, contexts, zero, ne, nr, device
    )

    args.out.mkdir(parents=True, exist_ok=True)
    for rule in ("median", "mean"):
        corr = corrected_ranks(
            candidate, q, biases[rule], ne, nr,
            (retain, data.valid, data.test, forget), device
        )
        cm = pair_metrics(corr, refa_forget)
        corr_test = corrected_ranks(
            candidate, test_q, biases[rule], ne, nr,
            (retain, data.valid, data.test), device
        )
        placement_after = placement_did(
            candidate, refa.model, refb.model, psel, pctrl, contexts,
            biases[rule], ne, nr, device
        )

        rec = {
            "dataset": dataset,
            "base_seed": base_seed,
            "request_seed": req_seed,
            "request_hash": d["request_hash"],
            "delta_rule": rule,
            "baseline_logrank_excess": baseline["logrank"] - null["logrank"],
            "corrected_logrank_excess": cm["logrank"] - null["logrank"],
            "logrank_excess_reduction": baseline["logrank"] - cm["logrank"],
            "baseline_top10_excess": baseline["top10"] - null["top10"],
            "corrected_top10_excess": cm["top10"] - null["top10"],
            "baseline_top100_excess": baseline["top100"] - null["top100"],
            "corrected_top100_excess": cm["top100"] - null["top100"],
            "baseline_mrr_excess": baseline["mrr_gap"] - null["mrr_gap"],
            "corrected_mrr_excess": cm["mrr_gap"] - null["mrr_gap"],
            "baseline_test_mrr": float(np.mean(1.0 / baseline_test)),
            "corrected_test_mrr": float(np.mean(1.0 / corr_test)),
            "test_mrr_change": float(np.mean(1.0 / corr_test) - np.mean(1.0 / baseline_test)),
            "placement_did_before": float(np.mean(placement_before)),
            "placement_did_after": float(np.mean(placement_after)),
            "placement_did_reduction": float(np.mean(placement_before - placement_after)),
            "n_restarted": int(len(restarted)),
            "n_probed": int(len(psel)),
            "B": B,
            "K": K,
            "baseline_reconstruction_gate": True,
        }
        stem = f"{dataset}_seed{base_seed}_{rule}"
        (args.out / f"{stem}.json").write_text(json.dumps(rec, indent=2) + "\n")
        np.savez_compressed(
            args.out / f"{stem}.npz",
            baseline_rank=reconstructed.astype(np.float32),
            corrected_rank=corr.astype(np.float32),
            refA_rank=refa_forget.astype(np.float32),
            refB_rank=refb_forget.astype(np.float32),
            baseline_test_rank=baseline_test.astype(np.float32),
            corrected_test_rank=corr_test.astype(np.float32),
            placement_did_before=placement_before.astype(np.float32),
            placement_did_after=placement_after.astype(np.float32),
            restarted_entities=restarted,
            delta=deltas[rule],
            background=background,
        )
        print(
            "W8_STRONGER_CELL_OK", dataset, base_seed, rule,
            "before", f"{rec['baseline_logrank_excess']:.10f}",
            "after", f"{rec['corrected_logrank_excess']:.10f}",
            "placement_reduction", f"{rec['placement_did_reduction']:.10f}",
            flush=True,
        )


if __name__ == "__main__":
    main()
