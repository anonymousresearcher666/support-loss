# W9: Reference-Free Placement Correction Across Published Methods

Status: **FROZEN BEFORE RESULTS**

This protocol defines one transfer experiment. It applies the same reference-free
candidate-placement idea used in W8 to three independently implemented unlearning
procedures on the already-audited random-fact requests.

No result from W9 may be inspected before this protocol is committed.

## 1. Frozen population

Exactly six request cells:

- datasets: `FB15K-237`, `CoDEx-M`;
- request seeds: `17, 29, 43`;
- deletion policy: random-fact;
- deletion fraction: `0.10`.

Exactly three candidate methods in every cell:

- `Finetune`;
- `GraphDPO`;
- `SGU` (the corrected matched SGU-Schema port already used by the published-method audit).

The candidate checkpoints, request export, RefA, and RefB are the same artifacts
used by `cluster/mechanism/79_published_method_rank_audit.sbatch`.
W9 is an evaluation campaign. It does not train or modify any model.

## 2. Common vocabulary and support loss

All scoring uses the exact GraphDPO common vocabulary and mapping used by
`scripts/experiments/run_published_method_rank_audit.py`.

Let `U` be the deleted training triples and `R` the retained training graph in
that common vocabulary. Let

`A_U = {v : v is the head or tail of at least one triple in U}`.

For every `v in A_U`, define endpoint support counts

`d_U(v)` = endpoint incidence count in `U`,
`d_R(v)` = endpoint incidence count in `R`,

and freeze

`rho_v = d_U(v) / (d_U(v) + d_R(v))`.

Thus `rho_v = 1` for complete support loss and `0 < rho_v < 1` for partial
support loss.

## 3. Calibration data and controls

Frozen constants:

- `B = 200` retained-training background contexts;
- `K = 20` unaffected controls per affected endpoint;
- center rule: **median only**.

Calibration contexts are sampled without replacement from `R` using a
SHA256-derived deterministic seed from
`(dataset, request_seed, request_hash, "w9-calibration-v1")`.

The same B tail contexts `q=(h,r)` are used for all affected endpoints in the
cell. No exclusion based on affectedness is imposed on context endpoints; random
10% deletion can affect most entities, and the identification is the
within-context affected-vs-matched-control contrast.

Controls must:

1. not belong to `A_U`;
2. have positive retained degree.

Matching is deterministic.

- If `d_R(v) > 0`, controls are matched primarily on `d_R`.
- If `d_R(v) = 0`, matching falls back to pre-deletion endpoint degree
  `d_U(v)+d_R(v)`, which is the W8 zero-support case.
- Ties are broken by a SHA256-derived permutation using
  `(dataset, request_seed, request_hash, "w9-controls-v1")`.

## 4. Reference-free offset

For each candidate checkpoint `M` in `{Finetune, GraphDPO, SGU}`, independently,
freeze

`delta_v^M = median_{q in B} [ s_M(q,v) - median_{c in C_v} s_M(q,c) ]`.

Only candidate-checkpoint scores, the retained graph, and the deletion request
may enter this computation.

Forbidden during fitting of `delta`:

- RefA;
- RefB;
- any retraining checkpoint or retraining rank;
- validation triples;
- test triples;
- forgotten-query evaluation ranks;
- placement-probe evaluation contexts.

## 5. Frozen correction variants

Exactly two variants are evaluated for every method-cell.

### W9-A: exact endpoint transfer

`s'_M(q,v) = s_M(q,v) - delta_v^M` for `v in A_U`.

All other candidate scores are bitwise unchanged.

### W9-B: support-weighted endpoint transfer

`s'_M(q,v) = s_M(q,v) - rho_v * delta_v^M` for `v in A_U`.

All other candidate scores are bitwise unchanged.

No lambda sweep, mean offset, validation selection, method-specific tuning, or
best-variant selection is allowed.

## 6. Evaluation after offsets are frozen

Only after both bias vectors are computed and frozen may evaluation load RefA,
RefB, forgotten queries, test queries, or placement-probe contexts.

### 6.1 Forgotten-query rank fidelity

Use the same deterministic set of up to 1,000 forgotten queries and the same
filtered ranking semantics as the existing published-method rank audit.

For each method and variant report:

- candidate mean absolute log10-rank gap to RefA;
- RefB-vs-RefA null gap;
- signed calibrated log-rank excess;
- Top-10 membership disagreement and signed excess over the null;
- Top-100 membership disagreement and signed excess over the null;
- MRR gap and signed excess over the null.

The uncorrected candidate is evaluated in the same process and must reproduce
the published-method baseline within numerical tolerance before a corrected
result is accepted.

### 6.2 Test utility

Use up to 1,000 common-vocabulary test queries per cell, sampled deterministically
from a SHA256 seed based on
`(dataset, request_seed, request_hash, "w9-test-v1")`.

Report uncorrected and corrected test MRR and their paired difference.
Test queries are not read until after the offsets are frozen.

### 6.3 Independent placement probe

The mechanism check is frozen as follows:

- `P = 256` affected endpoints per cell, or all affected endpoints if fewer;
- affected endpoints are sampled deterministically with seed
  `(dataset, request_seed, request_hash, "w9-placement-targets-v1")`;
- one unaffected control per probed endpoint is selected by the same frozen
  degree-matching rule, with an independent tie seed;
- head and tail probe contexts are sampled from the retained graph with seed
  `(dataset, request_seed, request_hash, "w9-placement-contexts-v1")`;
- inserted affected/control triples must be absent from train/valid/test;
- placement contexts used here are never calibration contexts.

For each method, compute affected and matched-control candidate promotion relative
to the RefA/RefB log-rank center, then the difference-in-differences (DID), both
before and after correction.

The intended diagnostic is:

`placement_DID_before - placement_DID_after`.

No placement quantity participates in fitting `delta`.

## 7. Statistical analysis

All inferential comparisons are paired.

Frozen bootstrap:

- 10,000 replicates;
- resampling unit: forgotten query, with head and tail kept paired;
- resampling is stratified within each of the six request cells;
- cell means are then averaged with equal cell weight;
- deterministic bootstrap seed: `19092026`.

For every method and correction variant define

`Delta E_M = E_M_before - E_M_after`.

Report the point estimate, 95% percentile CI, and percentage reduction when the
uncorrected excess is nonzero. The scientifically useful direction is
`Delta E_M > 0`; a CI fully above zero is stronger evidence. There is no
pre-declared arbitrary percentage threshold.

The same paired bootstrap is reported for Top-10 excess, Top-100 excess, and
placement DID change. Test-MRR change is reported with its paired CI.

## 8. Hard gates

A cell aborts if any of the following fails:

- request hash agrees across request manifest and regenerated SGU metadata;
- all forgotten triples are covered by the common vocabulary;
- exactly the three frozen methods are supplied;
- `B=200`, `K=20`, `P=256`, median-only calibration;
- non-affected candidate scores are bitwise identical after correction;
- placement contexts overlap calibration triples;
- a placement inserted triple is present in train/valid/test;
- baseline forgotten ranks fail to reproduce the existing published-method
  audit within numerical tolerance.

Signed excess values are never converted to absolute values.

## 9. Output scope

The campaign writes per-cell JSON/NPZ artifacts plus aggregate CSV/JSON tables
for all three methods and both variants. Results are reported completely; no
method or variant is dropped based on outcome.
