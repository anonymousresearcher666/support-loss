#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

METHODS = ("Finetune", "GraphDPO", "SGU")
VARIANTS = ("exact", "support_weighted")
DATASETS = ("FB15K-237", "CoDEx-M")
SEEDS = (17, 29, 43)


def ci95(x: np.ndarray) -> tuple[float, float]:
    return float(np.quantile(x, 0.025)), float(np.quantile(x, 0.975))


def split_sides(x: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    x = np.asarray(x, dtype=float)
    if len(x) % 2:
        raise RuntimeError(f"Expected tail+head vector of even length, got {len(x)}")
    n = len(x) // 2
    return x[:n], x[n:]


def query_contribs(z) -> dict[str, np.ndarray]:
    b = np.asarray(z["baseline_rank"], float)
    c = np.asarray(z["corrected_rank"], float)
    a = np.asarray(z["refA_rank"], float)
    r = np.asarray(z["refB_rank"], float)

    bt, bh = split_sides(b)
    ct, ch = split_sides(c)
    at, ah = split_sides(a)
    rt, rh = split_sides(r)

    def pair_avg(x1, x2):
        return 0.5 * (x1 + x2)

    base_log = pair_avg(np.abs(np.log10(bt) - np.log10(at)),
                        np.abs(np.log10(bh) - np.log10(ah)))
    corr_log = pair_avg(np.abs(np.log10(ct) - np.log10(at)),
                        np.abs(np.log10(ch) - np.log10(ah)))
    null_log = pair_avg(np.abs(np.log10(rt) - np.log10(at)),
                        np.abs(np.log10(rh) - np.log10(ah)))

    base_t10 = pair_avg(((bt <= 10) != (at <= 10)).astype(float),
                        ((bh <= 10) != (ah <= 10)).astype(float))
    corr_t10 = pair_avg(((ct <= 10) != (at <= 10)).astype(float),
                        ((ch <= 10) != (ah <= 10)).astype(float))
    null_t10 = pair_avg(((rt <= 10) != (at <= 10)).astype(float),
                        ((rh <= 10) != (ah <= 10)).astype(float))

    base_t100 = pair_avg(((bt <= 100) != (at <= 100)).astype(float),
                         ((bh <= 100) != (ah <= 100)).astype(float))
    corr_t100 = pair_avg(((ct <= 100) != (at <= 100)).astype(float),
                         ((ch <= 100) != (ah <= 100)).astype(float))
    null_t100 = pair_avg(((rt <= 100) != (at <= 100)).astype(float),
                         ((rh <= 100) != (ah <= 100)).astype(float))

    btest = np.asarray(z["baseline_test_rank"], float)
    ctest = np.asarray(z["corrected_test_rank"], float)
    btt, bth = split_sides(btest)
    ctt, cth = split_sides(ctest)
    test_change = pair_avg(1.0 / ctt - 1.0 / btt, 1.0 / cth - 1.0 / bth)

    p_before = np.asarray(z["placement_did_before"], float)
    p_after = np.asarray(z["placement_did_after"], float)
    if p_before.ndim != 2 or p_before.shape[0] != 2 or p_after.shape != p_before.shape:
        raise RuntimeError(f"Unexpected placement arrays: {p_before.shape}, {p_after.shape}")
    placement_change = np.mean(p_before - p_after, axis=0)

    return {
        "baseline_logrank_excess": base_log - null_log,
        "corrected_logrank_excess": corr_log - null_log,
        "logrank_excess_reduction": base_log - corr_log,
        "baseline_top10_excess": base_t10 - null_t10,
        "corrected_top10_excess": corr_t10 - null_t10,
        "top10_excess_reduction": base_t10 - corr_t10,
        "baseline_top100_excess": base_t100 - null_t100,
        "corrected_top100_excess": corr_t100 - null_t100,
        "top100_excess_reduction": base_t100 - corr_t100,
        "test_mrr_change": test_change,
        "placement_did_reduction": placement_change,
    }


def equal_cell_point(cells: list[dict[str, np.ndarray]], key: str) -> float:
    return float(np.mean([np.mean(c[key]) for c in cells]))


def paired_bootstrap(
    cells: list[dict[str, np.ndarray]],
    key: str,
    n_boot: int,
    rng: np.random.Generator,
) -> np.ndarray:
    out = np.empty(n_boot, dtype=float)
    for b in range(n_boot):
        vals = []
        for cell in cells:
            x = np.asarray(cell[key], float)
            idx = rng.integers(0, len(x), size=len(x))
            vals.append(float(np.mean(x[idx])))
        out[b] = float(np.mean(vals))
    return out


def paired_bootstrap_ratio(
    cells: list[dict[str, np.ndarray]],
    numerator_key: str,
    denominator_key: str,
    n_boot: int,
    rng: np.random.Generator,
) -> np.ndarray:
    out = np.full(n_boot, np.nan, dtype=float)
    for b in range(n_boot):
        nums = []
        dens = []
        for cell in cells:
            num = np.asarray(cell[numerator_key], float)
            den = np.asarray(cell[denominator_key], float)
            if len(num) != len(den):
                raise RuntimeError("Paired ratio arrays have different lengths")
            idx = rng.integers(0, len(num), size=len(num))
            nums.append(float(np.mean(num[idx])))
            dens.append(float(np.mean(den[idx])))
        n = float(np.mean(nums))
        d = float(np.mean(dens))
        if abs(d) > 1e-15:
            out[b] = 100.0 * n / d
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description="Aggregate frozen W9 method-transfer campaign.")
    ap.add_argument("--root", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--n-boot", type=int, default=10000)
    ap.add_argument("--seed", type=int, default=19092026)
    args = ap.parse_args()

    if args.n_boot != 10000:
        raise RuntimeError("W9 protocol frozen at 10,000 bootstrap replicates")

    args.out.mkdir(parents=True, exist_ok=True)
    rows = []
    summary_json = {
        "protocol": "W9_REFERENCE_FREE_METHOD_TRANSFER_PROTOCOL",
        "bootstrap": {
            "replicates": args.n_boot,
            "seed": args.seed,
            "unit": "query paired head/tail within request cell; equal cell weighting",
        },
        "results": [],
    }

    for method in METHODS:
        for variant in VARIANTS:
            cells = []
            cell_names = []
            for dataset in DATASETS:
                for seed in SEEDS:
                    p = args.root / f"{dataset}_seed{seed}_{method}_{variant}.npz"
                    if not p.is_file():
                        raise FileNotFoundError(p)
                    with np.load(p, allow_pickle=False) as z:
                        cells.append(query_contribs(z))
                    cell_names.append(f"{dataset}:seed{seed}")

            metrics = [
                "baseline_logrank_excess",
                "corrected_logrank_excess",
                "logrank_excess_reduction",
                "baseline_top10_excess",
                "corrected_top10_excess",
                "top10_excess_reduction",
                "baseline_top100_excess",
                "corrected_top100_excess",
                "top100_excess_reduction",
                "placement_did_reduction",
                "test_mrr_change",
            ]
            dists = {}
            points = {}
            for metric in metrics:
                points[metric] = equal_cell_point(cells, metric)
                rng = np.random.default_rng(
                    args.seed + sum(ord(c) for c in f"{method}|{variant}|{metric}")
                )
                dists[metric] = paired_bootstrap(cells, metric, args.n_boot, rng)

            # Percent reduction uses the paired aggregate baseline and reduction bootstrap.
            before = points["baseline_logrank_excess"]
            reduction = points["logrank_excess_reduction"]
            pct_point = float("nan") if before == 0 else 100.0 * reduction / before

            rng_ratio = np.random.default_rng(
                args.seed + sum(ord(c) for c in f"{method}|{variant}|pct")
            )
            pct_dist = paired_bootstrap_ratio(
                cells,
                "logrank_excess_reduction",
                "baseline_logrank_excess",
                args.n_boot,
                rng_ratio,
            )
            finite_pct = pct_dist[np.isfinite(pct_dist)]
            pct_lo, pct_hi = (float("nan"), float("nan")) if len(finite_pct) == 0 else ci95(finite_pct)

            record = {
                "method": method,
                "variant": variant,
                "cells": cell_names,
                "logrank_percent_reduction": pct_point,
                "logrank_percent_reduction_ci95_low": pct_lo,
                "logrank_percent_reduction_ci95_high": pct_hi,
            }
            for metric in metrics:
                lo, hi = ci95(dists[metric])
                record[metric] = points[metric]
                record[f"{metric}_ci95_low"] = lo
                record[f"{metric}_ci95_high"] = hi

            summary_json["results"].append(record)
            rows.append(record)

    csv_path = args.out / "W9_METHOD_TRANSFER_AGGREGATE.csv"
    with csv_path.open("w", newline="", encoding="utf8") as f:
        keys = [k for k in rows[0].keys() if k != "cells"]
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow({k: r[k] for k in keys})

    (args.out / "W9_METHOD_TRANSFER_AGGREGATE.json").write_text(
        json.dumps(summary_json, indent=2) + "\n", encoding="utf8"
    )

    print("W9_AGGREGATE_OK")
    for r in rows:
        print(
            r["method"], r["variant"],
            "before", f"{r['baseline_logrank_excess']:.10f}",
            "after", f"{r['corrected_logrank_excess']:.10f}",
            "reduction", f"{r['logrank_excess_reduction']:.10f}",
            "CI", f"[{r['logrank_excess_reduction_ci95_low']:.10f},"
                  f"{r['logrank_excess_reduction_ci95_high']:.10f}]",
            "top100_reduction", f"{r['top100_excess_reduction']:.10f}",
            "placement_reduction", f"{r['placement_did_reduction']:.10f}",
            "test_mrr_change", f"{r['test_mrr_change']:.10f}",
        )


if __name__ == "__main__":
    main()
