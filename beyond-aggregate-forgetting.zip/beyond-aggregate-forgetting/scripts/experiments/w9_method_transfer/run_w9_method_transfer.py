#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from schemacert.data import deterministic_holdout, infer_paths, load_dataset
from schemacert.graphdpo_shared import load_graphdpo_shared_checkpoint
from scripts.run_publication_families import select_forget
from scripts.experiments.evaluate_graphdpo_common import (
    graphdpo_vocab,
    parse_named,
    request_fingerprint,
    verify_exported_request,
)
from scripts.experiments.evaluate_graphdpo_common_support import (
    map_supported,
    supported_mask,
)
from scripts.experiments.run_published_method_rank_audit import (
    filter_maps,
    rank_pair,
    ranks_for_queries,
)

METHODS = ("Finetune", "GraphDPO", "SGU")
VARIANTS = ("exact", "support_weighted")
B_FROZEN = 200
K_FROZEN = 20
P_FROZEN = 256
EVAL_SEED = 19092026


def sha_seed(*parts: object) -> int:
    s = "|".join(map(str, parts)).encode("utf8")
    return int.from_bytes(hashlib.sha256(s).digest()[:8], "little") & 0x7FFFFFFF


def degree(triples: np.ndarray, ne: int) -> np.ndarray:
    d = np.zeros(ne, dtype=np.int64)
    if len(triples):
        np.add.at(d, triples[:, 0], 1)
        np.add.at(d, triples[:, 2], 1)
    return d


def sample_indices(n: int, k: int, seed: int) -> np.ndarray:
    if n < k:
        raise RuntimeError(f"Need {k} rows, found only {n}")
    rng = np.random.default_rng(seed)
    return np.sort(rng.choice(n, k, replace=False))


def matched_controls_k(
    targets: np.ndarray,
    affected: np.ndarray,
    retained_degree: np.ndarray,
    pre_degree: np.ndarray,
    k: int,
    seed: int,
) -> tuple[np.ndarray, np.ndarray]:
    ne = len(pre_degree)
    blocked = np.zeros(ne, dtype=bool)
    blocked[np.asarray(affected, dtype=np.int64)] = True
    eligible = np.flatnonzero((~blocked) & (retained_degree > 0))
    if len(eligible) < k:
        raise RuntimeError(f"Only {len(eligible)} supported unaffected controls; need K={k}")

    rng = np.random.default_rng(seed)
    tie = rng.permutation(eligible)
    tie_pos = np.empty(ne, dtype=np.int64)
    tie_pos.fill(np.iinfo(np.int64).max)
    tie_pos[tie] = np.arange(len(tie), dtype=np.int64)

    out = np.empty((len(targets), k), dtype=np.int64)
    for i, target in enumerate(np.asarray(targets, dtype=np.int64)):
        use_retained = int(retained_degree[target]) > 0
        td = int(retained_degree[target] if use_retained else pre_degree[target])
        metric = retained_degree[eligible] if use_retained else pre_degree[eligible]
        dist = np.abs(metric - td)
        order = np.lexsort((tie_pos[eligible], dist))
        out[i] = eligible[order[:k]]
    return out, eligible


def conventional_median(x: torch.Tensor, dim: int) -> torch.Tensor:
    xs = torch.sort(x, dim=dim).values
    n = xs.shape[dim]
    if n % 2:
        return xs.select(dim, n // 2)
    return 0.5 * (xs.select(dim, n // 2 - 1) + xs.select(dim, n // 2))


@torch.no_grad()
def estimate_delta(
    model,
    background: np.ndarray,
    targets: np.ndarray,
    controls: np.ndarray,
    ne: int,
    device: str,
    batch: int = 32,
) -> np.ndarray:
    model = model.to(device)
    model.eval()
    deltas_by_batch = []
    for st in range(0, len(background), batch):
        bg = np.asarray(background[st:st + batch], dtype=np.int64)
        a = torch.as_tensor(bg[:, 0], dtype=torch.long, device=device)
        r = torch.as_tensor(bg[:, 1], dtype=torch.long, device=device)
        target_t = torch.as_tensor(targets, dtype=torch.long, device=device)
        control_t = torch.as_tensor(controls.reshape(-1), dtype=torch.long, device=device)

        target_score = model.score_candidates("tail", a, r, target_t).float()
        control_score = model.score_candidates("tail", a, r, control_t).float()
        control_score = control_score.reshape(len(bg), len(targets), controls.shape[1])
        ctrl_med = conventional_median(control_score, dim=2)
        deltas_by_batch.append((target_score - ctrl_med).cpu())

    diffs = torch.cat(deltas_by_batch, dim=0)
    return conventional_median(diffs, dim=0).numpy().astype(np.float32, copy=False)


@torch.no_grad()
def ranks_corrected(
    model,
    queries: np.ndarray,
    bias_np: np.ndarray,
    ne: int,
    truth,
    device: str,
    batch: int,
    chunk: int,
) -> np.ndarray:
    tails, heads = filter_maps(*truth)
    model = model.to(device)
    model.eval()
    bias = torch.as_tensor(bias_np, dtype=torch.float32, device=device)
    cand_full = torch.arange(ne, dtype=torch.long, device=device)
    tail_ranks: list[float] = []
    head_ranks: list[float] = []

    for side in ("tail", "head"):
        dst = tail_ranks if side == "tail" else head_ranks
        for st in range(0, len(queries), batch):
            b = np.asarray(queries[st:st + batch], dtype=np.int64)
            bt = torch.as_tensor(b, dtype=torch.long, device=device)
            target_np = b[:, 2] if side == "tail" else b[:, 0]
            target = torch.as_tensor(target_np, dtype=torch.long, device=device)
            true = model.score(bt).float() - bias[target]
            counts = torch.zeros(len(b), dtype=torch.long, device=device)

            for cs in range(0, ne, chunk):
                ce = min(ne, cs + chunk)
                cand = cand_full[cs:ce]
                if side == "tail":
                    sc = model.score_candidates("tail", bt[:, 0], bt[:, 1], cand).float()
                else:
                    sc = model.score_candidates("head", bt[:, 1], bt[:, 2], cand).float()
                sc = sc - bias[cand][None, :]
                for j, (h, r, t) in enumerate(b):
                    filt = tails.get((int(h), int(r)), ()) if side == "tail" else heads.get((int(r), int(t)), ())
                    tgt = int(t) if side == "tail" else int(h)
                    for x in filt:
                        x = int(x)
                        if x != tgt and cs <= x < ce:
                            sc[j, x - cs] = -torch.inf
                counts += (sc > true[:, None]).sum(1)
            dst.extend((counts + 1).cpu().numpy().astype(float).tolist())

    return np.r_[np.asarray(tail_ranks), np.asarray(head_ranks)]


def bitwise_gate(model, background: np.ndarray, bias: np.ndarray, affected: np.ndarray,
                 ne: int, device: str, seed: int) -> None:
    mask = np.ones(ne, dtype=bool)
    mask[np.asarray(affected, dtype=np.int64)] = False
    unaffected = np.flatnonzero(mask)
    rng = np.random.default_rng(seed)
    nc = min(1024, len(unaffected))
    nb = min(32, len(background))
    cand_np = np.sort(rng.choice(unaffected, nc, replace=False))
    bg = background[np.sort(rng.choice(len(background), nb, replace=False))]
    cand = torch.as_tensor(cand_np, dtype=torch.long, device=device)
    a = torch.as_tensor(bg[:, 0], dtype=torch.long, device=device)
    r = torch.as_tensor(bg[:, 1], dtype=torch.long, device=device)
    model = model.to(device)
    raw = model.score_candidates("tail", a, r, cand).float()
    b = torch.as_tensor(bias[cand_np], dtype=torch.float32, device=device)
    corr = raw - b[None, :]
    if not torch.equal(raw, corr):
        raise RuntimeError("W9 bitwise non-affected score gate failed")


def load_baseline_rows(path: Path, method: str) -> np.ndarray:
    rows = []
    with path.open(newline="", encoding="utf8") as f:
        for row in csv.DictReader(f):
            rows.append(float(row[f"rank_{method}"]))
    return np.asarray(rows, dtype=float)


def fixed_query_subset(q: np.ndarray, max_queries: int, seed: int) -> tuple[np.ndarray, np.ndarray]:
    q = np.asarray(q, dtype=np.int64)
    if max_queries <= 0 or len(q) <= max_queries:
        idx = np.arange(len(q), dtype=np.int64)
    else:
        rng = np.random.default_rng(seed)
        idx = np.sort(rng.choice(len(q), max_queries, replace=False))
    return q[idx], idx


def choose_probe_targets(affected: np.ndarray, p: int, seed: int) -> np.ndarray:
    affected = np.asarray(affected, dtype=np.int64)
    if len(affected) <= p:
        return np.sort(affected)
    rng = np.random.default_rng(seed)
    return np.sort(rng.choice(affected, p, replace=False))


def build_probe_contexts(
    side: str,
    pool: np.ndarray,
    selected: np.ndarray,
    controls: np.ndarray,
    all_true: set[tuple[int, int, int]],
    forbidden_source_triples: set[tuple[int, int, int]],
    seed: int,
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    order = rng.permutation(len(pool))
    out = np.empty((len(selected), 2), dtype=np.int64)
    cursor = 0
    for i, (sel, ctl) in enumerate(zip(selected, controls)):
        found = False
        attempts = 0
        while attempts < max(50000, 4 * len(pool)):
            if cursor >= len(order):
                order = rng.permutation(len(pool))
                cursor = 0
            h, r, t = map(int, pool[int(order[cursor])])
            cursor += 1
            attempts += 1
            if (h, r, t) in forbidden_source_triples:
                continue
            if int(sel) in (h, t) or int(ctl) in (h, t):
                continue
            if side == "tail":
                ts, tc, ctx = (h, r, int(sel)), (h, r, int(ctl)), (h, r)
            else:
                ts, tc, ctx = (int(sel), r, t), (int(ctl), r, t), (r, t)
            if ts in all_true or tc in all_true:
                continue
            out[i] = ctx
            found = True
            break
        if not found:
            raise RuntimeError(f"Could not construct W9 {side} probe for target={int(sel)}")
    return out


@torch.no_grad()
def rank_targets(model, side: str, contexts: np.ndarray, targets: np.ndarray,
                 bias_np: np.ndarray, ne: int, device: str,
                 batch: int, chunk: int) -> np.ndarray:
    model = model.to(device)
    model.eval()
    bias = torch.as_tensor(bias_np, dtype=torch.float32, device=device)
    cand_full = torch.arange(ne, dtype=torch.long, device=device)
    out = []
    for st in range(0, len(contexts), batch):
        ctx = np.asarray(contexts[st:st + batch], dtype=np.int64)
        tgt = np.asarray(targets[st:st + batch], dtype=np.int64)
        if side == "tail":
            triples = np.c_[ctx[:, 0], ctx[:, 1], tgt]
            a = torch.as_tensor(ctx[:, 0], dtype=torch.long, device=device)
            b = torch.as_tensor(ctx[:, 1], dtype=torch.long, device=device)
        else:
            triples = np.c_[tgt, ctx[:, 0], ctx[:, 1]]
            a = torch.as_tensor(ctx[:, 0], dtype=torch.long, device=device)
            b = torch.as_tensor(ctx[:, 1], dtype=torch.long, device=device)

        xt = torch.as_tensor(triples, dtype=torch.long, device=device)
        tt = torch.as_tensor(tgt, dtype=torch.long, device=device)
        true = model.score(xt).float() - bias[tt]
        gt = torch.zeros(len(ctx), dtype=torch.long, device=device)
        eq = torch.zeros(len(ctx), dtype=torch.long, device=device)

        for cs in range(0, ne, chunk):
            ce = min(ne, cs + chunk)
            cand = cand_full[cs:ce]
            sc = model.score_candidates(side, a, b, cand).float() - bias[cand][None, :]
            for j, target in enumerate(tgt):
                if cs <= int(target) < ce:
                    sc[j, int(target) - cs] = -torch.inf
            gt += (sc > true[:, None]).sum(1)
            eq += (sc == true[:, None]).sum(1)
        out.append((1.0 + gt.double() + 0.5 * eq.double()).cpu().numpy())
    return np.concatenate(out)


def placement_did(candidate, refa, refb, selected, controls, contexts_by_side,
                  bias, ne, device, batch, chunk) -> np.ndarray:
    per_side = []
    zero = np.zeros(ne, dtype=np.float32)
    for side in ("tail", "head"):
        ctx = contexts_by_side[side]
        cs = rank_targets(candidate, side, ctx, selected, bias, ne, device, batch, chunk)
        cc = rank_targets(candidate, side, ctx, controls, bias, ne, device, batch, chunk)
        ars = rank_targets(refa, side, ctx, selected, zero, ne, device, batch, chunk)
        arc = rank_targets(refa, side, ctx, controls, zero, ne, device, batch, chunk)
        brs = rank_targets(refb, side, ctx, selected, zero, ne, device, batch, chunk)
        brc = rank_targets(refb, side, ctx, controls, zero, ne, device, batch, chunk)
        ps = 0.5 * (np.log10(ars) + np.log10(brs)) - np.log10(cs)
        pc = 0.5 * (np.log10(arc) + np.log10(brc)) - np.log10(cc)
        per_side.append(ps - pc)
    return np.stack(per_side, axis=0)


def main() -> None:
    ap = argparse.ArgumentParser(description="W9 reference-free placement correction transfer.")
    ap.add_argument("--dataset", required=True, choices=["FB15K-237", "CoDEx-M"])
    ap.add_argument("--fraction", type=float, default=0.10)
    ap.add_argument("--request-seed", required=True, type=int, choices=[17, 29, 43])
    ap.add_argument("--data-root", type=Path, required=True)
    ap.add_argument("--request-dir", type=Path, required=True)
    ap.add_argument("--ref-a", type=Path, required=True)
    ap.add_argument("--ref-b", type=Path, required=True)
    ap.add_argument("--method", action="append", default=[])
    ap.add_argument("--baseline-dir", type=Path, required=True)
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--max-queries", type=int, default=1000)
    ap.add_argument("--test-queries", type=int, default=1000)
    ap.add_argument("--background-contexts", type=int, default=B_FROZEN)
    ap.add_argument("--controls", type=int, default=K_FROZEN)
    ap.add_argument("--placement-targets", type=int, default=P_FROZEN)
    ap.add_argument("--eval-batch", type=int, default=16)
    ap.add_argument("--entity-chunk", type=int, default=4096)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()

    if not np.isclose(args.fraction, 0.10, rtol=0.0, atol=1e-12):
        raise RuntimeError("W9 protocol frozen at fraction=0.10")
    if (args.background_contexts, args.controls, args.placement_targets) != (B_FROZEN, K_FROZEN, P_FROZEN):
        raise RuntimeError("W9 protocol frozen at B=200, K=20, P=256")

    methods = parse_named(args.method)
    if tuple(sorted(methods)) != tuple(sorted(METHODS)):
        raise RuntimeError(f"W9 requires exactly {METHODS}, got {sorted(methods)}")

    torch.set_num_threads(1)
    data = deterministic_holdout(load_dataset(*infer_paths(args.dataset, args.data_root)), seed=17)
    fi, _ = select_forget(
        data.train, args.fraction,
        args.request_seed + int(args.fraction * 10000), "random"
    )
    forget = data.train[fi]
    keep = np.ones(len(data.train), dtype=bool)
    keep[fi] = False
    retain = data.train[keep]
    req_hash = request_fingerprint(data, forget)

    manifest, all_data_path = verify_exported_request(
        args.request_dir, data, forget, args.dataset, "random",
        args.request_seed, args.fraction,
    )
    if manifest.get("request_hash") and manifest["request_hash"] != req_hash:
        raise RuntimeError("Request hash mismatch")

    entity2id, relation2id = graphdpo_vocab(all_data_path)
    forget_mask = supported_mask(forget, data, entity2id, relation2id)
    if not forget_mask.all():
        raise RuntimeError("Forgotten request not fully covered by common vocabulary")
    retain_mask = supported_mask(retain, data, entity2id, relation2id)
    forget_c = map_supported(forget, data, entity2id, relation2id)
    retain_c = map_supported(retain[retain_mask], data, entity2id, relation2id)
    ne = len(entity2id)

    pre_c = np.concatenate([retain_c, forget_c], axis=0)
    rdeg = degree(retain_c, ne)
    udeg = degree(forget_c, ne)
    predeg = degree(pre_c, ne)
    affected = np.flatnonzero(udeg > 0)
    rho = np.zeros(ne, dtype=np.float32)
    rho[affected] = udeg[affected] / np.maximum(predeg[affected], 1)

    control_seed = sha_seed(args.dataset, args.request_seed, req_hash, "w9-controls-v1")
    controls, _ = matched_controls_k(
        affected, affected, rdeg, predeg, K_FROZEN, control_seed
    )
    cal_seed = sha_seed(args.dataset, args.request_seed, req_hash, "w9-calibration-v1")
    bg_idx = sample_indices(len(retain_c), B_FROZEN, cal_seed)
    background = np.asarray(retain_c[bg_idx], dtype=np.int64)

    # Freeze BOTH correction vectors for ALL candidate methods before loading any reference
    # checkpoint, test triples, validation triples, forgotten evaluation ranks, or probe contexts.
    frozen_bias: dict[str, dict[str, np.ndarray]] = {}
    delta_stats: dict[str, dict[str, float]] = {}
    for method in METHODS:
        model = load_graphdpo_shared_checkpoint(methods[method]).to(args.device)
        delta = estimate_delta(
            model, background, affected, controls, ne, args.device, batch=32
        )
        exact = np.zeros(ne, dtype=np.float32)
        exact[affected] = delta
        weighted = np.zeros(ne, dtype=np.float32)
        weighted[affected] = rho[affected] * delta
        for variant, bias in (("exact", exact), ("support_weighted", weighted)):
            bitwise_gate(
                model, background, bias, affected, ne, args.device,
                sha_seed(args.dataset, args.request_seed, req_hash, method, variant, "w9-bitwise-v1"),
            )
        frozen_bias[method] = {"exact": exact, "support_weighted": weighted}
        delta_stats[method] = {
            "mean": float(np.mean(delta)),
            "median": float(np.median(delta)),
            "q05": float(np.quantile(delta, 0.05)),
            "q95": float(np.quantile(delta, 0.95)),
        }
        del model
        if args.device.startswith("cuda"):
            torch.cuda.empty_cache()

    # Evaluation-only material starts here.
    valid_mask = supported_mask(data.valid, data, entity2id, relation2id)
    test_mask = supported_mask(data.test, data, entity2id, relation2id)
    valid_c = map_supported(data.valid[valid_mask], data, entity2id, relation2id)
    test_c = map_supported(data.test[test_mask], data, entity2id, relation2id)
    truth = (retain_c, valid_c, test_c, forget_c)

    q, q_idx = fixed_query_subset(
        forget_c, args.max_queries, EVAL_SEED + args.request_seed
    )
    test_q, test_idx = fixed_query_subset(
        test_c, args.test_queries,
        sha_seed(args.dataset, args.request_seed, req_hash, "w9-test-v1"),
    )

    refa = load_graphdpo_shared_checkpoint(args.ref_a).to(args.device)
    refb = load_graphdpo_shared_checkpoint(args.ref_b).to(args.device)
    refa_rank = ranks_for_queries(refa, q, ne, truth, args.device, args.eval_batch, args.entity_chunk)
    refb_rank = ranks_for_queries(refb, q, ne, truth, args.device, args.eval_batch, args.entity_chunk)
    null = rank_pair(refb_rank, refa_rank)

    # Frozen placement sample and independent contexts, constructed only now.
    selected = choose_probe_targets(
        affected, P_FROZEN,
        sha_seed(args.dataset, args.request_seed, req_hash, "w9-placement-targets-v1"),
    )
    pctrl, _ = matched_controls_k(
        selected, affected, rdeg, predeg, 1,
        sha_seed(args.dataset, args.request_seed, req_hash, "w9-placement-controls-v1"),
    )
    pctrl = pctrl[:, 0]
    all_true_arr = np.concatenate([pre_c, valid_c, test_c], axis=0)
    all_true = {tuple(map(int, x)) for x in all_true_arr}
    forbidden_bg = {tuple(map(int, x)) for x in background}
    contexts = {
        "tail": build_probe_contexts(
            "tail", retain_c, selected, pctrl, all_true, forbidden_bg,
            sha_seed(args.dataset, args.request_seed, req_hash, "w9-placement-contexts-v1", "tail"),
        ),
        "head": build_probe_contexts(
            "head", retain_c, selected, pctrl, all_true, forbidden_bg,
            sha_seed(args.dataset, args.request_seed, req_hash, "w9-placement-contexts-v1", "head"),
        ),
    }

    args.out.mkdir(parents=True, exist_ok=True)
    zero = np.zeros(ne, dtype=np.float32)
    baseline_rows_path = args.baseline_dir / f"{args.dataset}_seed{args.request_seed}_published_rank_rows.csv"
    if not baseline_rows_path.is_file():
        raise FileNotFoundError(baseline_rows_path)

    summaries = []
    for method in METHODS:
        candidate = load_graphdpo_shared_checkpoint(methods[method]).to(args.device)
        baseline_rank = ranks_corrected(
            candidate, q, zero, ne, truth, args.device, args.eval_batch, args.entity_chunk
        )
        expected = load_baseline_rows(baseline_rows_path, method)
        if expected.shape != baseline_rank.shape or not np.array_equal(expected, baseline_rank):
            if expected.shape != baseline_rank.shape or not np.allclose(expected, baseline_rank, rtol=0.0, atol=1e-7):
                raise RuntimeError(
                    f"Published-method baseline reproduction failed for {method}: "
                    f"expected_shape={expected.shape} got={baseline_rank.shape}"
                )

        base_metric = rank_pair(baseline_rank, refa_rank)
        baseline_test = ranks_corrected(
            candidate, test_q, zero, ne, (retain_c, valid_c, test_c),
            args.device, args.eval_batch, args.entity_chunk
        )
        placement_before = placement_did(
            candidate, refa, refb, selected, pctrl, contexts,
            zero, ne, args.device, args.eval_batch, args.entity_chunk,
        )

        for variant in VARIANTS:
            bias = frozen_bias[method][variant]
            corr_rank = ranks_corrected(
                candidate, q, bias, ne, truth, args.device, args.eval_batch, args.entity_chunk
            )
            corr_metric = rank_pair(corr_rank, refa_rank)
            corr_test = ranks_corrected(
                candidate, test_q, bias, ne, (retain_c, valid_c, test_c),
                args.device, args.eval_batch, args.entity_chunk
            )
            placement_after = placement_did(
                candidate, refa, refb, selected, pctrl, contexts,
                bias, ne, args.device, args.eval_batch, args.entity_chunk,
            )

            record = {
                "dataset": args.dataset,
                "request_seed": int(args.request_seed),
                "request_hash": req_hash,
                "fraction": float(args.fraction),
                "method": method,
                "variant": variant,
                "B": B_FROZEN,
                "K": K_FROZEN,
                "P": P_FROZEN,
                "calibration_rule": "median",
                "affected_endpoints": int(len(affected)),
                "probed_endpoints": int(len(selected)),
                "baseline_candidate_logrank": base_metric["mean_abs_log10_rank_gap"],
                "corrected_candidate_logrank": corr_metric["mean_abs_log10_rank_gap"],
                "null_logrank": null["mean_abs_log10_rank_gap"],
                "baseline_logrank_excess": base_metric["mean_abs_log10_rank_gap"] - null["mean_abs_log10_rank_gap"],
                "corrected_logrank_excess": corr_metric["mean_abs_log10_rank_gap"] - null["mean_abs_log10_rank_gap"],
                "logrank_excess_reduction": (
                    base_metric["mean_abs_log10_rank_gap"] - corr_metric["mean_abs_log10_rank_gap"]
                ),
                "baseline_top10_excess": base_metric["top10_membership_disagreement"] - null["top10_membership_disagreement"],
                "corrected_top10_excess": corr_metric["top10_membership_disagreement"] - null["top10_membership_disagreement"],
                "baseline_top100_excess": base_metric["top100_membership_disagreement"] - null["top100_membership_disagreement"],
                "corrected_top100_excess": corr_metric["top100_membership_disagreement"] - null["top100_membership_disagreement"],
                "baseline_mrr_excess": base_metric["mrr_gap"] - null["mrr_gap"],
                "corrected_mrr_excess": corr_metric["mrr_gap"] - null["mrr_gap"],
                "baseline_test_mrr": float(np.mean(1.0 / baseline_test)),
                "corrected_test_mrr": float(np.mean(1.0 / corr_test)),
                "test_mrr_change": float(np.mean(1.0 / corr_test) - np.mean(1.0 / baseline_test)),
                "placement_did_before": float(np.mean(placement_before)),
                "placement_did_after": float(np.mean(placement_after)),
                "placement_did_reduction": float(np.mean(placement_before - placement_after)),
                "delta_stats": delta_stats[method],
                "rho_mean": float(np.mean(rho[affected])),
                "rho_median": float(np.median(rho[affected])),
                "rho_q05": float(np.quantile(rho[affected], 0.05)),
                "rho_q95": float(np.quantile(rho[affected], 0.95)),
                "baseline_reproduction_gate": True,
                "bitwise_nonaffected_gate": True,
                "checkpoints": {
                    "candidate": methods[method],
                    "RefA": str(args.ref_a),
                    "RefB": str(args.ref_b),
                },
            }
            stem = f"{args.dataset}_seed{args.request_seed}_{method}_{variant}"
            (args.out / f"{stem}.json").write_text(json.dumps(record, indent=2) + "\n")
            np.savez_compressed(
                args.out / f"{stem}.npz",
                forgotten_query_index=q_idx,
                baseline_rank=baseline_rank.astype(np.float32),
                corrected_rank=corr_rank.astype(np.float32),
                refA_rank=refa_rank.astype(np.float32),
                refB_rank=refb_rank.astype(np.float32),
                test_query_index=test_idx,
                baseline_test_rank=baseline_test.astype(np.float32),
                corrected_test_rank=corr_test.astype(np.float32),
                placement_selected=selected,
                placement_controls=pctrl,
                placement_did_before=placement_before.astype(np.float32),
                placement_did_after=placement_after.astype(np.float32),
                affected_endpoints=affected,
                rho=rho[affected].astype(np.float32),
                delta=(frozen_bias[method]["exact"][affected]).astype(np.float32),
                calibration_background=background,
                placement_tail_contexts=contexts["tail"],
                placement_head_contexts=contexts["head"],
            )
            summaries.append(record)
            print(
                "W9_METHOD_CELL_OK", args.dataset, args.request_seed, method, variant,
                "before_excess", f"{record['baseline_logrank_excess']:.10f}",
                "after_excess", f"{record['corrected_logrank_excess']:.10f}",
                "placement_reduction", f"{record['placement_did_reduction']:.10f}",
                "test_mrr_change", f"{record['test_mrr_change']:.10f}",
                flush=True,
            )

        del candidate
        if args.device.startswith("cuda"):
            torch.cuda.empty_cache()

    cell_summary = {
        "dataset": args.dataset,
        "request_seed": int(args.request_seed),
        "request_hash": req_hash,
        "methods": list(METHODS),
        "variants": list(VARIANTS),
        "records": summaries,
    }
    (args.out / f"{args.dataset}_seed{args.request_seed}_W9_CELL_SUMMARY.json").write_text(
        json.dumps(cell_summary, indent=2) + "\n"
    )
    print("W9_REQUEST_CELL_OK", args.dataset, args.request_seed, req_hash, flush=True)


if __name__ == "__main__":
    main()
