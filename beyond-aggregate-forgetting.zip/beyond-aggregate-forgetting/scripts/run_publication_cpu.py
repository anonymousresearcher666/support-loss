from __future__ import annotations
import argparse,csv,json
from collections import defaultdict
from pathlib import Path
import numpy as np
import torch
from schemacert.data import infer_paths,load_dataset,deterministic_holdout
from schemacert.models import make_model
from schemacert.train import train_model,clone_model
from schemacert.unlearn import local_retrain
from schemacert.eval import mean_score


def fresh(name,ne,nr,dim,seed,device):
    torch.manual_seed(seed); np.random.seed(seed)
    if device.startswith('cuda'): torch.cuda.manual_seed_all(seed)
    return make_model(name,ne,nr,dim).to(device)


def select_forget(train,fraction,seed,policy='relation'):
    rng=np.random.default_rng(seed)
    if policy=='relation':
        u,c=np.unique(train[:,1],return_counts=True); rid=int(u[np.argmax(c)]); cand=np.flatnonzero(train[:,1]==rid); k=max(1,int(round(fraction*len(cand))))
        tails,counts=np.unique(train[cand,2],return_counts=True); order=tails[np.argsort(-counts)]; picked=[]
        for t in order:
            x=cand[train[cand,2]==t]
            if len(x)>1: picked.extend(x.tolist())
            if len(picked)>=max(2,k//3): break
        picked=list(dict.fromkeys(picked))[:min(k,max(2,k//3))]; s=set(picked); rem=np.asarray([int(i) for i in cand if int(i) not in s],dtype=np.int64)
        if len(picked)<k: picked += rng.choice(rem,k-len(picked),replace=False).tolist()
        return np.asarray(picked[:k],dtype=np.int64),{'policy':'relation','relation_id':rid,'candidates':len(cand)}
    if policy=='random':
        k=max(1,int(round(fraction*len(train)))); return np.sort(rng.choice(len(train),k,replace=False)),{'policy':'random','candidates':len(train)}
    if policy=='entity':
        target=max(1,int(round(fraction*len(train)))); ents=np.r_[train[:,0],train[:,2]]; u,c=np.unique(ents,return_counts=True); order=u[np.argsort(-c)]; chosen=[]; mask=np.zeros(len(train),bool)
        for e in order:
            chosen.append(int(e)); mask |= (train[:,0]==e)|(train[:,2]==e)
            if int(mask.sum())>=target: break
        return np.flatnonzero(mask),{'policy':'entity','entities':chosen,'candidates':len(train)}
    raise KeyError(policy)


def filter_maps(*arrays):
    tails=defaultdict(set); heads=defaultdict(set)
    for arr in arrays:
        for h,r,t in arr:
            tails[(int(h),int(r))].add(int(t)); heads[(int(r),int(t))].add(int(h))
    return tails,heads


def candidate_scores(model,kind,a,b,cand):
    if model.__class__.__name__.lower()=='transe':
        e=model.entity(cand)
        if kind=='tail':
            q=model.entity(a)+model.relation(b); return -torch.linalg.vector_norm(q[:,None,:]-e[None,:,:],ord=model.p,dim=-1)
        q=model.entity(b)-model.relation(a); return -torch.linalg.vector_norm(e[None,:,:]-q[:,None,:],ord=model.p,dim=-1)
    e=model.entity(cand); er,ei=e.chunk(2,-1)
    if kind=='tail':
        h=model.entity(a); r=model.relation(b); hr,hi=h.chunk(2,-1); rr,ri=r.chunk(2,-1); ar=hr*rr-hi*ri; ai=hi*rr+hr*ri; return ar@er.T+ai@ei.T
    r=model.relation(a); t=model.entity(b); rr,ri=r.chunk(2,-1); tr,ti=t.chunk(2,-1); ar=rr*tr+ri*ti; ai=rr*ti-ri*tr; return ar@er.T+ai@ei.T


@torch.no_grad()
def filtered_lp(model,queries,ne,truth,device,batch=16,chunk=4096,max_queries=1000,seed=17):
    rng=np.random.default_rng(seed); q=queries
    if max_queries and len(q)>max_queries: q=q[rng.choice(len(q),max_queries,replace=False)]
    tails,heads=filter_maps(*truth); cand_full=torch.arange(ne,dtype=torch.long,device=device); rr=[]
    model.to(device); model.eval()
    for st in range(0,len(q),batch):
        b=q[st:st+batch]; bt=torch.as_tensor(b,dtype=torch.long,device=device); true=model.score(bt).float(); B=len(b)
        counts=torch.zeros(B,dtype=torch.long,device=device)
        for cs in range(0,ne,chunk):
            ce=min(ne,cs+chunk); cand=cand_full[cs:ce]; sc=candidate_scores(model,'tail',bt[:,0],bt[:,1],cand).float()
            for j,(h,r,t) in enumerate(b):
                for x in tails.get((int(h),int(r)),()):
                    if x!=int(t) and cs<=x<ce: sc[j,x-cs]=-torch.inf
            counts += (sc>true[:,None]).sum(1)
        rr.extend((1/(counts+1).float()).cpu().tolist())
        counts=torch.zeros(B,dtype=torch.long,device=device)
        for cs in range(0,ne,chunk):
            ce=min(ne,cs+chunk); cand=cand_full[cs:ce]; sc=candidate_scores(model,'head',bt[:,1],bt[:,2],cand).float()
            for j,(h,r,t) in enumerate(b):
                for x in heads.get((int(r),int(t)),()):
                    if x!=int(h) and cs<=x<ce: sc[j,x-cs]=-torch.inf
            counts += (sc>true[:,None]).sum(1)
        rr.extend((1/(counts+1).float()).cpu().tolist())
    rr=np.asarray(rr); ranks=1/rr
    return {'mrr':float(rr.mean()),'h1':float((ranks<=1).mean()),'h3':float((ranks<=3).mean()),'h10':float((ranks<=10).mean()),'n':int(len(rr))}


def param_dist(a,b):
    with torch.no_grad(): return float(sum(float(((x.detach().cpu()-y.detach().cpu())**2).sum()) for x,y in zip(a.parameters(),b.parameters()))**0.5)


def score_rmse(a,b,triples,device,maxq,seed):
    rng=np.random.default_rng(seed); q=triples if maxq<=0 or len(triples)<=maxq else triples[rng.choice(len(triples),maxq,replace=False)]; ss=0.;n=0
    with torch.no_grad():
        for i in range(0,len(q),4096):
            x=torch.as_tensor(q[i:i+4096],dtype=torch.long,device=device); d=(a.score(x)-b.score(x)).float(); ss+=float((d*d).sum()); n+=len(x)
    return float((ss/max(n,1))**0.5)


def run(args):
    seed=args.seed; device=args.device; torch.set_num_threads(max(1,args.threads)); tp=infer_paths(args.dataset,args.data_root); data=deterministic_holdout(load_dataset(*tp),seed=17); ne,nr=len(data.entities),len(data.relations)
    base=fresh(args.model,ne,nr,args.dim,seed,device); bs=train_model(base,data.train,ne,args.epochs,args.batch_size,args.lr,args.l2,seed,device)
    base_lp=filtered_lp(base,data.test,ne,(data.train,data.valid,data.test),device,args.eval_batch,args.entity_chunk,args.eval_queries,seed)
    rows=[]
    for frac in args.fractions:
        fi,meta=select_forget(data.train,frac,seed+int(frac*10000),args.policy); forget=data.train[fi]
        local,retain,lstats=local_retrain(base,data.train,fi,ne,args.hops,args.local_epochs,args.batch_size,args.local_lr,args.l2,seed,device)
        ref=fresh(args.model,ne,nr,args.dim,seed,device); rs=train_model(ref,retain,ne,args.ref_epochs,args.batch_size,args.lr,args.l2,seed,device)
        ft=clone_model(base); fs=train_model(ft,retain,ne,args.local_epochs,args.batch_size,args.local_lr,args.l2,seed+31,device)
        local_lp=filtered_lp(local.model,data.test,ne,(retain,data.valid,data.test),device,args.eval_batch,args.entity_chunk,args.eval_queries,seed)
        ref_lp=filtered_lp(ref,data.test,ne,(retain,data.valid,data.test),device,args.eval_batch,args.entity_chunk,args.eval_queries,seed)
        probe=np.concatenate([data.valid,data.test,forget]) if len(data.valid) else np.concatenate([data.test,forget])
        row=dict(dataset=args.dataset,model=args.model,policy=args.policy,seed=seed,dim=args.dim,epochs=args.epochs,train_triples=len(data.train),entities=ne,relations=nr,fraction=frac,forget_n=len(fi),request_meta=json.dumps(meta,separators=(',',':')),affected_entities=len(local.affected_entities),affected_relations=len(local.affected_relations),boundary_entities=len(local.boundary_entities),parameter_fraction=local.parameter_fraction,base_train_sec=bs.seconds,local_sec=local.seconds,reference_retrain_sec=rs.seconds,full_finetune_sec=fs.seconds,speedup_vs_reference=rs.seconds/max(local.seconds,1e-12),base_mrr=base_lp['mrr'],local_mrr=local_lp['mrr'],reference_mrr=ref_lp['mrr'],local_h1=local_lp['h1'],reference_h1=ref_lp['h1'],local_h3=local_lp['h3'],reference_h3=ref_lp['h3'],local_h10=local_lp['h10'],reference_h10=ref_lp['h10'],mrr_gap_to_reference=abs(local_lp['mrr']-ref_lp['mrr']),score_rmse_to_reference=score_rmse(local.model,ref,probe,device,args.score_queries,seed),parameter_distance_to_reference=param_dist(local.model,ref),forget_score_base=mean_score(base,forget,device=device),forget_score_local=mean_score(local.model,forget,device=device),forget_score_reference=mean_score(ref,forget,device=device),forget_score_gap_to_reference=abs(mean_score(local.model,forget,device=device)-mean_score(ref,forget,device=device)),eval_rankings=local_lp['n'])
        rows.append(row); print(json.dumps(row),flush=True)
        del ref,ft,local
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True);stem=f'{args.dataset}_{args.model}_{args.policy}_s{seed}';json.dump(rows,open(out/f'{stem}.json','w'),indent=2)
    with open(out/f'{stem}.csv','w',newline='') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)


def main():
    p=argparse.ArgumentParser();p.add_argument('--dataset',required=True);p.add_argument('--model',choices=['transe','complex'],required=True);p.add_argument('--policy',choices=['relation','random','entity'],default='relation');p.add_argument('--seed',type=int,default=17);p.add_argument('--data-root',default='data');p.add_argument('--out',default='results_publication');p.add_argument('--device',default='cpu');p.add_argument('--threads',type=int,default=4);p.add_argument('--dim',type=int,default=128);p.add_argument('--epochs',type=int,default=20);p.add_argument('--ref-epochs',type=int,default=20);p.add_argument('--local-epochs',type=int,default=5);p.add_argument('--batch-size',type=int,default=4096);p.add_argument('--lr',type=float,default=.002);p.add_argument('--local-lr',type=float,default=.001);p.add_argument('--l2',type=float,default=1e-6);p.add_argument('--hops',type=int,default=1);p.add_argument('--eval-batch',type=int,default=16);p.add_argument('--entity-chunk',type=int,default=4096);p.add_argument('--eval-queries',type=int,default=1000);p.add_argument('--score-queries',type=int,default=10000);p.add_argument('--fractions',nargs='+',type=float,default=[.01,.05,.10,.20]);a=p.parse_args();run(a)
if __name__=='__main__':main()
