from __future__ import annotations
import argparse,csv,json
from pathlib import Path
import numpy as np
import torch
from schemacert.data import infer_paths,load_dataset,deterministic_holdout
from schemacert.models import make_model
from schemacert.train import train_model,clone_model
from schemacert.unlearn import select_forget,local_retrain
from schemacert.eval import sampled_mrr,mean_score
from schemacert.certificate import structural_certificate

def run(args):
    torch.manual_seed(args.seed);np.random.seed(args.seed);torch.set_num_threads(max(1,args.threads));tp=infer_paths(args.dataset,args.data_root);data=deterministic_holdout(load_dataset(*tp),seed=args.seed);ne=len(data.entities);nr=len(data.relations);model=make_model(args.model,ne,nr,args.dim);base=train_model(model,data.train,ne,args.epochs,args.batch_size,args.lr,args.l2,args.seed,args.device);base_mrr=sampled_mrr(model,data.test,ne,args.eval_neg,args.eval_queries,args.seed,args.device);rows=[]
    for frac in args.fractions:
        fi,rid,rc=select_forget(data.train,frac,args.seed+int(frac*10000));f=data.train[fi];loc,retain,lstats=local_retrain(model,data.train,fi,ne,args.hops,args.local_epochs,args.batch_size,args.local_lr,args.l2,args.seed,args.device);retr=clone_model(model);rstats=train_model(retr,retain,ne,args.retrain_epochs,args.batch_size,args.local_lr,args.l2,args.seed+7,args.device);bmask=np.isin(retain[:,0],loc.boundary_entities)|np.isin(retain[:,2],loc.boundary_entities);btrip=retain[bmask]
        with torch.no_grad(): d2=sum(float(((a-b)**2).sum()) for a,b in zip(loc.model.parameters(),retr.parameters()))
        dist=d2**0.5;cert=structural_certificate(data.train,fi,loc.affected_entities,loc.affected_relations,dist,damping=args.damping);row=dict(dataset=args.dataset,model=args.model,train_triples=len(data.train),entities=ne,relations=nr,relation_id=rid,relation_count=rc,fraction=frac,forget_n=len(fi),affected_entities=len(loc.affected_entities),affected_relations=len(loc.affected_relations),boundary_entities=len(loc.boundary_entities),parameter_fraction=loc.parameter_fraction,base_train_sec=base.seconds,local_sec=loc.seconds,retrain_ft_sec=rstats.seconds,parameter_distance_to_retrain_ft=dist,eta_proxy=cert.eta_proxy,boundary_ratio=cert.boundary_ratio,radius_proxy=cert.radius_proxy,base_mrr=base_mrr,local_mrr=sampled_mrr(loc.model,data.test,ne,args.eval_neg,args.eval_queries,args.seed,args.device),retrain_ft_mrr=sampled_mrr(retr,data.test,ne,args.eval_neg,args.eval_queries,args.seed,args.device),forget_score_before=mean_score(model,f,device=args.device),forget_score_local=mean_score(loc.model,f,device=args.device),forget_score_retrain_ft=mean_score(retr,f,device=args.device),boundary_mrr_local=sampled_mrr(loc.model,btrip,ne,args.eval_neg,min(args.eval_queries,len(btrip)),args.seed,args.device),boundary_mrr_retrain_ft=sampled_mrr(retr,btrip,ne,args.eval_neg,min(args.eval_queries,len(btrip)),args.seed,args.device));rows.append(row);print(json.dumps(row),flush=True)
    return rows

def main():
    p=argparse.ArgumentParser();p.add_argument('--dataset',required=True);p.add_argument('--model',choices=['transe','complex'],default='transe');p.add_argument('--data-root',default='data');p.add_argument('--out',default='results');p.add_argument('--dim',type=int,default=64);p.add_argument('--epochs',type=int,default=4);p.add_argument('--local-epochs',type=int,default=3);p.add_argument('--retrain-epochs',type=int,default=3);p.add_argument('--batch-size',type=int,default=2048);p.add_argument('--lr',type=float,default=.002);p.add_argument('--local-lr',type=float,default=.001);p.add_argument('--l2',type=float,default=1e-6);p.add_argument('--damping',type=float,default=.1);p.add_argument('--hops',type=int,default=1);p.add_argument('--eval-neg',type=int,default=256);p.add_argument('--eval-queries',type=int,default=1000);p.add_argument('--threads',type=int,default=4);p.add_argument('--seed',type=int,default=17);p.add_argument('--device',default='cpu');p.add_argument('--fractions',type=float,nargs='+',default=[.01,.05,.10,.20]);a=p.parse_args();rows=run(a);out=Path(a.out);out.mkdir(parents=True,exist_ok=True);name=f'{a.dataset}_{a.model}';json.dump(rows,open(out/f'{name}.json','w'),indent=2);f=open(out/f'{name}.csv','w',newline='');w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows);f.close()
if __name__=='__main__':main()
