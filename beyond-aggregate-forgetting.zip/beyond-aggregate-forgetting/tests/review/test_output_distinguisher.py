import unittest
import numpy as np
from scripts.experiments.diagnose_output_distinguishability import roc_auc,fit_attack,features
class OutputDistinguisherTests(unittest.TestCase):
    def test_auc_ties_and_no_orientation_flip(self):
        y=np.array([0,0,1,1])
        self.assertEqual(roc_auc(y,[1,1,1,1]),.5)
        self.assertEqual(roc_auc(y,[0,0,1,1]),1.)
        self.assertEqual(roc_auc(y,[1,1,0,0]),0.)
    def test_classifier_separation(self):
        x=np.array([[-3.,0],[-2.,0],[-1.,0],[1.,0],[2.,0],[3.,0]])
        f=fit_attack(x,np.array([0,0,0,1,1,1]))
        self.assertLess(f([[-1.,0]])[0],0);self.assertGreater(f([[1.,0]])[0],0)
    def test_features_are_per_query(self):
        p={'forgotten_scores':np.array([[1,2,3],[1,2,3]]),'forgotten_ranks':np.array([[1,2,3],[3,2,1]])}
        x=features(p);self.assertEqual(x.shape,(3,3));np.testing.assert_array_equal(x[:,0],[1,2,3])
if __name__=='__main__':unittest.main()
