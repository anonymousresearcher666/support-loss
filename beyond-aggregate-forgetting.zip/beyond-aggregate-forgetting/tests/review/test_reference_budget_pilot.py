"""Tests for the independently specified full-split reference-budget study."""
import copy
import unittest
import numpy as np
import torch
from scripts.experiments.run_reference_budget_pilot import (
    corrupt_tail, epoch, filters, fresh, rank_queries, star_request, PROTOCOL)

class ReferenceBudgetTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)
        self.triples = np.array([[0,0,1],[0,0,2],[0,1,3],[1,0,2],[2,1,3],[3,1,1]],dtype=np.int64)

    def test_negatives_never_equal_the_positive_tail(self):
        for ne in (2,4,100):
            pos=np.tile([[0,0,ne-1],[0,0,0]],(2000,1))
            neg=corrupt_tail(pos,ne,np.random.default_rng(99))
            self.assertTrue(np.all(neg[:,2]!=pos[:,2]))
            self.assertTrue(np.all((neg[:,2]>=0)&(neg[:,2]<ne)))
            np.testing.assert_array_equal(neg[:,:2],pos[:,:2])
        with self.assertRaises(ValueError): corrupt_tail(self.triples,1,np.random.default_rng(1))

    def test_stars_remove_all_selected_entity_incidence(self):
        ix,selected=star_request(self.triples,.25)
        remain=np.delete(self.triples,ix,axis=0)
        self.assertFalse(np.isin(remain[:,[0,2]],selected).any())
        self.assertGreaterEqual(len(ix),round(.25*len(self.triples)))
        np.testing.assert_array_equal(ix,star_request(self.triples,.25)[0])

    def test_initialization_does_not_change_global_rng(self):
        torch.manual_seed(8);state=torch.get_rng_state().clone()
        a=fresh(4,2,17,dim=3);b=fresh(4,2,17,dim=3)
        self.assertTrue(torch.equal(torch.get_rng_state(),state))
        for x,y in zip(a.parameters(),b.parameters()):self.assertTrue(torch.equal(x,y))

    def test_correct_average_ties_and_filtered_target(self):
        m=fresh(4,1,17,dim=2)
        with torch.no_grad():
            m.entity.weight.fill_(1);m.relation.weight.fill_(1)
        q=np.array([[0,0,1]])
        # One alternative true tail is excluded; 3 tail candidates remain.
        truth=filters(q,np.array([[0,0,2]]))
        pred=rank_queries(m,q,truth)
        np.testing.assert_array_equal(pred['ranks'],[[2.5],[2.0]])
        self.assertTrue(np.isfinite(pred['scores']).all())

    def test_scores_and_ranks_match_direct_enumeration(self):
        m=fresh(4,2,123,dim=3);q=self.triples[:3];truth=filters(self.triples)
        got=rank_queries(m,q,truth,batch=1)
        E=m.entity.weight.detach().double().numpy();R=m.relation.weight.detach().double().numpy()
        for side in (0,1):
            for k,(h,r,t) in enumerate(q):
                # Use integer synthetic scores for an exact tie-free oracle below.
                scores=(E*R[r]*E[t if side==0 else h]).sum(-1)
                target=h if side==0 else t
                exclude=truth[1].get((r,t),set()) if side==0 else truth[0].get((h,r),set())
                rivals=[j for j in range(4) if j!=target and j not in exclude]
                rank=1+sum(scores[j]>scores[target] for j in rivals)+.5*sum(scores[j]==scores[target] for j in rivals)
                self.assertEqual(rank,got['ranks'][side,k])
                self.assertAlmostEqual(scores[target],got['scores'][side,k],places=13)

    def test_equal_presentations_and_frozen_rows(self):
        m=fresh(4,2,17,dim=3);before=copy.deepcopy(m)
        em=torch.tensor([[1.],[0.],[0.],[0.]]);rm=torch.ones(2,1)
        opt=torch.optim.Adam(m.parameters(),lr=PROTOCOL['lr'])
        stats=epoch(m,self.triples,opt,np.random.default_rng(19),4,budget=4100,masks=(em,rm))
        self.assertEqual(stats['presentations'],4100);self.assertEqual(stats['steps'],3)
        self.assertTrue(torch.equal(m.entity.weight[1:],before.entity.weight[1:]))
        self.assertFalse(torch.equal(m.entity.weight[0],before.entity.weight[0]))

    def test_dense_same_stream_same_rng_is_reproducible(self):
        a=fresh(4,2,17,dim=3);b=copy.deepcopy(a)
        for m in (a,b):
            opt=torch.optim.Adam(m.parameters(),lr=PROTOCOL['lr'])
            epoch(m,self.triples,opt,np.random.default_rng(29),4,budget=19)
        for x,y in zip(a.parameters(),b.parameters()):self.assertTrue(torch.equal(x,y))

if __name__=='__main__':unittest.main()
