import unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
import torch
from scripts.experiments.evaluate_random_fact_reconstruction import (
    cost_aware_star_cover,retained_degrees,restart_rows_all,repair_from_retained_star)
from schemacert.graphdpo_shared import GraphDPOSharedTransE,_graphdpo_facts,_margin_batch
from scripts.experiments.analyze_remaining_review_controls import attack_folds,FEATURE_SETS

class RestoredCoverTests(unittest.TestCase):
    def test_exhaustive_random_coverage_and_determinism(self):
        rng=np.random.default_rng(55991)
        for case in range(50):
            ne=8
            U=np.c_[rng.integers(ne,size=20),np.zeros(20,int),rng.integers(ne,size=20)]
            R=np.c_[rng.integers(ne,size=35),np.zeros(35,int),rng.integers(ne,size=35)]
            A=cost_aware_star_cover(U,R,ne)
            with self.subTest(case=case):
                self.assertTrue((np.isin(U[:,0],A)|np.isin(U[:,2],A)).all())
                np.testing.assert_array_equal(A,cost_aware_star_cover(U[rng.permutation(len(U))],R,ne))
                for v in A:
                    B=A[A!=v]
                    self.assertFalse((np.isin(U[:,0],B)|np.isin(U[:,2],B)).all())
    def test_self_loops_and_empty_request(self):
        R=np.array([[0,0,1],[1,0,2]])
        A=cost_aware_star_cover(np.array([[2,0,2],[0,0,1]]),R,3)
        self.assertIn(2,A)
        self.assertEqual(len(cost_aware_star_cover(np.empty((0,3),int),R,3)),0)
    def test_retained_self_loop_has_two_incidences(self):
        np.testing.assert_array_equal(retained_degrees(np.array([[0,0,0],[0,0,1]]),2),[3,1])
    def test_repair_only_uses_retained_positives_and_freezes_other_rows(self):
        torch.manual_seed(17)
        m=GraphDPOSharedTransE(torch.randn(6,4),torch.randn(4,4))
        R=np.array([[0,0,1],[2,2,3],[4,0,5],[0,2,4]])
        anchors=np.array([0,2]);seen=[]
        allowed=set(map(tuple,_graphdpo_facts(R[np.isin(R[:,0],anchors)|np.isin(R[:,2],anchors)])))
        def audited(model,pos,*a,**kw):
            seen.extend(map(tuple,pos));return _margin_batch(model,pos,*a,**kw)
        with patch('scripts.experiments.evaluate_random_fact_reconstruction._margin_batch',audited):
            out,_,n=repair_from_retained_star(m,R,anchors,6,1,2,.001,29,'cpu',2,1.)
        self.assertTrue(set(seen)<=allowed);self.assertEqual(n,3)
        self.assertTrue(torch.equal(out.relation.weight,m.relation.weight))
        untouched=np.array([1,3,4,5])
        self.assertTrue(torch.equal(out.entity.weight[untouched],m.entity.weight[untouched]))
    def test_seeded_reset_changes_only_requested_rows(self):
        m=GraphDPOSharedTransE(torch.randn(6,4),torch.randn(4,4));a,_=restart_rows_all(m,np.array([2,4]),9,'cpu');b,_=restart_rows_all(m,np.array([4,2]),9,'cpu')
        self.assertTrue(torch.equal(a.entity.weight,b.entity.weight))
        self.assertTrue(torch.equal(a.entity.weight[[0,1,3,5]],m.entity.weight[[0,1,3,5]]))
        self.assertTrue(torch.equal(a.relation.weight,m.relation.weight))

class FeatureSplitTests(unittest.TestCase):
    def test_model_identity_overlap_rejected(self):
        x=[np.zeros((20,3)) for _ in range(3)]
        with self.assertRaises(ValueError):list(attack_folds(x,x,['a','b','c'],['d','e','a'],[0]))
    def test_all_feature_ablations_preserve_split(self):
        rng=np.random.default_rng(3);x=[rng.normal(size=(50,3))+1 for _ in range(3)];y=[rng.normal(size=(50,3))-1 for _ in range(3)]
        for cols in FEATURE_SETS.values():
            rows=list(attack_folds(x,y,['a','b','c'],['d','e','f'],cols))
            self.assertEqual(len(rows),3)
            for r in rows:
                self.assertFalse(set(r['train_models'].split(';')) & set(r['test_models'].split(';')))
                self.assertEqual(r['train_queries'],25);self.assertEqual(r['test_queries'],25)
                self.assertGreaterEqual(r['roc_auc'],0);self.assertLessEqual(r['roc_auc'],1)
if __name__=='__main__':unittest.main()
