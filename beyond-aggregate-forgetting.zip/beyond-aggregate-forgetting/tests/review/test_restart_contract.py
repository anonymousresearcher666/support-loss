"""Initializer/score distinctions; not a retraining-equivalence test."""
import ast
from pathlib import Path
import unittest
import numpy as np
import torch
from schemacert.graphdpo_shared import GraphDPOSharedTransE, deterministic_xavier_restart

ROOT=Path(__file__).resolve().parents[2]

class RestartContractTests(unittest.TestCase):
    def setUp(self):
        g=torch.Generator().manual_seed(19)
        self.model=GraphDPOSharedTransE(torch.randn(6,4,generator=g,dtype=torch.float64),
                                      torch.randn(4,4,generator=g,dtype=torch.float64))
        self.retained=np.array([[1,0,2],[2,2,3]],dtype=np.int64)

    def test_seeded_xavier_not_zero_anchor(self):
        out,_,unsupported,_=deterministic_xavier_restart(self.model,self.retained,np.array([0,1]),27)
        self.assertEqual(unsupported.tolist(),[0])
        torch.testing.assert_close(out.entity.weight[1:],self.model.entity.weight[1:])
        torch.testing.assert_close(out.relation.weight,self.model.relation.weight)
        fresh=torch.empty_like(self.model.entity.weight)
        torch.nn.init.xavier_normal_(fresh,generator=torch.Generator().manual_seed(27))
        torch.testing.assert_close(out.entity.weight[0],fresh[0])
        self.assertGreater(float(out.entity.weight[0].detach().norm()),0.)

    def test_determinism_is_conditional_on_seed(self):
        a,_,_,_=deterministic_xavier_restart(self.model,self.retained,np.array([0]),27)
        b,_,_,_=deterministic_xavier_restart(self.model,self.retained,np.array([0]),27)
        c,_,_,_=deterministic_xavier_restart(self.model,self.retained,np.array([0]),28)
        torch.testing.assert_close(a.entity.weight,b.entity.weight)
        self.assertFalse(torch.equal(a.entity.weight[0],c.entity.weight[0]))

    def test_scores_do_not_identify_raw_vectors(self):
        other=GraphDPOSharedTransE(7*self.model.entity.weight.detach(),3*self.model.relation.weight.detach())
        triples=torch.tensor([[0,0,1],[1,2,4],[5,0,3]])
        torch.testing.assert_close(other.score(triples),self.model.score(triples),atol=1e-12,rtol=1e-12)
        self.assertGreater(float((other.entity.weight-self.model.entity.weight).detach().norm()),1.)

    def test_shared_adam_has_no_declared_ridge_weight_decay(self):
        tree=ast.parse((ROOT/'schemacert/graphdpo_shared.py').read_text())
        fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='local_retrain_graphdpo_shared')
        calls=[x for x in ast.walk(fn) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr=='Adam']
        self.assertEqual(len(calls),1)
        self.assertNotIn('weight_decay',{k.arg for k in calls[0].keywords})


if __name__=='__main__':unittest.main()
