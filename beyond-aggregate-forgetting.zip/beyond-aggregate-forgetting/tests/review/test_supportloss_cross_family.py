import copy
import importlib.util
from pathlib import Path
import unittest
import tempfile
import json
import csv
import numpy as np
import torch

ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('campaign',ROOT/'scripts/experiments/run_supportloss_cross_family.py')
x=importlib.util.module_from_spec(spec);spec.loader.exec_module(x)

class CampaignTests(unittest.TestCase):
    def setUp(self):
        x.DEVICE='cpu';x.DIM=8;x.NEGATIVE='tail';torch.set_num_threads(1)

    def test_candidate_scoring_matches_explicit_triples_all_families(self):
        for family in x.MODEL_NAMES:
            x.FAMILY=family;m=x.fresh(7,3,17).double()
            ids=torch.arange(7)
            for side in ('head','tail'):
                q=np.array([[1,2,4]])
                triples=torch.tensor(np.repeat(q,7,axis=0));triples[:,0 if side=='head' else 2]=ids
                a,b=(2,4) if side=='head' else (1,2)
                actual=m.score_candidates(side,torch.tensor([a]),torch.tensor([b]),ids)[0]
                torch.testing.assert_close(actual,m.score(triples),rtol=1e-12,atol=1e-12)
                expected=1+int((actual>actual[1 if side=='head' else 4]).sum())
                got=x.rank_queries(m,q,x.filters(q))['ranks'][0 if side=='head' else 1,0]
                self.assertEqual(got,expected,family)

    def test_fractional_ties_and_filtered_target(self):
        x.FAMILY='distmult';m=x.fresh(5,1,17)
        with torch.no_grad():
            for p in m.parameters():p.zero_()
        q=np.array([[0,0,1]])
        truth=x.filters(q,np.array([[0,0,2],[3,0,1]]))
        np.testing.assert_array_equal(x.rank_queries(m,q,truth)['ranks'],[[2.5],[2.5]])

    def test_corruption_excludes_positive_and_balances_sides(self):
        p=np.tile([1,0,2],(10000,1));x.NEGATIVE='balanced'
        n=x.corrupt_tail(p,7,np.random.default_rng(17))
        self.assertTrue(np.all((n!=p).sum(axis=1)==1))
        self.assertTrue(.45<np.mean(n[:,0]!=p[:,0])<.55)
        np.testing.assert_array_equal(n[:,1],p[:,1])

    def test_equal_stream_pairing_budget_and_frozen_parameters(self):
        x.FAMILY='complex';x.NEGATIVE='balanced';m=x.fresh(7,2,17);initial=copy.deepcopy(m)
        work=np.array([[0,0,1],[1,1,2],[2,0,3]],dtype=np.int64)
        em=torch.zeros(7,1);em[:3]=1;rm=torch.ones(2,1)
        stats=x.epoch(m,work,torch.optim.Adam(m.parameters(),lr=.002),np.random.default_rng(29),7,budget=11,masks=(em,rm))
        self.assertEqual(stats['presentations'],11)
        torch.testing.assert_close(m.entity.weight[3:],initial.entity.weight[3:],rtol=0,atol=0)
        replay=copy.deepcopy(initial)
        again=x.epoch(replay,work,torch.optim.Adam(replay.parameters(),lr=.002),np.random.default_rng(29),7,budget=11,masks=(em,rm))
        self.assertEqual(stats,again)
        for a,b in zip(m.parameters(),replay.parameters()):torch.testing.assert_close(a,b,rtol=0,atol=0)

    def test_complete_stars_remove_all_positive_support(self):
        train=np.array([[0,0,1],[0,0,2],[0,0,3],[1,0,2],[3,0,4],[4,0,1]])
        fi,selected=x.star_request(train)
        self.assertFalse(np.isin(np.delete(train,fi,axis=0)[:,[0,2]],selected).any())

class CollectorTests(unittest.TestCase):
    def test_functional_metrics_and_incomplete_smoke_rejection(self):
        spec=importlib.util.spec_from_file_location('collector',ROOT/'scripts/experiments/collect_supportloss_cross_family.py')
        collector=importlib.util.module_from_spec(spec);spec.loader.exec_module(collector)
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);run=root/'full/tail/FB15K-237/distmult/seed17';run.mkdir(parents=True)
            meta=dict(dataset='FB15K-237',seed=17,protocol=dict(smoke=False,model='distmult',negative_rule='tail uniform'),reference_labels=['Reference20'])
            (run/'COMPLETE.json').write_text(json.dumps(meta))
            methods=['Unchanged','ResetOnly','Local','ResetLocal','FullRetain','ResetFullRetain','ResetDenseSameWork','IndependentReference20','Reference20']
            for method in methods:
                payload={}
                for subset in ['forgotten','retained','test']:
                    payload[subset+'_ranks']=np.array([[1.,20.],[1.,20.]]) if method=='Reference20' else np.array([[2.,5.],[2.,5.]])
                    payload[subset+'_top1']=np.array([[1,2],[1,2]]) if method=='Reference20' else np.array([[1,3],[1,3]])
                np.savez_compressed(run/(method+'_predictions.npz'),**payload)
            collector.collect(root,1)
            with (root/'cross_family_per_seed.csv').open() as f:rows=list(csv.DictReader(f))
            self.assertEqual(len(rows),48)
            self.assertEqual(float(rows[0]['hits10_status_disagreement']),.5)
            self.assertEqual(float(rows[0]['top1_disagreement']),.5)
            self.assertAlmostEqual(float(rows[0]['absolute_mrr_gap']),.175)
            with self.assertRaises(ValueError):collector.collect(root,72)
            meta['protocol']['smoke']=True;(run/'COMPLETE.json').write_text(json.dumps(meta))
            with self.assertRaises(ValueError):collector.collect(root,1)

if __name__=='__main__':unittest.main()
