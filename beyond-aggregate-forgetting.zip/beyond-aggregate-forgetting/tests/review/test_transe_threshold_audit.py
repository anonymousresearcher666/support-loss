from pathlib import Path
import tempfile
import unittest
from scripts.experiments.analyze_transe_threshold_dump import parse

class TransEThresholdAuditTests(unittest.TestCase):
    def test_parser_keeps_matched_rows_and_metadata(self):
        text = '''==================== results/x/FB15K-237_transe_entity_f0.1_s17_common_shared_base.csv ====================
method,source,global_mrr,global_h1,global_h3,global_h10,forget_mrr,forget_h1,forget_h3,forget_h10
ExactRetrain,r,0.1,0.1,0.1,0.1,0.01,0,0,0.01
SchemaCert+Restart-L5,r,0.1,0.1,0.1,0.1,0.02,0,0,0.02
GraphDPO,r,0.1,0.1,0.1,0.1,0.4,0.2,0.3,0.5
NoiseMethod,r,0,0,0,0,0,0,0,0
'''
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'dump.txt';p.write_text(text)
            df=parse(p)
        self.assertEqual(set(df.method), {'ExactRetrain','SchemaCert+Restart-L5','GraphDPO'})
        self.assertEqual(set(df.dataset), {'FB15K-237'})
        self.assertEqual(set(df.seed), {'17'})
        self.assertEqual(set(df.fraction), {'0.1'})

    def test_reciprocal_rank_tail_compression(self):
        r,s=1000,100000
        self.assertLessEqual(abs(1/r-1/s),1/1000)
        self.assertGreater(abs(r-s),90000)

if __name__=='__main__':unittest.main()
