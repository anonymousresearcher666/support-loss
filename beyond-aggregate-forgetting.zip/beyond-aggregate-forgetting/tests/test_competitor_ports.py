import numpy as np
import pytest
import torch

from schemacert.competitor_ports import (
    save_graphdpo_shared_checkpoint,
    sgu_schema_entity_shared,
    zero_fisher_shared,
)
from schemacert.graphdpo_shared import GraphDPOSharedTransE, load_graphdpo_shared_checkpoint


def tiny_case():
    torch.manual_seed(7)
    ent = torch.randn(6, 8)
    # forward relation ids are 0 and 2; odd rows are their inverses
    rel = torch.randn(4, 8)
    base = GraphDPOSharedTransE(ent, rel)
    train = np.asarray([
        [0, 0, 1],  # forgotten
        [0, 2, 4],
        [1, 2, 5],
        [2, 0, 3],  # same-relation match for forgotten triple
        [2, 2, 4],
        [3, 2, 5],
    ], dtype=np.int64)
    forget_idx = np.asarray([0], dtype=np.int64)
    return base, train, forget_idx


def test_shared_checkpoint_roundtrip(tmp_path):
    base, _, _ = tiny_case()
    p = tmp_path / 'm.tar'
    save_graphdpo_shared_checkpoint(base, p)
    got = load_graphdpo_shared_checkpoint(p)
    assert torch.allclose(base.entity.weight, got.entity.weight)
    assert torch.allclose(base.relation.weight, got.relation.weight)


def test_zero_fisher_port_smoke_and_determinism():
    base, train, fi = tiny_case()
    a = zero_fisher_shared(
        base, train, fi, 6, seed=17, device='cpu',
        iterations=3, batch_size=4, neg_ratio=2, margin=2.0,
    )
    b = zero_fisher_shared(
        base, train, fi, 6, seed=17, device='cpu',
        iterations=3, batch_size=4, neg_ratio=2, margin=2.0,
    )
    assert torch.isfinite(a.model.entity.weight).all()
    assert torch.isfinite(a.model.relation.weight).all()
    assert torch.allclose(a.model.entity.weight, b.model.entity.weight)
    assert torch.allclose(a.model.relation.weight, b.model.relation.weight)
    assert a.metadata['iterations'] == 3


def test_sgu_port_smoke():
    pytest.importorskip('sklearn')
    base, train, fi = tiny_case()
    forget = train[fi]
    res = sgu_schema_entity_shared(
        base, train, forget,
        seed=17, device='cpu', n_clusters=1, lr=1e-5,
    )
    assert torch.isfinite(res.model.entity.weight).all()
    assert res.metadata['forgotten_triples'] == 1
    assert res.metadata['used_triples'] == 1
    assert res.metadata['skipped_triples'] == 0
