#!/usr/bin/env python3
import numpy as np
import torch

from schemacert.family_models import DistMult, ComplEx
from scripts.experiments.evaluate_family_missing_full import deterministic_family_restart


def check(model_cls):
    torch.manual_seed(7)
    m = model_cls(6, 2, 4)
    before = m.entity.weight.detach().clone()

    # Entity 0 has no retained positive support; entity 1 remains supported.
    retain = np.asarray([
        [1, 0, 2],
        [2, 0, 3],
        [3, 1, 4],
        [4, 1, 5],
    ], dtype=np.int64)
    selected = np.asarray([0, 1], dtype=np.int64)

    a, _, unsupported_a, deg_a = deterministic_family_restart(m, retain, selected, 12345)
    b, _, unsupported_b, deg_b = deterministic_family_restart(m, retain, selected, 12345)

    assert unsupported_a.tolist() == [0]
    assert unsupported_b.tolist() == [0]
    assert deg_a == deg_b == {0: 0, 1: 1}

    # Deterministic restart.
    assert torch.equal(a.entity.weight, b.entity.weight)

    # Unsupported row changes; every other entity row is preserved exactly.
    assert not torch.equal(a.entity.weight[0], before[0])
    assert torch.equal(a.entity.weight[1:], before[1:])

    # Source model must remain untouched.
    assert torch.equal(m.entity.weight, before)


def main():
    check(DistMult)
    check(ComplEx)
    print('FAMILY_MISSING_FULL_TESTS_OK')


if __name__ == '__main__':
    main()
