#!/usr/bin/env python3
from __future__ import annotations

import numpy as np
import torch

from schemacert.family_models import make_model
from scripts.experiments.evaluate_family_restart import deterministic_family_restart


def check(model_name: str):
    torch.manual_seed(123)
    model = make_model(model_name, 6, 2, 4)
    before_e = model.entity.weight.detach().clone()
    before_r = model.relation.weight.detach().clone()

    # Entity 0 has zero retained positive support; entity 1 still occurs.
    retain = np.asarray([
        [1, 0, 2],
        [2, 1, 3],
        [4, 0, 5],
    ], dtype=np.int64)
    selected = np.asarray([0, 1], dtype=np.int64)

    a, _, unsupported_a, deg_a = deterministic_family_restart(
        model, retain, selected, seed=777
    )
    b, _, unsupported_b, deg_b = deterministic_family_restart(
        model, retain, selected, seed=777
    )

    assert unsupported_a.tolist() == [0]
    assert unsupported_b.tolist() == [0]
    assert deg_a == {0: 0, 1: 1}
    assert deg_b == deg_a

    # Deterministic fresh restart for unsupported row only.
    assert torch.equal(a.entity.weight[0], b.entity.weight[0])
    assert not torch.equal(a.entity.weight[0], before_e[0])
    assert torch.equal(a.entity.weight[1:], before_e[1:])
    assert torch.equal(a.relation.weight, before_r)


if __name__ == '__main__':
    check('distmult')
    check('complex')
    print('FAMILY_RESTART_TESTS_OK')
