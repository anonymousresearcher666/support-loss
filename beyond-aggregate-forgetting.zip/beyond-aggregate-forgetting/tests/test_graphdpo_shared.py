import numpy as np
import torch

from schemacert.graphdpo_shared import GraphDPOSharedTransE


def test_shared_transe_candidate_scores_match_true_forward_score():
    torch.manual_seed(7)
    ent = torch.randn(6, 4, dtype=torch.float64)
    rel = torch.randn(4, 4, dtype=torch.float64)  # two forward/inverse pairs
    model = GraphDPOSharedTransE(ent, rel)

    triples = torch.tensor([[0, 0, 1], [2, 2, 3]], dtype=torch.long)
    true = model.score(triples)
    cand = torch.arange(6, dtype=torch.long)

    tail_scores = model.score_candidates('tail', triples[:, 0], triples[:, 1], cand)
    head_scores = model.score_candidates('head', triples[:, 1], triples[:, 2], cand)

    assert torch.allclose(tail_scores[0, triples[0, 2]], true[0])
    assert torch.allclose(tail_scores[1, triples[1, 2]], true[1])
    assert torch.allclose(head_scores[0, triples[0, 0]], true[0])
    assert torch.allclose(head_scores[1, triples[1, 0]], true[1])


def test_shared_transe_preserves_checkpoint_weights_exactly():
    ent = torch.arange(24, dtype=torch.float64).reshape(6, 4) / 10.0
    rel = torch.arange(16, dtype=torch.float64).reshape(4, 4) / 7.0
    model = GraphDPOSharedTransE(ent, rel)
    assert torch.equal(model.entity.weight.detach(), ent)
    assert torch.equal(model.relation.weight.detach(), rel)


if __name__ == '__main__':
    test_shared_transe_candidate_scores_match_true_forward_score()
    test_shared_transe_preserves_checkpoint_weights_exactly()
    print('GRAPHDPO_SHARED_TESTS_OK')
