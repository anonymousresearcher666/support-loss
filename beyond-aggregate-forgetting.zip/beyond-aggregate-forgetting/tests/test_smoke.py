import numpy as np
from schemacert.models import make_model
from schemacert.train import train_model
from schemacert.unlearn import select_forget,local_retrain

def test_smoke():
    rng=np.random.default_rng(3);T=np.c_[rng.integers(0,30,200),rng.integers(0,5,200),rng.integers(0,30,200)].astype(np.int64);m=make_model('transe',30,5,8);train_model(m,T,30,1,64,.01,0,3);fi,_,_=select_forget(T,.1,3);res,retain,_=local_retrain(m,T,fi,30,1,1,64,.005,0,3);assert len(retain)<len(T);assert 0<res.parameter_fraction<=1
